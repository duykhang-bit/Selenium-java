"""Integration test: verify all MCP tools are registered and callable."""

import asyncio

from app.mcp_server import mcp


def test_all_tools_registered():
    """All 6 MCP tools are registered on the server."""
    # list_tools() is a coroutine on FastMCP
    tools = asyncio.run(mcp.list_tools())
    tool_names = {t.name for t in tools}

    expected = {
        "search_context",
        "list_sources",
        "get_confluence_page",
        "get_repo_structure",
        "get_task_brief",
        "sync_sources",
    }
    assert expected.issubset(tool_names), f"Missing tools: {expected - tool_names}"


def test_tool_descriptions_present():
    """All tools have non-empty descriptions."""
    tools = asyncio.run(mcp.list_tools())
    for tool in tools:
        assert tool.description, f"Tool {tool.name} has no description"


def test_server_name():
    """Server has correct name."""
    assert mcp.name == "AI Context Engine"
