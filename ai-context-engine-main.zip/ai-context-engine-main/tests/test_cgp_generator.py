"""Tests cho CGP generator."""

from __future__ import annotations

from unittest.mock import patch

from app.tasks.code_gen.models import CodingTask
from app.tasks.code_gen.generator import generate, _generate_skeleton


def _task(task_type: str, description: str = "do something") -> CodingTask:
    return CodingTask(
        task_id="t1", title="Test task", type=task_type,
        target_file="app/foo.py", description=description,
    )


class TestSkeletonMode:
    def test_create_file_has_future_import(self):
        result = _generate_skeleton(_task("create_file"))
        assert "from __future__ import annotations" in result.content
        assert result.mode == "skeleton"

    def test_add_function_has_not_implemented(self):
        result = _generate_skeleton(_task("add_function", "add process_order function"))
        assert "NotImplementedError" in result.content
        assert "def " in result.content

    def test_add_function_has_docstring(self):
        result = _generate_skeleton(_task("add_function", "add process_order function"))
        assert '"""' in result.content

    def test_add_class_has_init(self):
        result = _generate_skeleton(_task("add_class", "create OrderModel class"))
        assert "class " in result.content
        assert "__init__" in result.content

    def test_add_endpoint_has_http_exception(self):
        result = _generate_skeleton(_task("add_endpoint", "POST /api/orders create order"))
        assert "HTTPException" in result.content
        assert "501" in result.content

    def test_mode_is_skeleton_without_llm_key(self):
        with patch("app.tasks.code_gen.generator.settings") as mock_settings:
            mock_settings.llm_api_key = ""
            result = generate(_task("add_function"))
            assert result.mode == "skeleton"


class TestLLMMode:
    def test_uses_llm_when_key_configured(self):
        with patch("app.tasks.code_gen.generator.settings") as mock_settings:
            mock_settings.llm_api_key = "sk-test123"
            mock_settings.llm_model = "gpt-4o-mini"
            mock_settings.llm_timeout = 30
            with patch("app.tasks.code_gen.generator._call_llm", return_value="```python\ndef foo(): pass\n```"):
                with patch("app.tasks.code_gen.generator._llm_available", return_value=True):
                    result = generate(_task("add_function"))
                    assert result.mode == "llm"
                    assert "def foo" in result.content

    def test_graceful_degrade_on_llm_failure(self):
        with patch("app.tasks.code_gen.generator._llm_available", return_value=True):
            with patch("app.tasks.code_gen.generator._generate_llm", side_effect=Exception("LLM timeout")):
                result = generate(_task("add_function"))
                assert result.mode == "skeleton"

    def test_task_id_preserved(self):
        task = _task("create_file")
        result = _generate_skeleton(task)
        assert result.task_id == "t1"
