"""Tests cho CI promoter, UAT promoter, PROD gate, và incident correlator."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from app.catalog.database import init_database
from app.tasks.k8s.models import PromotionResult, GateResult, CorrelationResult


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def setup_db(tmp_path, monkeypatch):
    import app.core.config as cfg_mod
    from unittest.mock import PropertyMock
    with patch.object(type(cfg_mod.settings), "catalog_db_path", new_callable=PropertyMock) as mock_db:
        mock_db.return_value = tmp_path / "catalog.db"
        with patch.object(type(cfg_mod.settings), "data_dir", new_callable=PropertyMock) as mock_data:
            mock_data.return_value = tmp_path
            with patch.object(type(cfg_mod.settings), "logs_dir", new_callable=PropertyMock) as mock_logs:
                mock_logs.return_value = tmp_path
                init_database()
                yield


def _save_deployment(service, env, build_number, status, tmp_path=None):
    from app.catalog.database import save_deployment_record
    import uuid
    from app.core.utils import utc_now_iso
    save_deployment_record(
        record_id=uuid.uuid4().hex[:8],
        service=service, environment=env, build_number=build_number,
        job_name=f"deploy-{env}", status=status,
        deployed_at=utc_now_iso(), deployed_by="test",
    )


# ---------------------------------------------------------------------------
# CI Promoter tests
# ---------------------------------------------------------------------------

class TestCIPromoter:
    def test_approved_when_jenkins_unavailable(self):
        """Graceful degrade — nếu Jenkins không cấu hình thì vẫn approve."""
        from app.tasks.k8s.ci_promoter import promote_to_ci
        with patch("app.tasks.k8s.ci_promoter._get_jenkins_connector",
                   side_effect=ValueError("Jenkins not configured")):
            result = promote_to_ci("order-svc", 42, "deploy-ci")
            assert result.approved is True
            assert result.environment == "ci"

    def test_blocked_when_build_failure(self):
        from app.tasks.k8s.ci_promoter import promote_to_ci
        mock_connector = MagicMock()
        mock_connector.get_build_status.return_value = {"status": "FAILURE"}
        with patch("app.tasks.k8s.ci_promoter._get_jenkins_connector", return_value=mock_connector):
            result = promote_to_ci("order-svc", 42, "deploy-ci")
            assert result.approved is False
            assert len(result.blocking_reasons) > 0

    def test_deployment_record_saved(self):
        from app.tasks.k8s.ci_promoter import promote_to_ci
        from app.catalog.database import list_deployments
        with patch("app.tasks.k8s.ci_promoter._get_jenkins_connector",
                   side_effect=ValueError("not configured")):
            promote_to_ci("order-svc", 42, "deploy-ci")
        records = list_deployments(service="order-svc", environment="ci")
        assert len(records) >= 1

    def test_audit_record_written(self, tmp_path):
        from app.tasks.k8s.ci_promoter import promote_to_ci
        with patch("app.tasks.k8s.ci_promoter._get_jenkins_connector",
                   side_effect=ValueError("not configured")):
            with patch("app.tasks.k8s._audit.settings") as mock_settings:
                mock_settings.logs_dir = tmp_path
                promote_to_ci("order-svc", 42, "deploy-ci", trace_id="test-ci")
        audit_file = tmp_path / "k8s_audit.jsonl"
        assert audit_file.exists()


# ---------------------------------------------------------------------------
# UAT Promoter tests
# ---------------------------------------------------------------------------

class TestUATPromoter:
    def test_blocked_when_no_ci_success(self):
        from app.tasks.k8s.uat_promoter import promote_to_uat
        result = promote_to_uat("order-svc", 42, "deploy-uat")
        assert result.approved is False
        assert any("CI deployment" in r for r in result.blocking_reasons)

    def test_approved_when_ci_success(self):
        from app.tasks.k8s.uat_promoter import promote_to_uat
        _save_deployment("order-svc", "ci", 42, "success")
        with patch("app.tasks.k8s.uat_promoter._get_jenkins_connector",
                   side_effect=ValueError("not configured")):
            result = promote_to_uat("order-svc", 42, "deploy-uat")
            assert result.approved is True
            assert result.environment == "uat"

    def test_blocked_when_uat_duplicate(self):
        from app.tasks.k8s.uat_promoter import promote_to_uat
        _save_deployment("order-svc", "ci", 42, "success")
        _save_deployment("order-svc", "uat", 42, "success")
        result = promote_to_uat("order-svc", 42, "deploy-uat")
        assert result.approved is False
        assert any("đã tồn tại" in r for r in result.blocking_reasons)

    def test_audit_record_written(self, tmp_path):
        from app.tasks.k8s.uat_promoter import promote_to_uat
        with patch("app.tasks.k8s._audit.settings") as mock_settings:
            mock_settings.logs_dir = tmp_path
            promote_to_uat("order-svc", 42, "deploy-uat", trace_id="test-uat")
        audit_file = tmp_path / "k8s_audit.jsonl"
        assert audit_file.exists()


# ---------------------------------------------------------------------------
# PROD Gate tests
# ---------------------------------------------------------------------------

class TestProdGate:
    def test_blocked_when_no_uat(self):
        from app.tasks.k8s.prod_gate import check_prod_gate
        result = check_prod_gate("order-svc", 42)
        assert result.approved is False
        assert any(i.name == "UAT deployment exists" and i.status == "FAIL"
                   for i in result.checklist)

    def test_approved_when_uat_success_and_soak_passed(self):
        from app.tasks.k8s.prod_gate import check_prod_gate
        from app.catalog.database import save_deployment_record
        import uuid
        # Deploy UAT 60 phút trước
        from datetime import datetime, timezone, timedelta
        old_time = (datetime.now(timezone.utc) - timedelta(minutes=60)).isoformat()
        save_deployment_record(
            record_id=uuid.uuid4().hex[:8],
            service="order-svc", environment="uat", build_number=42,
            job_name="deploy-uat", status="success",
            deployed_at=old_time, deployed_by="test",
        )
        with patch("app.tasks.k8s.prod_gate.settings") as mock_settings:
            mock_settings.k8s_prod_soak_minutes = 30
            mock_settings.logs_dir = Path("/tmp")
            result = check_prod_gate("order-svc", 42, soak_minutes=30)
        uat_item = next(i for i in result.checklist if i.name == "UAT deployment exists")
        assert uat_item.status == "PASS"

    def test_suggested_command_when_approved(self):
        from app.tasks.k8s.prod_gate import check_prod_gate
        from app.catalog.database import save_deployment_record
        import uuid
        from datetime import datetime, timezone, timedelta
        old_time = (datetime.now(timezone.utc) - timedelta(minutes=60)).isoformat()
        save_deployment_record(
            record_id=uuid.uuid4().hex[:8],
            service="svc", environment="uat", build_number=1,
            job_name="deploy-uat", status="success",
            deployed_at=old_time, deployed_by="test",
        )
        with patch("app.tasks.k8s.prod_gate.settings") as mock_settings:
            mock_settings.k8s_prod_soak_minutes = 30
            mock_settings.logs_dir = Path("/tmp")
            result = check_prod_gate("svc", 1, jenkins_deploy_job="deploy-prod", soak_minutes=30)
        if result.approved:
            assert "deploy-prod" in result.suggested_command


# ---------------------------------------------------------------------------
# Incident Correlator tests
# ---------------------------------------------------------------------------

class TestIncidentCorrelator:
    def test_likely_cause_true_within_30_min(self):
        from app.tasks.k8s.incident_correlator import correlate_incident
        from app.catalog.database import save_deployment_record
        import uuid
        from datetime import datetime, timezone, timedelta
        # Deploy 15 phút trước incident
        incident_time = datetime.now(timezone.utc)
        deploy_time = incident_time - timedelta(minutes=15)
        save_deployment_record(
            record_id=uuid.uuid4().hex[:8],
            service="order-svc", environment="prod", build_number=42,
            job_name="deploy-prod", status="success",
            deployed_at=deploy_time.isoformat(), deployed_by="test",
        )
        with patch("app.tasks.k8s.incident_correlator.list_deployments") as mock_list:
            mock_list.return_value = [{
                "record_id": "abc", "service": "order-svc", "environment": "prod",
                "build_number": 42, "job_name": "deploy-prod", "status": "success",
                "deployed_at": deploy_time.isoformat(), "deployed_by": "test", "build_url": "",
            }]
            result = correlate_incident("order-svc", incident_time.isoformat())
        assert result.likely_cause is True
        assert result.suggested_action == "rollback"

    def test_no_deployment_in_24h(self):
        from app.tasks.k8s.incident_correlator import correlate_incident
        with patch("app.tasks.k8s.incident_correlator.list_deployments", return_value=[]):
            result = correlate_incident("order-svc", "2024-01-01T10:00:00Z")
        assert result.likely_cause is False
        assert result.suggested_action == "investigate_infra"
        assert result.deployment is None

    def test_graceful_degrade_chromadb(self):
        from app.tasks.k8s.incident_correlator import correlate_incident
        with patch("app.tasks.k8s.incident_correlator.list_deployments", return_value=[]):
            with patch("app.retrieval.search.search", side_effect=Exception("no db")):
                result = correlate_incident("order-svc", "2024-01-01T10:00:00Z")
        assert result.context_snippets == []
