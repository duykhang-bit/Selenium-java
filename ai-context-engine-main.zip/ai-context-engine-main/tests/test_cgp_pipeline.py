"""Tests cho CGP pipeline."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from app.tasks.code_gen.models import BranchAlreadyExistsError, MRResult


_SIMPLE_DESIGN = """
## API Endpoints

POST /api/orders — tạo order mới

## Data Models

class OrderModel:
    id: str
"""


def _mock_mr() -> MRResult:
    return MRResult(mr_id=7, mr_url="https://gitlab.example.com/mr/7",
                    branch_name="feature/x", title="feat: feature/x", source_id="gitlab:42")


class TestRunPipeline:
    def _run(self, design_doc=_SIMPLE_DESIGN, source_id="gitlab:42", branch="feature/x"):
        from app.tasks.code_gen.pipeline import run_pipeline
        with patch("app.tasks.code_gen.pipeline.branch_manager.create_branch", return_value={}):
            with patch("app.tasks.code_gen.pipeline.branch_manager.commit_files", return_value={}):
                with patch("app.tasks.code_gen.pipeline.branch_manager.create_mr", return_value=_mock_mr()):
                    return run_pipeline(design_doc, source_id, branch)

    def test_returns_pipeline_result(self):
        result = self._run()
        assert result is not None
        assert isinstance(result.tasks, list)
        assert isinstance(result.generated_files, list)

    def test_mr_result_set(self):
        result = self._run()
        assert result.mr_result is not None
        assert result.mr_result.mr_id == 7

    def test_duration_ms_positive(self):
        result = self._run()
        assert result.duration_ms >= 0

    def test_trace_id_set(self):
        result = self._run()
        assert result.trace_id != ""

    def test_branch_conflict_raises(self):
        from app.tasks.code_gen.pipeline import run_pipeline
        with patch("app.tasks.code_gen.pipeline.branch_manager.create_branch",
                   side_effect=BranchAlreadyExistsError("branch exists")):
            with pytest.raises(BranchAlreadyExistsError):
                run_pipeline(_SIMPLE_DESIGN, "gitlab:42", "feature/x")

    def test_audit_record_written(self, tmp_path):
        from app.tasks.code_gen.pipeline import run_pipeline
        with patch("app.tasks.code_gen.pipeline.settings") as mock_settings:
            mock_settings.logs_dir = tmp_path
            with patch("app.tasks.code_gen.pipeline.branch_manager.create_branch", return_value={}):
                with patch("app.tasks.code_gen.pipeline.branch_manager.commit_files", return_value={}):
                    with patch("app.tasks.code_gen.pipeline.branch_manager.create_mr", return_value=_mock_mr()):
                        run_pipeline(_SIMPLE_DESIGN, "gitlab:42", "feature/x", trace_id="test-trace")

        audit_file = tmp_path / "cgp_audit.jsonl"
        assert audit_file.exists()
        record = json.loads(audit_file.read_text().strip())
        assert record["event_type"] == "cgp_run_pipeline"
        assert record["details"]["trace_id"] == "test-trace"
