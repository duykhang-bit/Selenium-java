"""Tests for enhanced task brief with Confluence context."""
from unittest.mock import patch, MagicMock
from app.tasks.brief import build_task_brief

@patch("app.tasks.brief.search")
@patch("app.tasks.brief.rank_sources")
def test_brief_includes_confluence_results(mock_rank, mock_search):
    """build_task_brief queries both git and confluence sources."""
    mock_rank.return_value = [
        {
            "source": {
                "source_id": "gitlab:1",
                "title": "oms-service",
                "status": "indexed",
                "local_path": "/data/repos/oms",
                "metadata_json": '{"repo_id": "1"}',
            },
            "score": 10.0,
            "reasons": ["match"],
        }
    ]
    git_result = MagicMock()
    git_result.to_dict.return_value = {"content": "OrderController", "score": 0.9, "metadata": {"source_type": "git_repo"}}
    git_result.metadata = {"relative_source": "src/order.py", "source": "src/order.py"}
    git_result.content = "OrderController handles POST /orders"
    git_result.score = 0.9

    confluence_result = MagicMock()
    confluence_result.to_dict.return_value = {"content": "Business rule: orders need approval", "score": 0.8, "metadata": {"source_type": "confluence_page", "title": "Order Rules"}}

    mock_search.side_effect = [[git_result], [confluence_result]]

    result = build_task_brief("fix order approval flow", "knowledge", top_k=5)
    assert mock_search.call_count == 2
    assert "confluence_results" in result
    assert len(result["confluence_results"]) == 1
