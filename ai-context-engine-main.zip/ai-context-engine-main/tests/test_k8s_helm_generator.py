"""Tests cho Helm values generator."""

from __future__ import annotations

import yaml

from app.tasks.k8s.helm_generator import generate_helm_values


def _gen(**kwargs):
    defaults = dict(
        service_name="order-svc",
        image_repository="registry.example.com/order-svc",
        image_tag="1.0.0",
        port=8080,
    )
    defaults.update(kwargs)
    return generate_helm_values(**defaults)


class TestBasicOutput:
    def test_returns_helm_values(self):
        result = _gen()
        assert result.filename == "values.yaml"
        assert result.service_name == "order-svc"
        assert result.environment == "uat"

    def test_yaml_is_valid(self):
        result = _gen()
        parsed = yaml.safe_load(result.content)
        assert isinstance(parsed, dict)

    def test_image_fields(self):
        result = _gen(image_tag="2.0.0")
        parsed = yaml.safe_load(result.content)
        assert parsed["image"]["repository"] == "registry.example.com/order-svc"
        assert parsed["image"]["tag"] == "2.0.0"

    def test_port_in_service(self):
        result = _gen(port=9090)
        parsed = yaml.safe_load(result.content)
        assert parsed["service"]["port"] == 9090

    def test_resources_set(self):
        result = _gen(cpu_request="200m", memory_limit="1Gi")
        parsed = yaml.safe_load(result.content)
        assert parsed["resources"]["requests"]["cpu"] == "200m"
        assert parsed["resources"]["limits"]["memory"] == "1Gi"


class TestIngress:
    def test_ingress_disabled_by_default(self):
        result = _gen()
        parsed = yaml.safe_load(result.content)
        assert parsed["ingress"]["enabled"] is False

    def test_ingress_enabled_with_host(self):
        result = _gen(ingress_host="order.example.com")
        parsed = yaml.safe_load(result.content)
        assert parsed["ingress"]["enabled"] is True
        assert parsed["ingress"]["host"] == "order.example.com"
        assert parsed["ingress"]["tls"] is True


class TestEnvVars:
    def test_env_vars_injected(self):
        result = _gen(env_vars={"DB_HOST": "localhost", "PORT": "5432"})
        parsed = yaml.safe_load(result.content)
        env_names = [e["name"] for e in parsed["env"]]
        assert "DB_HOST" in env_names
        assert "PORT" in env_names

    def test_no_env_vars_empty_list(self):
        result = _gen()
        parsed = yaml.safe_load(result.content)
        assert parsed["env"] == []


class TestHPA:
    def test_hpa_disabled_by_default(self):
        result = _gen()
        parsed = yaml.safe_load(result.content)
        assert parsed["autoscaling"]["enabled"] is False

    def test_hpa_enabled(self):
        result = _gen(hpa_enabled=True, hpa_min_replicas=2, hpa_max_replicas=10)
        parsed = yaml.safe_load(result.content)
        assert parsed["autoscaling"]["enabled"] is True
        assert parsed["autoscaling"]["minReplicas"] == 2
        assert parsed["autoscaling"]["maxReplicas"] == 10
