"""Tests cho build log analyzer."""

from __future__ import annotations

from app.tasks.jenkins.log_analyzer import analyze_log


class TestCompilationError:
    def test_detect_python_syntax_error(self):
        log = "Running build...\nSyntaxError: invalid syntax\nBuild FAILED"
        result = analyze_log(log)
        assert result.error_type == "compilation"

    def test_detect_java_compilation_error(self):
        log = "COMPILATION ERROR\ncannot find symbol\nBuild FAILED"
        result = analyze_log(log)
        assert result.error_type == "compilation"


class TestTestFailure:
    def test_detect_pytest_failure(self):
        log = "collected 10 items\nFAILED tests/test_foo.py::test_bar\n1 failed"
        result = analyze_log(log)
        assert result.error_type == "test_failure"

    def test_detect_junit_failure(self):
        log = "Tests run: 5, Failures: 2, Errors: 0"
        result = analyze_log(log)
        assert result.error_type == "test_failure"


class TestDependencyError:
    def test_detect_module_not_found(self):
        log = "ModuleNotFoundError: No module named 'requests'\nBuild FAILED"
        result = analyze_log(log)
        assert result.error_type == "dependency"

    def test_detect_could_not_resolve(self):
        log = "Could not resolve dependency: com.example:lib:1.0.0"
        result = analyze_log(log)
        assert result.error_type == "dependency"


class TestTimeout:
    def test_detect_timeout(self):
        log = "Build timed out after 30 minutes"
        result = analyze_log(log)
        assert result.error_type == "timeout"


class TestOOM:
    def test_detect_java_oom(self):
        log = "java.lang.OutOfMemoryError: Java heap space"
        result = analyze_log(log)
        assert result.error_type == "oom"


class TestUnknown:
    def test_empty_log(self):
        result = analyze_log("")
        assert result.error_type == "unknown"

    def test_no_known_pattern(self):
        result = analyze_log("Build started\nDoing stuff\nBuild completed")
        assert result.error_type == "unknown"


class TestSuggestedFix:
    def test_has_suggested_fix(self):
        log = "SyntaxError: invalid syntax"
        result = analyze_log(log)
        assert result.suggested_fix != ""
