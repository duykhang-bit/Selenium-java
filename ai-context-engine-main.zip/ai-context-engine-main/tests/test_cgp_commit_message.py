"""Tests cho commit message generator."""

from __future__ import annotations

from app.tasks.code_gen.commit_message import generate_message


_FEAT_DIFF = """\
--- /dev/null
+++ b/app/tasks/foo.py
@@ -0,0 +1,5 @@
+from __future__ import annotations
+
+def process_order(order_id: str) -> dict:
+    pass
"""

_TEST_DIFF = """\
--- /dev/null
+++ b/tests/test_foo.py
@@ -0,0 +1,3 @@
+def test_process_order():
+    pass
"""

_CHORE_DIFF = """\
--- a/requirements.txt
+++ b/requirements.txt
@@ -1,1 +1,2 @@
+requests>=2.31.0
"""

_ENDPOINT_DIFF = """\
--- a/app/api/routes.py
+++ b/app/api/routes.py
@@ -1,1 +1,5 @@
+@router.post("/api/orders")
+async def create_order(request: dict) -> dict:
+    pass
"""


class TestDetectType:
    def test_feat_from_new_function(self):
        msg = generate_message(_FEAT_DIFF)
        assert msg.startswith("feat")

    def test_test_from_test_file(self):
        msg = generate_message(_TEST_DIFF)
        assert msg.startswith("test")

    def test_chore_from_requirements(self):
        msg = generate_message(_CHORE_DIFF)
        assert msg.startswith("chore")


class TestDetectScope:
    def test_scope_from_tasks_path(self):
        msg = generate_message(_FEAT_DIFF)
        assert "(tasks)" in msg

    def test_scope_from_api_path(self):
        msg = generate_message(_ENDPOINT_DIFF)
        assert "(api)" in msg

    def test_scope_from_test_path(self):
        msg = generate_message(_TEST_DIFF)
        assert "(tests)" in msg


class TestDescription:
    def test_description_max_72_chars(self):
        msg = generate_message(_FEAT_DIFF)
        # format: type(scope): description — description part ≤ 72
        desc = msg.split(": ", 1)[1] if ": " in msg else msg
        assert len(desc) <= 72

    def test_task_description_takes_priority(self):
        msg = generate_message(_FEAT_DIFF, task_description="add order processing logic")
        assert "order processing logic" in msg

    def test_task_description_truncated_to_72(self):
        long_desc = "a" * 100
        msg = generate_message(_FEAT_DIFF, task_description=long_desc)
        desc = msg.split(": ", 1)[1] if ": " in msg else msg
        assert len(desc) <= 72


class TestEdgeCases:
    def test_empty_diff_no_task_desc(self):
        msg = generate_message("")
        assert msg  # không raise, trả về fallback

    def test_format_with_scope(self):
        msg = generate_message(_FEAT_DIFF)
        assert "(" in msg and ")" in msg
        assert ": " in msg
