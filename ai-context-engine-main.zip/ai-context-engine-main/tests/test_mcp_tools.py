"""Tests for MCP tools: search_context and list_sources."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

# Import the tool functions directly from mcp_server
from app.mcp_server import search_context, list_sources, get_confluence_page, get_repo_structure, get_task_brief, sync_sources
from app.retrieval.search import SearchResult


# ---------------------------------------------------------------------------
# search_context tests
# ---------------------------------------------------------------------------

class TestSearchContext:
    def _make_result(self, content: str = "some content", score: float = 0.9, metadata: dict | None = None) -> SearchResult:
        return SearchResult(content=content, score=score, metadata=metadata or {"source_type": "confluence_page"})

    def test_happy_path_returns_results(self):
        """search_context returns query + results list on success."""
        fake_result = self._make_result()
        with patch("app.mcp_server.search_mod.search", return_value=[fake_result]) as mock_search:
            response = search_context("order service API")

        assert response["query"] == "order service API"
        assert len(response["results"]) == 1
        assert response["results"][0]["content"] == "some content"
        assert response["results"][0]["score"] == round(0.9, 4)
        assert "metadata" in response["results"][0]
        assert "error" not in response

    def test_empty_results_returns_message(self):
        """search_context returns a helpful message when no results are found."""
        with patch("app.mcp_server.search_mod.search", return_value=[]):
            response = search_context("unknown jargon xyz")

        assert response["query"] == "unknown jargon xyz"
        assert response["results"] == []
        assert "message" in response
        assert "No matching context found" in response["message"]

    def test_source_type_filter_passed_to_search(self):
        """search_context passes source_type filter through to the underlying search call."""
        fake_result = self._make_result(metadata={"source_type": "git_repo"})
        with patch("app.mcp_server.search_mod.search", return_value=[fake_result]) as mock_search:
            response = search_context("api gateway", source_type="git_repo", top_k=3)

        mock_search.assert_called_once()
        call_kwargs = mock_search.call_args
        # Verify source_type and top_k were forwarded
        assert call_kwargs.kwargs.get("source_type") == "git_repo" or call_kwargs.args[3:] or True
        # More robust: check kwargs or positional
        args, kwargs = mock_search.call_args
        assert kwargs.get("source_type") == "git_repo"
        assert kwargs.get("top_k") == 3
        assert "error" not in response

    def test_exception_returns_error_dict(self):
        """search_context catches exceptions and returns an error dict."""
        with patch("app.mcp_server.search_mod.search", side_effect=RuntimeError("chroma unavailable")):
            response = search_context("anything")

        assert response["error"] == "search_failed"
        assert "chroma unavailable" in response["message"]


# ---------------------------------------------------------------------------
# list_sources tests
# ---------------------------------------------------------------------------

class TestListSources:
    def _make_source(self, source_id: str = "src-1", source_type: str = "confluence_page") -> dict:
        return {
            "source_id": source_id,
            "source_type": source_type,
            "title": f"Title for {source_id}",
            "url": f"https://example.com/{source_id}",
            "status": "indexed",
        }

    def test_all_sources_no_filter(self):
        """list_sources returns all sources when no filter is given."""
        fake_sources = [
            self._make_source("src-1", "confluence_page"),
            self._make_source("src-2", "git_repo"),
        ]
        with patch("app.mcp_server.db.list_sources", return_value=fake_sources) as mock_list:
            response = list_sources()

        mock_list.assert_called_once_with(source_type=None)
        assert response["total"] == 2
        assert len(response["sources"]) == 2
        ids = {s["source_id"] for s in response["sources"]}
        assert ids == {"src-1", "src-2"}

    def test_filtered_by_source_type(self):
        """list_sources passes source_type filter and returns only matching sources."""
        fake_sources = [self._make_source("src-3", "git_repo")]
        with patch("app.mcp_server.db.list_sources", return_value=fake_sources) as mock_list:
            response = list_sources(source_type="git_repo")

        mock_list.assert_called_once_with(source_type="git_repo")
        assert response["total"] == 1
        assert response["sources"][0]["source_type"] == "git_repo"
        assert response["sources"][0]["source_id"] == "src-3"

    def test_exception_returns_error_dict(self):
        """list_sources catches exceptions and returns an error dict."""
        with patch("app.mcp_server.db.list_sources", side_effect=Exception("db locked")):
            response = list_sources()

        assert response["error"] == "list_failed"
        assert "db locked" in response["message"]


# ---------------------------------------------------------------------------
# get_confluence_page tests
# ---------------------------------------------------------------------------

class TestGetConfluencePage:
    @patch("app.mcp_server.db.get_source")
    def test_get_confluence_page_found(self, mock_get, tmp_path):
        html_file = tmp_path / "page.html"
        html_file.write_text("<html><body><h1>Order Flow</h1><p>Orders are processed via API.</p></body></html>")
        mock_get.return_value = {
            "source_id": "confluence:123",
            "title": "Order Flow",
            "url": "https://confluence.example.com/pages/viewpage.action?pageId=123",
            "local_path": str(html_file),
        }
        result = get_confluence_page("123")
        assert result["title"] == "Order Flow"
        assert "Orders are processed" in result["content"]
        assert result["page_id"] == "123"
        assert "error" not in result

    @patch("app.mcp_server.db.get_source")
    def test_get_confluence_page_not_found(self, mock_get):
        mock_get.return_value = None
        result = get_confluence_page("999")
        assert result["error"] == "not_found"
        assert "999" in result["message"]

    @patch("app.mcp_server.db.get_source")
    def test_get_confluence_page_not_synced(self, mock_get, tmp_path):
        nonexistent = tmp_path / "missing.html"
        mock_get.return_value = {
            "source_id": "confluence:456",
            "title": "Some Page",
            "url": "https://confluence.example.com/pages/456",
            "local_path": str(nonexistent),
        }
        result = get_confluence_page("456")
        assert result["error"] == "not_synced"
        assert "456" in result["message"]

    @patch("app.mcp_server.db.get_source")
    def test_get_confluence_page_exception(self, mock_get):
        mock_get.side_effect = Exception("connection refused")
        result = get_confluence_page("789")
        assert result["error"] == "fetch_failed"
        assert "connection refused" in result["message"]


# ---------------------------------------------------------------------------
# get_repo_structure tests
# ---------------------------------------------------------------------------

class TestGetRepoStructure:
    _FAKE_LAYOUT = {
        "source_roots": ["src"],
        "docs_roots": ["docs"],
        "test_roots": ["tests"],
        "manifests": ["pyproject.toml"],
        "install": "pip install -e .",
        "build": None,
        "test": "pytest",
    }

    @patch("app.mcp_server.detect_repo_layout")
    @patch("app.mcp_server.db.get_source")
    def test_get_repo_structure_found(self, mock_get, mock_layout, tmp_path):
        """Returns title and layout when source exists, is a git_repo, and path is synced."""
        mock_get.return_value = {
            "source_id": "gitlab:42",
            "source_type": "git_repo",
            "title": "My Service",
            "url": "https://gitlab.example.com/group/my-service",
            "local_path": str(tmp_path),
            "default_branch": "main",
        }
        mock_layout.return_value = self._FAKE_LAYOUT

        result = get_repo_structure("gitlab:42")

        assert result["source_id"] == "gitlab:42"
        assert result["title"] == "My Service"
        assert result["layout"] == self._FAKE_LAYOUT
        assert "error" not in result
        mock_layout.assert_called_once()

    @patch("app.mcp_server.db.get_source")
    def test_get_repo_structure_not_found(self, mock_get):
        """Returns error 'not_found' when source_id is not in catalog."""
        mock_get.return_value = None

        result = get_repo_structure("gitlab:999")

        assert result["error"] == "not_found"
        assert "gitlab:999" in result["message"]

    @patch("app.mcp_server.db.get_source")
    def test_get_repo_structure_wrong_type(self, mock_get):
        """Returns error 'wrong_type' when source is not a git_repo."""
        mock_get.return_value = {
            "source_id": "confluence:10",
            "source_type": "confluence_page",
            "title": "Some Page",
            "url": "https://confluence.example.com/pages/10",
            "local_path": "/some/path",
        }

        result = get_repo_structure("confluence:10")

        assert result["error"] == "wrong_type"
        assert "confluence:10" in result["message"]

    @patch("app.mcp_server.db.get_source")
    def test_get_repo_structure_not_synced(self, mock_get, tmp_path):
        """Returns error 'not_synced' when local_path does not exist on disk."""
        nonexistent = tmp_path / "repo_not_here"
        mock_get.return_value = {
            "source_id": "gitlab:7",
            "source_type": "git_repo",
            "title": "Ghost Repo",
            "url": "https://gitlab.example.com/group/ghost",
            "local_path": str(nonexistent),
        }

        result = get_repo_structure("gitlab:7")

        assert result["error"] == "not_synced"
        assert "gitlab:7" in result["message"]

    @patch("app.mcp_server.db.get_source")
    def test_get_repo_structure_exception(self, mock_get):
        """Returns error 'layout_failed' when db.get_source raises an exception."""
        mock_get.side_effect = Exception("db connection lost")

        result = get_repo_structure("gitlab:1")

        assert result["error"] == "layout_failed"
        assert "db connection lost" in result["message"]


# ---------------------------------------------------------------------------
# get_task_brief tests
# ---------------------------------------------------------------------------

@patch("app.mcp_server.build_task_brief")
def test_get_task_brief_returns_brief(mock_brief):
    mock_brief.return_value = {"task": "fix order API", "brief": "# Brief\n...", "confluence_results": []}
    result = get_task_brief("fix order API")
    assert result["task"] == "fix order API"
    assert "brief" in result

@patch("app.mcp_server.build_task_brief")
def test_get_task_brief_exception(mock_brief):
    mock_brief.side_effect = ValueError("No sources")
    result = get_task_brief("unknown task")
    assert result["error"] == "brief_failed"


# ---------------------------------------------------------------------------
# sync_sources tests
# ---------------------------------------------------------------------------

class TestSyncSources:
    def test_sync_sources_single(self):
        """sync_sources with a source_id calls sync_and_ingest_source and returns synced=1."""
        fake_result = {"source_id": "gitlab:42", "status": "indexed", "chunks": 10}
        with patch("app.mcp_server.service.sync_and_ingest_source", return_value=fake_result) as mock_sync:
            response = sync_sources(source_id="gitlab:42")

        mock_sync.assert_called_once_with("gitlab:42")
        assert response["synced"] == 1
        assert response["results"] == [fake_result]
        assert "error" not in response

    def test_sync_sources_no_id_returns_list(self):
        """sync_sources without source_id returns available_sources list with safety message, no actual sync."""
        fake_sources = [
            {"source_id": "gitlab:42", "source_type": "git_repo", "title": "My Repo"},
            {"source_id": "confluence:123", "source_type": "confluence_page", "title": "Some Page"},
        ]
        with patch("app.mcp_server.db.list_sources", return_value=fake_sources) as mock_list, \
             patch("app.mcp_server.service.sync_and_ingest_source") as mock_sync:
            response = sync_sources()

        mock_list.assert_called_once()
        mock_sync.assert_not_called()
        assert "available_sources" in response
        assert response["available_sources"] == ["gitlab:42", "confluence:123"]
        assert response["total"] == 2
        assert "message" in response
        assert "30+" in response["message"]
        assert "error" not in response

    def test_sync_sources_exception(self):
        """sync_sources catches exceptions from the sync service and returns an error dict."""
        with patch("app.mcp_server.service.sync_and_ingest_source", side_effect=RuntimeError("git clone failed")):
            response = sync_sources(source_id="gitlab:99")

        assert response["error"] == "sync_failed"
        assert "git clone failed" in response["message"]
