"""Tests cho confidence scorer."""

from __future__ import annotations

from unittest.mock import patch
from pathlib import Path

from app.tasks.observability.confidence import score_confidence


class TestRequirementsDoc:
    def test_high_score_with_all_sections(self):
        content = """
# Requirements
## Acceptance Criteria
1. WHEN user does X, THE system SHALL do Y
## Compliance Requirements
PCI-DSS compliance required
## Correctness Properties
Invariant: ...
## User Story
As a user...
""" * 5  # make it long enough
        result = score_confidence("requirements_doc", content)
        assert result.score >= 0.6
        assert result.low_confidence is False

    def test_low_score_when_too_short(self):
        result = score_confidence("requirements_doc", "Short doc")
        assert result.score < 0.6
        assert result.low_confidence is True


class TestGeneratedCode:
    def test_high_score_llm_mode(self):
        data = {"mode": "llm", "content": 'def foo(x: int) -> str:\n    """Do foo."""\n    return str(x)'}
        result = score_confidence("generated_code", data)
        assert result.score >= 0.6

    def test_low_score_skeleton_with_not_implemented(self):
        data = {"mode": "skeleton", "content": "def foo():\n    raise NotImplementedError"}
        result = score_confidence("generated_code", data)
        assert result.score < 0.6
        assert result.low_confidence is True
        assert any("NotImplementedError" in r for r in result.review_reasons)


class TestCommitMessage:
    def test_high_score_correct_format(self):
        result = score_confidence("commit_message", "feat(api): add order endpoint")
        assert result.score >= 0.6

    def test_low_score_no_scope(self):
        result = score_confidence("commit_message", "feat: add something")
        assert result.score < 0.8  # lower than with scope

    def test_low_score_wrong_format(self):
        result = score_confidence("commit_message", "Added some stuff to the codebase")
        assert result.low_confidence is True


class TestHelmValues:
    def test_high_score_complete_values(self):
        content = """
replicaCount: 1
image:
  repository: registry/svc
  tag: "1.0"
resources:
  requests:
    cpu: 100m
  limits:
    cpu: 500m
livenessProbe:
  httpGet:
    path: /health
    port: 8080
ingress:
  enabled: true
  host: svc.example.com
"""
        result = score_confidence("helm_values", content)
        assert result.score >= 0.6

    def test_low_score_invalid_yaml(self):
        result = score_confidence("helm_values", "not: valid: yaml: ::::")
        assert result.low_confidence is True


class TestScoreRange:
    def test_score_always_between_0_and_1(self):
        for output_type in ["requirements_doc", "design_doc", "generated_code", "commit_message", "helm_values"]:
            result = score_confidence(output_type, "")
            assert 0.0 <= result.score <= 1.0

    def test_unknown_type_returns_low_confidence(self):
        result = score_confidence("unknown_type", "some content")
        assert result.low_confidence is True


class TestAuditLog:
    def test_confidence_log_written(self, tmp_path):
        with patch("app.tasks.observability.confidence.settings") as mock_settings:
            mock_settings.logs_dir = tmp_path
            score_confidence("commit_message", "feat(api): add endpoint")
        log_file = tmp_path / "confidence.jsonl"
        assert log_file.exists()
