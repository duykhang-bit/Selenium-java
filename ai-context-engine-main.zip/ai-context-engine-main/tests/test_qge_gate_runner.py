"""Tests cho gate_runner."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest
from app.tasks.quality_gate.gate_runner import run_all_gates
from app.tasks.quality_gate.models import GateReport, Finding


_SIMPLE_DIFF = """\
--- /dev/null
+++ b/app/tasks/new_module.py
@@ -0,0 +1,5 @@
+from __future__ import annotations
+
+
+def hello() -> str:
+    return "hello"
"""

_SECRET_DIFF = """\
--- /dev/null
+++ b/app/config.py
@@ -0,0 +1,2 @@
+from __future__ import annotations
+password = "supersecret123"
"""


class TestGateRunnerBasic:
    def test_returns_quality_gate_report(self):
        report = run_all_gates(_SIMPLE_DIFF)
        assert report is not None
        assert report.overall in {"PASS", "WARN", "FAIL"}

    def test_all_gates_run(self):
        report = run_all_gates(_SIMPLE_DIFF)
        gate_names = {r.gate for r in report.gate_reports}
        assert "code_quality" in gate_names
        assert "security" in gate_names
        assert "secret_detection" in gate_names

    def test_empty_diff_returns_pass(self):
        report = run_all_gates("")
        assert report.overall == "PASS"
        assert report.total_critical == 0
        assert report.total_high == 0


class TestSeverityAggregation:
    def test_fail_when_secret_detected(self):
        report = run_all_gates(_SECRET_DIFF)
        assert report.overall == "FAIL"
        assert report.total_critical > 0

    def test_totals_sum_correctly(self):
        report = run_all_gates(_SIMPLE_DIFF)
        total = report.total_critical + report.total_high + report.total_medium + report.total_low
        assert total == len([f for f in report.all_findings if f.severity in {"CRITICAL", "HIGH", "MEDIUM", "LOW"}])


class TestGateIndependence:
    def test_gate_exception_does_not_abort_others(self):
        """Gate exception không được abort các gate khác."""
        def failing_gate(diff):
            raise RuntimeError("Gate exploded")

        with patch.dict("app.tasks.quality_gate.gate_runner._ALL_GATES", {"failing": failing_gate}):
            report = run_all_gates(_SIMPLE_DIFF, enabled_gates=["failing", "security"])

        gate_names = {r.gate for r in report.gate_reports}
        assert "failing" in gate_names
        assert "security" in gate_names

        failing_report = next(r for r in report.gate_reports if r.gate == "failing")
        assert failing_report.error is not None


class TestEnabledGates:
    def test_only_specified_gates_run(self):
        report = run_all_gates(_SIMPLE_DIFF, enabled_gates=["security"])
        gate_names = {r.gate for r in report.gate_reports}
        assert gate_names == {"security"}


class TestAuditLog:
    def test_audit_record_written(self, tmp_path):
        with patch("app.tasks.quality_gate.gate_runner.settings") as mock_settings:
            mock_settings.logs_dir = tmp_path
            run_all_gates(_SIMPLE_DIFF, trace_id="test-trace-123")

        audit_file = tmp_path / "qge_audit.jsonl"
        assert audit_file.exists()
        record = json.loads(audit_file.read_text().strip())
        assert record["event_type"] == "qge_analyze"
        assert record["details"]["trace_id"] == "test-trace-123"
        assert "overall" in record["details"]

    def test_audit_does_not_contain_diff_content(self, tmp_path):
        with patch("app.tasks.quality_gate.gate_runner.settings") as mock_settings:
            mock_settings.logs_dir = tmp_path
            run_all_gates(_SECRET_DIFF, trace_id="test-secret-trace")

        audit_file = tmp_path / "qge_audit.jsonl"
        content = audit_file.read_text()
        assert "supersecret123" not in content
