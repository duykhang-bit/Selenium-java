"""Tests cho Jenkins models."""

from __future__ import annotations

from app.tasks.jenkins.models import BuildAnalysis, BuildStatus, DeploymentRecord, TriggerResult


class TestTriggerResult:
    def test_fields(self):
        r = TriggerResult(job_name="my-job", build_number=42, build_url="http://...", triggered_at="2024-01-01T00:00:00Z")
        assert r.job_name == "my-job"
        assert r.build_number == 42
        assert r.triggered_by == "system"


class TestBuildStatus:
    def test_fields(self):
        s = BuildStatus(job_name="my-job", build_number=1, status="SUCCESS")
        assert s.status == "SUCCESS"
        assert s.duration_ms == 0


class TestBuildAnalysis:
    def test_fields(self):
        a = BuildAnalysis(error_type="compilation", error_message="SyntaxError")
        assert a.error_type == "compilation"
        assert a.affected_files == []


class TestDeploymentRecord:
    def test_fields(self):
        d = DeploymentRecord(
            record_id="abc", service="order-service", environment="uat",
            build_number=10, job_name="deploy-uat", status="success",
            deployed_at="2024-01-01T00:00:00Z",
        )
        assert d.environment == "uat"
        assert d.deployed_by == "system"
