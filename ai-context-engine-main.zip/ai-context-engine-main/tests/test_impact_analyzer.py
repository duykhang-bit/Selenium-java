"""Tests for app/tasks/impact_analyzer.py

Validates: Requirements 7.2, 7.4
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from app.tasks.impact_analyzer import (
    ImpactReport,
    ImpactedService,
    _classify_impact,
    _detect_conflicts,
    _extract_service_name,
    analyze_impact,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_result(content: str, source: str, score: float = 0.9) -> MagicMock:
    """Tạo mock SearchResult."""
    r = MagicMock()
    r.content = content
    r.score = score
    r.metadata = {"source": source}
    return r


# ---------------------------------------------------------------------------
# Unit tests — _classify_impact
# ---------------------------------------------------------------------------


class TestClassifyImpact:
    """**Validates: Requirements 7.2**"""

    def test_high_keyword_api(self):
        assert _classify_impact("This changes the api endpoint", "app/api/routes.py") == "HIGH"

    def test_high_keyword_schema(self):
        assert _classify_impact("Update database schema migration", "app/models.py") == "HIGH"

    def test_high_keyword_interface(self):
        assert _classify_impact("Modify interface contract", "app/core/interface.py") == "HIGH"

    def test_high_keyword_endpoint(self):
        assert _classify_impact("New endpoint added", "app/api/routes.py") == "HIGH"

    def test_high_keyword_model(self):
        assert _classify_impact("Update data model", "app/models/user.py") == "HIGH"

    def test_medium_keyword_service(self):
        assert _classify_impact("Update service logic", "app/tasks/service.py") == "MEDIUM"

    def test_medium_keyword_handler(self):
        assert _classify_impact("Modify handler processing", "app/tasks/handler.py") == "MEDIUM"

    def test_medium_keyword_validator(self):
        assert _classify_impact("Add validator rule", "app/core/validator.py") == "MEDIUM"

    def test_medium_keyword_workflow(self):
        assert _classify_impact("Change workflow steps", "app/sync/workflow.py") == "MEDIUM"

    def test_low_keyword_config(self):
        assert _classify_impact("Update config setting", "app/core/config.py") == "LOW"

    def test_low_keyword_label(self):
        assert _classify_impact("Change label text message", "app/core/messages.py") == "LOW"

    def test_low_keyword_constant(self):
        assert _classify_impact("Update constant value", "app/core/constants.py") == "LOW"

    def test_high_takes_priority_over_medium(self):
        # Content has both api (HIGH) and service (MEDIUM) keywords
        assert _classify_impact("api service handler", "app/api/service.py") == "HIGH"

    def test_high_from_source_path(self):
        # Source path contains "schema" → HIGH
        assert _classify_impact("some content", "app/db/schema.py") == "HIGH"

    def test_low_fallback_for_unknown_content(self):
        assert _classify_impact("some random text", "app/misc/helper.py") == "LOW"


# ---------------------------------------------------------------------------
# Unit tests — _extract_service_name
# ---------------------------------------------------------------------------


class TestExtractServiceName:
    def test_app_api_routes(self):
        assert _extract_service_name("app/api/routes.py") == "api"

    def test_app_tasks_brief(self):
        assert _extract_service_name("app/tasks/brief.py") == "tasks"

    def test_app_core_config(self):
        assert _extract_service_name("app/core/config.py") == "core"

    def test_app_ingest_pipeline(self):
        assert _extract_service_name("app/ingest/pipeline.py") == "ingest"

    def test_app_sync_service(self):
        assert _extract_service_name("app/sync/service.py") == "sync"

    def test_backslash_path(self):
        assert _extract_service_name("app\\api\\routes.py") == "api"

    def test_no_app_prefix(self):
        # Falls back to second-to-last segment
        result = _extract_service_name("src/utils/helper.py")
        assert result == "utils"

    def test_single_segment(self):
        result = _extract_service_name("main.py")
        assert result == "main.py"


# ---------------------------------------------------------------------------
# Unit tests — _detect_conflicts
# ---------------------------------------------------------------------------


class TestDetectConflicts:
    """**Validates: Requirements 7.4**"""

    def test_no_conflict_returns_empty(self):
        doc = "Hệ thống lưu trữ dữ liệu người dùng."
        assert _detect_conflicts(doc) == []

    def test_conflict_khong_luu_vs_luu(self):
        doc = "Hệ thống không lưu token. Hệ thống lưu token để tái sử dụng."
        conflicts = _detect_conflicts(doc)
        assert len(conflicts) >= 1
        assert any("token" in c for c in conflicts)

    def test_conflict_tat_vs_bat(self):
        doc = "Tắt logging. Bật logging cho production."
        conflicts = _detect_conflicts(doc)
        assert len(conflicts) >= 1

    def test_conflict_disable_vs_enable(self):
        doc = "Disable cache. Enable cache for performance."
        conflicts = _detect_conflicts(doc)
        assert len(conflicts) >= 1

    def test_no_false_positive_different_entities(self):
        doc = "Không lưu password. Lưu username."
        # "không lưu password" vs "lưu username" — different entities, no conflict
        conflicts = _detect_conflicts(doc)
        # Should not flag password vs username as conflict
        assert not any("username" in c and "password" in c for c in conflicts)

    def test_empty_doc_no_conflicts(self):
        assert _detect_conflicts("") == []


# ---------------------------------------------------------------------------
# Unit tests — analyze_impact with mock ChromaDB
# ---------------------------------------------------------------------------


class TestAnalyzeImpact:
    """**Validates: Requirements 7.1, 7.2, 7.3, 7.4**"""

    @patch("app.retrieval.search.search")
    def test_returns_impact_report(self, mock_search):
        mock_search.return_value = [
            _make_result("api endpoint changes", "app/api/routes.py"),
        ]
        report = analyze_impact("New API requirement", trace_id="test-001")
        assert isinstance(report, ImpactReport)
        assert isinstance(report.impacted_services, list)

    @patch("app.retrieval.search.search")
    def test_high_impact_from_api_file(self, mock_search):
        mock_search.return_value = [
            _make_result("api endpoint schema contract", "app/api/routes.py"),
        ]
        report = analyze_impact("Change API contract", trace_id="test-002")
        high_services = [s for s in report.impacted_services if s.impact_level == "HIGH"]
        assert len(high_services) >= 1
        assert report.total_high >= 1

    @patch("app.retrieval.search.search")
    def test_medium_impact_from_service_file(self, mock_search):
        mock_search.return_value = [
            _make_result("service handler logic workflow", "app/tasks/service.py"),
        ]
        report = analyze_impact("Update business logic", trace_id="test-003")
        medium_services = [s for s in report.impacted_services if s.impact_level == "MEDIUM"]
        assert len(medium_services) >= 1
        assert report.total_medium >= 1

    @patch("app.retrieval.search.search")
    def test_low_impact_from_config_file(self, mock_search):
        mock_search.return_value = [
            _make_result("config setting constant", "app/core/config.py"),
        ]
        report = analyze_impact("Update config label", trace_id="test-004")
        low_services = [s for s in report.impacted_services if s.impact_level == "LOW"]
        assert len(low_services) >= 1
        assert report.total_low >= 1

    @patch("app.retrieval.search.search")
    def test_totals_sum_correctly(self, mock_search):
        mock_search.return_value = [
            _make_result("api endpoint", "app/api/routes.py"),
            _make_result("service logic", "app/tasks/service.py"),
            _make_result("config setting", "app/core/config.py"),
        ]
        report = analyze_impact("Mixed requirements", trace_id="test-005")
        total = report.total_high + report.total_medium + report.total_low
        assert total == len(report.impacted_services)

    @patch("app.retrieval.search.search")
    def test_graceful_degradation_when_chromadb_fails(self, mock_search):
        mock_search.side_effect = Exception("ChromaDB unavailable")
        report = analyze_impact("Some requirement", trace_id="test-006")
        assert isinstance(report, ImpactReport)
        assert report.impacted_services == []
        assert report.total_high == 0
        assert report.total_medium == 0
        assert report.total_low == 0

    @patch("app.retrieval.search.search")
    def test_empty_search_results_returns_empty_report(self, mock_search):
        mock_search.return_value = []
        report = analyze_impact("Some requirement", trace_id="test-007")
        assert report.impacted_services == []
        assert report.total_high == 0

    @patch("app.retrieval.search.search")
    def test_trace_id_propagated(self, mock_search):
        mock_search.return_value = []
        report = analyze_impact("req", trace_id="my-trace-xyz")
        assert report.trace_id == "my-trace-xyz"

    @patch("app.retrieval.search.search")
    def test_trace_id_auto_generated_when_none(self, mock_search):
        mock_search.return_value = []
        report = analyze_impact("req", trace_id=None)
        assert report.trace_id is not None
        assert len(report.trace_id) > 0

    @patch("app.retrieval.search.search")
    def test_analyzed_at_is_iso8601(self, mock_search):
        from datetime import datetime
        mock_search.return_value = []
        report = analyze_impact("req", trace_id="test-iso")
        dt = datetime.fromisoformat(report.analyzed_at)
        assert dt.tzinfo is not None

    @patch("app.retrieval.search.search")
    def test_files_grouped_by_service(self, mock_search):
        """Multiple files from same service should be grouped together."""
        mock_search.return_value = [
            _make_result("api route handler", "app/api/routes.py"),
            _make_result("api schema model", "app/api/schemas.py"),
        ]
        report = analyze_impact("API changes", trace_id="test-group")
        api_services = [s for s in report.impacted_services if s.service_name == "api"]
        assert len(api_services) == 1
        assert len(api_services[0].affected_files) == 2

    @patch("app.retrieval.search.search")
    def test_impact_escalates_to_highest_level(self, mock_search):
        """When same service has LOW and HIGH results, should be HIGH."""
        mock_search.return_value = [
            _make_result("config setting", "app/api/config.py"),
            _make_result("api endpoint schema", "app/api/routes.py"),
        ]
        report = analyze_impact("API + config changes", trace_id="test-escalate")
        api_services = [s for s in report.impacted_services if s.service_name == "api"]
        assert len(api_services) == 1
        assert api_services[0].impact_level == "HIGH"

    @patch("app.retrieval.search.search")
    def test_impacted_service_has_test_strategy(self, mock_search):
        mock_search.return_value = [
            _make_result("api endpoint", "app/api/routes.py"),
        ]
        report = analyze_impact("API requirement", trace_id="test-strategy")
        for service in report.impacted_services:
            assert service.test_strategy
            assert len(service.test_strategy) > 0

    @patch("app.retrieval.search.search")
    def test_conflict_detection_integrated(self, mock_search):
        """Conflicts in requirements_doc should appear in ImpactReport."""
        mock_search.return_value = []
        doc = "Hệ thống không lưu token. Hệ thống lưu token để tái sử dụng."
        report = analyze_impact(doc, trace_id="test-conflict")
        assert len(report.conflicts) >= 1

    @patch("app.retrieval.search.search")
    def test_no_conflict_when_doc_is_consistent(self, mock_search):
        mock_search.return_value = []
        doc = "Hệ thống lưu trữ dữ liệu người dùng an toàn."
        report = analyze_impact(doc, trace_id="test-no-conflict")
        assert report.conflicts == []

    @patch("app.retrieval.search.search")
    def test_search_called_with_correct_params(self, mock_search):
        mock_search.return_value = []
        analyze_impact("req doc", collection_name="my_col", top_k=5, trace_id="test-params")
        mock_search.assert_called_once()
        call_kwargs = mock_search.call_args
        assert (
            call_kwargs.kwargs.get("collection_name") == "my_col"
            or call_kwargs.args[1] == "my_col"
        )
        assert (
            call_kwargs.kwargs.get("top_k") == 5
            or call_kwargs.args[2] == 5
        )


# ---------------------------------------------------------------------------
# Property-based tests
# ---------------------------------------------------------------------------


class TestImpactAnalyzerProperties:
    """**Validates: Requirements 7.2, 7.4**"""

    @given(st.text(max_size=200))
    @settings(max_examples=50)
    def test_totals_always_sum_to_services_count(self, content: str):
        """total_high + total_medium + total_low == len(impacted_services) always."""
        with patch("app.retrieval.search.search") as mock_search:
            mock_search.return_value = [
                _make_result(content, "app/api/routes.py"),
            ]
            report = analyze_impact(content, trace_id="prop-test")
        total = report.total_high + report.total_medium + report.total_low
        assert total == len(report.impacted_services)

    @given(st.text(max_size=200))
    @settings(max_examples=50)
    def test_impact_level_always_valid(self, content: str):
        """Every ImpactedService must have a valid impact_level."""
        with patch("app.retrieval.search.search") as mock_search:
            mock_search.return_value = [
                _make_result(content, "app/tasks/service.py"),
            ]
            report = analyze_impact(content, trace_id="prop-level")
        for service in report.impacted_services:
            assert service.impact_level in ("HIGH", "MEDIUM", "LOW")

    @given(st.text(max_size=200))
    @settings(max_examples=50)
    def test_classify_impact_always_returns_valid_level(self, content: str):
        """_classify_impact always returns HIGH, MEDIUM, or LOW."""
        level = _classify_impact(content, "app/some/file.py")
        assert level in ("HIGH", "MEDIUM", "LOW")

    @given(st.text(max_size=200))
    @settings(max_examples=50)
    def test_graceful_degradation_always_returns_report(self, doc: str):
        """analyze_impact always returns ImpactReport even when ChromaDB fails."""
        with patch("app.retrieval.search.search") as mock_search:
            mock_search.side_effect = RuntimeError("DB down")
            report = analyze_impact(doc, trace_id="prop-graceful")
        assert isinstance(report, ImpactReport)
        assert report.total_high == 0
        assert report.total_medium == 0
        assert report.total_low == 0
        assert report.impacted_services == []

    @given(
        st.lists(
            st.builds(
                lambda content, path: _make_result(content, path),
                content=st.text(max_size=100),
                path=st.sampled_from([
                    "app/api/routes.py",
                    "app/tasks/service.py",
                    "app/core/config.py",
                    "app/ingest/pipeline.py",
                ]),
            ),
            min_size=0,
            max_size=5,
        )
    )
    @settings(max_examples=30)
    def test_no_duplicate_service_names(self, results: list):
        """Each service_name appears at most once in impacted_services."""
        with patch("app.retrieval.search.search") as mock_search:
            mock_search.return_value = results
            report = analyze_impact("some req", trace_id="prop-dedup")
        names = [s.service_name for s in report.impacted_services]
        assert len(names) == len(set(names))
