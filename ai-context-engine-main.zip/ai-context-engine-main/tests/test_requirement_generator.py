"""Tests for app/tasks/requirement_generator.py

Validates: Requirements 1.1, 1.5, 1.6
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from app.tasks.compliance_checker import ComplianceReport
from app.tasks.requirement_generator import (
    RequirementGeneratorResult,
    generate_requirements,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

PHARMACY_INTENT = "Xây dựng hệ thống nhà thuốc bán lẻ thuốc kê đơn (Rx) và quản lý dược phẩm"
VACCINATION_INTENT = "Xây dựng hệ thống quản lý tiêm chủng vắc xin cho trẻ em"
PAYMENT_INTENT = "Xây dựng hệ thống thanh toán thẻ POS cho chuỗi nhà thuốc"
GENERIC_INTENT = "Xây dựng hệ thống quản lý nhân sự nội bộ"


def _mock_search_results(n: int = 3) -> list[MagicMock]:
    """Tạo mock search results."""
    results = []
    for i in range(n):
        r = MagicMock()
        r.content = f"Context chunk {i}: relevant code snippet"
        r.score = 0.9 - i * 0.1
        results.append(r)
    return results


# ---------------------------------------------------------------------------
# Test: RequirementGeneratorResult dataclass
# ---------------------------------------------------------------------------


def test_result_dataclass_fields():
    """RequirementGeneratorResult phải có đủ các field theo spec."""
    report = ComplianceReport(
        passed=True,
        domains_checked=[],
        violations=[],
        warnings=[],
        checked_at="2024-01-01T00:00:00+00:00",
    )
    result = RequirementGeneratorResult(
        document="# Test",
        domains=["PHARMACY"],
        compliance_report=report,
        context_chunks_used=5,
        generated_at="2024-01-01T00:00:00+00:00",
        trace_id="abc123",
    )
    assert result.document == "# Test"
    assert result.domains == ["PHARMACY"]
    assert result.compliance_report is report
    assert result.context_chunks_used == 5
    assert result.generated_at == "2024-01-01T00:00:00+00:00"
    assert result.trace_id == "abc123"


# ---------------------------------------------------------------------------
# Test: generate_requirements — document structure
# ---------------------------------------------------------------------------


@patch("app.tasks.requirement_generator.chroma_search" if False else "app.retrieval.search.search")
def test_document_contains_required_sections(mock_search):
    """Document sinh ra phải có đủ các section theo template chuẩn."""
    mock_search.return_value = []

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements(GENERIC_INTENT)

    doc = result.document
    assert "# Tài liệu Yêu cầu:" in doc
    assert "## Giới thiệu" in doc
    assert "## Bảng chú giải" in doc
    assert "## Yêu cầu" in doc
    assert "## Compliance Requirements" in doc
    assert "## Correctness Properties" in doc


@patch("app.retrieval.search.search")
def test_document_title_extracted_from_intent(mock_search):
    """Tiêu đề document phải được trích xuất từ dòng đầu của intent."""
    mock_search.return_value = []

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements("Hệ thống quản lý kho thuốc")

    assert "Hệ thống quản lý kho thuốc" in result.document


@patch("app.retrieval.search.search")
def test_document_has_user_story_and_acceptance_criteria(mock_search):
    """Document phải có User Story và Acceptance Criteria theo EARS format."""
    mock_search.return_value = []

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements(GENERIC_INTENT)

    doc = result.document
    assert "User Story" in doc
    assert "Acceptance Criteria" in doc
    # EARS keywords
    assert any(kw in doc for kw in ["WHEN", "THE", "SHALL", "IF", "THEN"])


# ---------------------------------------------------------------------------
# Test: Compliance clauses injection theo domain
# ---------------------------------------------------------------------------


@patch("app.retrieval.search.search")
def test_pharmacy_compliance_clauses_injected(mock_search):
    """Compliance clauses PHARMACY phải được inject vào document khi detect PHARMACY domain."""
    mock_search.return_value = []

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements(PHARMACY_INTENT)

    assert "PHARMACY" in result.domains
    doc = result.document
    # Compliance section phải có PHARMACY clauses
    assert "PHARMACY-001" in doc or "Validation kê đơn Rx" in doc
    assert "Luật Dược" in doc


@patch("app.retrieval.search.search")
def test_vaccination_compliance_clauses_injected(mock_search):
    """Compliance clauses VACCINATION phải được inject khi detect VACCINATION domain."""
    mock_search.return_value = []

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements(VACCINATION_INTENT)

    assert "VACCINATION" in result.domains
    doc = result.document
    assert "VAC-001" in doc or "tiêm chủng quốc gia" in doc.lower()
    assert "Thông tư 09" in doc


@patch("app.retrieval.search.search")
def test_payment_compliance_clauses_injected(mock_search):
    """Compliance clauses PAYMENT phải được inject khi detect PAYMENT domain."""
    mock_search.return_value = []

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements(PAYMENT_INTENT)

    assert "PAYMENT" in result.domains
    doc = result.document
    assert "PAY-001" in doc or "CVV" in doc
    assert "PCI-DSS" in doc


@patch("app.retrieval.search.search")
def test_no_domain_no_compliance_clauses(mock_search):
    """Khi không detect được domain, compliance section vẫn có nhưng không có clauses cụ thể."""
    mock_search.return_value = []

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements(GENERIC_INTENT)

    assert result.domains == []
    assert "## Compliance Requirements" in result.document


@patch("app.retrieval.search.search")
def test_multi_domain_all_clauses_injected(mock_search):
    """Khi detect nhiều domain, tất cả compliance clauses phải được inject."""
    mock_search.return_value = []
    multi_intent = "Hệ thống nhà thuốc bán thuốc kê đơn Rx và xử lý thanh toán thẻ POS"

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements(multi_intent)

    assert "PHARMACY" in result.domains
    assert "PAYMENT" in result.domains
    doc = result.document
    assert "Luật Dược" in doc
    assert "PCI-DSS" in doc


# ---------------------------------------------------------------------------
# Test: ChromaDB integration
# ---------------------------------------------------------------------------


@patch("app.retrieval.search.search")
def test_context_chunks_used_reflects_search_results(mock_search):
    """context_chunks_used phải phản ánh số lượng kết quả từ ChromaDB."""
    mock_search.return_value = _mock_search_results(5)

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements(GENERIC_INTENT, top_k=5)

    assert result.context_chunks_used == 5
    mock_search.assert_called_once()


@patch("app.retrieval.search.search")
def test_graceful_degradation_when_chromadb_fails(mock_search):
    """Khi ChromaDB không khả dụng, generator vẫn hoạt động bình thường."""
    mock_search.side_effect = Exception("ChromaDB connection failed")

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements(GENERIC_INTENT)

    # Vẫn sinh ra document hợp lệ
    assert result.document
    assert "# Tài liệu Yêu cầu:" in result.document
    assert result.context_chunks_used == 0


@patch("app.retrieval.search.search")
def test_search_called_with_correct_params(mock_search):
    """search() phải được gọi với đúng collection_name và top_k."""
    mock_search.return_value = []

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        generate_requirements(GENERIC_INTENT, collection_name="my_collection", top_k=7)

    mock_search.assert_called_once()
    call_kwargs = mock_search.call_args
    assert call_kwargs.kwargs.get("collection_name") == "my_collection" or call_kwargs.args[1] == "my_collection"
    assert call_kwargs.kwargs.get("top_k") == 7 or call_kwargs.args[2] == 7


# ---------------------------------------------------------------------------
# Test: Compliance report
# ---------------------------------------------------------------------------


@patch("app.retrieval.search.search")
def test_compliance_report_attached_to_result(mock_search):
    """compliance_report phải được đính kèm vào result sau khi generate."""
    mock_search.return_value = []

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements(GENERIC_INTENT)

    assert isinstance(result.compliance_report, ComplianceReport)
    assert hasattr(result.compliance_report, "passed")
    assert hasattr(result.compliance_report, "violations")
    assert hasattr(result.compliance_report, "domains_checked")


@patch("app.retrieval.search.search")
def test_pharmacy_compliance_report_has_domain_checked(mock_search):
    """compliance_report phải có PHARMACY trong domains_checked khi detect PHARMACY."""
    mock_search.return_value = []

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements(PHARMACY_INTENT)

    assert "PHARMACY" in result.compliance_report.domains_checked


# ---------------------------------------------------------------------------
# Test: Audit record
# ---------------------------------------------------------------------------


@patch("app.retrieval.search.search")
def test_audit_record_written_after_generate(mock_search):
    """Audit record phải được ghi vào rde_audit.jsonl sau mỗi lần generate."""
    mock_search.return_value = []

    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "rde_audit.jsonl"

        with patch("app.tasks.requirement_generator.settings") as mock_settings:
            mock_settings.logs_dir = Path(tmpdir)
            generate_requirements(GENERIC_INTENT, trace_id="test-trace-001")

        assert log_path.exists(), "rde_audit.jsonl phải được tạo"
        lines = log_path.read_text(encoding="utf-8").strip().splitlines()
        assert len(lines) == 1

        record = json.loads(lines[0])
        assert record["event_type"] == "rde_generate_requirements"
        assert "created_at" in record
        assert "details" in record


@patch("app.retrieval.search.search")
def test_audit_record_format_correct(mock_search):
    """Audit record phải có đúng format theo spec."""
    mock_search.return_value = []

    with tempfile.TemporaryDirectory() as tmpdir:
        with patch("app.tasks.requirement_generator.settings") as mock_settings:
            mock_settings.logs_dir = Path(tmpdir)
            generate_requirements(PHARMACY_INTENT, trace_id="trace-xyz-789")

        log_path = Path(tmpdir) / "rde_audit.jsonl"
        record = json.loads(log_path.read_text(encoding="utf-8").strip())

        details = record["details"]
        assert "audit_id" in details
        assert details["trace_id"] == "trace-xyz-789"
        assert details["action"] == "generate_requirements"
        assert details["actor"] == "system"
        assert isinstance(details["domains"], list)
        assert isinstance(details["compliance_passed"], bool)
        assert isinstance(details["violations_count"], int)
        assert "duration_ms" in details
        assert "confluence_page_id" in details


@patch("app.retrieval.search.search")
def test_audit_record_no_pii(mock_search):
    """Audit record KHÔNG được chứa intent text (PII)."""
    mock_search.return_value = []
    sensitive_intent = "Hệ thống quản lý bệnh nhân Nguyễn Văn A, SĐT 0901234567"

    with tempfile.TemporaryDirectory() as tmpdir:
        with patch("app.tasks.requirement_generator.settings") as mock_settings:
            mock_settings.logs_dir = Path(tmpdir)
            generate_requirements(sensitive_intent, trace_id="trace-pii-test")

        log_path = Path(tmpdir) / "rde_audit.jsonl"
        raw_content = log_path.read_text(encoding="utf-8")

        # Không được chứa tên người hay số điện thoại
        assert "Nguyễn Văn A" not in raw_content
        assert "0901234567" not in raw_content


@patch("app.retrieval.search.search")
def test_audit_record_appended_on_multiple_calls(mock_search):
    """Mỗi lần generate phải append một record mới vào audit log."""
    mock_search.return_value = []

    with tempfile.TemporaryDirectory() as tmpdir:
        with patch("app.tasks.requirement_generator.settings") as mock_settings:
            mock_settings.logs_dir = Path(tmpdir)
            generate_requirements(GENERIC_INTENT, trace_id="trace-001")
            generate_requirements(PHARMACY_INTENT, trace_id="trace-002")

        log_path = Path(tmpdir) / "rde_audit.jsonl"
        lines = log_path.read_text(encoding="utf-8").strip().splitlines()
        assert len(lines) == 2

        trace_ids = [json.loads(line)["details"]["trace_id"] for line in lines]
        assert "trace-001" in trace_ids
        assert "trace-002" in trace_ids


# ---------------------------------------------------------------------------
# Test: trace_id
# ---------------------------------------------------------------------------


@patch("app.retrieval.search.search")
def test_trace_id_propagated_to_result(mock_search):
    """trace_id được truyền vào phải xuất hiện trong result."""
    mock_search.return_value = []

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements(GENERIC_INTENT, trace_id="my-custom-trace")

    assert result.trace_id == "my-custom-trace"


@patch("app.retrieval.search.search")
def test_trace_id_auto_generated_when_none(mock_search):
    """Khi trace_id=None, phải tự sinh trace_id."""
    mock_search.return_value = []

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements(GENERIC_INTENT, trace_id=None)

    assert result.trace_id is not None
    assert len(result.trace_id) > 0


# ---------------------------------------------------------------------------
# Test: generated_at
# ---------------------------------------------------------------------------


@patch("app.retrieval.search.search")
def test_generated_at_is_iso8601_utc(mock_search):
    """generated_at phải là ISO 8601 UTC string."""
    mock_search.return_value = []

    with patch("app.tasks.requirement_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_requirements(GENERIC_INTENT)

    from datetime import datetime
    # Phải parse được
    dt = datetime.fromisoformat(result.generated_at)
    assert dt.tzinfo is not None
