"""Tests cho code_quality gate."""

from __future__ import annotations

import pytest
from app.tasks.quality_gate.diff_parser import parse_diff
from app.tasks.quality_gate.gates.code_quality import run


def _make_diff(path: str, content: str, change_type: str = "added") -> str:
    lines = content.splitlines()
    added = "\n".join(f"+{line}" for line in lines)
    return f"--- /dev/null\n+++ b/{path}\n@@ -0,0 +1,{len(lines)} @@\n{added}\n"


def _make_modified_diff(path: str, content: str) -> str:
    lines = content.splitlines()
    added = "\n".join(f"+{line}" for line in lines)
    return f"--- a/{path}\n+++ b/{path}\n@@ -1,1 +1,{len(lines)} @@\n{added}\n"


class TestCyclomaticComplexity:
    def test_high_complexity_function(self):
        code = "from __future__ import annotations\n\ndef complex_func(x):\n    '''doc'''\n"
        # Thêm 11 if statements
        for i in range(11):
            code += f"    if x == {i}:\n        pass\n"
        diff = _make_diff("app/foo.py", code)
        report = run(parse_diff(diff))
        rule_ids = [f.rule_id for f in report.findings]
        assert "CQ-001" in rule_ids

    def test_low_complexity_passes(self):
        code = "from __future__ import annotations\n\ndef simple(x):\n    '''doc'''\n    return x + 1\n"
        diff = _make_diff("app/foo.py", code)
        report = run(parse_diff(diff))
        assert not any(f.rule_id == "CQ-001" for f in report.findings)


class TestFunctionLength:
    def test_long_function_medium_finding(self):
        lines = ["from __future__ import annotations", "", "def long_func():", "    '''doc'''"]
        lines += ["    x = 1"] * 52
        code = "\n".join(lines)
        diff = _make_diff("app/foo.py", code)
        report = run(parse_diff(diff))
        assert any(f.rule_id == "CQ-002" for f in report.findings)

    def test_short_function_passes(self):
        code = "from __future__ import annotations\n\ndef short():\n    '''doc'''\n    return 1\n"
        diff = _make_diff("app/foo.py", code)
        report = run(parse_diff(diff))
        assert not any(f.rule_id == "CQ-002" for f in report.findings)


class TestMissingFutureImport:
    def test_missing_future_import_in_new_file(self):
        code = "def foo():\n    '''doc'''\n    pass\n"
        diff = _make_diff("app/foo.py", code)
        report = run(parse_diff(diff))
        assert any(f.rule_id == "CQ-004" for f in report.findings)

    def test_present_future_import_passes(self):
        code = "from __future__ import annotations\n\ndef foo():\n    '''doc'''\n    pass\n"
        diff = _make_diff("app/foo.py", code)
        report = run(parse_diff(diff))
        assert not any(f.rule_id == "CQ-004" for f in report.findings)


class TestPrintStatement:
    def test_print_in_production_code(self):
        code = "from __future__ import annotations\n\ndef foo():\n    '''doc'''\n    print('hello')\n"
        diff = _make_diff("app/foo.py", code)
        report = run(parse_diff(diff))
        assert any(f.rule_id == "CQ-006" for f in report.findings)

    def test_print_in_test_file_ignored(self):
        code = "from __future__ import annotations\n\ndef test_foo():\n    print('debug')\n"
        diff = _make_diff("tests/test_foo.py", code)
        report = run(parse_diff(diff))
        assert not any(f.rule_id == "CQ-006" for f in report.findings)


class TestEmptyDiff:
    def test_empty_diff_no_findings(self):
        report = run(parse_diff(""))
        assert report.findings == []

    def test_non_python_file_skipped(self):
        diff = _make_diff("README.md", "# Hello\n")
        report = run(parse_diff(diff))
        assert report.findings == []
