"""Tests cho performance gate."""

from __future__ import annotations

from app.tasks.quality_gate.diff_parser import parse_diff
from app.tasks.quality_gate.gates.performance import run


def _diff(path: str, content: str) -> str:
    lines = content.splitlines()
    added = "\n".join(f"+{line}" for line in lines)
    return f"--- /dev/null\n+++ b/{path}\n@@ -0,0 +1,{len(lines)} @@\n{added}\n"


class TestNPlusOne:
    def test_db_call_in_loop_detected(self):
        code = "for item in items:\n    result = db.query(Model).filter(id=item.id).first()\n"
        report = run(parse_diff(_diff("app/service.py", code)))
        assert any(f.rule_id == "PERF-001" for f in report.findings)

    def test_db_call_outside_loop_passes(self):
        code = "results = db.query(Model).all()\nfor r in results:\n    process(r)\n"
        report = run(parse_diff(_diff("app/service.py", code)))
        assert not any(f.rule_id == "PERF-001" for f in report.findings)


class TestSleep:
    def test_sleep_in_production_detected(self):
        code = "import time\ntime.sleep(5)\n"
        report = run(parse_diff(_diff("app/worker.py", code)))
        assert any(f.rule_id == "PERF-002" for f in report.findings)

    def test_sleep_in_test_ignored(self):
        code = "import time\ntime.sleep(0.1)\n"
        report = run(parse_diff(_diff("tests/test_foo.py", code)))
        assert not any(f.rule_id == "PERF-002" for f in report.findings)


class TestSelectStar:
    def test_select_star_detected(self):
        diff_text = "--- a/app/db.py\n+++ b/app/db.py\n@@ -1,1 +1,1 @@\n+query = 'SELECT * FROM users'\n"
        report = run(parse_diff(diff_text))
        assert any(f.rule_id == "PERF-003" for f in report.findings)

    def test_select_columns_passes(self):
        diff_text = "--- a/app/db.py\n+++ b/app/db.py\n@@ -1,1 +1,1 @@\n+query = 'SELECT id, name FROM users'\n"
        report = run(parse_diff(diff_text))
        assert not any(f.rule_id == "PERF-003" for f in report.findings)


class TestEmptyDiff:
    def test_empty_diff_no_findings(self):
        report = run(parse_diff(""))
        assert report.findings == []
