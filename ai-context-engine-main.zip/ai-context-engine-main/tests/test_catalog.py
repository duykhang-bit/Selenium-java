"""Tests for catalog database operations and token encryption round-trip."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest


@pytest.fixture()
def tmp_db(tmp_path, monkeypatch):
    """Spin up an isolated catalog DB in a temp directory."""
    monkeypatch.setenv("AI_CONTEXT_V2_SECRET_KEY", "")  # plaintext mode by default
    db_path = tmp_path / "catalog.db"
    data_dir = tmp_path

    with patch("app.core.config.settings") as mock_settings:
        mock_settings.catalog_db_path = db_path
        mock_settings.data_dir = data_dir
        mock_settings.chroma_dir = data_dir / "chroma"
        mock_settings.logs_dir = data_dir / "logs"
        mock_settings.workspaces_dir = data_dir / "workspaces"
        mock_settings.repos_dir = data_dir / "workspaces" / "repos"
        mock_settings.confluence_dir = data_dir / "workspaces" / "confluence"
        mock_settings.reports_dir = data_dir / "reports"
        mock_settings.tasks_dir = data_dir / "tasks"

        # Ensure dirs exist
        for d in [data_dir / "chroma", data_dir / "logs", data_dir / "workspaces",
                  data_dir / "workspaces" / "repos", data_dir / "workspaces" / "confluence",
                  data_dir / "reports", data_dir / "tasks"]:
            d.mkdir(parents=True, exist_ok=True)

        from app.catalog.database import init_database
        init_database()
        yield db_path


class TestTokenEncryption:
    def test_plaintext_roundtrip(self):
        """Without a key, token is stored with plain: prefix and returned as-is."""
        import importlib
        import app.core.crypto as crypto_mod

        # Reset cached fernet instance
        crypto_mod._fernet_instance = None
        crypto_mod._warn_once_emitted = False

        with patch.dict(os.environ, {"AI_CONTEXT_V2_SECRET_KEY": ""}):
            crypto_mod._fernet_instance = None
            stored = crypto_mod.encrypt_token("my-secret-token")
            assert stored.startswith("plain:")
            recovered = crypto_mod.decrypt_token(stored)
            assert recovered == "my-secret-token"

    def test_fernet_roundtrip(self):
        """With a valid key, token is Fernet-encrypted and decryptable."""
        from cryptography.fernet import Fernet
        import app.core.crypto as crypto_mod

        key = Fernet.generate_key().decode()
        crypto_mod._fernet_instance = None
        crypto_mod._warn_once_emitted = False

        with patch.dict(os.environ, {"AI_CONTEXT_V2_SECRET_KEY": key}):
            crypto_mod._fernet_instance = None
            stored = crypto_mod.encrypt_token("super-secret")
            assert stored.startswith("fernet:")
            assert "super-secret" not in stored

            recovered = crypto_mod.decrypt_token(stored)
            assert recovered == "super-secret"

    def test_legacy_plaintext_backward_compat(self):
        """Bare strings (old rows without prefix) are returned as-is."""
        import app.core.crypto as crypto_mod
        result = crypto_mod.decrypt_token("bare-legacy-token")
        assert result == "bare-legacy-token"

    def test_empty_token_passthrough(self):
        """Empty string token should not raise and should round-trip cleanly."""
        import app.core.crypto as crypto_mod
        assert crypto_mod.encrypt_token("") == ""
        assert crypto_mod.decrypt_token("") == ""


class TestUpsertSource:
    def test_upsert_and_retrieve(self, tmp_db):
        """Source can be inserted and retrieved by source_id."""
        from app.catalog import database as db

        source = {
            "source_id": "gitlab:99",
            "connector_id": None,
            "connector_type": "gitlab",
            "source_type": "git_repo",
            "external_id": "99",
            "title": "Test Repo",
            "url": "https://git.example.com/test/repo",
            "path_with_namespace": "test/repo",
            "clone_url": "https://git.example.com/test/repo.git",
            "default_branch": "main",
            "local_path": "/tmp/test-repo",
            "status": "discovered",
            "discovered_at": "2024-01-01T00:00:00+00:00",
            "metadata": {"repo_id": "test-repo"},
        }
        inserted = db.upsert_source(source)
        assert inserted["source_id"] == "gitlab:99"
        assert inserted["title"] == "Test Repo"

        retrieved = db.get_source("gitlab:99")
        assert retrieved is not None
        assert retrieved["source_id"] == "gitlab:99"

    def test_update_source_state(self, tmp_db):
        """update_source_state should correctly update status and local_path."""
        from app.catalog import database as db

        source = {
            "source_id": "gitlab:100",
            "connector_id": None,
            "connector_type": "gitlab",
            "source_type": "git_repo",
            "external_id": "100",
            "title": "Another Repo",
            "url": "https://git.example.com/another",
            "path_with_namespace": "another/repo",
            "clone_url": "https://git.example.com/another.git",
            "default_branch": "main",
            "local_path": "",
            "status": "discovered",
            "discovered_at": "2024-01-01T00:00:00+00:00",
            "metadata": {},
        }
        db.upsert_source(source)
        updated = db.update_source_state("gitlab:100", status="synced", local_path="/tmp/another")
        assert updated["status"] == "synced"
        assert updated["local_path"] == "/tmp/another"
