"""Tests cho Jenkins connector."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
import requests

from app.connectors.jenkins import (
    JenkinsConnectionError,
    JenkinsConnector,
    JenkinsJobNotFoundError,
)


def _connector() -> JenkinsConnector:
    return JenkinsConnector("http://jenkins.example.com", "admin", "token123")


class TestCheckConnection:
    def test_success(self):
        conn = _connector()
        with patch.object(conn._session, "get") as mock_get:
            mock_get.return_value = MagicMock(ok=True, status_code=200)
            assert conn.check_connection() is True

    def test_401_raises(self):
        conn = _connector()
        with patch.object(conn._session, "get") as mock_get:
            mock_get.return_value = MagicMock(ok=False, status_code=401)
            with pytest.raises(JenkinsConnectionError, match="authentication failed"):
                conn.check_connection()

    def test_connection_error_raises(self):
        conn = _connector()
        with patch.object(conn._session, "get", side_effect=requests.exceptions.ConnectionError("refused")):
            with pytest.raises(JenkinsConnectionError):
                conn.check_connection()


class TestGetBuildStatus:
    def test_success_build(self):
        conn = _connector()
        with patch.object(conn._session, "get") as mock_get:
            mock_get.return_value = MagicMock(
                ok=True, status_code=200,
                json=lambda: {"result": "SUCCESS", "duration": 5000, "timestamp": 0, "url": "http://..."},
            )
            result = conn.get_build_status("my-job", 42)
            assert result["status"] == "SUCCESS"
            assert result["duration_ms"] == 5000

    def test_running_build_returns_running(self):
        conn = _connector()
        with patch.object(conn._session, "get") as mock_get:
            mock_get.return_value = MagicMock(
                ok=True, status_code=200,
                json=lambda: {"result": None, "duration": 0, "timestamp": 0, "url": ""},
            )
            result = conn.get_build_status("my-job", 1)
            assert result["status"] == "RUNNING"

    def test_404_raises_job_not_found(self):
        conn = _connector()
        with patch.object(conn._session, "get") as mock_get:
            mock_get.return_value = MagicMock(ok=False, status_code=404)
            with pytest.raises(JenkinsJobNotFoundError):
                conn.get_build_status("missing-job", 1)


class TestGetBuildLog:
    def test_returns_log_text(self):
        conn = _connector()
        with patch.object(conn._session, "get") as mock_get:
            mock_get.return_value = MagicMock(ok=True, status_code=200, text="Build started\nBuild SUCCESS")
            log = conn.get_build_log("my-job", 1)
            assert "Build SUCCESS" in log

    def test_truncates_to_max_bytes(self):
        conn = _connector()
        long_log = "x" * 100000
        with patch.object(conn._session, "get") as mock_get:
            mock_get.return_value = MagicMock(ok=True, status_code=200, text=long_log)
            log = conn.get_build_log("my-job", 1, max_bytes=1000)
            assert len(log) == 1000


class TestListJobs:
    def test_returns_jobs(self):
        conn = _connector()
        with patch.object(conn._session, "get") as mock_get:
            mock_get.return_value = MagicMock(
                ok=True, status_code=200,
                json=lambda: {"jobs": [{"name": "job-a", "url": "http://...", "color": "blue"}]},
            )
            jobs = conn.list_jobs()
            assert len(jobs) == 1
            assert jobs[0]["name"] == "job-a"
