"""Tests cho secret_detection gate."""

from __future__ import annotations

import pytest
from app.tasks.quality_gate.diff_parser import parse_diff
from app.tasks.quality_gate.gates.secret_detection import run


def _diff(path: str, line: str) -> str:
    return f"--- /dev/null\n+++ b/{path}\n@@ -0,0 +1,1 @@\n+{line}\n"


class TestGitLabPAT:
    def test_detect_gitlab_pat(self):
        report = run(parse_diff(_diff("app/config.py", "token = 'glpat-UxFTGtNt2OWrkRQj7bQX'")))
        assert any(f.rule_id == "SD-001" for f in report.findings)
        assert report.findings[0].severity == "CRITICAL"


class TestHardcodedCredential:
    def test_detect_password_assignment(self):
        report = run(parse_diff(_diff("app/db.py", 'password = "supersecret123"')))
        assert any(f.rule_id == "SD-006" for f in report.findings)

    def test_detect_api_key_assignment(self):
        report = run(parse_diff(_diff("app/client.py", 'api_key = "abcdefghijklmnop"')))
        assert any(f.rule_id == "SD-006" for f in report.findings)

    def test_empty_string_not_flagged(self):
        report = run(parse_diff(_diff("app/config.py", 'password = ""')))
        assert not any(f.rule_id == "SD-006" for f in report.findings)


class TestPEMKey:
    def test_detect_private_key(self):
        report = run(parse_diff(_diff("app/auth.py", "-----BEGIN RSA PRIVATE KEY-----")))
        assert any(f.rule_id == "SD-005" for f in report.findings)


class TestCredentialsInURL:
    def test_detect_credentials_in_url(self):
        report = run(parse_diff(_diff("app/db.py", 'url = "postgresql://admin:password123@localhost/db"')))
        assert any(f.rule_id == "SD-007" for f in report.findings)


class TestSkipPaths:
    def test_skip_test_files(self):
        report = run(parse_diff(_diff("tests/test_auth.py", 'password = "testpassword123"')))
        assert report.findings == []

    def test_skip_env_example(self):
        report = run(parse_diff(_diff(".env.example", 'API_KEY="your-api-key-here"')))
        assert report.findings == []

    def test_skip_sample_file(self):
        report = run(parse_diff(_diff("config.sample", 'token = "glpat-UxFTGtNt2OWrkRQj7bQX"')))
        assert report.findings == []


class TestEmptyDiff:
    def test_empty_diff_no_findings(self):
        report = run(parse_diff(""))
        assert report.findings == []
