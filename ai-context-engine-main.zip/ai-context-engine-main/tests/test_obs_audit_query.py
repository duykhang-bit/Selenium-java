"""Tests cho audit_query."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

from app.tasks.observability.audit_query import AuditEvent, export_audit_logs, query_audit_logs


def _write_log(tmp_path: Path, filename: str, events: list[dict]) -> None:
    f = tmp_path / filename
    f.write_text("\n".join(json.dumps(e) for e in events) + "\n", encoding="utf-8")


class TestQueryAuditLogs:
    def test_returns_empty_when_no_logs(self, tmp_path):
        with patch("app.tasks.observability.audit_query.settings") as mock_settings:
            mock_settings.logs_dir = tmp_path
            result = query_audit_logs()
        assert result == []

    def test_reads_all_jsonl_files(self, tmp_path):
        _write_log(tmp_path, "rde_audit.jsonl", [
            {"event_type": "rde_generate_requirements", "created_at": "2024-01-01T10:00:00Z", "details": {"trace_id": "abc"}},
        ])
        _write_log(tmp_path, "qge_audit.jsonl", [
            {"event_type": "qge_analyze", "created_at": "2024-01-01T11:00:00Z", "details": {"trace_id": "xyz"}},
        ])
        with patch("app.tasks.observability.audit_query.settings") as mock_settings:
            mock_settings.logs_dir = tmp_path
            result = query_audit_logs()
        assert len(result) == 2

    def test_filter_by_event_type(self, tmp_path):
        _write_log(tmp_path, "audit.jsonl", [
            {"event_type": "rde_generate_requirements", "created_at": "2024-01-01T10:00:00Z", "details": {}},
            {"event_type": "qge_analyze", "created_at": "2024-01-01T11:00:00Z", "details": {}},
        ])
        with patch("app.tasks.observability.audit_query.settings") as mock_settings:
            mock_settings.logs_dir = tmp_path
            result = query_audit_logs(event_types=["qge_analyze"])
        assert len(result) == 1
        assert result[0].event_type == "qge_analyze"

    def test_filter_by_trace_id(self, tmp_path):
        _write_log(tmp_path, "audit.jsonl", [
            {"event_type": "evt", "created_at": "2024-01-01T10:00:00Z", "details": {"trace_id": "abc123"}},
            {"event_type": "evt", "created_at": "2024-01-01T11:00:00Z", "details": {"trace_id": "xyz789"}},
        ])
        with patch("app.tasks.observability.audit_query.settings") as mock_settings:
            mock_settings.logs_dir = tmp_path
            result = query_audit_logs(trace_id="abc123")
        assert len(result) == 1
        assert result[0].details["trace_id"] == "abc123"

    def test_limit_respected(self, tmp_path):
        events = [{"event_type": "evt", "created_at": f"2024-01-01T{i:02d}:00:00Z", "details": {}} for i in range(10)]
        _write_log(tmp_path, "audit.jsonl", events)
        with patch("app.tasks.observability.audit_query.settings") as mock_settings:
            mock_settings.logs_dir = tmp_path
            result = query_audit_logs(limit=3)
        assert len(result) == 3

    def test_sorted_desc(self, tmp_path):
        _write_log(tmp_path, "audit.jsonl", [
            {"event_type": "evt", "created_at": "2024-01-01T08:00:00Z", "details": {}},
            {"event_type": "evt", "created_at": "2024-01-01T10:00:00Z", "details": {}},
        ])
        with patch("app.tasks.observability.audit_query.settings") as mock_settings:
            mock_settings.logs_dir = tmp_path
            result = query_audit_logs()
        assert result[0].created_at > result[1].created_at


class TestExportAuditLogs:
    def _sample_events(self):
        return [AuditEvent(event_type="evt", created_at="2024-01-01T10:00:00Z",
                           details={"trace_id": "abc"}, source_file="test.jsonl")]

    def test_export_json_valid(self):
        events = self._sample_events()
        output = export_audit_logs(events, format="json")
        parsed = json.loads(output)
        assert isinstance(parsed, list)
        assert parsed[0]["event_type"] == "evt"

    def test_export_csv_has_header(self):
        events = self._sample_events()
        output = export_audit_logs(events, format="csv")
        assert "event_type" in output
        assert "created_at" in output

    def test_export_csv_has_data(self):
        events = self._sample_events()
        output = export_audit_logs(events, format="csv")
        lines = output.strip().splitlines()
        assert len(lines) == 2  # header + 1 data row
