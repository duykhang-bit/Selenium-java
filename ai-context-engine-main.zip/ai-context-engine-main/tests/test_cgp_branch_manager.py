"""Tests cho CGP branch_manager."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from app.tasks.code_gen.models import BranchAlreadyExistsError


def _mock_source(source_id: str = "gitlab:42") -> dict:
    return {
        "source_id": source_id,
        "external_id": "42",
        "connector_id": 1,
        "default_branch": "main",
    }


def _mock_connector_row() -> dict:
    return {"base_url": "https://gitlab.example.com", "token": "token123"}


class TestCreateBranch:
    def test_success(self):
        from app.tasks.code_gen import branch_manager
        with patch("app.tasks.code_gen.branch_manager.get_source", return_value=_mock_source()):
            with patch("app.tasks.code_gen.branch_manager.get_connector", return_value=_mock_connector_row()):
                mock_gl = MagicMock()
                mock_gl.get_branch.return_value = None
                mock_gl.create_branch.return_value = {"name": "feature/x"}
                with patch("app.tasks.code_gen.branch_manager.GitLabConnector", return_value=mock_gl):
                    result = branch_manager.create_branch("gitlab:42", "feature/x")
                    assert result["name"] == "feature/x"

    def test_raises_when_branch_exists(self):
        from app.tasks.code_gen import branch_manager
        with patch("app.tasks.code_gen.branch_manager.get_source", return_value=_mock_source()):
            with patch("app.tasks.code_gen.branch_manager.get_connector", return_value=_mock_connector_row()):
                mock_gl = MagicMock()
                mock_gl.get_branch.return_value = {"name": "feature/x"}  # already exists
                with patch("app.tasks.code_gen.branch_manager.GitLabConnector", return_value=mock_gl):
                    with pytest.raises(BranchAlreadyExistsError):
                        branch_manager.create_branch("gitlab:42", "feature/x")

    def test_raises_when_source_not_found(self):
        from app.tasks.code_gen import branch_manager
        with patch("app.tasks.code_gen.branch_manager.get_source", return_value=None):
            with pytest.raises(KeyError):
                branch_manager.create_branch("gitlab:999", "feature/x")


class TestCommitFiles:
    def test_success(self):
        from app.tasks.code_gen import branch_manager
        files = [{"file_path": "app/foo.py", "content": "# code", "action": "create"}]
        with patch("app.tasks.code_gen.branch_manager.get_source", return_value=_mock_source()):
            with patch("app.tasks.code_gen.branch_manager.get_connector", return_value=_mock_connector_row()):
                mock_gl = MagicMock()
                mock_gl.commit_files.return_value = {"id": "abc123"}
                with patch("app.tasks.code_gen.branch_manager.GitLabConnector", return_value=mock_gl):
                    result = branch_manager.commit_files("gitlab:42", "feature/x", files, "feat: add foo")
                    assert result["id"] == "abc123"


class TestCreateMR:
    def test_success(self):
        from app.tasks.code_gen import branch_manager
        with patch("app.tasks.code_gen.branch_manager.get_source", return_value=_mock_source()):
            with patch("app.tasks.code_gen.branch_manager.get_connector", return_value=_mock_connector_row()):
                mock_gl = MagicMock()
                mock_gl.create_merge_request.return_value = {
                    "iid": 7, "web_url": "https://gitlab.example.com/mr/7"
                }
                with patch("app.tasks.code_gen.branch_manager.GitLabConnector", return_value=mock_gl):
                    result = branch_manager.create_mr("gitlab:42", "feature/x", "feat: new feature")
                    assert result.mr_id == 7
                    assert result.mr_url == "https://gitlab.example.com/mr/7"
                    assert result.branch_name == "feature/x"
