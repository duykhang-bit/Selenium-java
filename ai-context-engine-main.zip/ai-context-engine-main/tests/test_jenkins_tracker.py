"""Tests cho deployment tracker."""

from __future__ import annotations

import pytest
from app.catalog.database import init_database
from app.tasks.jenkins.tracker import get_deployments, get_latest, record_deployment


@pytest.fixture(autouse=True)
def setup_db(tmp_path, monkeypatch):
    """Use temp DB for each test."""
    import app.core.config as cfg_mod
    monkeypatch.setenv("AI_CONTEXT_V2_DATA_DIR", str(tmp_path))
    # Patch catalog_db_path property via settings instance workaround
    from unittest.mock import patch, PropertyMock
    with patch.object(type(cfg_mod.settings), "catalog_db_path", new_callable=PropertyMock) as mock_db:
        mock_db.return_value = tmp_path / "catalog.db"
        with patch.object(type(cfg_mod.settings), "data_dir", new_callable=PropertyMock) as mock_data:
            mock_data.return_value = tmp_path
            init_database()
            yield


class TestRecordDeployment:
    def test_record_and_retrieve(self):
        rec = record_deployment("order-service", "uat", 42, "deploy-uat", "success")
        assert rec.service == "order-service"
        assert rec.environment == "uat"
        assert rec.build_number == 42
        assert rec.status == "success"

    def test_record_id_generated(self):
        rec = record_deployment("svc", "prod", 1, "job", "success")
        assert rec.record_id != ""


class TestGetDeployments:
    def test_filter_by_service(self):
        record_deployment("svc-a", "uat", 1, "job", "success")
        record_deployment("svc-b", "uat", 2, "job", "success")
        results = get_deployments(service="svc-a")
        assert all(r.service == "svc-a" for r in results)

    def test_filter_by_environment(self):
        record_deployment("svc", "uat", 1, "job", "success")
        record_deployment("svc", "prod", 2, "job", "success")
        results = get_deployments(environment="prod")
        assert all(r.environment == "prod" for r in results)

    def test_limit(self):
        for i in range(5):
            record_deployment("svc", "uat", i, "job", "success")
        results = get_deployments(limit=3)
        assert len(results) <= 3


class TestGetLatest:
    def test_returns_most_recent(self):
        record_deployment("svc", "uat", 1, "job", "success")
        record_deployment("svc", "uat", 2, "job", "success")
        latest = get_latest("svc", "uat")
        assert latest is not None
        assert latest.build_number == 2

    def test_returns_none_when_no_records(self):
        result = get_latest("nonexistent", "uat")
        assert result is None
