"""Tests for app/tasks/design_generator.py

Validates: Requirements 2.3, 2.4
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from app.tasks.compliance_checker import ComplianceReport
from app.tasks.impact_analyzer import ImpactReport
from app.tasks.design_generator import (
    DesignGeneratorResult,
    generate_design,
    _extract_title,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

PHARMACY_REQ_DOC = """\
# Tài liệu Yêu cầu: Hệ thống nhà thuốc
## Giới thiệu
Xây dựng hệ thống nhà thuốc bán lẻ thuốc kê đơn (Rx) và quản lý dược phẩm.
"""

VACCINATION_REQ_DOC = """\
# Tài liệu Yêu cầu: Hệ thống tiêm chủng
## Giới thiệu
Xây dựng hệ thống quản lý tiêm chủng vắc xin cho trẻ em.
"""

LAB_EMR_REQ_DOC = """\
# Tài liệu Yêu cầu: Hệ thống bệnh án điện tử
## Giới thiệu
Xây dựng hệ thống quản lý hồ sơ bệnh án điện tử EMR và xét nghiệm.
"""

GENERIC_REQ_DOC = """\
# Tài liệu Yêu cầu: Hệ thống quản lý nhân sự
## Giới thiệu
Xây dựng hệ thống quản lý nhân sự nội bộ.
"""

PAYMENT_REQ_DOC = """\
# Tài liệu Yêu cầu: Hệ thống thanh toán
## Giới thiệu
Xây dựng hệ thống thanh toán thẻ POS và giao dịch.
"""


def _mock_search_results(n: int = 3) -> list[MagicMock]:
    results = []
    for i in range(n):
        r = MagicMock()
        r.content = f"Context chunk {i}: relevant code snippet"
        r.score = 0.9 - i * 0.1
        r.metadata = {"source": f"app/tasks/module_{i}.py"}
        results.append(r)
    return results


# ---------------------------------------------------------------------------
# Test: DesignGeneratorResult dataclass
# ---------------------------------------------------------------------------


def test_result_dataclass_fields():
    """DesignGeneratorResult phải có đủ các field theo spec."""
    compliance = ComplianceReport(
        passed=True, domains_checked=[], violations=[], warnings=[],
        checked_at="2024-01-01T00:00:00+00:00",
    )
    impact = ImpactReport(
        impacted_services=[], total_high=0, total_medium=0, total_low=0,
        analyzed_at="2024-01-01T00:00:00+00:00", trace_id="t1",
    )
    result = DesignGeneratorResult(
        document="# Design",
        domains=["PHARMACY"],
        compliance_report=compliance,
        impact_report=impact,
        context_chunks_used=5,
        generated_at="2024-01-01T00:00:00+00:00",
        trace_id="abc123",
    )
    assert result.document == "# Design"
    assert result.domains == ["PHARMACY"]
    assert result.compliance_report is compliance
    assert result.impact_report is impact
    assert result.context_chunks_used == 5
    assert result.generated_at == "2024-01-01T00:00:00+00:00"
    assert result.trace_id == "abc123"


# ---------------------------------------------------------------------------
# Test: _extract_title
# ---------------------------------------------------------------------------


def test_extract_title_from_req_header():
    doc = "# Tài liệu Yêu cầu: Hệ thống nhà thuốc\n## Giới thiệu"
    assert _extract_title(doc) == "Hệ thống nhà thuốc"


def test_extract_title_from_generic_header():
    doc = "# My System\nSome content"
    assert _extract_title(doc) == "My System"


def test_extract_title_fallback_to_first_line():
    doc = "Hệ thống quản lý kho\nMore content"
    assert _extract_title(doc) == "Hệ thống quản lý kho"


def test_extract_title_truncates_long_title():
    doc = "# Tài liệu Yêu cầu: " + "A" * 200
    title = _extract_title(doc)
    assert len(title) <= 120


# ---------------------------------------------------------------------------
# Test: Document structure — required sections
# ---------------------------------------------------------------------------


@patch("app.retrieval.search.search")
def test_document_contains_all_required_sections(mock_search):
    """Document sinh ra phải có đủ các section theo template chuẩn."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(GENERIC_REQ_DOC)

    doc = result.document
    assert "# Tài liệu Thiết kế:" in doc
    assert "## Tổng quan" in doc
    assert "## Kiến trúc" in doc
    assert "## Components và Interfaces" in doc
    assert "## Data Models (ERD)" in doc
    assert "## Data Flow Diagram" in doc
    assert "## Threat Model" in doc
    assert "## Data Retention Policy" in doc
    assert "## Backup & Recovery Strategy" in doc
    assert "## API Contract" in doc
    assert "## Error Handling" in doc
    assert "## Testing Strategy" in doc


@patch("app.retrieval.search.search")
def test_document_contains_mermaid_diagrams(mock_search):
    """Document phải có Mermaid diagrams cho kiến trúc và data flow."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(GENERIC_REQ_DOC)

    doc = result.document
    assert "```mermaid" in doc
    assert "graph TD" in doc or "sequenceDiagram" in doc or "erDiagram" in doc


@patch("app.retrieval.search.search")
def test_document_title_extracted_from_requirements(mock_search):
    """Tiêu đề design document phải được trích xuất từ requirements_doc."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(PHARMACY_REQ_DOC)

    assert "Hệ thống nhà thuốc" in result.document


# ---------------------------------------------------------------------------
# Test: Healthcare domain → phân quyền theo chức danh
# ---------------------------------------------------------------------------


@patch("app.retrieval.search.search")
def test_pharmacy_domain_generates_access_control(mock_search):
    """PHARMACY domain phải sinh ra phần phân quyền theo chức danh y tế."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(PHARMACY_REQ_DOC)

    assert "PHARMACY" in result.domains
    doc = result.document
    assert "## Phân quyền truy cập" in doc
    assert "Bác sĩ" in doc
    assert "Dược sĩ" in doc
    assert "Điều dưỡng" in doc


@patch("app.retrieval.search.search")
def test_vaccination_domain_generates_access_control(mock_search):
    """VACCINATION domain phải sinh ra phần phân quyền."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(VACCINATION_REQ_DOC)

    assert "VACCINATION" in result.domains
    assert "## Phân quyền truy cập" in result.document


@patch("app.retrieval.search.search")
def test_lab_emr_domain_generates_access_control(mock_search):
    """LAB_EMR domain phải sinh ra phần phân quyền."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(LAB_EMR_REQ_DOC)

    assert "LAB_EMR" in result.domains
    assert "## Phân quyền truy cập" in result.document


@patch("app.retrieval.search.search")
def test_non_healthcare_domain_no_access_control(mock_search):
    """Domain không phải healthcare KHÔNG sinh ra phần phân quyền y tế."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(GENERIC_REQ_DOC)

    assert "## Phân quyền truy cập" not in result.document


@patch("app.retrieval.search.search")
def test_payment_domain_no_healthcare_access_control(mock_search):
    """PAYMENT domain không phải healthcare — không sinh phân quyền y tế."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(PAYMENT_REQ_DOC)

    assert "## Phân quyền truy cập" not in result.document


# ---------------------------------------------------------------------------
# Test: compliance_report được đính kèm đúng
# ---------------------------------------------------------------------------


@patch("app.retrieval.search.search")
def test_compliance_report_attached(mock_search):
    """compliance_report phải được đính kèm vào result."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(GENERIC_REQ_DOC)

    assert isinstance(result.compliance_report, ComplianceReport)
    assert hasattr(result.compliance_report, "passed")
    assert hasattr(result.compliance_report, "violations")
    assert hasattr(result.compliance_report, "domains_checked")
    assert hasattr(result.compliance_report, "checked_at")


@patch("app.retrieval.search.search")
def test_compliance_report_passes_for_complete_design(mock_search):
    """Design document đầy đủ phải pass compliance check (không có violations)."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(GENERIC_REQ_DOC)

    # Template sinh ra đầy đủ các section → phải pass DESIGN-001..004
    assert result.compliance_report.passed is True


@patch("app.retrieval.search.search")
def test_compliance_report_checks_design_rules(mock_search):
    """compliance_report phải dùng check_design (không phải check_requirements)."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        with patch("app.tasks.design_generator.check_design") as mock_check:
            mock_check.return_value = ComplianceReport(
                passed=True, domains_checked=[], violations=[], warnings=[],
                checked_at="2024-01-01T00:00:00+00:00",
            )
            result = generate_design(GENERIC_REQ_DOC)

    mock_check.assert_called_once()


# ---------------------------------------------------------------------------
# Test: impact_report được đính kèm đúng
# ---------------------------------------------------------------------------


@patch("app.retrieval.search.search")
def test_impact_report_attached(mock_search):
    """impact_report phải được đính kèm vào result."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(GENERIC_REQ_DOC)

    assert isinstance(result.impact_report, ImpactReport)
    assert hasattr(result.impact_report, "impacted_services")
    assert hasattr(result.impact_report, "total_high")
    assert hasattr(result.impact_report, "total_medium")
    assert hasattr(result.impact_report, "total_low")


@patch("app.retrieval.search.search")
def test_impact_report_analyze_impact_called(mock_search):
    """analyze_impact phải được gọi để sinh impact_report."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        with patch("app.tasks.design_generator.analyze_impact") as mock_impact:
            mock_impact.return_value = ImpactReport(
                impacted_services=[], total_high=0, total_medium=0, total_low=0,
                analyzed_at="2024-01-01T00:00:00+00:00", trace_id="t1",
            )
            result = generate_design(GENERIC_REQ_DOC, trace_id="test-impact")

    mock_impact.assert_called_once()
    # trace_id phải được truyền vào analyze_impact
    call_kwargs = mock_impact.call_args
    assert call_kwargs.kwargs.get("trace_id") == "test-impact" or \
           "test-impact" in str(call_kwargs)


# ---------------------------------------------------------------------------
# Test: ChromaDB integration
# ---------------------------------------------------------------------------


@patch("app.retrieval.search.search")
def test_context_chunks_used_reflects_search_results(mock_search):
    """context_chunks_used phải phản ánh số lượng kết quả từ ChromaDB."""
    mock_search.return_value = _mock_search_results(7)

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(GENERIC_REQ_DOC, top_k=7)

    # search được gọi ít nhất 1 lần (có thể 2 lần: generate_design + analyze_impact)
    assert mock_search.call_count >= 1
    assert result.context_chunks_used == 7


@patch("app.retrieval.search.search")
def test_graceful_degradation_when_chromadb_fails(mock_search):
    """Khi ChromaDB không khả dụng, generator vẫn hoạt động bình thường."""
    mock_search.side_effect = Exception("ChromaDB connection failed")

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(GENERIC_REQ_DOC)

    assert result.document
    assert "# Tài liệu Thiết kế:" in result.document
    assert result.context_chunks_used == 0


@patch("app.retrieval.search.search")
def test_search_called_with_top_k_15_by_default(mock_search):
    """ChromaDB search phải được gọi với top_k=15 theo mặc định."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        generate_design(GENERIC_REQ_DOC)

    # Kiểm tra lần gọi đầu tiên (generate_design context search)
    first_call = mock_search.call_args_list[0]
    top_k_val = first_call.kwargs.get("top_k") or (first_call.args[2] if len(first_call.args) > 2 else None)
    assert top_k_val == 15


# ---------------------------------------------------------------------------
# Test: Audit record
# ---------------------------------------------------------------------------


@patch("app.retrieval.search.search")
def test_audit_record_written_after_generate(mock_search):
    """Audit record phải được ghi vào rde_audit.jsonl sau mỗi lần generate."""
    mock_search.return_value = []

    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "rde_audit.jsonl"

        with patch("app.tasks.design_generator.settings") as mock_settings:
            mock_settings.logs_dir = Path(tmpdir)
            generate_design(GENERIC_REQ_DOC, trace_id="test-design-audit")

        assert log_path.exists(), "rde_audit.jsonl phải được tạo"
        lines = log_path.read_text(encoding="utf-8").strip().splitlines()
        assert len(lines) >= 1

        record = json.loads(lines[0])
        assert record["event_type"] == "rde_generate_design"
        assert "created_at" in record
        assert "details" in record


@patch("app.retrieval.search.search")
def test_audit_record_format_correct(mock_search):
    """Audit record phải có đúng format theo spec."""
    mock_search.return_value = []

    with tempfile.TemporaryDirectory() as tmpdir:
        with patch("app.tasks.design_generator.settings") as mock_settings:
            mock_settings.logs_dir = Path(tmpdir)
            generate_design(PHARMACY_REQ_DOC, trace_id="trace-design-xyz")

        log_path = Path(tmpdir) / "rde_audit.jsonl"
        record = json.loads(log_path.read_text(encoding="utf-8").strip().splitlines()[0])

        details = record["details"]
        assert "audit_id" in details
        assert details["trace_id"] == "trace-design-xyz"
        assert details["action"] == "generate_design"
        assert details["actor"] == "system"
        assert isinstance(details["domains"], list)
        assert isinstance(details["compliance_passed"], bool)
        assert isinstance(details["violations_count"], int)
        assert "duration_ms" in details
        assert "confluence_page_id" in details


@patch("app.retrieval.search.search")
def test_audit_record_no_pii(mock_search):
    """Audit record KHÔNG được chứa nội dung requirements (PII)."""
    mock_search.return_value = []
    sensitive_doc = "# Tài liệu Yêu cầu: Bệnh nhân Nguyễn Văn A, SĐT 0901234567"

    with tempfile.TemporaryDirectory() as tmpdir:
        with patch("app.tasks.design_generator.settings") as mock_settings:
            mock_settings.logs_dir = Path(tmpdir)
            generate_design(sensitive_doc, trace_id="trace-pii-test")

        log_path = Path(tmpdir) / "rde_audit.jsonl"
        raw_content = log_path.read_text(encoding="utf-8")

        assert "Nguyễn Văn A" not in raw_content
        assert "0901234567" not in raw_content


# ---------------------------------------------------------------------------
# Test: trace_id và generated_at
# ---------------------------------------------------------------------------


@patch("app.retrieval.search.search")
def test_trace_id_propagated_to_result(mock_search):
    """trace_id được truyền vào phải xuất hiện trong result."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(GENERIC_REQ_DOC, trace_id="my-design-trace")

    assert result.trace_id == "my-design-trace"


@patch("app.retrieval.search.search")
def test_trace_id_auto_generated_when_none(mock_search):
    """Khi trace_id=None, phải tự sinh trace_id."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(GENERIC_REQ_DOC, trace_id=None)

    assert result.trace_id is not None
    assert len(result.trace_id) > 0


@patch("app.retrieval.search.search")
def test_generated_at_is_iso8601_utc(mock_search):
    """generated_at phải là ISO 8601 UTC string."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(GENERIC_REQ_DOC)

    from datetime import datetime
    dt = datetime.fromisoformat(result.generated_at)
    assert dt.tzinfo is not None


# ---------------------------------------------------------------------------
# Test: Data retention policy theo domain
# ---------------------------------------------------------------------------


@patch("app.retrieval.search.search")
def test_pharmacy_data_retention_includes_5_years(mock_search):
    """PHARMACY domain phải có data retention 5 năm cho giao dịch thuốc."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(PHARMACY_REQ_DOC)

    assert "5 năm" in result.document
    assert "Luật Dược" in result.document


@patch("app.retrieval.search.search")
def test_vaccination_data_retention_includes_20_years(mock_search):
    """VACCINATION domain phải có data retention 20 năm."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(VACCINATION_REQ_DOC)

    assert "20 năm" in result.document
    assert "Thông tư 09" in result.document


@patch("app.retrieval.search.search")
def test_lab_emr_data_retention_includes_10_and_15_years(mock_search):
    """LAB_EMR domain phải có data retention 10 và 15 năm."""
    mock_search.return_value = []

    with patch("app.tasks.design_generator.settings") as mock_settings:
        mock_settings.logs_dir = Path(tempfile.mkdtemp())
        result = generate_design(LAB_EMR_REQ_DOC)

    assert "10 năm" in result.document
    assert "15 năm" in result.document
