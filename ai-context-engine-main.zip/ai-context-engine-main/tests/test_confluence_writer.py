"""Tests for app/tasks/confluence_writer.py

Validates: Requirements 6.3, 6.4
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import requests

from app.tasks.confluence_writer import (
    ConfluenceWriteResult,
    write_document,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_create_response(page_id: str = "111", title: str = "Test Page") -> dict:
    return {
        "id": page_id,
        "title": title,
        "_links": {"webui": f"/pages/viewpage.action?pageId={page_id}"},
        "version": {"number": 1},
    }


def _mock_get_page_response(page_id: str = "222", version: int = 3) -> dict:
    return {
        "id": page_id,
        "title": "Existing Page",
        "version": {"number": version},
        "_links": {"webui": f"/pages/viewpage.action?pageId={page_id}"},
    }


def _mock_update_response(page_id: str = "222", version: int = 4) -> dict:
    return {
        "id": page_id,
        "title": "Updated Page",
        "_links": {"webui": f"/pages/viewpage.action?pageId={page_id}"},
        "version": {"number": version},
    }


def _patch_settings(tmpdir: str):
    """Patch settings.logs_dir và confluence config."""
    mock_settings = MagicMock()
    mock_settings.logs_dir = Path(tmpdir)
    mock_settings.confluence_base_url = "https://confluence.example.com"
    mock_settings.confluence_token = "test-token"
    mock_settings.confluence_username = "user@example.com"
    return mock_settings


# ---------------------------------------------------------------------------
# Test: ConfluenceWriteResult dataclass
# ---------------------------------------------------------------------------


class TestConfluenceWriteResult:
    def test_dataclass_fields(self):
        result = ConfluenceWriteResult(
            page_id="123",
            page_url="https://example.com/page",
            version=2,
            action="created",
            audit_id="abc12345",
            written_at="2024-01-15T10:00:00+00:00",
        )
        assert result.page_id == "123"
        assert result.page_url == "https://example.com/page"
        assert result.version == 2
        assert result.action == "created"
        assert result.audit_id == "abc12345"
        assert result.written_at == "2024-01-15T10:00:00+00:00"

    def test_action_values(self):
        for action in ("created", "updated"):
            r = ConfluenceWriteResult(
                page_id="1", page_url="", version=1,
                action=action, audit_id="x", written_at="2024-01-01T00:00:00+00:00",
            )
            assert r.action == action


# ---------------------------------------------------------------------------
# Test: ValueError khi Confluence chưa cấu hình
# ---------------------------------------------------------------------------


class TestConfluenceNotConfigured:
    def test_raises_value_error_when_no_base_url(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            mock_settings.confluence_base_url = ""

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with pytest.raises(ValueError, match="Confluence chưa được cấu hình"):
                    write_document(
                        title="Test",
                        content_markdown="# Hello",
                        space_key="PROJ",
                        retry_delay_s=0,
                    )


# ---------------------------------------------------------------------------
# Test: create_page (existing_page_id=None)
# ---------------------------------------------------------------------------


class TestWriteDocumentCreate:
    def test_create_page_success(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            create_resp = _mock_create_response("111")

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.return_value = create_resp

                    result = write_document(
                        title="New Page",
                        content_markdown="# Hello\n\nContent",
                        space_key="PROJ",
                        actor="test-user",
                        trace_id="trace-create-001",
                        retry_delay_s=0,
                    )

            assert result.page_id == "111"
            assert result.action == "created"
            assert result.version == 1
            assert result.audit_id
            assert result.written_at
            instance.create_page.assert_called_once()

    def test_create_page_with_parent(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            create_resp = _mock_create_response("333")

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.return_value = create_resp

                    result = write_document(
                        title="Child Page",
                        content_markdown="# Child",
                        space_key="PROJ",
                        parent_page_id="100",
                        retry_delay_s=0,
                    )

            assert result.action == "created"
            call_kwargs = instance.create_page.call_args
            assert call_kwargs.kwargs.get("parent_id") == "100" or call_kwargs.args[3] == "100"


# ---------------------------------------------------------------------------
# Test: update_page (existing_page_id provided)
# ---------------------------------------------------------------------------


class TestWriteDocumentUpdate:
    def test_update_page_success(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            get_resp = _mock_get_page_response("222", version=3)
            update_resp = _mock_update_response("222", version=4)

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.get_page.return_value = get_resp
                    instance.update_page.return_value = update_resp

                    result = write_document(
                        title="Updated Page",
                        content_markdown="# Updated",
                        space_key="PROJ",
                        existing_page_id="222",
                        actor="api-user",
                        trace_id="trace-update-001",
                        retry_delay_s=0,
                    )

            assert result.page_id == "222"
            assert result.action == "updated"
            assert result.version == 4
            instance.get_page.assert_called_once_with("222")
            # update_page phải được gọi với version = current + 1 = 4
            call_kwargs = instance.update_page.call_args
            assert call_kwargs.kwargs.get("version_number") == 4 or call_kwargs.args[3] == 4


# ---------------------------------------------------------------------------
# Test: Retry logic
# ---------------------------------------------------------------------------


class TestRetryLogic:
    def test_retries_3_times_on_connection_error(self):
        """Khi Confluence không khả dụng, phải retry đúng 3 lần."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            conn_error = requests.ConnectionError("Connection refused")

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.side_effect = conn_error

                    with patch("app.tasks.confluence_writer.time.sleep") as mock_sleep:
                        with pytest.raises(requests.ConnectionError):
                            write_document(
                                title="Test",
                                content_markdown="# Test",
                                space_key="PROJ",
                                retry_delay_s=0.001,
                            )

            # create_page phải được gọi đúng 3 lần
            assert instance.create_page.call_count == 3

    def test_retry_delay_called_between_attempts(self):
        """time.sleep phải được gọi giữa các lần retry (2 lần cho 3 attempts)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.side_effect = Exception("Timeout")

                    with patch("app.tasks.confluence_writer.time.sleep") as mock_sleep:
                        with pytest.raises(Exception):
                            write_document(
                                title="Test",
                                content_markdown="# Test",
                                space_key="PROJ",
                                retry_delay_s=5.0,
                            )

            # sleep phải được gọi 2 lần (sau attempt 1 và 2, không sau attempt 3)
            assert mock_sleep.call_count == 2
            mock_sleep.assert_called_with(5.0)

    def test_succeeds_on_second_attempt(self):
        """Nếu attempt 1 thất bại nhưng attempt 2 thành công, trả về kết quả."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            create_resp = _mock_create_response("555")

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.side_effect = [
                        requests.ConnectionError("First fail"),
                        create_resp,
                    ]

                    with patch("app.tasks.confluence_writer.time.sleep"):
                        result = write_document(
                            title="Test",
                            content_markdown="# Test",
                            space_key="PROJ",
                            retry_delay_s=0.001,
                        )

            assert result.page_id == "555"
            assert result.action == "created"
            assert instance.create_page.call_count == 2

    def test_raises_last_exception_after_all_retries(self):
        """Sau 3 lần retry thất bại, phải raise exception cuối cùng."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.side_effect = [
                        requests.ConnectionError("Error 1"),
                        requests.ConnectionError("Error 2"),
                        requests.ConnectionError("Final error"),
                    ]

                    with patch("app.tasks.confluence_writer.time.sleep"):
                        with pytest.raises(requests.ConnectionError, match="Final error"):
                            write_document(
                                title="Test",
                                content_markdown="# Test",
                                space_key="PROJ",
                                retry_delay_s=0.001,
                            )


# ---------------------------------------------------------------------------
# Test: Queue khi thất bại sau 3 lần retry
# ---------------------------------------------------------------------------


class TestQueueOnFailure:
    def test_queue_file_created_on_all_retries_fail(self):
        """Khi tất cả 3 retry thất bại, phải lưu record vào confluence_write_queue.jsonl."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            queue_path = Path(tmpdir) / "confluence_write_queue.jsonl"

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.side_effect = Exception("Connection refused")

                    with patch("app.tasks.confluence_writer.time.sleep"):
                        with pytest.raises(Exception):
                            write_document(
                                title="My Doc",
                                content_markdown="# Content",
                                space_key="PROJ",
                                actor="system",
                                trace_id="trace-queue-001",
                                retry_delay_s=0.001,
                            )

            assert queue_path.exists(), "confluence_write_queue.jsonl phải được tạo"
            lines = queue_path.read_text(encoding="utf-8").strip().splitlines()
            assert len(lines) == 1

    def test_queue_record_format(self):
        """Queue record phải có đúng format theo spec."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            queue_path = Path(tmpdir) / "confluence_write_queue.jsonl"

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.side_effect = Exception("Timeout error")

                    with patch("app.tasks.confluence_writer.time.sleep"):
                        with pytest.raises(Exception):
                            write_document(
                                title="Queue Test",
                                content_markdown="# Test",
                                space_key="MYSPACE",
                                parent_page_id="100",
                                existing_page_id=None,
                                actor="api-user",
                                trace_id="trace-queue-format",
                                retry_delay_s=0.001,
                            )

            record = json.loads(queue_path.read_text(encoding="utf-8").strip())
            assert "queued_at" in record
            assert record["trace_id"] == "trace-queue-format"
            assert record["title"] == "Queue Test"
            assert record["space_key"] == "MYSPACE"
            assert record["parent_page_id"] == "100"
            assert record["existing_page_id"] is None
            assert record["actor"] == "api-user"
            assert record["retry_count"] == 3
            assert "Timeout error" in record["last_error"]

    def test_queue_not_written_on_success(self):
        """Khi write thành công, không được tạo queue file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            queue_path = Path(tmpdir) / "confluence_write_queue.jsonl"

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.return_value = _mock_create_response("999")

                    write_document(
                        title="Success",
                        content_markdown="# OK",
                        space_key="PROJ",
                        retry_delay_s=0,
                    )

            assert not queue_path.exists(), "Queue file không được tạo khi thành công"

    def test_multiple_failures_append_to_queue(self):
        """Nhiều lần thất bại phải append nhiều record vào queue."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            queue_path = Path(tmpdir) / "confluence_write_queue.jsonl"

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.side_effect = Exception("Error")

                    with patch("app.tasks.confluence_writer.time.sleep"):
                        for i in range(2):
                            with pytest.raises(Exception):
                                write_document(
                                    title=f"Doc {i}",
                                    content_markdown="# Test",
                                    space_key="PROJ",
                                    trace_id=f"trace-{i}",
                                    retry_delay_s=0.001,
                                )

            lines = queue_path.read_text(encoding="utf-8").strip().splitlines()
            assert len(lines) == 2


# ---------------------------------------------------------------------------
# Test: Audit log
# ---------------------------------------------------------------------------


class TestAuditLog:
    def test_audit_record_written_on_create(self):
        """Audit record phải được ghi vào rde_audit.jsonl sau khi create thành công."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            audit_path = Path(tmpdir) / "rde_audit.jsonl"

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.return_value = _mock_create_response("111")

                    write_document(
                        title="Audit Test",
                        content_markdown="# Hello",
                        space_key="PROJ",
                        actor="test-actor",
                        trace_id="trace-audit-001",
                        retry_delay_s=0,
                    )

            assert audit_path.exists(), "rde_audit.jsonl phải được tạo"
            record = json.loads(audit_path.read_text(encoding="utf-8").strip())
            assert record["event_type"] == "rde_confluence_write"
            assert "created_at" in record
            assert "details" in record

    def test_audit_record_format_correct(self):
        """Audit record phải có đúng format theo spec."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            audit_path = Path(tmpdir) / "rde_audit.jsonl"

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.return_value = _mock_create_response("222")

                    write_document(
                        title="Format Test",
                        content_markdown="# Content",
                        space_key="PROJ",
                        actor="system",
                        trace_id="trace-format-001",
                        retry_delay_s=0,
                    )

            record = json.loads(audit_path.read_text(encoding="utf-8").strip())
            details = record["details"]
            assert "audit_id" in details
            assert details["trace_id"] == "trace-format-001"
            assert details["action"] == "created"
            assert details["actor"] == "system"
            assert details["page_id"] == "222"
            assert "page_url" in details
            assert isinstance(details["version"], int)
            assert details["title"] == "Format Test"

    def test_audit_record_action_updated_on_update(self):
        """Audit record phải có action='updated' khi update page."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            audit_path = Path(tmpdir) / "rde_audit.jsonl"

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.get_page.return_value = _mock_get_page_response("333", version=2)
                    instance.update_page.return_value = _mock_update_response("333", version=3)

                    write_document(
                        title="Updated",
                        content_markdown="# Updated",
                        space_key="PROJ",
                        existing_page_id="333",
                        actor="editor",
                        trace_id="trace-update-audit",
                        retry_delay_s=0,
                    )

            record = json.loads(audit_path.read_text(encoding="utf-8").strip())
            assert record["details"]["action"] == "updated"
            assert record["details"]["actor"] == "editor"

    def test_audit_record_no_content_markdown(self):
        """Audit record KHÔNG được chứa content_markdown (không lưu nội dung đầy đủ)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            audit_path = Path(tmpdir) / "rde_audit.jsonl"
            sensitive_content = "SECRET_CONTENT_SHOULD_NOT_APPEAR_IN_LOG_XYZ123"

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.return_value = _mock_create_response("444")

                    write_document(
                        title="PII Test",
                        content_markdown=f"# Title\n\n{sensitive_content}",
                        space_key="PROJ",
                        retry_delay_s=0,
                    )

            raw = audit_path.read_text(encoding="utf-8")
            assert sensitive_content not in raw, "content_markdown không được xuất hiện trong audit log"

    def test_audit_record_appended_on_multiple_writes(self):
        """Mỗi lần write thành công phải append một record mới vào audit log."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            audit_path = Path(tmpdir) / "rde_audit.jsonl"

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.side_effect = [
                        _mock_create_response("10"),
                        _mock_create_response("20"),
                    ]

                    write_document(
                        title="Doc 1", content_markdown="# 1",
                        space_key="PROJ", trace_id="t1", retry_delay_s=0,
                    )
                    write_document(
                        title="Doc 2", content_markdown="# 2",
                        space_key="PROJ", trace_id="t2", retry_delay_s=0,
                    )

            lines = audit_path.read_text(encoding="utf-8").strip().splitlines()
            assert len(lines) == 2
            trace_ids = [json.loads(l)["details"]["trace_id"] for l in lines]
            assert "t1" in trace_ids
            assert "t2" in trace_ids

    def test_audit_not_written_on_failure(self):
        """Audit record KHÔNG được ghi khi write thất bại (sau tất cả retry)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)
            audit_path = Path(tmpdir) / "rde_audit.jsonl"

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.side_effect = Exception("Always fails")

                    with patch("app.tasks.confluence_writer.time.sleep"):
                        with pytest.raises(Exception):
                            write_document(
                                title="Fail",
                                content_markdown="# Fail",
                                space_key="PROJ",
                                retry_delay_s=0.001,
                            )

            assert not audit_path.exists(), "Audit log không được ghi khi write thất bại"


# ---------------------------------------------------------------------------
# Test: trace_id và written_at
# ---------------------------------------------------------------------------


class TestMetadata:
    def test_trace_id_auto_generated_when_none(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.return_value = _mock_create_response("1")

                    result = write_document(
                        title="T", content_markdown="# T",
                        space_key="PROJ", trace_id=None, retry_delay_s=0,
                    )

            assert result.audit_id
            assert result.written_at

    def test_written_at_is_iso8601(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            mock_settings = _patch_settings(tmpdir)

            with patch("app.tasks.confluence_writer.settings", mock_settings):
                with patch("app.tasks.confluence_writer.ConfluenceConnector") as MockConn:
                    instance = MockConn.return_value
                    instance.create_page.return_value = _mock_create_response("2")

                    result = write_document(
                        title="T", content_markdown="# T",
                        space_key="PROJ", retry_delay_s=0,
                    )

            from datetime import datetime
            dt = datetime.fromisoformat(result.written_at)
            assert dt.tzinfo is not None
