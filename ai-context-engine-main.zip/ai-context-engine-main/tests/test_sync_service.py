"""Tests for sync service: manual source registration and safe batch sync."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest


class TestSyncAndIngestSafe:
    def test_ok_true_on_success(self):
        """_sync_and_ingest_safe returns ok=True when sync succeeds."""
        mock_result = {"source": {"source_id": "gitlab:1"}, "ingest": {"chunks": 10}}

        with patch("app.sync.service.sync_and_ingest_source", return_value=mock_result):
            from app.sync.service import _sync_and_ingest_safe
            result = _sync_and_ingest_safe("gitlab:1")
            assert result["ok"] is True
            assert result["source"]["source_id"] == "gitlab:1"

    def test_ok_false_on_exception(self):
        """_sync_and_ingest_safe returns ok=False with error string on failure."""
        with patch("app.sync.service.sync_and_ingest_source", side_effect=RuntimeError("clone failed")):
            from app.sync.service import _sync_and_ingest_safe
            result = _sync_and_ingest_safe("gitlab:99")
            assert result["ok"] is False
            assert result["source_id"] == "gitlab:99"
            assert "clone failed" in result["error"]

    def test_error_is_logged(self):
        """Failure should be logged via logger.error."""
        with patch("app.sync.service.sync_and_ingest_source", side_effect=ValueError("bad")):
            with patch("app.sync.service.logger") as mock_logger:
                from app.sync import service as svc
                # Re-import to pick up patch
                result = svc._sync_and_ingest_safe("gitlab:42")
                assert result["ok"] is False
                mock_logger.error.assert_called_once()


class TestRegisterManualGitSource:
    def test_no_connector_registers_manual_source(self):
        """When no matching connector exists, source is registered as manual_git."""
        with (
            patch("app.sync.service.initialize_runtime"),
            patch("app.sync.service.connector_for_url", return_value=None),
            patch("app.sync.service.upsert_source") as mock_upsert,
        ):
            mock_upsert.return_value = {"source_id": "manual-git:test-repo", "title": "repo"}

            from app.sync.service import register_manual_git_source
            result = register_manual_git_source("https://git.example.com/org/repo.git")

            assert mock_upsert.called
            call_args = mock_upsert.call_args[0][0]
            assert call_args["connector_type"] == "manual_git"
            assert call_args["source_type"] == "git_repo"
            assert "org/repo" in call_args["path_with_namespace"]

    def test_with_connector_uses_gitlab_api(self):
        """When a matching connector exists, GitLab API is called for project info."""
        fake_connector = {"id": 1, "base_url": "https://git.example.com", "token": "tok"}
        fake_project = {
            "id": 42,
            "name": "repo",
            "path_with_namespace": "org/repo",
            "web_url": "https://git.example.com/org/repo",
            "http_url_to_repo": "https://git.example.com/org/repo.git",
            "default_branch": "main",
            "description": "Test repo",
        }

        with (
            patch("app.sync.service.initialize_runtime"),
            patch("app.sync.service.connector_for_url", return_value=fake_connector),
            patch("app.sync.service.GitLabConnector") as MockGitLab,
            patch("app.sync.service.upsert_source") as mock_upsert,
        ):
            mock_client = MagicMock()
            mock_client.get_project_by_url.return_value = fake_project
            MockGitLab.return_value = mock_client
            mock_upsert.return_value = {"source_id": "gitlab:42", "title": "repo"}

            from app.sync.service import register_manual_git_source
            result = register_manual_git_source("https://git.example.com/org/repo.git")

            assert mock_upsert.called
            call_args = mock_upsert.call_args[0][0]
            assert call_args["source_id"] == "gitlab:42"
            assert call_args["connector_type"] == "gitlab"
