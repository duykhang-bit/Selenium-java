"""Tests cho domain_detector — unit tests và property-based tests.

Validates: Yêu cầu 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7
Invariant: Compliance Injection
"""

from __future__ import annotations

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from app.tasks.domain_detector import (
    ComplianceClause,
    DomainDetectionResult,
    _KEYWORD_MAP,
    detect_domains,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

ALL_DOMAINS = list(_KEYWORD_MAP.keys())

# One representative keyword per domain (VI + EN)
_SAMPLE_KEYWORDS: dict[str, list[str]] = {
    "PHARMACY": ["thuốc", "dược", "kê đơn", "nhà thuốc", "dược sĩ", "drug", "pharmacy", "prescription", "rx"],
    "LAB_EMR": ["xét nghiệm", "bệnh án", "hồ sơ bệnh nhân", "lab", "medical record", "emr", "test result"],
    "VACCINATION": ["tiêm", "vắc xin", "tiêm chủng", "vaccine", "immunization", "vaccination"],
    "PAYMENT": ["thanh toán", "thẻ", "pos", "giao dịch", "payment", "card", "transaction", "pci"],
    "MEDICAL_DEVICE": ["thiết bị", "iot", "cảm biến", "monitor", "device", "sensor", "wearable"],
    "INFOSEC": ["bảo mật", "an toàn thông tin", "sự cố", "security", "incident", "vncert"],
}


# ---------------------------------------------------------------------------
# Property-based test — Task 1.1
# ---------------------------------------------------------------------------


@given(
    domain=st.sampled_from(ALL_DOMAINS),
    keyword=st.data(),
)
@settings(max_examples=60)
def test_compliance_injection_invariant(domain: str, keyword):
    """**Property 1: Compliance Injection Invariant**

    Với mọi domain được phát hiện, phải có ít nhất một compliance clause
    tương ứng với domain đó trong kết quả.

    **Validates: Yêu cầu 3.6, 3.7 và Invariant "Compliance Injection"**

    Hình thức:
        ∀ domain ∈ detected_domains(text) →
            ∃ clause ∈ result.compliance_clauses : clause.domain = domain
    """
    # Pick a keyword that belongs to the chosen domain
    kw = keyword.draw(st.sampled_from(_SAMPLE_KEYWORDS[domain]))
    text = f"Hệ thống cần xử lý {kw} theo quy định."

    result = detect_domains(text)

    # The domain must be detected (keyword guarantees a hit)
    assert domain in result.domains, (
        f"Domain '{domain}' phải được phát hiện khi text chứa keyword '{kw}'"
    )

    # Invariant: every detected domain must have ≥ 1 compliance clause
    for detected in result.domains:
        matching = [c for c in result.compliance_clauses if c.domain == detected]
        assert len(matching) >= 1, (
            f"Domain '{detected}' được phát hiện nhưng không có compliance clause tương ứng. "
            f"Vi phạm Compliance Injection Invariant."
        )


# ---------------------------------------------------------------------------
# Unit tests — Task 1.2
# ---------------------------------------------------------------------------


class TestPharmacyDomain:
    """Validates: Yêu cầu 3.1"""

    @pytest.mark.parametrize("keyword", ["thuốc", "dược", "kê đơn", "nhà thuốc", "dược sĩ"])
    def test_vi_keywords(self, keyword: str):
        result = detect_domains(f"Hệ thống quản lý {keyword} tại bệnh viện.")
        assert "PHARMACY" in result.domains

    @pytest.mark.parametrize("keyword", ["drug", "pharmacy", "prescription", "rx"])
    def test_en_keywords(self, keyword: str):
        result = detect_domains(f"System manages {keyword} dispensing.")
        assert "PHARMACY" in result.domains

    def test_score_positive(self):
        result = detect_domains("Quản lý thuốc và kê đơn tại nhà thuốc.")
        assert result.scores.get("PHARMACY", 0) > 0

    def test_compliance_clauses_present(self):
        result = detect_domains("Hệ thống bán thuốc kê đơn.")
        clauses = [c for c in result.compliance_clauses if c.domain == "PHARMACY"]
        assert len(clauses) >= 1


class TestLabEmrDomain:
    """Validates: Yêu cầu 3.2"""

    @pytest.mark.parametrize("keyword", ["xét nghiệm", "bệnh án", "hồ sơ bệnh nhân"])
    def test_vi_keywords(self, keyword: str):
        result = detect_domains(f"Hệ thống lưu trữ {keyword} điện tử.")
        assert "LAB_EMR" in result.domains

    @pytest.mark.parametrize("keyword", ["lab", "medical record", "emr", "test result"])
    def test_en_keywords(self, keyword: str):
        result = detect_domains(f"System stores {keyword} data.")
        assert "LAB_EMR" in result.domains

    def test_compliance_clauses_present(self):
        result = detect_domains("Quản lý bệnh án điện tử và xét nghiệm.")
        clauses = [c for c in result.compliance_clauses if c.domain == "LAB_EMR"]
        assert len(clauses) >= 1


class TestVaccinationDomain:
    """Validates: Yêu cầu 3.3"""

    @pytest.mark.parametrize("keyword", ["tiêm", "vắc xin", "tiêm chủng"])
    def test_vi_keywords(self, keyword: str):
        result = detect_domains(f"Hệ thống quản lý {keyword} cho trẻ em.")
        assert "VACCINATION" in result.domains

    @pytest.mark.parametrize("keyword", ["vaccine", "immunization", "vaccination"])
    def test_en_keywords(self, keyword: str):
        result = detect_domains(f"System tracks {keyword} records.")
        assert "VACCINATION" in result.domains

    def test_compliance_clauses_present(self):
        result = detect_domains("Quản lý lịch tiêm chủng và vắc xin.")
        clauses = [c for c in result.compliance_clauses if c.domain == "VACCINATION"]
        assert len(clauses) >= 1


class TestPaymentDomain:
    """Validates: Yêu cầu 3.4"""

    @pytest.mark.parametrize("keyword", ["thanh toán", "thẻ", "pos", "giao dịch"])
    def test_vi_keywords(self, keyword: str):
        result = detect_domains(f"Hệ thống xử lý {keyword} tại quầy.")
        assert "PAYMENT" in result.domains

    @pytest.mark.parametrize("keyword", ["payment", "card", "transaction", "pci"])
    def test_en_keywords(self, keyword: str):
        result = detect_domains(f"System processes {keyword} data.")
        assert "PAYMENT" in result.domains

    def test_compliance_clauses_present(self):
        result = detect_domains("Xử lý thanh toán thẻ và giao dịch POS.")
        clauses = [c for c in result.compliance_clauses if c.domain == "PAYMENT"]
        assert len(clauses) >= 1


class TestMedicalDeviceDomain:
    """Validates: Yêu cầu 3.5"""

    @pytest.mark.parametrize("keyword", ["thiết bị", "iot", "cảm biến", "monitor"])
    def test_vi_keywords(self, keyword: str):
        result = detect_domains(f"Hệ thống kết nối {keyword} y tế.")
        assert "MEDICAL_DEVICE" in result.domains

    @pytest.mark.parametrize("keyword", ["device", "sensor", "wearable"])
    def test_en_keywords(self, keyword: str):
        result = detect_domains(f"System integrates {keyword} data.")
        assert "MEDICAL_DEVICE" in result.domains

    def test_compliance_clauses_present(self):
        result = detect_domains("Quản lý thiết bị IoT và cảm biến y tế.")
        clauses = [c for c in result.compliance_clauses if c.domain == "MEDICAL_DEVICE"]
        assert len(clauses) >= 1


class TestInfosecDomain:
    @pytest.mark.parametrize("keyword", ["bảo mật", "an toàn thông tin", "sự cố"])
    def test_vi_keywords(self, keyword: str):
        result = detect_domains(f"Hệ thống đảm bảo {keyword} mạng.")
        assert "INFOSEC" in result.domains

    @pytest.mark.parametrize("keyword", ["security", "incident", "vncert"])
    def test_en_keywords(self, keyword: str):
        result = detect_domains(f"System handles {keyword} events.")
        assert "INFOSEC" in result.domains

    def test_compliance_clauses_present(self):
        result = detect_domains("Xử lý sự cố bảo mật và an toàn thông tin.")
        clauses = [c for c in result.compliance_clauses if c.domain == "INFOSEC"]
        assert len(clauses) >= 1


class TestMultiDomainMerge:
    """Validates: Yêu cầu 3.6 — multi-domain merge không trùng lặp."""

    def test_two_domains_detected(self):
        result = detect_domains("Hệ thống bán thuốc và xử lý thanh toán thẻ.")
        assert "PHARMACY" in result.domains
        assert "PAYMENT" in result.domains

    def test_three_domains_detected(self):
        result = detect_domains(
            "Quản lý thuốc kê đơn, xét nghiệm bệnh án, và tiêm chủng vắc xin."
        )
        assert "PHARMACY" in result.domains
        assert "LAB_EMR" in result.domains
        assert "VACCINATION" in result.domains

    def test_no_duplicate_compliance_codes(self):
        """Merge không tạo ra clause trùng code."""
        result = detect_domains(
            "Hệ thống quản lý thuốc, thanh toán, thiết bị IoT và bảo mật."
        )
        codes = [c.code for c in result.compliance_clauses]
        assert len(codes) == len(set(codes)), "Compliance clause codes phải unique sau khi merge"

    def test_all_detected_domains_have_clauses(self):
        """Mọi domain được phát hiện đều có ít nhất 1 clause."""
        result = detect_domains(
            "Hệ thống tiêm chủng vaccine, xét nghiệm lab, và thanh toán payment."
        )
        for domain in result.domains:
            matching = [c for c in result.compliance_clauses if c.domain == domain]
            assert len(matching) >= 1, f"Domain '{domain}' thiếu compliance clause"

    def test_compliance_clauses_cover_all_domains(self):
        """Tập hợp domain trong clauses phải là superset của detected domains."""
        result = detect_domains("Quản lý thuốc và thiết bị sensor y tế.")
        clause_domains = {c.domain for c in result.compliance_clauses}
        for domain in result.domains:
            assert domain in clause_domains


class TestNoMatchReturnsEmpty:
    """Validates: text không khớp domain nào → danh sách rỗng."""

    def test_empty_string(self):
        result = detect_domains("")
        assert result.domains == []
        assert result.compliance_clauses == []
        assert result.scores == {}

    def test_whitespace_only(self):
        result = detect_domains("   \n\t  ")
        assert result.domains == []
        assert result.compliance_clauses == []

    def test_unrelated_text(self):
        result = detect_domains("Hôm nay trời đẹp, tôi đi dạo công viên.")
        assert result.domains == []
        assert result.compliance_clauses == []

    def test_unrelated_english_text(self):
        result = detect_domains("The weather is nice today, let's go for a walk.")
        assert result.domains == []
        assert result.compliance_clauses == []

    def test_result_type(self):
        result = detect_domains("Không có từ khoá liên quan.")
        assert isinstance(result, DomainDetectionResult)
        assert isinstance(result.domains, list)
        assert isinstance(result.compliance_clauses, list)
        assert isinstance(result.scores, dict)


class TestResultStructure:
    """Kiểm tra cấu trúc DomainDetectionResult và ComplianceClause."""

    def test_detected_at_is_iso8601(self):
        result = detect_domains("Quản lý thuốc kê đơn.")
        # Should parse without error
        from datetime import datetime
        dt = datetime.fromisoformat(result.detected_at)
        assert dt is not None

    def test_compliance_clause_fields(self):
        result = detect_domains("Hệ thống bán thuốc prescription.")
        assert len(result.compliance_clauses) > 0
        clause = result.compliance_clauses[0]
        assert isinstance(clause, ComplianceClause)
        assert clause.domain
        assert clause.code
        assert clause.title
        assert clause.requirement_text
        assert clause.legal_basis
        assert isinstance(clause.mandatory, bool)

    def test_scores_match_domains(self):
        result = detect_domains("Quản lý thuốc và thanh toán.")
        for domain in result.domains:
            assert domain in result.scores
            assert result.scores[domain] > 0
