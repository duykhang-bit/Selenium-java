"""Tests cho dependency gate."""

from __future__ import annotations

from app.tasks.quality_gate.diff_parser import parse_diff
from app.tasks.quality_gate.gates.dependency import run


def _req_diff(content: str) -> str:
    lines = content.splitlines()
    added = "\n".join(f"+{line}" for line in lines)
    return f"--- /dev/null\n+++ b/requirements.txt\n@@ -0,0 +1,{len(lines)} @@\n{added}\n"


class TestDependencyGate:
    def test_known_vulnerable_package(self):
        diff = _req_diff("requests==2.28.0\n")
        report = run(parse_diff(diff))
        assert any(f.rule_id == "DEP-002" for f in report.findings)

    def test_safe_package_version(self):
        diff = _req_diff("requests>=2.31.0\n")
        report = run(parse_diff(diff))
        assert not any(f.rule_id == "DEP-002" for f in report.findings)

    def test_unknown_package_no_finding(self):
        diff = _req_diff("some-unknown-package==1.0.0\n")
        report = run(parse_diff(diff))
        assert report.findings == []

    def test_empty_diff_no_findings(self):
        report = run(parse_diff(""))
        assert report.findings == []

    def test_non_requirements_file_skipped(self):
        diff = "--- /dev/null\n+++ b/app/foo.py\n@@ -0,0 +1,1 @@\n+requests==2.28.0\n"
        report = run(parse_diff(diff))
        assert report.findings == []
