"""Tests cho diff_parser."""

from __future__ import annotations

import pytest
from app.tasks.quality_gate.diff_parser import parse_diff

_ADDED_FILE_DIFF = """\
--- /dev/null
+++ b/app/tasks/foo.py
@@ -0,0 +1,5 @@
+from __future__ import annotations
+
+
+def hello() -> str:
+    return "hello"
"""

_MODIFIED_FILE_DIFF = """\
--- a/app/tasks/foo.py
+++ b/app/tasks/foo.py
@@ -1,4 +1,5 @@
 from __future__ import annotations
 
+import os
 
 def hello() -> str:
"""

_DELETED_FILE_DIFF = """\
--- a/app/tasks/old.py
+++ /dev/null
@@ -1,3 +0,0 @@
-def old():
-    pass
"""

_MULTI_FILE_DIFF = _ADDED_FILE_DIFF + "\n" + _MODIFIED_FILE_DIFF


class TestParseEmptyDiff:
    def test_empty_string(self):
        result = parse_diff("")
        assert result.files == []

    def test_whitespace_only(self):
        result = parse_diff("   \n  \n")
        assert result.files == []


class TestParseAddedFile:
    def test_change_type_is_added(self):
        result = parse_diff(_ADDED_FILE_DIFF)
        assert len(result.files) == 1
        assert result.files[0].change_type == "added"

    def test_path_correct(self):
        result = parse_diff(_ADDED_FILE_DIFF)
        assert result.files[0].path == "app/tasks/foo.py"

    def test_added_lines_extracted(self):
        result = parse_diff(_ADDED_FILE_DIFF)
        lines = [content for _, content in result.files[0].added_lines]
        assert "def hello() -> str:" in lines

    def test_full_new_content_set(self):
        result = parse_diff(_ADDED_FILE_DIFF)
        assert result.files[0].full_new_content is not None
        assert "def hello" in result.files[0].full_new_content

    def test_no_removed_lines(self):
        result = parse_diff(_ADDED_FILE_DIFF)
        assert result.files[0].removed_lines == []


class TestParseModifiedFile:
    def test_change_type_is_modified(self):
        result = parse_diff(_MODIFIED_FILE_DIFF)
        assert result.files[0].change_type == "modified"

    def test_added_lines_extracted(self):
        result = parse_diff(_MODIFIED_FILE_DIFF)
        lines = [content for _, content in result.files[0].added_lines]
        assert "import os" in lines


class TestParseDeletedFile:
    def test_change_type_is_deleted(self):
        result = parse_diff(_DELETED_FILE_DIFF)
        assert result.files[0].change_type == "deleted"

    def test_removed_lines_extracted(self):
        result = parse_diff(_DELETED_FILE_DIFF)
        lines = [content for _, content in result.files[0].removed_lines]
        assert "def old():" in lines


class TestParseMultipleFiles:
    def test_two_files_parsed(self):
        result = parse_diff(_MULTI_FILE_DIFF)
        assert len(result.files) == 2

    def test_line_numbers_start_from_hunk(self):
        result = parse_diff(_ADDED_FILE_DIFF)
        first_line_num = result.files[0].added_lines[0][0]
        assert first_line_num == 1
