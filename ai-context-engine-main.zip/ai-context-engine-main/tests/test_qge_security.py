"""Tests cho security gate."""

from __future__ import annotations

import pytest
from app.tasks.quality_gate.diff_parser import parse_diff
from app.tasks.quality_gate.gates.security import run


def _diff(path: str, content: str) -> str:
    lines = content.splitlines()
    added = "\n".join(f"+{line}" for line in lines)
    return f"--- /dev/null\n+++ b/{path}\n@@ -0,0 +1,{len(lines)} @@\n{added}\n"


class TestEvalExec:
    def test_eval_detected(self):
        code = "result = eval(user_input)\n"
        report = run(parse_diff(_diff("app/foo.py", code)))
        assert any(f.rule_id == "SEC-002" for f in report.findings)

    def test_exec_detected(self):
        code = "exec(code_string)\n"
        report = run(parse_diff(_diff("app/foo.py", code)))
        assert any(f.rule_id == "SEC-002" for f in report.findings)


class TestSubprocessShell:
    def test_shell_true_detected(self):
        code = "import subprocess\nsubprocess.run(cmd, shell=True)\n"
        report = run(parse_diff(_diff("app/foo.py", code)))
        assert any(f.rule_id == "SEC-003" for f in report.findings)

    def test_shell_false_passes(self):
        code = "import subprocess\nsubprocess.run(['ls', '-la'], shell=False)\n"
        report = run(parse_diff(_diff("app/foo.py", code)))
        assert not any(f.rule_id == "SEC-003" for f in report.findings)


class TestPickleYaml:
    def test_pickle_loads_detected(self):
        code = "import pickle\ndata = pickle.loads(raw)\n"
        report = run(parse_diff(_diff("app/foo.py", code)))
        assert any(f.rule_id == "SEC-004" for f in report.findings)

    def test_yaml_load_detected(self):
        code = "import yaml\ndata = yaml.load(stream)\n"
        report = run(parse_diff(_diff("app/foo.py", code)))
        assert any(f.rule_id == "SEC-004" for f in report.findings)

    def test_yaml_safe_load_passes(self):
        code = "import yaml\ndata = yaml.safe_load(stream)\n"
        report = run(parse_diff(_diff("app/foo.py", code)))
        assert not any(f.rule_id == "SEC-004" for f in report.findings)


class TestVerifyFalse:
    def test_verify_false_detected(self):
        code = "import requests\nrequests.get(url, verify=False)\n"
        report = run(parse_diff(_diff("app/foo.py", code)))
        assert any(f.rule_id == "SEC-006" for f in report.findings)


class TestDebugTrue:
    def test_debug_true_detected(self):
        diff_text = "--- a/config.py\n+++ b/config.py\n@@ -1,1 +1,1 @@\n+DEBUG = True\n"
        report = run(parse_diff(diff_text))
        assert any(f.rule_id == "SEC-007" for f in report.findings)


class TestEmptyDiff:
    def test_empty_diff_no_findings(self):
        report = run(parse_diff(""))
        assert report.findings == []
