"""Integration tests for RDE API endpoints.

Validates: Requirements 1.6, 5.6
"""

from __future__ import annotations

import dataclasses
from datetime import datetime, timezone
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.tasks.compliance_checker import ComplianceReport, ComplianceViolation
from app.tasks.domain_detector import DomainDetectionResult
from app.tasks.impact_analyzer import ImpactReport
from app.tasks.requirement_generator import RequirementGeneratorResult
from app.tasks.design_generator import DesignGeneratorResult


client = TestClient(app)

_NOW = datetime.now(timezone.utc).isoformat()

# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------


def _passing_compliance() -> ComplianceReport:
    return ComplianceReport(
        passed=True,
        domains_checked=[],
        violations=[],
        warnings=[],
        checked_at=_NOW,
    )


def _failing_compliance() -> ComplianceReport:
    return ComplianceReport(
        passed=False,
        domains_checked=["PHARMACY"],
        violations=[
            ComplianceViolation(
                code="PHARMACY-001",
                severity="ERROR",
                message="Thiếu điều khoản validation kê đơn Rx",
                section="Yêu cầu bán thuốc",
                remediation="Thêm điều khoản validation",
            )
        ],
        warnings=[],
        checked_at=_NOW,
    )


def _empty_impact() -> ImpactReport:
    return ImpactReport(
        impacted_services=[],
        total_high=0,
        total_medium=0,
        total_low=0,
        conflicts=[],
        analyzed_at=_NOW,
        trace_id="test-trace",
    )


def _make_req_result(compliance: ComplianceReport) -> RequirementGeneratorResult:
    return RequirementGeneratorResult(
        document="# Tài liệu Yêu cầu: Test\n\nContent",
        domains=["PHARMACY"],
        compliance_report=compliance,
        context_chunks_used=0,
        generated_at=_NOW,
        trace_id="trace-req-001",
    )


def _make_design_result() -> DesignGeneratorResult:
    return DesignGeneratorResult(
        document="# Tài liệu Thiết kế: Test\n\nContent",
        domains=["PHARMACY"],
        compliance_report=_passing_compliance(),
        impact_report=_empty_impact(),
        context_chunks_used=0,
        generated_at=_NOW,
        trace_id="trace-design-001",
    )


# ---------------------------------------------------------------------------
# POST /api/rde/generate-requirements — happy path
# ---------------------------------------------------------------------------


def test_generate_requirements_success():
    """POST /api/rde/generate-requirements returns 200 with valid payload."""
    mock_result = _make_req_result(_passing_compliance())

    with patch("app.api.routes.generate_requirements", return_value=mock_result):
        response = client.post(
            "/api/rde/generate-requirements",
            json={"intent": "Xây dựng hệ thống nhà thuốc"},
        )

    assert response.status_code == 200
    data = response.json()
    assert "task_id" in data
    assert data["requirements_doc"] == mock_result.document
    assert data["domains"] == ["PHARMACY"]
    assert data["compliance_report"]["passed"] is True
    assert data["confluence_url"] is None
    assert data["trace_id"] == "trace-req-001"


# ---------------------------------------------------------------------------
# POST /api/rde/generate-requirements — compliance fail → HTTP 422
# ---------------------------------------------------------------------------


def test_generate_requirements_compliance_fail_returns_422():
    """POST /api/rde/generate-requirements returns 422 when compliance fails.

    Validates: Requirements 1.6
    """
    mock_result = _make_req_result(_failing_compliance())

    with patch("app.api.routes.generate_requirements", return_value=mock_result):
        response = client.post(
            "/api/rde/generate-requirements",
            json={"intent": "Bán thuốc không cần đơn"},
        )

    assert response.status_code == 422
    detail = response.json()["detail"]
    assert detail["message"] == "Compliance check failed"
    assert len(detail["violations"]) == 1
    assert detail["violations"][0]["code"] == "PHARMACY-001"


# ---------------------------------------------------------------------------
# POST /api/rde/check-compliance — requirements type
# ---------------------------------------------------------------------------


def test_check_compliance_requirements():
    """POST /api/rde/check-compliance with document_type=requirements returns report.

    Validates: Requirements 5.6
    """
    mock_report = _passing_compliance()
    mock_detection = DomainDetectionResult(
        domains=["PHARMACY"],
        scores={"PHARMACY": 0.9},
        compliance_clauses=[],
        detected_at=_NOW,
    )

    with (
        patch("app.api.routes.detect_domains", return_value=mock_detection),
        patch("app.api.routes.check_requirements", return_value=mock_report),
    ):
        response = client.post(
            "/api/rde/check-compliance",
            json={
                "document": "# Requirements\n\nkê đơn prescription validation",
                "document_type": "requirements",
            },
        )

    assert response.status_code == 200
    data = response.json()
    assert "compliance_report" in data
    assert data["compliance_report"]["passed"] is True
    assert "trace_id" in data


# ---------------------------------------------------------------------------
# POST /api/rde/check-compliance — design type
# ---------------------------------------------------------------------------


def test_check_compliance_design():
    """POST /api/rde/check-compliance with document_type=design returns report."""
    mock_report = _passing_compliance()
    mock_detection = DomainDetectionResult(
        domains=[],
        scores={},
        compliance_clauses=[],
        detected_at=_NOW,
    )

    with (
        patch("app.api.routes.detect_domains", return_value=mock_detection),
        patch("app.api.routes.check_design", return_value=mock_report),
    ):
        response = client.post(
            "/api/rde/check-compliance",
            json={
                "document": "# Design\n\nthreat model data flow backup recovery",
                "document_type": "design",
            },
        )

    assert response.status_code == 200
    data = response.json()
    assert data["compliance_report"]["passed"] is True


# ---------------------------------------------------------------------------
# POST /api/rde/check-compliance — explicit domains (no auto-detect)
# ---------------------------------------------------------------------------


def test_check_compliance_with_explicit_domains():
    """POST /api/rde/check-compliance with explicit domains skips auto-detect."""
    mock_report = _passing_compliance()

    with patch("app.api.routes.check_requirements", return_value=mock_report) as mock_check:
        response = client.post(
            "/api/rde/check-compliance",
            json={
                "document": "# Requirements\n\nkê đơn prescription",
                "document_type": "requirements",
                "domains": ["PHARMACY"],
            },
        )

    assert response.status_code == 200
    mock_check.assert_called_once()
    call_args = mock_check.call_args
    assert call_args[0][1] == ["PHARMACY"]


# ---------------------------------------------------------------------------
# POST /api/rde/check-compliance — invalid document_type → 422
# ---------------------------------------------------------------------------


def test_check_compliance_invalid_document_type():
    """POST /api/rde/check-compliance with invalid document_type returns 422."""
    response = client.post(
        "/api/rde/check-compliance",
        json={
            "document": "some content",
            "document_type": "invalid_type",
        },
    )
    assert response.status_code == 422


# ---------------------------------------------------------------------------
# POST /api/rde/generate-design — happy path
# ---------------------------------------------------------------------------


def test_generate_design_success():
    """POST /api/rde/generate-design returns 200 with valid payload."""
    mock_result = _make_design_result()

    with patch("app.api.routes.generate_design", return_value=mock_result):
        response = client.post(
            "/api/rde/generate-design",
            json={"requirements_doc": "# Tài liệu Yêu cầu: Test\n\nContent"},
        )

    assert response.status_code == 200
    data = response.json()
    assert "task_id" in data
    assert data["design_doc"] == mock_result.document
    assert data["domains"] == ["PHARMACY"]
    assert data["compliance_report"]["passed"] is True
    assert "impact_report" in data
    assert data["confluence_url"] is None
    assert data["trace_id"] == "trace-design-001"


# ---------------------------------------------------------------------------
# POST /api/rde/analyze-impact — happy path
# ---------------------------------------------------------------------------


def test_analyze_impact_success():
    """POST /api/rde/analyze-impact returns 200 with impact report."""
    mock_result = _empty_impact()

    with patch("app.api.routes.analyze_impact", return_value=mock_result):
        response = client.post(
            "/api/rde/analyze-impact",
            json={"requirements_doc": "# Requirements\n\nsome content"},
        )

    assert response.status_code == 200
    data = response.json()
    assert "impact_report" in data
    assert data["impact_report"]["total_high"] == 0
    assert "trace_id" in data
