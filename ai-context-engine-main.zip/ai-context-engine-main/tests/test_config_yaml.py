"""Tests for YAML config loader."""

import os
import tempfile
import pytest
from pathlib import Path
from unittest.mock import MagicMock
from app.core.config_yaml import load_yaml_config, interpolate_env_vars, apply_yaml_to_settings


def test_interpolate_env_vars():
    os.environ["TEST_TOKEN_XYZ"] = "secret123"
    result = interpolate_env_vars("token: ${TEST_TOKEN_XYZ}")
    assert "secret123" in result
    del os.environ["TEST_TOKEN_XYZ"]


def test_interpolate_missing_var():
    result = interpolate_env_vars("token: ${TOTALLY_MISSING_VAR_12345}")
    assert "${TOTALLY_MISSING_VAR_12345}" not in result
    assert "token: " in result  # var replaced with empty string


def test_load_yaml_config_returns_none_when_missing():
    result = load_yaml_config(Path("/nonexistent/config.yaml"))
    assert result is None


def test_load_yaml_config_parses_correctly():
    os.environ["TEST_GL_TOKEN"] = "glpat-abc"
    yaml_content = """
connectors:
  gitlab:
    base_url: https://gitlab.example.com
    token: ${TEST_GL_TOKEN}
    excluded_groups: [devops]
  confluence:
    base_url: https://confluence.example.com
    token: plain-token
chunking:
  repo:
    size: 400
    overlap: 80
"""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write(yaml_content)
        f.flush()
        result = load_yaml_config(Path(f.name))
    assert result["connectors"]["gitlab"]["token"] == "glpat-abc"
    assert result["connectors"]["gitlab"]["base_url"] == "https://gitlab.example.com"
    assert result["chunking"]["repo"]["size"] == 400
    os.unlink(f.name)
    del os.environ["TEST_GL_TOKEN"]


def test_load_yaml_config_malformed_yaml():
    """Malformed YAML raises SystemExit with helpful message."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write("connectors:\n  gitlab:\n    - broken: [unclosed")
        f.flush()
        with pytest.raises(SystemExit, match="malformed"):
            load_yaml_config(Path(f.name))
    os.unlink(f.name)


def test_apply_yaml_to_settings_gitlab():
    settings = MagicMock()
    yaml_config = {
        "connectors": {
            "gitlab": {
                "base_url": "https://git.example.com",
                "token": "tok123",
                "name": "MyGitLab",
                "excluded_groups": ["devops", "infra"],
            }
        }
    }
    apply_yaml_to_settings(yaml_config, settings)
    assert settings.gitlab_base_url == "https://git.example.com"
    assert settings.gitlab_token == "tok123"
    assert settings.gitlab_name == "MyGitLab"
    assert settings.gitlab_excluded_groups_raw == "devops,infra"


def test_apply_yaml_to_settings_confluence():
    settings = MagicMock()
    yaml_config = {
        "connectors": {
            "confluence": {
                "base_url": "https://wiki.example.com",
                "token": "cf-tok",
                "username": "admin",
            }
        }
    }
    apply_yaml_to_settings(yaml_config, settings)
    assert settings.confluence_base_url == "https://wiki.example.com"
    assert settings.confluence_token == "cf-tok"
    assert settings.confluence_username == "admin"


def test_apply_yaml_to_settings_chunking():
    settings = MagicMock()
    yaml_config = {
        "chunking": {
            "repo": {"size": 400, "overlap": 80},
            "confluence": {"size": 800, "overlap": 160},
        }
    }
    apply_yaml_to_settings(yaml_config, settings)
    assert settings.repo_chunk_size == 400
    assert settings.repo_chunk_overlap == 80
    assert settings.confluence_chunk_size == 800
    assert settings.confluence_chunk_overlap == 160


def test_apply_yaml_to_settings_partial():
    """Only provided keys are overridden."""
    settings = MagicMock()
    yaml_config = {"connectors": {"gitlab": {"token": "new-tok"}}}
    apply_yaml_to_settings(yaml_config, settings)
    assert settings.gitlab_token == "new-tok"
    # base_url should NOT have been set (no assertion on it = MagicMock default)
