"""Tests cho CGP decomposer."""

from __future__ import annotations

from unittest.mock import patch

from app.tasks.code_gen.decomposer import decompose


_DESIGN_WITH_ENDPOINT = """
## API Endpoints

POST /api/orders — tạo order mới
GET /api/orders/{id} — lấy order theo ID

## Data Models

class Order:
    id: str
    status: str
"""

_DESIGN_WITH_CLASS = """
## Data Models (ERD)

class UserModel:
    id: str
    username: str

## Service Layer

def process_order(order_id: str) -> dict:
    implement business logic here
"""


class TestDecomposeEmpty:
    def test_empty_string(self):
        assert decompose("") == []

    def test_whitespace_only(self):
        assert decompose("   \n  ") == []


class TestDecomposeTaskTypes:
    def test_detect_endpoint(self):
        tasks = decompose(_DESIGN_WITH_ENDPOINT)
        types = [t.type for t in tasks]
        assert "add_endpoint" in types

    def test_detect_class(self):
        tasks = decompose(_DESIGN_WITH_class := _DESIGN_WITH_CLASS)
        types = [t.type for t in tasks]
        assert "add_class" in types

    def test_detect_function(self):
        tasks = decompose(_DESIGN_WITH_CLASS)
        types = [t.type for t in tasks]
        assert "add_function" in types


class TestDependencyOrder:
    def test_class_before_endpoint(self):
        tasks = decompose(_DESIGN_WITH_ENDPOINT)
        if len(tasks) >= 2:
            type_order = [t.type for t in tasks]
            # add_class phải xuất hiện trước add_endpoint nếu cả hai có
            if "add_class" in type_order and "add_endpoint" in type_order:
                assert type_order.index("add_class") < type_order.index("add_endpoint")

    def test_tasks_have_unique_ids(self):
        tasks = decompose(_DESIGN_WITH_ENDPOINT)
        ids = [t.task_id for t in tasks]
        assert len(ids) == len(set(ids))


class TestGracefulDegrade:
    def test_chromadb_unavailable(self):
        with patch("app.retrieval.search.search", side_effect=Exception("ChromaDB down")):
            tasks = decompose(_DESIGN_WITH_ENDPOINT)
            assert isinstance(tasks, list)

    def test_target_file_fallback(self):
        with patch("app.retrieval.search.search", side_effect=Exception("no db")):
            tasks = decompose(_DESIGN_WITH_CLASS)
            for t in tasks:
                assert t.target_file.endswith(".py")
