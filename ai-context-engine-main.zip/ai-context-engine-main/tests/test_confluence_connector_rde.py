"""Tests for new ConfluenceConnector methods and markdown_to_storage.

Validates: Requirements 6.1
"""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest
import requests

from app.connectors.confluence import ConfluenceConnector, markdown_to_storage


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_connector() -> ConfluenceConnector:
    return ConfluenceConnector(
        base_url="https://confluence.example.com",
        token="test-token",
        username="user@example.com",
    )


def _mock_response(status_code: int = 200, body: dict | None = None) -> MagicMock:
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = body or {}
    resp.raise_for_status = MagicMock()
    if status_code >= 400:
        resp.raise_for_status.side_effect = requests.HTTPError(response=resp)
    return resp


# ---------------------------------------------------------------------------
# create_page
# ---------------------------------------------------------------------------

class TestCreatePage:
    def test_create_page_success(self):
        connector = _make_connector()
        expected = {
            "id": "123456",
            "title": "My Page",
            "_links": {"webui": "/pages/viewpage.action?pageId=123456"},
        }
        with patch.object(connector.session, "post", return_value=_mock_response(200, expected)) as mock_post:
            result = connector.create_page(
                space_key="PROJ",
                title="My Page",
                body_storage="<p>Hello</p>",
            )

        assert result["id"] == "123456"
        assert result["title"] == "My Page"
        call_kwargs = mock_post.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs.args[1] if len(call_kwargs.args) > 1 else call_kwargs.kwargs["json"]
        assert payload["type"] == "page"
        assert payload["space"]["key"] == "PROJ"
        assert payload["body"]["storage"]["value"] == "<p>Hello</p>"
        assert payload["ancestors"] == []

    def test_create_page_with_parent(self):
        connector = _make_connector()
        expected = {"id": "789", "title": "Child Page", "_links": {"webui": "/x/child"}}
        with patch.object(connector.session, "post", return_value=_mock_response(200, expected)) as mock_post:
            result = connector.create_page(
                space_key="PROJ",
                title="Child Page",
                body_storage="<p>Content</p>",
                parent_id="100",
            )

        assert result["id"] == "789"
        payload = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1]
        assert payload["ancestors"] == [{"id": "100"}]

    def test_create_page_raises_on_http_error(self):
        connector = _make_connector()
        with patch.object(connector.session, "post", return_value=_mock_response(403)):
            with pytest.raises(requests.HTTPError):
                connector.create_page("PROJ", "Title", "<p>body</p>")

    def test_create_page_uses_bearer_auth(self):
        connector = _make_connector()
        expected = {"id": "1", "title": "T", "_links": {}}
        with patch.object(connector.session, "post", return_value=_mock_response(200, expected)) as mock_post:
            connector.create_page("PROJ", "T", "<p>x</p>")

        headers_used = mock_post.call_args.kwargs.get("headers", {})
        assert "Authorization" in headers_used


# ---------------------------------------------------------------------------
# update_page
# ---------------------------------------------------------------------------

class TestUpdatePage:
    def test_update_page_success(self):
        connector = _make_connector()
        expected = {
            "id": "123456",
            "title": "Updated Title",
            "version": {"number": 2},
            "_links": {"webui": "/pages/viewpage.action?pageId=123456"},
        }
        with patch.object(connector.session, "put", return_value=_mock_response(200, expected)) as mock_put:
            result = connector.update_page(
                page_id="123456",
                title="Updated Title",
                body_storage="<p>New content</p>",
                version_number=2,
            )

        assert result["id"] == "123456"
        payload = mock_put.call_args.kwargs.get("json") or mock_put.call_args[1]
        assert payload["version"]["number"] == 2
        assert payload["version"]["minorEdit"] is False
        assert payload["title"] == "Updated Title"
        assert payload["type"] == "page"
        assert payload["body"]["storage"]["value"] == "<p>New content</p>"

    def test_update_page_minor_edit(self):
        connector = _make_connector()
        expected = {"id": "1", "title": "T", "_links": {}}
        with patch.object(connector.session, "put", return_value=_mock_response(200, expected)) as mock_put:
            connector.update_page("1", "T", "<p>x</p>", version_number=3, minor_edit=True)

        payload = mock_put.call_args.kwargs.get("json") or mock_put.call_args[1]
        assert payload["version"]["minorEdit"] is True
        assert payload["version"]["number"] == 3

    def test_update_page_raises_on_conflict(self):
        connector = _make_connector()
        with patch.object(connector.session, "put", return_value=_mock_response(409)):
            with pytest.raises(requests.HTTPError):
                connector.update_page("1", "T", "<p>x</p>", version_number=1)

    def test_update_page_url_contains_page_id(self):
        connector = _make_connector()
        expected = {"id": "42", "title": "T", "_links": {}}
        with patch.object(connector.session, "put", return_value=_mock_response(200, expected)) as mock_put:
            connector.update_page("42", "T", "<p>x</p>", version_number=5)

        url_called = mock_put.call_args.args[0] if mock_put.call_args.args else mock_put.call_args.kwargs.get("url", "")
        assert "42" in url_called


# ---------------------------------------------------------------------------
# search_pages
# ---------------------------------------------------------------------------

class TestSearchPages:
    def test_search_pages_returns_results(self):
        connector = _make_connector()
        pages = [{"id": "1", "title": "Page A"}, {"id": "2", "title": "Page B"}]
        with patch.object(connector.session, "get", return_value=_mock_response(200, {"results": pages})):
            result = connector.search_pages(cql="space = 'PROJ' AND title = 'Page A'")

        assert len(result) == 2
        assert result[0]["id"] == "1"

    def test_search_pages_empty(self):
        connector = _make_connector()
        with patch.object(connector.session, "get", return_value=_mock_response(200, {"results": []})):
            result = connector.search_pages(cql="space = 'EMPTY'")

        assert result == []

    def test_search_pages_passes_cql_and_limit(self):
        connector = _make_connector()
        with patch.object(connector.session, "get", return_value=_mock_response(200, {"results": []})) as mock_get:
            connector.search_pages(cql="type = page", limit=10)

        params = mock_get.call_args.kwargs.get("params", {})
        assert params["cql"] == "type = page"
        assert params["limit"] == 10

    def test_search_pages_raises_on_error(self):
        connector = _make_connector()
        with patch.object(connector.session, "get", return_value=_mock_response(500)):
            with pytest.raises(requests.HTTPError):
                connector.search_pages(cql="type = page")


# ---------------------------------------------------------------------------
# markdown_to_storage
# ---------------------------------------------------------------------------

class TestMarkdownToStorage:
    def test_headings_converted(self):
        result = markdown_to_storage("# Heading 1\n## Heading 2\n### Heading 3")
        assert "<h1>" in result
        assert "<h2>" in result
        assert "<h3>" in result
        assert "Heading 1" in result

    def test_bold_converted(self):
        result = markdown_to_storage("**bold text**")
        assert "<strong>bold text</strong>" in result

    def test_italic_converted(self):
        result = markdown_to_storage("*italic text*")
        assert "<em>italic text</em>" in result

    def test_paragraph_wrapped(self):
        result = markdown_to_storage("Hello world")
        assert "<p>" in result
        assert "Hello world" in result

    def test_code_block_converted_to_confluence_macro(self):
        md = "```python\nprint('hello')\n```"
        result = markdown_to_storage(md)
        assert 'ac:structured-macro ac:name="code"' in result
        assert 'ac:name="language">python' in result
        assert "CDATA" in result
        assert "print('hello')" in result

    def test_code_block_no_language(self):
        md = "```\nsome code\n```"
        result = markdown_to_storage(md)
        assert 'ac:structured-macro ac:name="code"' in result
        assert "some code" in result

    def test_table_converted(self):
        md = "| Col1 | Col2 |\n|------|------|\n| A    | B    |"
        result = markdown_to_storage(md)
        assert "<table>" in result
        assert "<td>" in result or "<th>" in result
        assert "Col1" in result
        assert "A" in result

    def test_empty_string(self):
        result = markdown_to_storage("")
        assert isinstance(result, str)

    def test_mixed_content(self):
        md = "# Title\n\nSome **bold** and *italic* text.\n\n```python\nx = 1\n```"
        result = markdown_to_storage(md)
        assert "<h1>" in result
        assert "<strong>bold</strong>" in result
        assert "<em>italic</em>" in result
        assert 'ac:structured-macro ac:name="code"' in result
