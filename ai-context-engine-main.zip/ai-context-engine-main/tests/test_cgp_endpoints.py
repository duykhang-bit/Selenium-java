"""Integration tests cho CGP endpoints."""

from __future__ import annotations

import os
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from app.tasks.code_gen.models import CodingTask, GeneratedCode, MRResult, PipelineResult

_SAMPLE_TASK = {
    "task_id": "t1", "title": "Add foo", "type": "add_function",
    "target_file": "app/foo.py", "description": "add foo function",
    "depends_on": [], "priority": 3,
}


@pytest.fixture()
def client():
    with patch.dict(os.environ, {"AI_CONTEXT_V2_API_KEY": ""}):
        import importlib
        import app.core.auth as auth_mod
        importlib.reload(auth_mod)
        from app.main import app
        with TestClient(app, raise_server_exceptions=False) as c:
            yield c


class TestCGPDecompose:
    def test_decompose_returns_tasks(self, client):
        with patch("app.tasks.code_gen.decomposer.decompose", return_value=[CodingTask(**_SAMPLE_TASK)]):
            resp = client.post("/api/cgp/decompose", json={
                "design_doc": "## API\nPOST /api/orders", "collection": "knowledge"
            })
            assert resp.status_code == 200
            assert len(resp.json()["tasks"]) == 1


class TestCGPCommitMessage:
    def test_returns_message(self, client):
        resp = client.post("/api/cgp/commit-message", json={
            "diff": "--- /dev/null\n+++ b/app/foo.py\n@@ -0,0 +1,3 @@\n+def foo(): pass\n"
        })
        assert resp.status_code == 200
        assert resp.json()["message"] != ""

    def test_with_task_description(self, client):
        resp = client.post("/api/cgp/commit-message", json={
            "diff": "", "task_description": "add order processing"
        })
        assert resp.status_code == 200
        assert "order processing" in resp.json()["message"]


class TestCGPRunPipeline:
    def test_success(self, client):
        mock_result = PipelineResult(
            tasks=[CodingTask(**_SAMPLE_TASK)],
            generated_files=[GeneratedCode(file_path="app/foo.py", content="# code", mode="skeleton")],
            mr_result=MRResult(mr_id=7, mr_url="https://gitlab.example.com/mr/7",
                               branch_name="feature/x", title="feat: x", source_id="gitlab:42"),
            duration_ms=100, trace_id="abc",
        )
        with patch("app.tasks.code_gen.pipeline.run_pipeline", return_value=mock_result):
            resp = client.post("/api/cgp/run-pipeline", json={
                "design_doc": "## API\nPOST /api/orders",
                "source_id": "gitlab:42",
                "branch_name": "feature/x",
            })
            assert resp.status_code == 200
            assert resp.json()["mr_result"]["mr_url"] == "https://gitlab.example.com/mr/7"

    def test_branch_conflict_returns_409(self, client):
        from app.tasks.code_gen.models import BranchAlreadyExistsError
        with patch("app.tasks.code_gen.pipeline.run_pipeline",
                   side_effect=BranchAlreadyExistsError("branch exists")):
            resp = client.post("/api/cgp/run-pipeline", json={
                "design_doc": "## API", "source_id": "gitlab:42", "branch_name": "main",
            })
            assert resp.status_code == 409
