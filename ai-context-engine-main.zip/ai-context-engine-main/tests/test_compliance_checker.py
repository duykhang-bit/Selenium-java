"""Tests for app/tasks/compliance_checker.py

Validates: Requirements 4.1–4.19, 5.1–5.6
"""

from __future__ import annotations

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from app.tasks.compliance_checker import (
    ComplianceReport,
    ComplianceViolation,
    check_design,
    check_requirements,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

PHARMACY_DOC_COMPLIANT = """
## Yêu cầu nhà thuốc
Hệ thống PHẢI xác nhận đơn thuốc Rx hợp lệ (prescription validation) trước khi bán.
Lưu trữ lịch sử giao dịch thuốc tối thiểu 5 năm theo Luật Dược 2016.
Thông tin thuốc phải đối chiếu danh mục Bộ Y tế.
Ghi nhận và báo cáo ADR (adverse drug reaction) định kỳ.
"""

LAB_DOC_COMPLIANT = """
## Yêu cầu bệnh án
Hệ thống PHẢI duy trì audit trail và chữ ký số cho mọi thao tác.
Lưu trữ hồ sơ bệnh án tối thiểu 10 năm (người lớn), 15 năm (trẻ em).
Kết quả xét nghiệm phải có giá trị tham chiếu và đơn vị đo chuẩn.
Hỗ trợ chia sẻ dữ liệu theo chuẩn HL7 FHIR R4.
"""

VAC_DOC_COMPLIANT = """
## Yêu cầu tiêm chủng
Kết nối hệ thống tiêm chủng quốc gia theo Thông tư 09/2023.
Cảnh báo chống chỉ định tự động dựa trên lịch sử bệnh án.
Lưu trữ lịch sử tiêm chủng tối thiểu 20 năm.
"""

PAY_DOC_COMPLIANT = """
## Yêu cầu thanh toán
Hệ thống KHÔNG lưu CVV và full PAN sau giao dịch.
Dữ liệu thẻ phải được mã hoá AES-256.
Phải có network segmentation giữa môi trường thanh toán và hệ thống khác.
"""

DEV_DOC_COMPLIANT = """
## Yêu cầu thiết bị y tế
Thiết bị phải đồng bộ timestamp qua NTP và có outlier detection.
Firmware phải hỗ trợ secure OTA update với chữ ký số.
"""

SEC_DOC_COMPLIANT = """
## Yêu cầu an toàn thông tin
Hệ thống phải đáp ứng RTO ≤ 4 giờ và RPO ≤ 1 giờ.
Báo cáo sự cố cho VNCERT trong 24 giờ.
Thông báo vi phạm dữ liệu trong 72 giờ theo NĐ 13/2023.
"""

DESIGN_DOC_COMPLIANT = """
## Data Retention Policy
Lưu trữ dữ liệu theo quy định pháp luật.

## Threat Model
Danh sách tác nhân đe doạ và vector tấn công.

## Data Flow Diagram
Luồng dữ liệu nhạy cảm qua các thành phần.

## Backup & Recovery Strategy
RTO ≤ 4 giờ, RPO ≤ 1 giờ. Backup hàng ngày.

## Phân quyền
Phân quyền theo chức danh: bác sĩ, dược sĩ, điều dưỡng, admin.
"""


# ---------------------------------------------------------------------------
# Unit tests — check_requirements
# ---------------------------------------------------------------------------


class TestCheckRequirementsPharmacy:
    def test_compliant_doc_passes(self):
        report = check_requirements(PHARMACY_DOC_COMPLIANT, ["PHARMACY"])
        assert report.passed is True
        assert report.violations == []

    def test_pharmacy_001_missing_prescription_validation(self):
        doc = "Hệ thống bán thuốc không có điều khoản gì về đơn thuốc."
        report = check_requirements(doc, ["PHARMACY"])
        codes = [v.code for v in report.violations]
        assert "PHARMACY-001" in codes
        assert report.passed is False

    def test_pharmacy_002_missing_retention(self):
        doc = "Hệ thống lưu trữ giao dịch thuốc trong 2 năm."
        report = check_requirements(doc, ["PHARMACY"])
        codes = [v.code for v in report.violations]
        assert "PHARMACY-002" in codes

    def test_pharmacy_002_passes_with_5_years(self):
        doc = "Lưu trữ giao dịch thuốc tối thiểu 5 năm. Kê đơn prescription validation rx."
        report = check_requirements(doc, ["PHARMACY"])
        codes = [v.code for v in report.violations]
        assert "PHARMACY-002" not in codes

    def test_pharmacy_003_missing_ministry_catalog(self):
        doc = "Hệ thống bán thuốc kê đơn prescription validation rx."
        report = check_requirements(doc, ["PHARMACY"])
        codes = [v.code for v in report.violations]
        assert "PHARMACY-003" in codes

    def test_pharmacy_004_missing_adr(self):
        doc = "Hệ thống bán thuốc kê đơn prescription validation rx danh mục bộ y tế 5 năm."
        report = check_requirements(doc, ["PHARMACY"])
        codes = [v.code for v in report.violations]
        assert "PHARMACY-004" in codes

    def test_domain_not_in_list_skips_rules(self):
        doc = "Không có gì về nhà thuốc."
        report = check_requirements(doc, ["INFOSEC"])
        codes = [v.code for v in report.violations]
        assert not any(c.startswith("PHARMACY") for c in codes)


class TestCheckRequirementsLab:
    def test_compliant_doc_passes(self):
        report = check_requirements(LAB_DOC_COMPLIANT, ["LAB_EMR"])
        assert report.passed is True

    def test_lab_001_missing_audit_trail(self):
        doc = "Hệ thống quản lý bệnh án điện tử."
        report = check_requirements(doc, ["LAB_EMR"])
        codes = [v.code for v in report.violations]
        assert "LAB-001" in codes

    def test_lab_002_missing_retention(self):
        doc = "Lưu trữ bệnh án 5 năm. Audit trail chữ ký số. Giá trị tham chiếu unit. HL7 FHIR."
        report = check_requirements(doc, ["LAB_EMR"])
        codes = [v.code for v in report.violations]
        assert "LAB-002" in codes

    def test_lab_002_passes_with_10_years(self):
        doc = "Lưu trữ bệnh án 10 năm. Audit trail chữ ký số. Giá trị tham chiếu unit. HL7 FHIR."
        report = check_requirements(doc, ["LAB_EMR"])
        codes = [v.code for v in report.violations]
        assert "LAB-002" not in codes

    def test_lab_003_missing_reference_values(self):
        doc = "Audit trail chữ ký số. 10 năm. HL7 FHIR."
        report = check_requirements(doc, ["LAB_EMR"])
        codes = [v.code for v in report.violations]
        assert "LAB-003" in codes

    def test_lab_004_missing_fhir(self):
        doc = "Audit trail chữ ký số. 10 năm. Giá trị tham chiếu unit."
        report = check_requirements(doc, ["LAB_EMR"])
        codes = [v.code for v in report.violations]
        assert "LAB-004" in codes


class TestCheckRequirementsVaccination:
    def test_compliant_doc_passes(self):
        report = check_requirements(VAC_DOC_COMPLIANT, ["VACCINATION"])
        assert report.passed is True

    def test_vac_001_missing_national_system(self):
        doc = "Hệ thống tiêm chủng chống chỉ định 20 năm."
        report = check_requirements(doc, ["VACCINATION"])
        codes = [v.code for v in report.violations]
        assert "VAC-001" in codes

    def test_vac_002_missing_contraindication(self):
        doc = "Tiêm chủng quốc gia thông tư 09. 20 năm."
        report = check_requirements(doc, ["VACCINATION"])
        codes = [v.code for v in report.violations]
        assert "VAC-002" in codes

    def test_vac_003_missing_20_year_retention(self):
        doc = "Tiêm chủng quốc gia thông tư 09. Chống chỉ định. Lưu 10 năm."
        report = check_requirements(doc, ["VACCINATION"])
        codes = [v.code for v in report.violations]
        assert "VAC-003" in codes

    def test_vac_003_passes_with_20_years(self):
        doc = "Tiêm chủng quốc gia thông tư 09. Chống chỉ định. Lưu 20 năm."
        report = check_requirements(doc, ["VACCINATION"])
        codes = [v.code for v in report.violations]
        assert "VAC-003" not in codes


class TestCheckRequirementsPayment:
    def test_compliant_doc_passes(self):
        report = check_requirements(PAY_DOC_COMPLIANT, ["PAYMENT"])
        assert report.passed is True

    def test_pay_001_missing_cvv_pan(self):
        doc = "Hệ thống thanh toán mã hoá AES-256 network segmentation."
        report = check_requirements(doc, ["PAYMENT"])
        codes = [v.code for v in report.violations]
        assert "PAY-001" in codes

    def test_pay_002_missing_aes256(self):
        doc = "Không lưu CVV PAN. Network segmentation."
        report = check_requirements(doc, ["PAYMENT"])
        codes = [v.code for v in report.violations]
        assert "PAY-002" in codes

    def test_pay_003_missing_network_segmentation(self):
        doc = "Không lưu CVV PAN. Mã hoá AES-256."
        report = check_requirements(doc, ["PAYMENT"])
        codes = [v.code for v in report.violations]
        assert "PAY-003" in codes


class TestCheckRequirementsDevice:
    def test_compliant_doc_passes(self):
        report = check_requirements(DEV_DOC_COMPLIANT, ["MEDICAL_DEVICE"])
        assert report.passed is True

    def test_dev_001_missing_ntp_outlier(self):
        doc = "Thiết bị y tế hỗ trợ OTA firmware update cập nhật."
        report = check_requirements(doc, ["MEDICAL_DEVICE"])
        codes = [v.code for v in report.violations]
        assert "DEV-001" in codes

    def test_dev_002_missing_ota(self):
        doc = "Thiết bị y tế NTP timestamp outlier detection."
        report = check_requirements(doc, ["MEDICAL_DEVICE"])
        codes = [v.code for v in report.violations]
        assert "DEV-002" in codes


class TestCheckRequirementsInfosec:
    def test_compliant_doc_passes(self):
        report = check_requirements(SEC_DOC_COMPLIANT, ["INFOSEC"])
        assert report.passed is True

    def test_sec_001_missing_rto_rpo(self):
        doc = "Hệ thống bảo mật VNCERT trong hai mươi bốn giờ. Vi phạm dữ liệu bảy mươi hai giờ."
        report = check_requirements(doc, ["INFOSEC"])
        codes = [v.code for v in report.violations]
        assert "SEC-001" in codes

    def test_sec_002_missing_vncert(self):
        doc = "RTO 4 giờ RPO 1 giờ. Vi phạm dữ liệu 72 giờ."
        report = check_requirements(doc, ["INFOSEC"])
        codes = [v.code for v in report.violations]
        assert "SEC-002" in codes

    def test_sec_003_missing_72h_breach(self):
        doc = "RTO 4 giờ RPO 1 giờ. VNCERT 24 giờ."
        report = check_requirements(doc, ["INFOSEC"])
        codes = [v.code for v in report.violations]
        assert "SEC-003" in codes


class TestCheckRequirementsMultiDomain:
    def test_multi_domain_checks_all(self):
        doc = ""  # empty — all rules should fire
        domains = ["PHARMACY", "PAYMENT"]
        report = check_requirements(doc, domains)
        codes = [v.code for v in report.violations]
        assert any(c.startswith("PHARMACY") for c in codes)
        assert any(c.startswith("PAY") for c in codes)
        assert report.passed is False

    def test_domains_checked_matches_input(self):
        report = check_requirements("some doc", ["PHARMACY", "INFOSEC"])
        assert set(report.domains_checked) == {"PHARMACY", "INFOSEC"}

    def test_empty_domains_no_violations(self):
        report = check_requirements("", [])
        assert report.passed is True
        assert report.violations == []


# ---------------------------------------------------------------------------
# Unit tests — check_design
# ---------------------------------------------------------------------------


class TestCheckDesign:
    def test_compliant_doc_passes(self):
        report = check_design(DESIGN_DOC_COMPLIANT, ["PHARMACY"])
        assert report.passed is True
        assert report.violations == []

    def test_design_001_missing_retention_policy(self):
        doc = "Threat model. Data flow luồng dữ liệu. Backup recovery RTO RPO. Bác sĩ dược sĩ."
        report = check_design(doc, ["PHARMACY"])
        codes = [v.code for v in report.violations]
        assert "DESIGN-001" in codes

    def test_design_002_missing_threat_model(self):
        doc = "Data retention lưu trữ dữ liệu. Data flow luồng dữ liệu. Backup RTO RPO. Bác sĩ."
        report = check_design(doc, ["PHARMACY"])
        codes = [v.code for v in report.violations]
        assert "DESIGN-002" in codes

    def test_design_003_missing_data_flow(self):
        doc = "Data retention. Threat model. Backup recovery RTO RPO. Bác sĩ dược sĩ."
        report = check_design(doc, ["PHARMACY"])
        codes = [v.code for v in report.violations]
        assert "DESIGN-003" in codes

    def test_design_004_missing_backup_rto_rpo(self):
        doc = "Data retention. Threat model. Data flow luồng dữ liệu. Bác sĩ dược sĩ."
        report = check_design(doc, ["PHARMACY"])
        codes = [v.code for v in report.violations]
        assert "DESIGN-004" in codes

    def test_design_005_missing_role_based_access_healthcare(self):
        doc = "Data retention. Threat model. Data flow. Backup RTO RPO."
        report = check_design(doc, ["PHARMACY"])
        codes = [v.code for v in report.violations]
        assert "DESIGN-005" in codes

    def test_design_005_skipped_for_non_healthcare(self):
        doc = "Data retention. Threat model. Data flow. Backup RTO RPO."
        report = check_design(doc, ["PAYMENT"])
        codes = [v.code for v in report.violations]
        assert "DESIGN-005" not in codes

    def test_design_005_passes_with_doctor_roles(self):
        doc = "Data retention. Threat model. Data flow. Backup RTO RPO. Bác sĩ dược sĩ điều dưỡng."
        report = check_design(doc, ["LAB_EMR"])
        codes = [v.code for v in report.violations]
        assert "DESIGN-005" not in codes

    def test_empty_doc_all_violations(self):
        report = check_design("", ["PHARMACY"])
        assert len(report.violations) == 5
        assert report.passed is False


# ---------------------------------------------------------------------------
# Property-based tests
# ---------------------------------------------------------------------------


class TestComplianceReportProperties:
    """**Validates: Requirements 4.1–4.19, 5.1–5.6**"""

    @given(st.text(max_size=500))
    @settings(max_examples=100)
    def test_passed_iff_no_violations(self, doc: str):
        """passed=True iff violations list is empty."""
        for domains in [["PHARMACY"], ["PAYMENT"], ["INFOSEC"], []]:
            report = check_requirements(doc, domains)
            assert report.passed == (len(report.violations) == 0)

    @given(st.text(max_size=500))
    @settings(max_examples=100)
    def test_design_passed_iff_no_violations(self, doc: str):
        """passed=True iff violations list is empty for design check."""
        for domains in [["PHARMACY"], ["PAYMENT"], []]:
            report = check_design(doc, domains)
            assert report.passed == (len(report.violations) == 0)

    @given(st.text(max_size=500))
    @settings(max_examples=50)
    def test_violations_have_required_fields(self, doc: str):
        """Every violation has non-empty code, severity, message, section, remediation."""
        report = check_requirements(doc, ["PHARMACY", "PAYMENT", "INFOSEC"])
        for v in report.violations:
            assert v.code
            assert v.severity in ("ERROR", "WARNING")
            assert v.message
            assert v.section
            assert v.remediation

    @given(st.lists(
        st.sampled_from(["PHARMACY", "LAB_EMR", "VACCINATION", "PAYMENT", "MEDICAL_DEVICE", "INFOSEC"]),
        min_size=0, max_size=6, unique=True,
    ))
    @settings(max_examples=50)
    def test_domains_checked_matches_input(self, domains: list[str]):
        """domains_checked in report always equals the input domains list."""
        report = check_requirements("some document text", domains)
        assert set(report.domains_checked) == set(domains)

    @given(st.text(max_size=500))
    @settings(max_examples=50)
    def test_empty_domains_always_passes(self, doc: str):
        """With no domains, requirements check always passes."""
        report = check_requirements(doc, [])
        assert report.passed is True
        assert report.violations == []

    @given(st.text(max_size=500))
    @settings(max_examples=50)
    def test_checked_at_is_iso8601(self, doc: str):
        """checked_at field is always a valid ISO 8601 string."""
        from datetime import datetime
        report = check_requirements(doc, ["PHARMACY"])
        # Should not raise
        datetime.fromisoformat(report.checked_at)


# ---------------------------------------------------------------------------
# Named property tests — Tasks 2.1 and 2.2
# ---------------------------------------------------------------------------


class TestNamedPropertyTests:
    """Named property tests for compliance checker invariants.

    **Validates: Yêu cầu 4.1, 4.2, 4.6, 4.11 và Error Condition "Rx Drug Without Prescription Validation" và Invariant "Data Retention"**
    """

    # -----------------------------------------------------------------------
    # Property 2: Rx Drug Without Prescription Validation
    # Validates: Yêu cầu 4.1 và Error Condition "Rx Drug Without Prescription Validation"
    # -----------------------------------------------------------------------

    @given(
        st.text(
            alphabet=st.characters(whitelist_categories=("Lu", "Ll", "Nd", "Zs")),
            min_size=0,
            max_size=200,
        ).flatmap(
            lambda prefix: st.sampled_from(
                ["thuốc", "drug", "bán thuốc", "sell drug"]
            ).map(lambda kw: f"{prefix} {kw} {prefix}")
        )
    )
    @settings(max_examples=50)
    def test_property2_rx_drug_without_prescription_fails_pharmacy_001(self, doc: str):
        """Property 2: Rx Drug Without Prescription Validation.

        Mọi requirement bán thuốc Rx mà thiếu validation kê đơn phải fail với mã PHARMACY-001.

        **Validates: Yêu cầu 4.1 và Error Condition "Rx Drug Without Prescription Validation"**
        """
        # Ensure the document does NOT contain prescription validation keywords
        prescription_keywords = ["kê đơn", "prescription", "validation", "rx"]
        doc_lower = doc.lower()
        if any(kw in doc_lower for kw in prescription_keywords):
            return  # skip — document already has prescription validation

        report = check_requirements(doc, ["PHARMACY"])
        violation_codes = [v.code for v in report.violations]
        assert "PHARMACY-001" in violation_codes, (
            f"Expected PHARMACY-001 violation for Rx drug doc without prescription validation, "
            f"got violations: {violation_codes!r}, doc snippet: {doc[:100]!r}"
        )
        assert report.passed is False

    # -----------------------------------------------------------------------
    # Property 3: Data Retention Invariant
    # Validates: Yêu cầu 4.2, 4.6, 4.11 và Invariant "Data Retention"
    # -----------------------------------------------------------------------

    @given(
        st.sampled_from([
            ("PHARMACY", "PHARMACY-002", 5),
            ("LAB_EMR", "LAB-002", 10),
            ("VACCINATION", "VAC-003", 20),
        ]),
        st.integers(min_value=0, max_value=4),  # years below PHARMACY minimum (< 5)
    )
    @settings(max_examples=50)
    def test_property3_data_retention_below_minimum_flagged(
        self,
        domain_config: tuple[str, str, int],
        years_below_min: int,
    ):
        """Property 3: Data Retention Invariant.

        Thời hạn lưu trữ trong document phải ≥ legal minimum theo từng loại dữ liệu.
        Documents with retention periods below legal minimums must be flagged.

        - PHARMACY: < 5 years → PHARMACY-002
        - LAB_EMR: < 10 years → LAB-002
        - VACCINATION: < 20 years → VAC-003

        **Validates: Yêu cầu 4.2, 4.6, 4.11 và Invariant "Data Retention"**
        """
        domain, expected_code, min_years = domain_config

        # Adjust years_below_min to be strictly below the domain's minimum
        # years_below_min is in [0, 4], so we scale it to be < min_years
        # Use modulo to keep it in [0, min_years - 1]
        actual_years = years_below_min % min_years if min_years > 0 else 0

        # Build a document that mentions the below-minimum retention period
        # but does NOT contain the minimum or higher
        doc = f"Lưu trữ dữ liệu trong {actual_years} năm."

        report = check_requirements(doc, [domain])
        violation_codes = [v.code for v in report.violations]
        assert expected_code in violation_codes, (
            f"Expected {expected_code} for domain={domain} with {actual_years} năm "
            f"(minimum is {min_years} năm), got violations: {violation_codes!r}"
        )
        assert report.passed is False
