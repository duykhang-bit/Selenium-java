"""Tests cho K8s models."""

from __future__ import annotations

from app.tasks.k8s.models import (
    ChecklistItem, GateResult, HelmValues, PromotionResult, CorrelationResult,
)


class TestHelmValues:
    def test_fields(self):
        h = HelmValues(filename="values.yaml", content="replicaCount: 1",
                       service_name="order-svc", environment="uat")
        assert h.filename == "values.yaml"
        assert h.environment == "uat"


class TestChecklistItem:
    def test_pass(self):
        item = ChecklistItem(name="UAT exists", status="PASS", message="OK")
        assert item.status == "PASS"

    def test_fail(self):
        item = ChecklistItem(name="UAT exists", status="FAIL", message="No UAT deployment found")
        assert item.status == "FAIL"


class TestGateResult:
    def test_approved_false_when_blocking_items(self):
        items = [
            ChecklistItem("UAT exists", "FAIL", "No UAT"),
            ChecklistItem("Soak time", "PASS", "OK"),
        ]
        result = GateResult(approved=False, checklist=items)
        assert result.approved is False

    def test_blocking_items_auto_populated(self):
        items = [
            ChecklistItem("UAT exists", "FAIL", "No UAT"),
            ChecklistItem("Soak time", "PASS", "OK"),
        ]
        result = GateResult(approved=False, checklist=items)
        assert len(result.blocking_items) == 1
        assert result.blocking_items[0].name == "UAT exists"

    def test_approved_true_no_blocking(self):
        items = [ChecklistItem("UAT exists", "PASS", "OK")]
        result = GateResult(approved=True, checklist=items)
        assert result.approved is True
        assert result.blocking_items == []


class TestPromotionResult:
    def test_defaults(self):
        r = PromotionResult(approved=True, service="svc", build_number=42, environment="ci")
        assert r.blocking_reasons == []
        assert r.jenkins_build_number is None

    def test_blocked(self):
        r = PromotionResult(approved=False, service="svc", build_number=42,
                            environment="uat", blocking_reasons=["CI not success"])
        assert r.approved is False
        assert len(r.blocking_reasons) == 1


class TestCorrelationResult:
    def test_likely_cause_true(self):
        r = CorrelationResult(
            service="svc", incident_time="2024-01-01T10:00:00Z",
            deployment={"record_id": "abc"}, time_delta_minutes=15.0,
            likely_cause=True, suggested_action="rollback",
        )
        assert r.likely_cause is True
        assert r.suggested_action == "rollback"

    def test_no_deployment(self):
        r = CorrelationResult(
            service="svc", incident_time="2024-01-01T10:00:00Z",
            deployment=None, time_delta_minutes=None,
            likely_cause=False, suggested_action="investigate_infra",
        )
        assert r.deployment is None
        assert r.context_snippets == []
