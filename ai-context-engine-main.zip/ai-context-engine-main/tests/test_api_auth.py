"""Tests for optional API key authentication middleware."""

from __future__ import annotations

import os
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient


@pytest.fixture()
def client_no_auth():
    """App with no API key configured (open access)."""
    with patch.dict(os.environ, {"AI_CONTEXT_V2_API_KEY": ""}):
        # Reload auth module to pick up cleared env var
        import importlib
        import app.core.auth as auth_mod
        importlib.reload(auth_mod)

        from app.main import app
        with TestClient(app, raise_server_exceptions=False) as c:
            yield c


@pytest.fixture()
def client_with_auth():
    """App with API key 'test-key-123' required."""
    with patch.dict(os.environ, {"AI_CONTEXT_V2_API_KEY": "test-key-123"}):
        import importlib
        import app.core.auth as auth_mod
        importlib.reload(auth_mod)

        from app.main import app
        with TestClient(app, raise_server_exceptions=False) as c:
            yield c

    # Cleanup: reload auth with empty key so subsequent tests are not affected
    import importlib
    import app.core.auth as auth_mod
    with patch.dict(os.environ, {"AI_CONTEXT_V2_API_KEY": ""}):
        importlib.reload(auth_mod)


class TestApiKeyDisabled:
    def test_root_accessible_without_key(self, client_no_auth):
        """When auth is disabled, root endpoint is accessible without any key."""
        resp = client_no_auth.get("/")
        assert resp.status_code == 200
        assert resp.json()["status"] == "running"

    def test_health_accessible_without_key(self, client_no_auth):
        """When auth is disabled, /api/health is accessible without any key."""
        resp = client_no_auth.get("/api/health")
        # 200 OK or 500 if DB not initialised in test — either way not 401
        assert resp.status_code != 401


class TestApiKeyEnabled:
    def test_missing_key_returns_401(self, client_with_auth):
        """When auth is enabled, request without X-API-Key header should get 401."""
        resp = client_with_auth.get("/api/health")
        assert resp.status_code == 401
        assert "X-API-Key" in resp.json().get("detail", "")

    def test_wrong_key_returns_401(self, client_with_auth):
        """Wrong key value should also get 401."""
        resp = client_with_auth.get("/api/health", headers={"X-API-Key": "wrong-key"})
        assert resp.status_code == 401

    def test_correct_key_passes(self, client_with_auth):
        """Correct key should pass authentication (response is not 401)."""
        resp = client_with_auth.get("/api/health", headers={"X-API-Key": "test-key-123"})
        assert resp.status_code != 401

    def test_root_not_protected(self, client_with_auth):
        """Root / endpoint should never be protected (health check, no /api prefix)."""
        resp = client_with_auth.get("/")
        assert resp.status_code == 200
