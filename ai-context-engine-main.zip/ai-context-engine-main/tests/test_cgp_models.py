"""Tests cho CGP models."""

from __future__ import annotations

from app.tasks.code_gen.models import (
    BranchAlreadyExistsError,
    CodingTask,
    GeneratedCode,
    MRResult,
    PipelineResult,
)


class TestCodingTask:
    def test_defaults(self):
        t = CodingTask(task_id="t1", title="Add foo", type="add_function",
                       target_file="app/foo.py", description="Add foo function")
        assert t.depends_on == []
        assert t.priority == 3

    def test_with_dependencies(self):
        t = CodingTask(task_id="t2", title="Add bar", type="add_endpoint",
                       target_file="app/api/routes.py", description="Add bar endpoint",
                       depends_on=["t1"])
        assert "t1" in t.depends_on


class TestGeneratedCode:
    def test_defaults(self):
        g = GeneratedCode(file_path="app/foo.py", content="# code", mode="skeleton")
        assert g.language == "python"
        assert g.task_id == ""

    def test_llm_mode(self):
        g = GeneratedCode(file_path="app/foo.py", content="# code", mode="llm", task_id="t1")
        assert g.mode == "llm"
        assert g.task_id == "t1"


class TestMRResult:
    def test_fields(self):
        mr = MRResult(mr_id=7, mr_url="https://gitlab.example.com/mr/7",
                      branch_name="feature/x", title="feat: x", source_id="gitlab:42")
        assert mr.mr_id == 7


class TestPipelineResult:
    def test_defaults(self):
        r = PipelineResult(tasks=[], generated_files=[], mr_result=None,
                           duration_ms=100, trace_id="abc")
        assert r.errors == []


class TestBranchAlreadyExistsError:
    def test_is_exception(self):
        err = BranchAlreadyExistsError("branch 'main' already exists")
        assert isinstance(err, Exception)
        assert "main" in str(err)
