"""Tests cho GitLab write operations."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
import requests

from app.connectors.gitlab import GitLabConnector


def _connector() -> GitLabConnector:
    return GitLabConnector("https://gitlab.example.com", "token123")


class TestGetBranch:
    def test_returns_branch_dict(self):
        conn = _connector()
        with patch.object(conn.session, "get") as mock_get:
            mock_get.return_value = MagicMock(status_code=200, json=lambda: {"name": "main"})
            result = conn.get_branch(42, "main")
            assert result == {"name": "main"}

    def test_returns_none_when_404(self):
        conn = _connector()
        with patch.object(conn.session, "get") as mock_get:
            mock_get.return_value = MagicMock(status_code=404)
            result = conn.get_branch(42, "nonexistent")
            assert result is None

    def test_returns_none_on_exception(self):
        conn = _connector()
        with patch.object(conn.session, "get", side_effect=Exception("network error")):
            result = conn.get_branch(42, "main")
            assert result is None


class TestCreateBranch:
    def test_success(self):
        conn = _connector()
        with patch.object(conn.session, "post") as mock_post:
            mock_post.return_value = MagicMock(
                ok=True, status_code=201,
                json=lambda: {"name": "feature/new", "commit": {"id": "abc"}},
            )
            result = conn.create_branch(42, "feature/new", "main")
            assert result["name"] == "feature/new"
            call_json = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1].get("json")
            assert call_json["branch"] == "feature/new"
            assert call_json["ref"] == "main"

    def test_raises_on_conflict(self):
        conn = _connector()
        with patch.object(conn.session, "post") as mock_post:
            resp = MagicMock(ok=False, status_code=400)
            resp.raise_for_status.side_effect = requests.HTTPError("400")
            mock_post.return_value = resp
            with pytest.raises(requests.HTTPError):
                conn.create_branch(42, "existing-branch", "main")


class TestCommitFiles:
    def test_success(self):
        conn = _connector()
        files = [{"file_path": "app/foo.py", "content": "# hello", "action": "create"}]
        with patch.object(conn.session, "post") as mock_post:
            mock_post.return_value = MagicMock(
                ok=True, status_code=201,
                json=lambda: {"id": "abc123", "message": "feat: add foo"},
            )
            result = conn.commit_files(42, "feature/new", files, "feat: add foo")
            assert result["id"] == "abc123"
            call_json = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1].get("json")
            assert call_json["branch"] == "feature/new"
            assert call_json["commit_message"] == "feat: add foo"
            assert call_json["actions"] == files


class TestCreateMergeRequest:
    def test_success(self):
        conn = _connector()
        with patch.object(conn.session, "post") as mock_post:
            mock_post.return_value = MagicMock(
                ok=True, status_code=201,
                json=lambda: {"iid": 7, "web_url": "https://gitlab.example.com/proj/-/merge_requests/7"},
            )
            result = conn.create_merge_request(42, "feature/new", "main", "feat: new feature")
            assert result["iid"] == 7
            call_json = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1].get("json")
            assert call_json["source_branch"] == "feature/new"
            assert call_json["target_branch"] == "main"
            assert call_json["title"] == "feat: new feature"
