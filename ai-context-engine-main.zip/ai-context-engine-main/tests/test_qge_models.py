"""Tests cho Quality Gate Engine models."""

from __future__ import annotations

import pytest
from app.tasks.quality_gate.models import Finding, GateReport, QualityGateReport


def _finding(severity: str) -> Finding:
    return Finding(gate="test", severity=severity, file="f.py", message="msg", rule_id="X-001", suggestion="fix")


class TestGateReportPassed:
    def test_passed_when_no_findings(self):
        r = GateReport(gate="test")
        assert r.passed is True

    def test_passed_when_only_medium(self):
        r = GateReport(gate="test", findings=[_finding("MEDIUM")])
        assert r.passed is True

    def test_passed_when_only_low(self):
        r = GateReport(gate="test", findings=[_finding("LOW")])
        assert r.passed is True

    def test_failed_when_high(self):
        r = GateReport(gate="test", findings=[_finding("HIGH")])
        assert r.passed is False

    def test_failed_when_critical(self):
        r = GateReport(gate="test", findings=[_finding("CRITICAL")])
        assert r.passed is False


class TestQualityGateReportOverall:
    def test_pass_when_no_findings(self):
        r = QualityGateReport()
        assert r.overall == "PASS"

    def test_warn_when_only_medium(self):
        gate = GateReport(gate="test", findings=[_finding("MEDIUM")])
        r = QualityGateReport(gate_reports=[gate])
        assert r.overall == "WARN"

    def test_warn_when_only_low(self):
        gate = GateReport(gate="test", findings=[_finding("LOW")])
        r = QualityGateReport(gate_reports=[gate])
        assert r.overall == "WARN"

    def test_fail_when_high(self):
        gate = GateReport(gate="test", findings=[_finding("HIGH")])
        r = QualityGateReport(gate_reports=[gate])
        assert r.overall == "FAIL"

    def test_fail_when_critical(self):
        gate = GateReport(gate="test", findings=[_finding("CRITICAL")])
        r = QualityGateReport(gate_reports=[gate])
        assert r.overall == "FAIL"

    def test_fail_takes_priority_over_medium(self):
        gate = GateReport(gate="test", findings=[_finding("CRITICAL"), _finding("MEDIUM")])
        r = QualityGateReport(gate_reports=[gate])
        assert r.overall == "FAIL"

    def test_totals_correct(self):
        gate = GateReport(gate="test", findings=[
            _finding("CRITICAL"), _finding("HIGH"),
            _finding("MEDIUM"), _finding("LOW"),
        ])
        r = QualityGateReport(gate_reports=[gate])
        assert r.total_critical == 1
        assert r.total_high == 1
        assert r.total_medium == 1
        assert r.total_low == 1

    def test_all_findings_aggregated_across_gates(self):
        g1 = GateReport(gate="g1", findings=[_finding("HIGH")])
        g2 = GateReport(gate="g2", findings=[_finding("MEDIUM")])
        r = QualityGateReport(gate_reports=[g1, g2])
        assert len(r.all_findings) == 2
