"""Tests cho HITL gate."""

from __future__ import annotations

from datetime import datetime, timezone, timedelta
from unittest.mock import patch

import pytest

from app.catalog.database import init_database


@pytest.fixture(autouse=True)
def setup_db(tmp_path):
    from unittest.mock import PropertyMock
    import app.core.config as cfg_mod
    with patch.object(type(cfg_mod.settings), "catalog_db_path", new_callable=PropertyMock) as mock_db:
        mock_db.return_value = tmp_path / "catalog.db"
        with patch.object(type(cfg_mod.settings), "data_dir", new_callable=PropertyMock) as mock_data:
            mock_data.return_value = tmp_path
            with patch.object(type(cfg_mod.settings), "logs_dir", new_callable=PropertyMock) as mock_logs:
                mock_logs.return_value = tmp_path
                init_database()
                yield


class TestRequestApproval:
    def test_creates_pending_request(self):
        from app.tasks.observability.hitl_gate import request_approval, get_request
        rid = request_approval("deploy_prod", "Deploy v1.0 to PROD", {"build": 42})
        req = get_request(rid)
        assert req is not None
        assert req.status == "pending"
        assert req.action_type == "deploy_prod"
        assert req.payload == {"build": 42}

    def test_returns_request_id(self):
        from app.tasks.observability.hitl_gate import request_approval
        rid = request_approval("merge_to_main", "Merge feature branch")
        assert rid != ""
        assert len(rid) == 16


class TestApprove:
    def test_approve_updates_status(self):
        from app.tasks.observability.hitl_gate import request_approval, approve
        rid = request_approval("deploy_prod", "Deploy to PROD")
        result = approve(rid, "manager@example.com", "LGTM")
        assert result.status == "approved"
        assert result.approved_by == "manager@example.com"
        assert result.comment == "LGTM"

    def test_approve_returns_payload(self):
        from app.tasks.observability.hitl_gate import request_approval, approve
        rid = request_approval("deploy_prod", "Deploy", payload={"job": "deploy-prod", "build": 42})
        result = approve(rid, "manager")
        assert result.payload == {"job": "deploy-prod", "build": 42}

    def test_approve_non_pending_raises(self):
        from app.tasks.observability.hitl_gate import request_approval, approve
        rid = request_approval("deploy_prod", "Deploy")
        approve(rid, "manager")
        with pytest.raises(ValueError, match="not pending"):
            approve(rid, "manager2")

    def test_approve_unknown_raises(self):
        from app.tasks.observability.hitl_gate import approve
        with pytest.raises(KeyError):
            approve("nonexistent-id", "manager")


class TestReject:
    def test_reject_updates_status(self):
        from app.tasks.observability.hitl_gate import request_approval, reject
        rid = request_approval("deploy_prod", "Deploy to PROD")
        result = reject(rid, "manager", "Not ready")
        assert result.status == "rejected"
        assert result.comment == "Not ready"


class TestListPending:
    def test_returns_only_pending(self):
        from app.tasks.observability.hitl_gate import request_approval, approve, list_pending
        rid1 = request_approval("deploy_prod", "Deploy 1")
        rid2 = request_approval("merge_to_main", "Merge 1")
        approve(rid1, "manager")
        pending = list_pending()
        ids = [r.request_id for r in pending]
        assert rid2 in ids
        assert rid1 not in ids

    def test_filter_by_action_type(self):
        from app.tasks.observability.hitl_gate import request_approval, list_pending
        request_approval("deploy_prod", "Deploy")
        request_approval("merge_to_main", "Merge")
        pending = list_pending(action_type="deploy_prod")
        assert all(r.action_type == "deploy_prod" for r in pending)

    def test_expired_not_in_pending(self):
        from app.tasks.observability.hitl_gate import request_approval, list_pending
        from app.catalog.database import save_approval_request
        import uuid
        # Tạo request đã expired
        now = datetime.now(timezone.utc)
        past = (now - timedelta(hours=25)).isoformat()
        rid = uuid.uuid4().hex[:16]
        save_approval_request(
            request_id=rid, action_type="deploy_prod",
            description="Old deploy", created_at=past,
            expires_at=(now - timedelta(hours=1)).isoformat(),
        )
        pending = list_pending()
        ids = [r.request_id for r in pending]
        assert rid not in ids


class TestAuditLog:
    def test_audit_written_on_approve(self, tmp_path):
        from app.tasks.observability.hitl_gate import request_approval, approve
        rid = request_approval("deploy_prod", "Deploy")
        approve(rid, "manager")
        audit_file = tmp_path / "hitl_audit.jsonl"
        assert audit_file.exists()
        content = audit_file.read_text()
        assert "hitl_approved" in content
