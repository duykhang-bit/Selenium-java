﻿# AGENTS.md

## Mục tiêu

File này hướng dẫn Cursor/Codex cách làm việc với `AI-CONTEXT-ENGINE-V2`
để người dùng chỉ cần chat yêu cầu tự nhiên, còn agent tự quyết định khi
nào phải:

-   bootstrap dữ liệu nguồn
-   discover và sync source
-   tạo task brief từ ChromaDB
-   mở repo thật để đọc/sửa code

------------------------------------------------------------------------

## Nguyên tắc cốt lõi

1.  `ChromaDB` chỉ dùng để tìm context.
2.  `catalog.db` là nguồn sự thật về connectors và sources.
3.  Context dùng để **hiểu**, repo thật dùng để **sửa**.
4.  Muốn sửa code thật, luôn phải đọc file trong
    `data/workspaces/repos/...`.
5.  Không chỉnh tay dữ liệu trong `data/chroma/` hoặc `data/catalog.db`.
6.  Mỗi task kỹ thuật phải có **task dossier** riêng để lưu brief, plan,
    scope, impact, notes, result.
7.  Khi user chỉ hỏi phân tích/plan → luôn tạo brief và task dossier trước.
8.  Khi user muốn code → luôn lấy context và tạo task dossier trước rồi mới
    sửa.
9.  Khi user muốn implement code trên Git source → luôn sync repo thật về
    bản mới nhất trước khi đọc/sửa file.
10. Sau khi chốt kết quả test cho task và trước khi commit → tự động tạo
    branch từ `main` theo công thức:
    `features/{ten-dev}-{ma-ticket-jira}-{key-work-noi-dung-task}`.
11. Mọi thao tác git cho task implement như sync latest, checkout `main`,
    tạo branch, commit, push phải thực hiện trên **repo source thật đang
    sửa** trong `data/workspaces/repos/...` theo repo đã chọn trong
    brief/dossier, không thực hiện trên repo `ict-ai-context`, trừ khi chính
    task đang sửa `ict-ai-context`.

------------------------------------------------------------------------

## Thư mục quan trọng

-   Project root: `<PROJECT_ROOT>`
-   Config: `.env`
-   Catalog: `data/catalog.db`
-   Vector DB: `data/chroma/`
-   Task dossiers: `data/tasks/`

### Git workspace

    data/workspaces/repos/

Ví dụ:

    data/workspaces/repos/<org>/<project>/<repo>

### Confluence workspace

    data/workspaces/confluence/

### Task dossier workspace

    data/tasks/<year>/<year-month>/<task-id>/

------------------------------------------------------------------------

## Khi nào chạy bootstrap

Nếu user nói: - setup lại dữ liệu - nạp lại toàn bộ - bootstrap -
discover lại

→ chạy:

``` powershell
python -m app.cli reset-data
python -m app.cli bootstrap
```

Có thể kèm sync:

``` powershell
python -m app.cli bootstrap --sync-git --sync-confluence
```

------------------------------------------------------------------------

## Flow xử lý task kỹ thuật

### Bước 1 --- task-start

``` powershell
python -m app.cli task-start "<task>"
```

Lệnh này sẽ:

-   tạo brief từ context hiện có
-   chọn repo phù hợp nhất
-   tạo thư mục dossier trong `data/tasks/...`
-   sinh sẵn các file:

        task.json
        brief.md
        plan.md
        scope.md
        impact.md
        notes.md
        result.md
        timeline.jsonl

------------------------------------------------------------------------

### Bước 2 --- Đọc context

-   Confluence → business rule
-   Git → repo + module

------------------------------------------------------------------------

### Bước 3 --- Output bắt buộc (pre-code)

1.  Brief:
    -   business
    -   technical
2.  Repo:
    -   tên
    -   lý do
3.  File:
    -   file chính liên quan
4.  Đánh giá:
    -   đủ context chưa
5.  Dossier:
    -   task_id
    -   dossier path

------------------------------------------------------------------------

### Bước 4 --- Nếu chỉ cần plan

-   phân tích
-   đề xuất hướng xử lý
-   nêu rủi ro
-   cập nhật dossier ngay sau khi chốt plan:

``` powershell
python -m app.cli task-plan "<task_id>" --plan "<plan>" --scope "<scope>" --impact "<impact>" --notes "<notes>"
```

Trong dossier phải có tối thiểu:

-   `plan.md`: hướng xử lý, giả định, rủi ro
-   `scope.md`: file/module dự kiến sửa, phần ngoài phạm vi
-   `impact.md`: ảnh hưởng business, API, data, integration, test
-   `notes.md`: lưu ý quan trọng trước khi bắt đầu làm

------------------------------------------------------------------------

### Bước 5 --- Nếu implement code

BẮT BUỘC:

1.  Đọc lại Confluence
2.  Đọc Git context
3.  Sync repo thật về local mới nhất:

``` powershell
python -m app.cli sync-source "<git_source_id>"
```

4.  Mở repo thật:

```{=html}
<!-- -->
```
    data/workspaces/repos/...

5.  Đọc file thật
6.  Mọi thao tác git tiếp theo phải chạy trong đúng repo source đang sửa ở
    `data/workspaces/repos/...`, không chạy ở root repo `ict-ai-context`

Sau đó:

-   implement (minimal & safe)
-   build/test
-   sau khi chốt kết quả test, tạo branch từ `main` trước khi commit theo
    format:

        features/{ten-dev}-{ma-ticket-jira}-{key-work-noi-dung-task}

    Ví dụ:

        features/datnm11-FI-29396-extrainfo-ordersource

    Lưu ý:

    -   `main` ở đây là `main` của chính repo source đang sửa
    -   branch mới phải được tạo trong repo source đó
    -   commit và push cũng phải thực hiện trong repo source đó
    -   nếu task đang sửa `ict-oms-service` thì branch/commit/push phải chạy
        trong repo `ict-oms-service`, không chạy trong repo `ict-ai-context`

-   cập nhật `result.md` và `timeline.jsonl` trong dossier nếu đã hoàn thành
-   tóm tắt kết quả

Có thể dùng:

``` powershell
python -m app.cli task-result "<task_id>" --result "<result>"
```

------------------------------------------------------------------------

## Output chuẩn khi code

1.  Brief
2.  Repo
3.  File
4.  Dossier
5.  Plan
6.  Implementation
7.  Build/Test
8.  Result

------------------------------------------------------------------------

## Khi user cung cấp link

### Git

``` powershell
python -m app.cli add-git "<url>"
python -m app.cli sync-source "<id>"
```

Hoặc:

``` powershell
python -m app.cli sync-git-all
```

------------------------------------------------------------------------

### Confluence

``` powershell
python -m app.cli add-confluence "<url>"
python -m app.cli sync-source "confluence:<id>"
```

Hoặc:

``` powershell
python -m app.cli sync-confluence-all
```

------------------------------------------------------------------------

## Các lệnh chính

``` powershell
python -m app.cli bootstrap
python -m app.cli sync-git-all
python -m app.cli sync-confluence-all
python -m app.cli task-start "<task>"
python -m app.cli task-plan "<task_id>" --plan "<plan>" --scope "<scope>" --impact "<impact>" --notes "<notes>"
python -m app.cli task-result "<task_id>" --result "<result>"
python -m app.cli task-show "<task_id>"
```

------------------------------------------------------------------------

## Quy tắc branch

-   Sau khi đã chốt kết quả test và trước khi commit, luôn tạo branch mới từ
    `main` của **repo source thật đang sửa** trong
    `data/workspaces/repos/...`.
-   Công thức branch:

        features/{ten-dev}-{ma-ticket-jira}-{key-work-noi-dung-task}

-   `key-work-noi-dung-task` phải viết thường, ngắn gọn, nối bằng dấu `-`.
-   Repo tạo branch là repo được chọn trong brief/dossier và là repo đang
    được implement thật.
-   Ví dụ chuẩn:

        features/datnm11-FI-29396-extrainfo-ordersource

-   Nếu task đang sửa `ict-oms-service` trong workspace thì branch phải được
    tạo từ `main` của repo `ict-oms-service` và commit/push cũng phải thực
    hiện trong repo `ict-oms-service`.
-   Chỉ tạo branch/commit ở repo `ict-ai-context` khi chính task đang sửa
    source của `ict-ai-context`.

------------------------------------------------------------------------

## Điều không nên làm

-   Không đoán repo
-   Không sửa code từ vector chunk
-   Không bỏ qua repo thật
-   Không sửa code trên repo local khi chưa sync latest nếu task là implement
-   Không bỏ qua task dossier khi đã bắt đầu task
-   Không tạo branch/commit ở repo `ict-ai-context` nếu repo đang sửa là repo
    source khác trong workspace
-   Không code khi chưa có context

------------------------------------------------------------------------

## Quy tắc ra quyết định

-   catalog → bootstrap
-   git → sync-git
-   confluence → sync-confluence
-   hiểu task → task-start
-   plan xong → task-plan
-   code → task-start → context → sync-source repo thật → repo → code →
    build/test → tao branch tu main → update dossier → commit
