# Hướng dẫn Workflow: AI-Native SDLC

## Tài liệu này dành cho ai?

Dành cho developer, tech lead, và product owner muốn hiểu:
- AI Context Engine hoạt động như thế nào
- Cách sử dụng đúng để tránh hallucination
- Toàn bộ workflow từ ý tưởng đến production
- Cách prompt hiệu quả với AI agent

---

## Phần 1: Hiểu đúng về hệ thống

### AI Context Engine là gì?

AI Context Engine **không phải** là một AI tự nghĩ ra code. Nó là một **nền tảng cung cấp context thật** cho AI agent, bao gồm:

- Code thật từ GitLab repos (đã clone về local)
- Tài liệu nghiệp vụ thật từ Confluence
- Ticket thật từ Jira
- Lịch sử thay đổi, convention, pattern của từng repo

Khi AI agent (Kiro, Claude, Cursor...) được kết nối vào hệ thống này qua **MCP protocol**, mọi output của AI đều dựa trên dữ liệu thật — không phải kiến thức chung chung từ training data.

### Tại sao cần điều này?

Vấn đề với AI agent thông thường:

```
Developer: "Viết API lấy đơn hàng cho hệ thống OMS"
AI (không có context): [Tự nghĩ ra cấu trúc, đặt tên biến, chọn pattern]
                        → Kết quả không khớp với codebase thực tế
                        → Developer phải sửa lại nhiều
```

Với AI Context Engine:

```
Developer: "Viết API lấy đơn hàng cho hệ thống OMS"
AI (có context): [Tìm trong ChromaDB: OrderService, OrderRepository, naming convention]
                 [Đọc Confluence: business rule về đơn hàng]
                 [Đọc Jira: ticket liên quan, acceptance criteria]
                 → Kết quả đúng convention, đúng business rule, đúng pattern
```

### Kiến trúc tổng thể

```
┌─────────────────────────────────────────────────────────────────┐
│                    AI Agent (Kiro / Claude / Cursor)             │
│                                                                  │
│  "Tạo requirement cho tính năng đặt lịch tiêm chủng"            │
└──────────────────────────┬──────────────────────────────────────┘
                           │ MCP Protocol
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                    MCP Server (port 3000)                        │
│                                                                  │
│  Nhóm Context:          Nhóm Jira:           Nhóm RDE:          │
│  - search_context       - jira_search        - rde_generate_req │
│  - get_confluence_page  - jira_brief         - rde_generate_des │
│  - get_repo_structure   - jira_create        - rde_check_comply │
│  - sync_sources         - jira_link_dossier  - rde_analyze_imp  │
│                                                                  │
│  [Module 3 sắp tới]     [Module 4 sắp tới]  [Module 5/6 tới]   │
│  - quality_gate_check   - jenkins_trigger    - code_generate    │
│  - sast_scan            - build_status       - k8s_deploy       │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Dữ liệu thật                                  │
│                                                                  │
│  ChromaDB          Jira Server      Confluence      GitLab      │
│  (vector index     (tickets,        (tài liệu       (repos,     │
│   của code +       epics,           nghiệp vụ)      branches)   │
│   tài liệu)        sprints)                                      │
└─────────────────────────────────────────────────────────────────┘
```

---

## Phần 2: Cơ chế chống Hallucination

### Nguyên tắc cốt lõi: Grounded Generation

Mọi output của AI phải có **nguồn gốc có thể truy vết**. Cụ thể:

**Bước 1 — Search trước, generate sau**
```
Intent → ChromaDB search (code thật) → Confluence search (docs thật) → Jira search (tickets thật)
      → Tổng hợp context → Generate document với citation
```

**Bước 2 — Citation bắt buộc**

Mọi requirement/design document được sinh ra đều phải có phần `sources`:
```markdown
## Nguồn tham khảo
- [GitLab] ict-oms-service/src/OrderService.java (chunk #42, score: 0.89)
- [Confluence] Quy trình xử lý đơn hàng OMS (page_id: 144019569)
- [Jira] OMS-123: Thêm field extraInfo vào order response
```

Nếu không tìm được source liên quan → AI phải báo rõ "Không tìm thấy context liên quan, cần bổ sung tài liệu" thay vì tự nghĩ ra.

**Bước 3 — Compliance check rule-based**

Compliance checker **không dùng AI** — dùng rule-based keyword matching và regex. Điều này đảm bảo:
- Không thể bị AI "sáng tạo" ra compliance clause giả
- Kết quả deterministic, có thể audit
- Mã lỗi cụ thể (PHARMACY-001, LAB-002...) có thể trace về quy định pháp luật cụ thể

**Bước 4 — Human-in-the-loop tại các điểm quan trọng**

AI không tự động làm mọi thứ. Có các gate bắt buộc phải có human approve:

| Gate | Điều kiện | Hành động |
|------|-----------|-----------|
| Requirement approval | Sau khi AI sinh requirements | Human review và approve |
| Design approval | Sau khi AI sinh design | Human review và approve |
| Code review | Sau khi AI sinh code | Human review MR trên GitLab |
| UAT approval | Sau khi deploy UAT | Human test và approve |
| PROD deployment | Trước khi lên PROD | Human approve bắt buộc |

---

## Phần 3: Toàn bộ Workflow Intent → Impact

### Sơ đồ tổng quan

```
[INTENT]
   │
   ▼
[BƯỚC 1] Sinh Requirements (Module 2)
   │  AI đọc ChromaDB + Confluence + Jira
   │  → BRD/PRD + Compliance check
   │  → Lưu Confluence
   │  ⚠️  HUMAN APPROVE
   │
   ▼
[BƯỚC 2] Sinh Design (Module 2)
   │  AI đọc requirements + codebase context
   │  → HLD + LLD + ERD + OpenAPI spec
   │  → Impact analysis
   │  → Lưu Confluence
   │  ⚠️  HUMAN APPROVE
   │
   ▼
[BƯỚC 3] Tạo Jira Tickets (Module 1 - đã có)
   │  AI tạo Epic → Story → Sub-task
   │  → Quality gate check
   │  → Tạo trên Jira
   │
   ▼
[BƯỚC 4] Sinh Code (Module 5 - sắp tới)
   │  AI đọc design + repo thật
   │  → Tạo branch trên GitLab
   │  → Sinh code theo convention
   │  → Sinh unit test
   │  ⚠️  HUMAN REVIEW MR
   │
   ▼
[BƯỚC 5] Quality Gate (Module 3 - sắp tới)
   │  SAST scan (Semgrep/Bandit)
   │  Code coverage check (≥ 80%)
   │  Performance check (N+1, missing index)
   │  Security scan (secret detection)
   │  API contract validation
   │  → Pass/Fail report
   │
   ▼
[BƯỚC 6] CI/CD (Module 4 - sắp tới)
   │  Jenkins pipeline trigger
   │  Build + test
   │  → Build status về dossier
   │  AI phân tích log nếu fail
   │
   ▼
[BƯỚC 7] Deploy UAT (Module 6 - sắp tới)
   │  K8s deployment
   │  Smoke test tự động
   │  ⚠️  HUMAN TEST & APPROVE
   │
   ▼
[BƯỚC 8] Deploy PROD (Module 6 - sắp tới)
   │  PROD promotion checklist
   │  Rollback plan
   │  ⚠️  HUMAN APPROVE BẮT BUỘC
   │
   ▼
[IMPACT]
```

### Task Dossier — Trung tâm quản lý trạng thái

Mỗi task đều có một **task dossier** lưu toàn bộ trạng thái:

```
data/tasks/2024/2024-01/task-20240115-120000-dat-lich-tiem-chung/
├── task.json          ← metadata, trạng thái, links
├── brief.md           ← context brief từ ChromaDB
├── requirements.md    ← BRD/PRD (Module 2)
├── design.md          ← HLD/LLD (Module 2)
├── plan.md            ← implementation plan
├── scope.md           ← phạm vi thay đổi
├── impact.md          ← impact analysis
├── notes.md           ← ghi chú
├── result.md          ← kết quả cuối
└── timeline.jsonl     ← audit trail mọi action
```

`task.json` liên kết với tất cả hệ thống:
```json
{
  "task_id": "task-20240115-...",
  "jira_issue_key": "VACC-123",
  "confluence_page_id": "144019569",
  "gitlab_branch": "features/datnm11-VACC-123-dat-lich-tiem-chung",
  "gitlab_mr_id": "456",
  "jenkins_build_id": "789",
  "k8s_deployment": "vaccination-service-uat",
  "status": "in_progress",
  "phase": "design"
}
```

---

## Phần 4: Cách sử dụng — Prompt Guide

### Cấu hình kết nối MCP

Thêm vào cấu hình của Kiro / Cursor / Claude Desktop:

```json
{
  "mcpServers": {
    "ai-context-engine": {
      "url": "http://localhost:3000/mcp"
    }
  }
}
```

Khởi động MCP server:
```bash
python -m app.mcp_server
```

### Nhóm 1: Tìm kiếm context

**Tìm kiếm tổng quát:**
```
Tìm trong codebase và tài liệu về cách xử lý đơn hàng trong hệ thống OMS
```
→ AI gọi `search_context(query="xử lý đơn hàng OMS")`

**Đọc tài liệu Confluence cụ thể:**
```
Đọc trang Confluence về quy trình xử lý đơn hàng (page ID: 144019569)
```
→ AI gọi `get_confluence_page(page_id="144019569")`

**Xem cấu trúc repo:**
```
Cho tôi xem cấu trúc thư mục và lệnh build của repo ict-oms-service
```
→ AI gọi `get_repo_structure(source_id="gitlab:42")`

### Nhóm 2: Jira workflow

**Tạo ticket từ ý tưởng:**
```
Tạo Jira ticket cho tính năng: Thêm tính năng đặt lịch tiêm chủng online cho phụ huynh
Project: VACC
```
→ AI gọi `jira_create_from_intent(intent="...", project_key="VACC")`

**Sinh brief từ ticket:**
```
Tạo task brief đầy đủ cho ticket VACC-123
```
→ AI gọi `jira_brief_from_ticket(issue_key="VACC-123")`

**Tìm kiếm Jira issues:**
```
Tìm các ticket liên quan đến tính năng đặt lịch trong Jira
```
→ AI gọi `jira_search(query="đặt lịch tiêm chủng")`

### Nhóm 3: Requirement & Design (Module 2 — sắp có)

**Sinh requirements từ intent:**
```
Sinh tài liệu requirements cho tính năng:
"Xây dựng module quản lý lịch tiêm chủng cho trung tâm tiêm chủng,
bao gồm đặt lịch online, nhắc lịch, và theo dõi phản ứng sau tiêm"

Publish lên Confluence space: VACC
```
→ AI gọi `rde_generate_requirements(intent="...", publish_to_confluence=True, confluence_space_key="VACC")`

**Sinh design từ requirements:**
```
Dựa trên requirements vừa tạo, sinh tài liệu thiết kế kỹ thuật
bao gồm HLD, data model, và API contract
```
→ AI gọi `rde_generate_design(requirements_doc="...", publish_to_confluence=True)`

**Kiểm tra compliance:**
```
Kiểm tra tài liệu requirements này có tuân thủ đầy đủ
Thông tư 09/2023 về tiêm chủng không?
```
→ AI gọi `rde_check_compliance(document="...", document_type="requirements", domains=["VACCINATION"])`

**Phân tích impact:**
```
Phân tích xem requirements mới này ảnh hưởng đến những service nào trong hệ thống
```
→ AI gọi `rde_analyze_impact(requirements_doc="...")`

### Nhóm 4: Quality Gate (Module 3 — sắp có)

```
Chạy quality gate cho MR !456 trên repo ict-vaccination-service
```
→ AI gọi `quality_gate_check(mr_id="456", repo="ict-vaccination-service")`

### Nhóm 5: Workflow đầy đủ (prompt một lần)

Đây là cách sử dụng mạnh nhất — AI tự điều phối toàn bộ:

```
Tôi muốn implement tính năng mới:
"Thêm tính năng xuất báo cáo doanh thu theo ngày cho hệ thống nhà thuốc"

Hãy:
1. Sinh requirements đầy đủ (có compliance check Luật Dược)
2. Sinh design kỹ thuật
3. Tạo Jira tickets
4. Publish tài liệu lên Confluence space PHARMACY

Project Jira: PHARM
```

AI sẽ tự động gọi theo thứ tự:
1. `rde_generate_requirements()` → BRD/PRD + compliance check
2. `rde_generate_design()` → HLD/LLD + impact analysis
3. `jira_create_from_intent()` → Epic/Story/Sub-task
4. `rde_publish_to_confluence()` → Lưu tài liệu

---

## Phần 5: Những điều cần lưu ý

### Trước khi dùng — Đảm bảo dữ liệu đã được index

AI chỉ biết những gì đã được sync vào ChromaDB. Nếu repo hoặc Confluence page chưa được sync, AI sẽ không có context.

```bash
# Kiểm tra sources đã index
python -m app.cli list-sources

# Sync repo mới
python -m app.cli add-git "https://gitlab.company.com/org/repo"
python -m app.cli sync-source "<source_id>"

# Sync Confluence page
python -m app.cli add-confluence "https://confluence.company.com/spaces/PHARM/pages/123"
python -m app.cli sync-source "confluence:123"

# Sync Jira project
python -m app.cli jira-sync --project-key PHARM
```

### Khi AI báo "không tìm thấy context"

Đây là hành vi **đúng** — AI không hallucinate. Cần:
1. Kiểm tra source đã được sync chưa
2. Thử query với từ khoá khác
3. Sync thêm tài liệu liên quan

### Khi compliance check fail

Đây là **bảo vệ bắt buộc**, không phải lỗi. Ví dụ:

```
PHARMACY-001: Thiếu điều khoản validation kê đơn Rx
→ Bổ sung vào requirements: "Hệ thống phải xác nhận đơn thuốc hợp lệ trước khi bán thuốc Rx"

LAB-002: Thời hạn lưu trữ bệnh án < 10 năm
→ Sửa lại: "Hồ sơ bệnh án phải được lưu trữ tối thiểu 10 năm (người lớn)"
```

### Không bao giờ bỏ qua human-in-the-loop gate

Dù AI có thể tự động hoá nhiều bước, các gate sau **bắt buộc** phải có human approve:
- Approve requirements trước khi sinh design
- Approve design trước khi tạo Jira tickets và sinh code
- Review MR trên GitLab trước khi merge
- Approve UAT trước khi lên PROD
- Approve PROD deployment

---

## Phần 6: Trạng thái hiện tại và Roadmap

### Đã có (có thể dùng ngay)

| Tool | Mô tả |
|------|-------|
| `search_context` | Tìm kiếm trong ChromaDB |
| `get_confluence_page` | Đọc trang Confluence |
| `get_repo_structure` | Xem cấu trúc repo |
| `sync_sources` | Sync source vào ChromaDB |
| `get_task_brief` | Sinh task brief |
| `jira_sync_project` | Pull Jira issues vào ChromaDB |
| `jira_create_from_intent` | Tạo Epic/Story/Sub-task |
| `jira_brief_from_ticket` | Sinh brief từ Jira ticket |
| `jira_search` | Tìm kiếm Jira issues |
| `jira_link_dossier` | Liên kết dossier với Jira |

### Đang phát triển (Module 2)

| Tool | Mô tả | ETA |
|------|-------|-----|
| `rde_generate_requirements` | Sinh BRD/PRD từ intent | Module 2 |
| `rde_generate_design` | Sinh HLD/LLD/OpenAPI | Module 2 |
| `rde_check_compliance` | Kiểm tra compliance theo domain | Module 2 |
| `rde_analyze_impact` | Phân tích impact lên codebase | Module 2 |
| `rde_publish_to_confluence` | Publish tài liệu lên Confluence | Module 2 |

### Sắp tới

| Module | Tools | Mô tả |
|--------|-------|-------|
| Module 3 | `quality_gate_check`, `sast_scan`, `test_generate` | Quality Gate Engine |
| Module 4 | `jenkins_trigger`, `build_status` | Jenkins Integration |
| Module 5 | `code_generate`, `branch_create`, `mr_create` | Code Generation |
| Module 6 | `k8s_deploy_uat`, `k8s_deploy_prod` | K8s Deployment |
