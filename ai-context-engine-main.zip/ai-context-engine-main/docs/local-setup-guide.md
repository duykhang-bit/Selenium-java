# Local Setup Guide — AI Context Engine V2

Hướng dẫn chạy AI Context Engine V2 trên máy local để test và phát triển.

> **Người mới:** có thể làm theo từng bước ngắn gọn trong [onboarding-new-developer.md](onboarding-new-developer.md), rồi quay lại tài liệu này khi cần chi tiết (sync, test module, troubleshooting).

---

## Yêu cầu

- Python **3.10+** (dependency `mcp` không hỗ trợ 3.9; khuyến nghị 3.11+ hoặc 3.12)
- Git
- RAM: tối thiểu 4GB (embedding model cần ~1.5GB)
- Disk: tối thiểu 10GB

---

## Bước 1 — Clone và cài dependencies

```bash
git clone <repo-url>
cd ict-ai-context-engine

# Tạo virtual environment
python3 -m venv .venv
source .venv/bin/activate  # macOS/Linux
# .venv\Scripts\activate   # Windows

# Cài dependencies
pip install -r requirements.txt
```

---

## Bước 2 — Tạo file `.env`

```bash
cp .env.example .env
```

### 2.1 Tạo Secret Key

```bash
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Dán vào `.env`:
```env
AI_CONTEXT_V2_SECRET_KEY=<output ở trên>
```

### 2.2 Điền tokens

Mở `.env` và điền các giá trị:

```env
# GitLab — cần scope: api
AI_CONTEXT_V2_GITLAB_BASE_URL=https://git.example.com
AI_CONTEXT_V2_GITLAB_TOKEN=glpat-xxxxxxxxxxxxxxxxxxxx

# Confluence
AI_CONTEXT_V2_CONFLUENCE_BASE_URL=https://confluence.example.com
AI_CONTEXT_V2_CONFLUENCE_TOKEN=<token>
AI_CONTEXT_V2_CONFLUENCE_USERNAME=<username>

# Jira (optional — chỉ cần nếu test Module 1)
AI_CONTEXT_V2_JIRA_BASE_URL=https://jira.example.com
AI_CONTEXT_V2_JIRA_TOKEN=<token>
AI_CONTEXT_V2_JIRA_PROJECT_KEYS=PROJ

# Jenkins (optional — chỉ cần nếu test Module 4/6)
AI_CONTEXT_V2_JENKINS_BASE_URL=https://jenkins.example.com
AI_CONTEXT_V2_JENKINS_USERNAME=admin
AI_CONTEXT_V2_JENKINS_TOKEN=<token>

# LLM (optional — để trống = dùng skeleton mode)
AI_CONTEXT_V2_LLM_API_KEY=
```

> Không cần điền tất cả ngay — chỉ điền những gì cần test.

---

## Bước 3 — Bootstrap

```bash
python -m app.cli bootstrap
```

Lệnh này sẽ:
- Khởi tạo `data/catalog.db`
- Đăng ký connectors từ `.env`
- Discover tất cả GitLab repos và Confluence pages

Kiểm tra:
```bash
python -m app.cli list-connectors
python -m app.cli list-sources
```

---

## Bước 4 — Sync sources (lần đầu)

```bash
# Sync tất cả (có thể mất 10-30 phút lần đầu)
python -m app.cli sync-all

# Hoặc sync từng phần
python -m app.cli sync-git-all
python -m app.cli sync-confluence-all

# Hoặc sync 1 source cụ thể để test nhanh
python -m app.cli sync-source gitlab:42
```

---

## Bước 5 — Khởi động servers

Mở 2 terminal:

**Terminal 1 — MCP Server (port 3000):**
```bash
source .venv/bin/activate
python -m app.mcp_server
```

**Terminal 2 — REST API (port 8100):**
```bash
source .venv/bin/activate
python -m app.main
```

Kiểm tra:
```bash
curl http://localhost:8100/api/health
# → {"status": "ok", "service": "ai-context-engine-v2"}
```

Swagger UI: http://localhost:8100/docs

---

## Bước 6 — Kết nối AI coding tool

**Kiro** (`.kiro/settings/mcp.json` trong workspace):
```json
{
  "mcpServers": {
    "ai-context-engine": {
      "url": "http://localhost:3000/mcp"
    }
  }
}
```

**Cursor** (Settings > MCP Servers):
```json
{ "ai-context-engine": { "url": "http://localhost:3000/mcp" } }
```

Restart tool → thử: `search_context("order service")`

---

## Test từng Module

### Module 2 — Requirements & Design

```bash
# Sinh requirements
python -m app.cli rde-requirements "thêm tính năng thanh toán trả góp"

# Sinh design
python -m app.cli rde-design requirements.md

# Kiểm tra compliance
python -m app.cli rde-check-compliance requirements.md --type requirements
```

### Module 3 — Quality Gate

```bash
# Tạo diff test
git diff HEAD~1 > test.diff

# Chạy quality gate
python -m app.cli qge-analyze test.diff

# Sinh test skeleton
python -m app.cli qge-generate-tests test.diff
```

### Module 4 — Jenkins (cần Jenkins thật hoặc mock)

```bash
python -m app.cli jenkins-status <job-name> <build-number>
python -m app.cli jenkins-deployments --service order-service
```

### Module 5 — Code Generation

```bash
# Phân tích design
python -m app.cli cgp-decompose design.md --source-id gitlab:42

# Sinh commit message
echo "+def process_order(): pass" | python -m app.cli cgp-commit-message -

# Chạy pipeline (cần GitLab token có quyền write)
python -m app.cli cgp-run-pipeline design.md \
  --source-id gitlab:42 \
  --branch feature/test-branch
```

### Module 6 — K8s Deployment

```bash
# Sinh Helm values
python -m app.cli k8s-helm-values order-service \
  --image registry/order-service \
  --tag 1.0.0 \
  --port 8080

# Test promotion flow (không cần K8s thật — chỉ check catalog)
python -m app.cli k8s-promote-ci order-service --build 1 --job deploy-ci
python -m app.cli k8s-promote-uat order-service --build 1 --job deploy-uat
python -m app.cli k8s-prod-gate order-service --build 1

# Correlate incident
python -m app.cli k8s-correlate order-service --time "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
```

### Module 7 — Observability

```bash
# Xem audit logs
python -m app.cli obs-audit-logs --limit 20

# Score confidence
python -m app.cli obs-score commit_message - <<< "feat(api): add order endpoint"

# Test HITL workflow
python -m app.cli obs-request-approval deploy_prod \
  --desc "Test deploy" \
  --payload '{"build": 1}'

python -m app.cli obs-list-approvals

python -m app.cli obs-approve <request_id> --by "test-user" --comment "OK"
```

---

## Test REST API trực tiếp

```bash
# Search context
curl "http://localhost:8100/api/search?q=order+service&top_k=3"

# Generate requirements
curl -X POST http://localhost:8100/api/rde/generate-requirements \
  -H "Content-Type: application/json" \
  -d '{"intent": "thêm tính năng thanh toán trả góp", "collection": "knowledge"}'

# Quality gate
curl -X POST http://localhost:8100/api/qge/analyze \
  -H "Content-Type: application/json" \
  -d '{"diff": "+def foo(): pass\n"}'

# Helm values
curl -X POST http://localhost:8100/api/k8s/helm-values \
  -H "Content-Type: application/json" \
  -d '{"service_name": "order-svc", "image_repository": "registry/order-svc", "image_tag": "1.0.0", "port": 8080}'

# List pending approvals
curl http://localhost:8100/api/obs/approvals
```

---

## Chạy tests

```bash
# Tất cả tests (bỏ qua test cần model download)
pytest tests/ --ignore=tests/test_brief_enhanced.py --ignore=tests/test_mcp_integration.py -v

# Test một module cụ thể
pytest tests/test_qge_*.py -v
pytest tests/test_k8s_*.py -v
pytest tests/test_obs_*.py -v

# Test nhanh (không verbose)
pytest tests/ --ignore=tests/test_brief_enhanced.py --ignore=tests/test_mcp_integration.py -q
```

---

## Reset và bắt đầu lại

```bash
python -m app.cli reset-data
python -m app.cli bootstrap
```

---

## Troubleshooting

**`ModuleNotFoundError`:**
```bash
pip install -r requirements.txt
```

**Embedding model download chậm lần đầu:**
Model `all-MiniLM-L6-v2` (~90MB) tự download khi chạy lần đầu. Chờ hoặc download thủ công:
```bash
python -c "from sentence_transformers import SentenceTransformer; SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')"
```

**Port đã bị dùng:**
```bash
# Kiểm tra port
lsof -i :3000
lsof -i :8100

# Đổi port trong .env
AI_CONTEXT_V2_API_PORT=8200
```

**ChromaDB lỗi:**
```bash
python -m app.cli reset-data
python -m app.cli bootstrap
```
