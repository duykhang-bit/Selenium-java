# Onboarding — Chạy AI Context Engine local (ưu tiên AI Agentic IDE)

Tài liệu này hướng dẫn **người mới** onboard bằng **Cursor**, **Kiro** hoặc **Antigravity** (và các IDE/agent tương tự): bạn **không cần gõ từng lệnh tay** — mở IDE, giao việc cho agent, rồi **kiểm tra** và **điền secret** khi cần.

Chi tiết kỹ thuật, module, troubleshooting: [local-setup-guide.md](local-setup-guide.md), [developer-guide.md](developer-guide.md).

---

## 1. Chuẩn bị tối thiểu (con người)

| Cần có | Ghi chú |
|--------|---------|
| Một **AI Agentic IDE** đã cài (Cursor / Kiro / Antigravity, …) | Agent sẽ chạy terminal, sửa file trong workspace |
| **URL repo Git** (GitLab/GitHub) mà bạn có quyền clone | Đưa vào prompt hoặc paste cho agent |
| (Tuỳ chọn) **PAT** GitLab, Confluence, Jira | Agent **không tự sinh** được — do bạn lấy từ portal và **dán vào `.env`** hoặc dict cho agent ghi file (không chia sẻ token qua chat công khai) |
| RAM ~4GB+, disk ~10GB+ | Lần đầu tải embedding model |

**Việc agent có thể làm giúp:** clone, tạo venv, cài `requirements.txt`, `cp .env.example`, sinh Fernet, chạy `setup-env` / `bootstrap` (có thể giới hạn discover), gợi ý cấu hình MCP trong IDE.

**Việc bạn vẫn nên tự làm:** phê duyệt lệnh nguy hiểm trong IDE, **không commit `.env`**, xác nhận URL/token đúng môi trường nội bộ.

---

## 2. Luồng đề xuất (5 phút hiểu, cả buổi để agent chạy)

1. Mở **Cursor / Kiro / Antigravity** → **Open Folder** (hoặc tạo thư mục workspace trống).
2. Mở chat agent (Agent / Composer / tương đương).
3. Dán **một prompt tổng** (mục 3) — thay URL repo bằng repo thật.
4. Khi agent hỏi: cung cấp **đường dẫn clone** hoặc cho phép chạy `git clone` trong terminal được IDE duyệt.
5. Sau khi code đã nằm local: agent đọc `docs/onboarding-new-developer.md` (file này) + `.env.example` để hoàn tất bước kỹ thuật.
6. **Bạn** điền **token thật** vào `.env` (hoặc nhờ agent ghi file sau khi bạn paste giá trị trong cửa sổ an toàn — tuỳ chính sách team).
7. Nhờ agent chạy `setup-env`, `bootstrap` (hoặc discover nhẹ), rồi `python -m app.mcp_server`.
8. Cấu hình **MCP trong IDE** (mục 5) — agent có thể tạo/sửa file cấu hình theo đúng IDE.

---

## 3. Prompt mẫu (copy-paste)

### 3.1 Prompt tổng (một lần)

Thay `REPO_URL_GIT` bằng URL HTTPS/SSH thật.

```text
Bạn là agent trong IDE. Hãy:

1) Clone repository: REPO_URL_GIT vào workspace (hoặc thư mục con tên ict-ai-context-engine nếu workspace đang trống).
2) Mở đúng thư mục gốc repo và đọc docs/onboarding-new-developer.md cùng .env.example.
3) Thiết lập môi trường Python: cần Python 3.10+ (nếu máy chỉ có 3.9 thì dùng uv để cài Python 3.12 và tạo .venv).
4) pip install -r requirements.txt trong .venv.
5) cp .env.example thành .env.
6) Sinh khóa Fernet: chạy python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())" và ghi vào AI_CONTEXT_V2_SECRET_KEY trong .env.
7) Nhắc tôi điền token GitLab/Confluence/Jira vào .env (đừng bịa token). Nếu chưa có token GitLab thì để trống AI_CONTEXT_V2_GITLAB_TOKEN để tránh lỗi discover.
8) Chạy: python -m app.cli setup-env và python -m app.cli bootstrap (nếu bootstrap quá lây thì đề xuất discover Confluence giới hạn theo docs/local-setup-guide.md).
9) Báo cáo kết quả và lỗi nếu có.

Chỉ sửa file trong repo; không commit .env; không xóa dữ liệu người dùng không hỏi.
```

### 3.2 Prompt bổ sung — chỉ cài đặt sau khi đã có clone

```text
Repo ict-ai-context-engine đã có trong workspace. Hãy đọc docs/onboarding-new-developer.md và hoàn thiện bước venv, requirements, .env từ .env.example, Fernet key, rồi setup-env và bootstrap. Ghi chú rõ nếu cần tôi điền token thủ công.
```

### 3.3 Prompt — chạy MCP server

```text
Trong thư mục repo ict-ai-context-engine, kích hoạt .venv và chạy python -m app.mcp_server ở foreground hoặc hướng dẫn tôi chạy terminal riêng; kiểm tra port 3000 không bị chiếm.
```

### 3.4 Prompt — cấu hình MCP trong IDE

```text
Thêm MCP server ai-context-engine trỏ tới http://localhost:3000/mcp theo đúng định dạng cho IDE hiện tại (Cursor: ~/.cursor/mcp.json; Kiro: .kiro/settings/mcp.json trong project nếu có; Antigravity: theo cấu hình MCP của tool). Không ghi secret vào repo.
```

---

## 4. Gợi ý theo từng IDE

### Cursor

- Dùng **Agent** hoặc **Composer** với quyền **terminal** + **workspace**.
- File MCP user-level: `~/.cursor/mcp.json` (xem [developer-guide.md](developer-guide.md)).
- Sau khi sửa MCP: **Restart Cursor** hoặc reload MCP.

### Kiro

- Thường có cấu hình MCP trong workspace, ví dụ `.kiro/settings/mcp.json` — đặt `url`: `http://localhost:3000/mcp` (và header `X-API-Key` nếu bật API key trong `.env`).
- Cho agent đọc `MCP_GUIDE.md` trong repo để khớp định dạng.

### Antigravity (Google)

- Luồng tương tự: agent chạy trong workspace, bạn phê duyệt lệnh; MCP phụ thuộc phiên bản IDE — dùng prompt 3.4 và để agent tra cứu định dạng chính thức hiện tại.

---

## 5. Điền `.env` và secret (vẫn cần con người)

Agent có thể **mở file** và **chèn placeholder**, nhưng **PAT thật** do bạn lấy từ GitLab / Confluence / Jira.

| Nhóm | Biến chính | Lưu ý |
|------|------------|--------|
| GitLab | `AI_CONTEXT_V2_GITLAB_BASE_URL`, `AI_CONTEXT_V2_GITLAB_TOKEN` | Scope `api`. Chưa có token → **để trống** token để không đăng ký connector. |
| Confluence | `AI_CONTEXT_V2_CONFLUENCE_*` | `USERNAME` phải khớp user tạo PAT. |
| Jira | `AI_CONTEXT_V2_JIRA_*` | `PROJECT_KEYS` ví dụ `AIN,PROJ`. |
| Tuỳ chọn | `AI_CONTEXT_V2_API_KEY`, `AI_CONTEXT_V2_LLM_API_KEY` | API key REST/MCP; LLM cho RDE/CGP. |

**Không** để URL kiểu `git.example.com` kèm token giả — `bootstrap` sẽ gọi API và lỗi.

Sau khi điền xong, nhờ agent:

```text
Chạy lại: python -m app.cli setup-env và python -m app.cli list-connectors để xác nhận connector.
```

---

## 6. Kiểm tra sau khi agent chạy xong

- [ ] `python -c "import mcp"` trong `.venv` không lỗi (Python ≥3.10).
- [ ] `python -m app.cli list-connectors` hiển thị connector mong muốn.
- [ ] `python -m app.mcp_server` lắng nghe port **3000** (hoặc port cấu hình).
- [ ] IDE đã trỏ MCP tới `http://localhost:3000/mcp` và (nếu có) header API key.

---

## 7. Checklist trước khi escalate hỗ trợ

- [ ] Agent đã chạy xong các bước trong prompt tổng; log lỗi được copy lại.
- [ ] `.env` có giá trị thật cho môi trường nội bộ (không placeholder).
- [ ] Không commit `.env`.

---

## 8. Lỗi thường gặp

| Hiện tượng | Gợi ý (có thể nhờ agent xử lý) |
|------------|--------------------------------|
| Python 3.9, không cài được `mcp` | Agent cài `uv` + Python 3.12 + tạo lại `.venv`. |
| `bootstrap` lỗi DNS tới `git.example.com` | Sửa `AI_CONTEXT_V2_GITLAB_BASE_URL` hoặc để trống token GitLab. |
| Confluence 401 khi **tạo** trang | PAT / username / quyền space — xem [local-setup-guide.md](local-setup-guide.md). |
| Port 3000 bận | `lsof -i :3000` hoặc đổi cấu hình MCP/port. |

---

## Phụ lục A — Lệnh tham chiếu (khi cần làm tay hoặc debug)

```bash
cd ict-ai-context-engine
source .venv/bin/activate   # Windows: .venv\Scripts\activate

cp .env.example .env
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
pip install -r requirements.txt

python -m app.cli setup-env
python -m app.cli bootstrap
python -m app.cli list-connectors

python -m app.mcp_server
# Terminal khác (tuỳ chọn):
# uvicorn app.main:app --host 0.0.0.0 --port 8100 --reload
```

Ví dụ discover Confluence nhẹ (thay `CONNECTOR_ID`):

```bash
python -m app.cli discover CONNECTOR_ID --cf-max-spaces 1 --cf-max-pages-per-space 5 --cf-max-pages-total 5
```

---

## Phụ lục B — MCP tối thiểu (Cursor)

`~/.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "ai-context-engine": {
      "url": "http://localhost:3000/mcp"
    }
  }
}
```

Nếu bật `AI_CONTEXT_V2_API_KEY`, thêm header theo [developer-guide.md](developer-guide.md).

Chúc onboard nhanh với agent.
