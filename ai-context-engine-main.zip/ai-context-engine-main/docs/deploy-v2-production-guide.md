# Deploy Guide — AI Context Engine V2 (Production-First)

Guide này dành cho mục tiêu chạy **Version 2** ổn định cho team sử dụng trước (MCP + REST API), chưa triển khai các thành phần V4 Portal.

## 1) Scope triển khai V2

Triển khai 2 service:

- `mcp` (port 3000): cho Cursor/Kiro/Claude qua endpoint `/mcp`
- `api` (port 8100): cho REST API + Swagger `/docs`

Data runtime dùng volume `./data`:

- `catalog.db`
- `chroma/`
- `workspaces/`
- `logs/`

## 2) Checklist hạ tầng cần có

- 1 Linux VM (khuyến nghị Ubuntu 22.04+), tối thiểu:
  - 4 vCPU
  - 8 GB RAM
  - 80 GB disk
- DNS nội bộ hoặc public:
  - `ai-context-api.<domain>`
  - `ai-context-mcp.<domain>`
- Reverse proxy TLS (Nginx/Traefik/Caddy)
- Docker Engine + Docker Compose plugin
- Cơ chế backup định kỳ (S3/NAS/rsync)

## 3) Security bắt buộc trước khi deploy

1. Không dùng trực tiếp file `.env` local có secrets trong repo.
2. Tạo file `.env` mới từ `.env.example` trên server.
3. Bắt buộc set:
   - `AI_CONTEXT_V2_SECRET_KEY`
   - `AI_CONTEXT_V2_API_KEY` (không để trống trong production)
4. Chỉ mở public 80/443; không expose trực tiếp 3000/8100 ra internet.
5. Service account tokens:
   - GitLab PAT
   - Confluence PAT
   - Jira PAT
   - Jenkins API token (nếu dùng module 4/6)

## 4) Chuẩn bị server

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl git

# Docker
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
newgrp docker

docker --version
docker compose version
```

## 5) Chuẩn bị source + biến môi trường

```bash
git clone <repo-url> /opt/ict-ai-context-engine
cd /opt/ict-ai-context-engine

cp .env.example .env
```

Sinh secret key:

```bash
python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
openssl rand -hex 32
```

Điền vào `.env`:

- `AI_CONTEXT_V2_SECRET_KEY=<fernet-key>`
- `AI_CONTEXT_V2_API_KEY=<random-hex>`
- các token tích hợp theo nhu cầu rollout.

## 6) Build và chạy service V2

```bash
cd /opt/ict-ai-context-engine
docker compose up -d --build
docker compose ps
```

Kiểm tra cơ bản:

```bash
curl -sS http://127.0.0.1:8100/api/health
curl -sS -H "X-API-Key: <AI_CONTEXT_V2_API_KEY>" "http://127.0.0.1:8100/api/health"
```

Ghi chú:

- Nếu set `AI_CONTEXT_V2_API_KEY`, tất cả call vào `/api/*` và `/mcp` phải gửi key.
- Với MCP client, cấu hình header `X-API-Key`.

## 7) Bootstrap và sync dữ liệu lần đầu

Chạy trong container `mcp`:

```bash
docker compose exec mcp python -m app.cli bootstrap
docker compose exec mcp python -m app.cli list-connectors
docker compose exec mcp python -m app.cli list-sources
```

Sync lần đầu (có thể lâu):

```bash
docker compose exec mcp python -m app.cli sync-git-all
docker compose exec mcp python -m app.cli sync-confluence-all
```

## 8) Expose qua reverse proxy (Nginx)

Ví dụ cấu hình:

```nginx
server {
  listen 443 ssl http2;
  server_name ai-context-api.example.com;
  # ssl_certificate ...
  # ssl_certificate_key ...

  location / {
    proxy_pass http://127.0.0.1:8100;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
  }
}

server {
  listen 443 ssl http2;
  server_name ai-context-mcp.example.com;
  # ssl_certificate ...
  # ssl_certificate_key ...

  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
  }
}
```

## 9) Cấu hình client cho member

Ví dụ MCP config:

```json
{
  "mcpServers": {
    "ai-context-engine": {
      "url": "https://ai-context-mcp.example.com/mcp",
      "headers": {
        "X-API-Key": "<shared-api-key>"
      }
    }
  }
}
```

## 10) Vận hành định kỳ

- Sync jobs (cron hoặc CI scheduled):
  - `python -m app.cli sync-all`
- Theo dõi logs:
  - `docker compose logs -f mcp`
  - `docker compose logs -f api`
- Healthcheck:
  - `GET /api/health`
- Backup định kỳ thư mục `data/`:
  - ít nhất hằng ngày
  - giữ 7-14 bản gần nhất

## 11) Rollback nhanh

1. Pin image tag theo release (không dùng `latest` cho production).
2. Khi lỗi:
   - checkout tag ổn định
   - `docker compose up -d --build`
3. Nếu lỗi dữ liệu:
   - restore thư mục `data/` từ backup gần nhất
   - chạy lại `bootstrap` + `sync` kiểm tra.

## 12) Pre-go-live checklist

- [ ] `/api/health` trả `ok`
- [ ] MCP connect được từ ít nhất 2 máy member
- [ ] `bootstrap` + `sync-all` chạy thành công
- [ ] API key đã bật
- [ ] TLS hợp lệ
- [ ] Backup + restore test 1 lần trên staging
- [ ] Đã rotate token khỏi mọi file local từng lộ ra ngoài

