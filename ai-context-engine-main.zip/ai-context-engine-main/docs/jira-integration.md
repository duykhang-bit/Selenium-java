# Hướng dẫn sử dụng: Jira Integration

Module kết nối AI Context Engine V2 với **Jira Server / Data Center** (tự dựng).
Cho phép AI agent đọc context từ Jira, tạo ticket từ intent, đồng bộ trạng thái, và sinh task brief.

---

## Mục lục

1. [Cấu hình](#1-cấu-hình)
2. [Đăng ký connector](#2-đăng-ký-connector)
3. [Pull Jira issues vào ChromaDB](#3-pull-jira-issues-vào-chromadb)
4. [Tạo Epic → Story → Sub-task từ intent](#4-tạo-epic--story--sub-task-từ-intent)
5. [Sinh task brief từ Jira ticket](#5-sinh-task-brief-từ-jira-ticket)
6. [Liên kết dossier với Jira ticket](#6-liên-kết-dossier-với-jira-ticket)
7. [Đồng bộ trạng thái dossier → Jira](#7-đồng-bộ-trạng-thái-dossier--jira)
8. [REST API](#8-rest-api)
9. [MCP Tools](#9-mcp-tools)
10. [AI Quality Gate](#10-ai-quality-gate)
11. [Bảo mật & Compliance](#11-bảo-mật--compliance)
12. [Xử lý lỗi thường gặp](#12-xử-lý-lỗi-thường-gặp)

---

## 1. Cấu hình

Thêm vào file `.env`:

```env
# Jira Server / Data Center
AI_CONTEXT_V2_JIRA_BASE_URL=https://jira.company.com
AI_CONTEXT_V2_JIRA_TOKEN=your-personal-access-token
AI_CONTEXT_V2_JIRA_NAME=Jira                          # tên hiển thị (tuỳ chọn)
AI_CONTEXT_V2_JIRA_PROJECT_KEYS=PROJ,OMS,VACC         # danh sách project cần sync

# Tuỳ chỉnh (có giá trị mặc định)
AI_CONTEXT_V2_JIRA_QUALITY_THRESHOLD=0.7              # ngưỡng quality gate [0.0-1.0]
AI_CONTEXT_V2_JIRA_CONNECT_TIMEOUT=5.0                # timeout kết nối (giây)
AI_CONTEXT_V2_JIRA_READ_TIMEOUT=30.0                  # timeout đọc (giây)
AI_CONTEXT_V2_JIRA_MAX_POOL_SIZE=10                   # connection pool tối đa
```

### Tạo Personal Access Token (PAT) trên Jira

Truy cập: `https://<jira-host>/plugins/personalaccesstokens/usertokens.action`

- Tạo token mới, copy ngay (chỉ hiện 1 lần)
- Scope cần thiết: `read`, `write` (hoặc `admin` nếu cần tạo ticket)

> **Lưu ý bảo mật:** Token được mã hoá Fernet trước khi lưu vào `catalog.db`. Không bao giờ commit file `.env` vào git.

---

## 2. Đăng ký connector

### Tự động (từ `.env`)

Khi chạy bootstrap, Jira connector được đăng ký tự động nếu `AI_CONTEXT_V2_JIRA_BASE_URL` và `AI_CONTEXT_V2_JIRA_TOKEN` đã được cấu hình:

```bash
python -m app.cli bootstrap
```

### Thủ công qua CLI

```bash
# Chưa có lệnh setup-jira riêng — dùng REST API hoặc bootstrap
```

### Thủ công qua REST API

```bash
curl -X POST http://localhost:8100/api/setup/jira \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{
    "base_url": "https://jira.company.com",
    "token": "your-pat-token",
    "name": "Company Jira"
  }'
```

**Response:**
```json
{
  "connector": {
    "id": 3,
    "connector_type": "jira",
    "name": "Company Jira",
    "base_url": "https://jira.company.com",
    "created_at": "2024-01-15T12:00:00Z"
  }
}
```

---

## 3. Pull Jira issues vào ChromaDB

Pull issues về để AI agent có thể search context từ Jira.

### CLI

```bash
# Sync tất cả project đã cấu hình trong AI_CONTEXT_V2_JIRA_PROJECT_KEYS
python -m app.cli jira-sync

# Sync project cụ thể
python -m app.cli jira-sync --project-key PROJ

# Sync nhiều project
python -m app.cli jira-sync --project-key PROJ --project-key OMS

# Chỉ định collection
python -m app.cli jira-sync --project-key PROJ --collection knowledge
```

### REST API

```bash
curl -X POST http://localhost:8100/api/jira/sync \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{
    "project_keys": ["PROJ", "OMS"],
    "collection": "knowledge"
  }'
```

**Response:**
```json
{
  "results": [
    {
      "project_key": "PROJ",
      "synced": 150,
      "failed": 2,
      "total": 152,
      "sync_run_id": 42,
      "status": "success"
    }
  ]
}
```

### Lưu ý

- Sync chạy **async/non-blocking** — không block REST API
- Upsert theo `issue_key` — chạy nhiều lần không tạo duplicate
- Issue type được pull: Epic, Story, Sub-task, Bug, Task, Improvement và custom types
- **PII trong description được mask tự động** trước khi lưu vào ChromaDB (CMND/CCCD, SĐT, email)

---

## 4. Tạo Epic → Story → Sub-task từ intent

Mô tả ý tưởng bằng ngôn ngữ tự nhiên, AI tự động tạo cấu trúc ticket trên Jira.

### CLI

```bash
python -m app.cli jira-create "Xây dựng tính năng đặt lịch tiêm chủng online cho phụ huynh" \
  --project-key VACC
```

### REST API

```bash
curl -X POST http://localhost:8100/api/jira/create-from-intent \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{
    "intent": "Xây dựng tính năng đặt lịch tiêm chủng online cho phụ huynh",
    "project_key": "VACC"
  }'
```

**Response thành công:**
```json
{
  "epic_key": "VACC-42",
  "stories": [
    {
      "story_key": "VACC-43",
      "summary": "Xây dựng tính năng đặt lịch tiêm chủng online cho phụ huynh",
      "story_points": 3,
      "subtasks": ["VACC-44", "VACC-45", "VACC-46"]
    }
  ],
  "idempotency_key": "sha256hash...",
  "quality_gate": {
    "confidence_score": 0.87,
    "passed": true
  }
}
```

**Response khi quality gate fail (HTTP 422):**
```json
{
  "detail": {
    "message": "Quality gate failed",
    "confidence_score": 0.45,
    "issues": [
      "Story phải có ít nhất 1 acceptance criteria trong description",
      "Issue liên quan đến health data phải có security note"
    ]
  }
}
```

**Response khi ticket đã tồn tại (HTTP 409 — idempotent):**
```json
{
  "detail": {
    "message": "Ticket đã tồn tại",
    "existing_ref": "VACC-42"
  }
}
```

### Cấu trúc ticket được tạo

```
Epic: [Epic] <intent>
  └── Story: <intent>
        ├── Sub-task: [Analysis] Phân tích và thiết kế
        ├── Sub-task: [Dev] Implement
        └── Sub-task: [Test] Kiểm thử
```

Story points được ước lượng tự động theo Fibonacci (1, 2, 3, 5, 8, 13) dựa trên độ phức tạp của intent.

---

## 5. Sinh task brief từ Jira ticket

Sinh task brief đầy đủ kết hợp **Jira context + Confluence business context + GitLab technical context**.

### CLI

```bash
python -m app.cli jira-brief PROJ-123

# Với collection và top_k tuỳ chỉnh
python -m app.cli jira-brief PROJ-123 --collection knowledge --top-k 10
```

### REST API

```bash
curl -X POST "http://localhost:8100/api/jira/brief/PROJ-123?collection=knowledge&top_k=5" \
  -H "X-API-Key: your-api-key"
```

**Response:**
```json
{
  "issue_key": "PROJ-123",
  "task_id": "task-20240115-120000-proj-123-implement-order-api",
  "jira_context": {
    "summary": "Implement order API",
    "description": "...",
    "issue_type": "Story",
    "status": "In Progress",
    "story_points": 5,
    "sprint_name": "Sprint 42",
    "epic_key": "PROJ-100",
    "acceptance_criteria": "- AC1: ...\n- AC2: ..."
  },
  "confluence_results": [...],
  "git_results": [...],
  "brief": "# Task Brief: [PROJ-123] Implement order API\n...",
  "data_freshness": "live"
}
```

### Lưu ý

- Pull issue **trực tiếp từ Jira API** (không chỉ từ ChromaDB) để đảm bảo dữ liệu mới nhất
- Tự động tạo task dossier và liên kết với `issue_key`
- Nếu dossier đã tồn tại cho `issue_key` đó, brief sẽ được cập nhật thay vì tạo mới

---

## 6. Liên kết dossier với Jira ticket

Liên kết một task dossier đã có với Jira issue key để bật tính năng sync 2 chiều.

### REST API

```bash
curl -X POST http://localhost:8100/api/jira/link-dossier \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{
    "task_id": "task-20240115-120000-implement-order-api",
    "issue_key": "PROJ-123"
  }'
```

**Response:**
```json
{
  "task_id": "task-20240115-120000-implement-order-api",
  "issue_key": "PROJ-123",
  "linked_at": "2024-01-15T12:00:00Z"
}
```

---

## 7. Đồng bộ trạng thái dossier → Jira

Khi cập nhật trạng thái task dossier, Jira ticket tự động chuyển trạng thái tương ứng.

### Bảng mapping trạng thái

| Dossier status | Jira transition |
|---|---|
| `started` | In Progress |
| `planned` | In Progress |
| `completed` | Done |
| `blocked` | Blocked |

### Cách hoạt động

Sync được kích hoạt tự động khi gọi `task-plan` hoặc `task-result` nếu dossier đã được liên kết với Jira issue key.

Hoặc gọi trực tiếp từ code:

```python
from app.tasks.jira_dossier_sync import sync_dossier_to_jira
from app.catalog.database import list_connectors

connector = list_connectors(connector_type="jira")[0]
result = sync_dossier_to_jira("task-20240115-...", connector)
print(result)
# {"transitioned": True, "skipped": False, "error": None, "issue_keys": ["PROJ-123"]}
```

### Lưu ý quan trọng

- Nếu Jira transition **thất bại**, dossier vẫn được cập nhật bình thường — không bị block
- Mọi lần transition (thành công, thất bại, bỏ qua) đều được ghi vào `timeline.jsonl`
- Nếu Jira đã ở đúng trạng thái đích, transition bị bỏ qua (không gọi API thừa)

---

## 8. REST API

Server chạy tại `http://localhost:8100`. Swagger UI: `http://localhost:8100/docs`

| Method | Endpoint | Mô tả |
|---|---|---|
| `POST` | `/api/setup/jira` | Đăng ký Jira connector |
| `POST` | `/api/jira/sync` | Pull issues vào ChromaDB |
| `POST` | `/api/jira/create-from-intent` | Tạo Epic/Story/Sub-task từ intent |
| `POST` | `/api/jira/brief/{issue_key}` | Sinh task brief từ ticket |
| `POST` | `/api/jira/link-dossier` | Liên kết dossier với issue key |

### Authentication

Khi `AI_CONTEXT_V2_API_KEY` được cấu hình, mọi request phải kèm header:

```
X-API-Key: your-api-key
```

### HTTP Status Codes

| Code | Ý nghĩa |
|---|---|
| `200` | Thành công |
| `404` | Issue key không tồn tại |
| `409` | Ticket đã tồn tại (idempotency) |
| `422` | Input không hợp lệ hoặc quality gate fail |
| `429` | Jira rate limit |
| `502` | Jira Server không khả dụng |

---

## 9. MCP Tools

Dành cho AI agent kết nối qua MCP (port 3000).

```json
{
  "mcpServers": {
    "ai-context-engine": {
      "url": "http://localhost:3000/mcp"
    }
  }
}
```

| Tool | Mô tả |
|---|---|
| `jira_sync_project` | Pull issues của một project vào ChromaDB |
| `jira_create_from_intent` | Tạo Epic/Story/Sub-task từ intent text |
| `jira_brief_from_ticket` | Sinh task brief từ issue key |
| `jira_link_dossier` | Liên kết task dossier với Jira issue |
| `jira_search` | Tìm kiếm Jira issues trong ChromaDB |

### Ví dụ sử dụng trong AI agent

```
# Tìm context liên quan đến order service
jira_search(query="order service payment integration", top_k=5)

# Sinh brief cho ticket đang làm
jira_brief_from_ticket(issue_key="OMS-456")

# Tạo ticket từ ý tưởng mới
jira_create_from_intent(
  intent="Thêm tính năng xuất báo cáo doanh thu theo ngày cho nhà thuốc",
  project_key="PHARMACY"
)
```

---

## 10. AI Quality Gate

Mọi ticket được AI tạo ra đều phải qua Quality Gate trước khi xuất hiện trên Jira.

### Tiêu chí kiểm tra

| Tiêu chí | Áp dụng cho | Hành động khi fail |
|---|---|---|
| Summary không rỗng | Tất cả | Score = 0.0, từ chối |
| Issue type hợp lệ | Tất cả | Score = 0.0, từ chối |
| Description ≥ 50 ký tự | Tất cả | Trừ điểm |
| Có acceptance criteria | Story | Trừ điểm |
| Có business objective | Epic | Trừ điểm |
| Không có placeholder (TODO, TBD) | Tất cả | Trừ điểm |
| Có security note | Issue liên quan auth/payment/health | Trừ điểm |
| Có data privacy note | Issue xử lý PII | Trừ điểm |

### Ngưỡng confidence score

- Mặc định: `0.7` (cấu hình qua `AI_CONTEXT_V2_JIRA_QUALITY_THRESHOLD`)
- Score < ngưỡng → từ chối tạo ticket, trả về danh sách vấn đề cụ thể
- Score = 0.0 → fatal error (summary rỗng hoặc issue type không hợp lệ)

### Audit trail

Mọi lần Quality Gate được gọi đều ghi audit record vào:
- `data/logs/jira_audit.jsonl` — log tập trung
- `data/tasks/<task_id>/timeline.jsonl` — nếu có task dossier liên quan

---

## 11. Bảo mật & Compliance

### Bảo vệ dữ liệu cá nhân (Nghị định 13/2023/NĐ-CP)

Trước khi lưu Jira issue vào ChromaDB, engine tự động **mask PII**:

| Loại PII | Pattern | Thay thế |
|---|---|---|
| CMND/CCCD | 9 hoặc 12 chữ số | `[CMND/CCCD]` |
| Số điện thoại VN | `0[3-9]xxxxxxxx` hoặc `+84...` | `[SĐT]` |
| Email | `user@domain.com` | `[EMAIL]` |
| Số thẻ ngân hàng | 16 chữ số | `[CARD]` |

### Chống SSRF

`base_url` của Jira connector được validate trước khi lưu:
- Chỉ chấp nhận scheme `http` hoặc `https`
- Từ chối private IP ranges: `10.x`, `172.16-31.x`, `192.168.x`, `127.x`, `169.254.x`

### Token security

- Token được mã hoá **Fernet (AES-128-CBC)** trước khi lưu vào `catalog.db`
- Token không bao giờ xuất hiện trong log hoặc response body
- CLI tự động redact token khi in JSON output

---

## 12. Xử lý lỗi thường gặp

### Lỗi kết nối

```
JiraAuthError: Xác thực thất bại (HTTP 401)
```
→ Kiểm tra lại `AI_CONTEXT_V2_JIRA_TOKEN`. Token có thể đã hết hạn.

```
JiraNetworkError: Timeout khi gọi https://jira.company.com
```
→ Tăng `AI_CONTEXT_V2_JIRA_READ_TIMEOUT`. Kiểm tra network connectivity.

```
JiraConfigError: Jira base_url không được trỏ đến private/loopback IP
```
→ Dùng hostname thay vì IP nội bộ, hoặc kiểm tra lại URL.

### Lỗi tạo ticket

```
HTTP 422: Quality gate failed, confidence_score: 0.45
```
→ Xem danh sách `issues` trong response để biết cần bổ sung gì vào intent.

```
HTTP 409: Ticket đã tồn tại, existing_ref: PROJ-42
```
→ Intent này đã được tạo ticket trước đó. Dùng `existing_ref` để tiếp tục.

### Lỗi sync

```
Jira sync thất bại: project=PROJ error=JiraAuthError
```
→ Connector token không đủ quyền đọc project. Kiểm tra Jira project permissions.

### Kiểm tra trạng thái connector

```bash
python -m app.cli list-connectors
```

```bash
curl http://localhost:8100/api/connectors \
  -H "X-API-Key: your-api-key"
```

---

## Ví dụ workflow đầy đủ

### Từ intent đến task brief

```bash
# 1. Bootstrap (lần đầu)
python -m app.cli bootstrap

# 2. Sync Jira issues vào ChromaDB
python -m app.cli jira-sync --project-key PROJ

# 3. Tạo ticket từ ý tưởng
python -m app.cli jira-create \
  "Thêm API lấy lịch sử đơn hàng theo khách hàng cho hệ thống OMS" \
  --project-key OMS

# 4. Sinh task brief từ ticket vừa tạo (ví dụ OMS-123)
python -m app.cli jira-brief OMS-123

# 5. Xem dossier đã tạo
python -m app.cli task-show task-20240115-120000-oms-123-...

# 6. Cập nhật plan và sync về Jira
python -m app.cli task-plan task-20240115-... \
  --plan "Thêm endpoint GET /orders?customerId=..." \
  --scope "app/api/orders.py, app/services/order_service.py" \
  --status "planned"
```
