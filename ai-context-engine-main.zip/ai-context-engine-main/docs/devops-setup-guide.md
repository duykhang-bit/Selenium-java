# DevOps Setup Guide — AI Context Engine V2 trên FPT Cloud K8s

> Khuyến nghị: nếu cần go-live nhanh V2 cho team dùng ngay, ưu tiên guide
> `docs/deploy-v2-production-guide.md` (VM + Docker Compose) trước, rồi mở rộng K8s sau.
>
> Lưu ý khi áp dụng file K8s bên dưới: dùng đúng tên biến môi trường theo source code (`AI_CONTEXT_V2_*`).

Hướng dẫn deploy AI Context Engine V2 lên FPT Cloud Kubernetes.

---

## Tổng quan kiến trúc trên K8s

```
FPT Cloud K8s Cluster
│
├── Namespace: ai-context-engine
│   ├── Deployment: mcp-server        (port 3000)
│   ├── Deployment: api-server        (port 8100)
│   ├── Service: mcp-svc              (ClusterIP / LoadBalancer)
│   ├── Service: api-svc              (ClusterIP / LoadBalancer)
│   ├── Ingress: ai-context-ingress   (HTTPS)
│   ├── PersistentVolumeClaim: data   (catalog.db, chroma, workspaces)
│   ├── Secret: ai-context-secrets    (tokens, API keys)
│   └── ConfigMap: ai-context-config  (non-sensitive config)
```

---

## Yêu cầu

- `kubectl` đã cấu hình kết nối FPT Cloud K8s cluster
- `helm` v3+
- Container Registry (FPT Cloud Container Registry hoặc Docker Hub)
- PersistentVolume hỗ trợ ReadWriteOnce (FPT Cloud Block Storage)
- RAM node: tối thiểu 4GB (embedding model cần ~1.5GB)

---

## Bước 1 — Chuẩn bị

### 1.1 Clone repo và build image

```bash
git clone <repo-url>
cd ict-ai-context-engine

# Build Docker image
docker build -t ai-context-engine:latest .

# Tag và push lên FPT Cloud Container Registry
docker tag ai-context-engine:latest cr.fptcloud.com/<your-org>/ai-context-engine:latest
docker push cr.fptcloud.com/<your-org>/ai-context-engine:latest
```

### 1.2 Tạo namespace

```bash
kubectl create namespace ai-context-engine
```

---

## Bước 2 — Tạo Personal Access Tokens

### 2.1 GitLab Token

1. Đăng nhập GitLab → avatar → **Edit profile** → **Access Tokens**
2. Tạo token:
   - Name: `ai-context-engine`
   - Scopes: ✅ `api` (cần write để tạo branch/MR)
3. Copy token

### 2.2 Confluence Token

1. Đăng nhập Confluence → avatar → **Profile** → **Personal Access Tokens**
2. Tạo token: Name `ai-context-engine`, Permissions Read + Write
3. Copy token

### 2.3 Jira Token

1. Đăng nhập Jira → avatar → **Profile** → **Personal Access Tokens**
2. Tạo token: Name `ai-context-engine`
3. Copy token

### 2.4 Jenkins Token

1. Đăng nhập Jenkins → tên user → **Configure** → **API Token** → **Add new Token**
2. Copy token

---

## Bước 3 — Tạo Secret Key và API Key

```bash
# Tạo Fernet secret key
python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"

# Tạo API key
openssl rand -hex 32
```

---

## Bước 4 — Tạo K8s Secret

```bash
kubectl create secret generic ai-context-secrets \
  --namespace ai-context-engine \
  --from-literal=SECRET_KEY="<fernet-key>" \
  --from-literal=API_KEY="<api-key>" \
  --from-literal=GITLAB_TOKEN="glpat-xxxxxxxxxxxxxxxxxxxx" \
  --from-literal=CONFLUENCE_TOKEN="<confluence-token>" \
  --from-literal=CONFLUENCE_USERNAME="<username>" \
  --from-literal=JIRA_TOKEN="<jira-token>" \
  --from-literal=JENKINS_TOKEN="<jenkins-token>" \
  --from-literal=LLM_API_KEY=""
```

Kiểm tra:
```bash
kubectl get secret ai-context-secrets -n ai-context-engine
```

---

## Bước 5 — Tạo ConfigMap

```bash
kubectl apply -f - <<EOF
apiVersion: v1
kind: ConfigMap
metadata:
  name: ai-context-config
  namespace: ai-context-engine
data:
  API_HOST: "0.0.0.0"
  API_PORT: "8100"
  LOG_LEVEL: "INFO"
  EMBEDDING_MODEL: "sentence-transformers/all-MiniLM-L6-v2"
  CHUNK_SIZE: "350"
  CHUNK_OVERLAP: "70"
  REPO_CHUNK_SIZE: "350"
  REPO_CHUNK_OVERLAP: "70"
  CONFLUENCE_CHUNK_SIZE: "700"
  CONFLUENCE_CHUNK_OVERLAP: "140"
  DEFAULT_COLLECTION: "knowledge"
  GITLAB_BASE_URL: "https://git.example.com"
  GITLAB_NAME: "GitLab"
  GITLAB_EXCLUDED_GROUPS: "devops-common"
  CONFLUENCE_BASE_URL: "https://confluence.example.com"
  CONFLUENCE_NAME: "Confluence"
  JIRA_BASE_URL: "https://jira.example.com"
  JIRA_NAME: "Jira"
  JIRA_PROJECT_KEYS: "PROJ,OMS"
  JENKINS_BASE_URL: "https://jenkins.example.com"
  JENKINS_USERNAME: "admin"
  JENKINS_QUEUE_POLL_INTERVAL: "2"
  JENKINS_QUEUE_POLL_TIMEOUT: "30"
  LLM_MODEL: "gpt-4o-mini"
  LLM_TIMEOUT: "30"
  K8S_PROD_SOAK_MINUTES: "30"
EOF
```

---

## Bước 6 — Tạo PersistentVolumeClaim

```bash
kubectl apply -f - <<EOF
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: ai-context-data
  namespace: ai-context-engine
spec:
  accessModes:
    - ReadWriteOnce
  storageClassName: fpt-block-storage  # Thay bằng StorageClass của FPT Cloud
  resources:
    requests:
      storage: 50Gi
EOF
```

Kiểm tra StorageClass có sẵn:
```bash
kubectl get storageclass
```

---

## Bước 7 — Deploy MCP Server

```bash
kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mcp-server
  namespace: ai-context-engine
spec:
  replicas: 1
  selector:
    matchLabels:
      app: mcp-server
  template:
    metadata:
      labels:
        app: mcp-server
    spec:
      containers:
        - name: mcp-server
          image: cr.fptcloud.com/<your-org>/ai-context-engine:latest
          ports:
            - containerPort: 3000
          resources:
            requests:
              memory: "2Gi"
              cpu: "500m"
            limits:
              memory: "4Gi"
              cpu: "2000m"
          volumeMounts:
            - name: data
              mountPath: /app/data
          envFrom:
            - configMapRef:
                name: ai-context-config
          env:
            - name: AI_CONTEXT_V2_SECRET_KEY
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: SECRET_KEY
            - name: AI_CONTEXT_V2_API_KEY
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: API_KEY
            - name: AI_CONTEXT_V2_GITLAB_TOKEN
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: GITLAB_TOKEN
            - name: AI_CONTEXT_V2_CONFLUENCE_TOKEN
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: CONFLUENCE_TOKEN
            - name: AI_CONTEXT_V2_CONFLUENCE_USERNAME
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: CONFLUENCE_USERNAME
            - name: AI_CONTEXT_V2_JIRA_TOKEN
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: JIRA_TOKEN
            - name: AI_CONTEXT_V2_JENKINS_TOKEN
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: JENKINS_TOKEN
            - name: AI_CONTEXT_V2_LLM_API_KEY
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: LLM_API_KEY
          livenessProbe:
            httpGet:
              path: /health
              port: 3000
            initialDelaySeconds: 60
            periodSeconds: 30
          readinessProbe:
            httpGet:
              path: /health
              port: 3000
            initialDelaySeconds: 30
            periodSeconds: 10
      volumes:
        - name: data
          persistentVolumeClaim:
            claimName: ai-context-data
---
apiVersion: v1
kind: Service
metadata:
  name: mcp-svc
  namespace: ai-context-engine
spec:
  selector:
    app: mcp-server
  ports:
    - port: 3000
      targetPort: 3000
EOF
```

---

## Bước 8 — Deploy REST API Server

```bash
kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api-server
  namespace: ai-context-engine
spec:
  replicas: 1
  selector:
    matchLabels:
      app: api-server
  template:
    metadata:
      labels:
        app: api-server
    spec:
      containers:
        - name: api-server
          image: cr.fptcloud.com/<your-org>/ai-context-engine:latest
          command: ["python", "-m", "app.main"]
          ports:
            - containerPort: 8100
          resources:
            requests:
              memory: "1Gi"
              cpu: "250m"
            limits:
              memory: "2Gi"
              cpu: "1000m"
          volumeMounts:
            - name: data
              mountPath: /app/data
          envFrom:
            - configMapRef:
                name: ai-context-config
          env:
            - name: AI_CONTEXT_V2_SECRET_KEY
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: SECRET_KEY
            - name: AI_CONTEXT_V2_API_KEY
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: API_KEY
            - name: AI_CONTEXT_V2_GITLAB_TOKEN
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: GITLAB_TOKEN
            - name: AI_CONTEXT_V2_CONFLUENCE_TOKEN
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: CONFLUENCE_TOKEN
            - name: AI_CONTEXT_V2_CONFLUENCE_USERNAME
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: CONFLUENCE_USERNAME
            - name: AI_CONTEXT_V2_JIRA_TOKEN
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: JIRA_TOKEN
            - name: AI_CONTEXT_V2_JENKINS_TOKEN
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: JENKINS_TOKEN
            - name: AI_CONTEXT_V2_LLM_API_KEY
              valueFrom:
                secretKeyRef:
                  name: ai-context-secrets
                  key: LLM_API_KEY
          livenessProbe:
            httpGet:
              path: /api/health
              port: 8100
            initialDelaySeconds: 30
            periodSeconds: 30
          readinessProbe:
            httpGet:
              path: /api/health
              port: 8100
            initialDelaySeconds: 15
            periodSeconds: 10
      volumes:
        - name: data
          persistentVolumeClaim:
            claimName: ai-context-data
---
apiVersion: v1
kind: Service
metadata:
  name: api-svc
  namespace: ai-context-engine
spec:
  selector:
    app: api-server
  ports:
    - port: 8100
      targetPort: 8100
EOF
```

---

## Bước 9 — Tạo Ingress

```bash
kubectl apply -f - <<EOF
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: ai-context-ingress
  namespace: ai-context-engine
  annotations:
    nginx.ingress.kubernetes.io/proxy-read-timeout: "300"
    nginx.ingress.kubernetes.io/proxy-send-timeout: "300"
    nginx.ingress.kubernetes.io/proxy-body-size: "10m"
spec:
  ingressClassName: nginx
  tls:
    - hosts:
        - ai-context.example.com
      secretName: ai-context-tls
  rules:
    - host: ai-context.example.com
      http:
        paths:
          - path: /mcp
            pathType: Prefix
            backend:
              service:
                name: mcp-svc
                port:
                  number: 3000
          - path: /api
            pathType: Prefix
            backend:
              service:
                name: api-svc
                port:
                  number: 8100
          - path: /docs
            pathType: Prefix
            backend:
              service:
                name: api-svc
                port:
                  number: 8100
EOF
```

> Nếu FPT Cloud dùng cert-manager, thêm annotation: `cert-manager.io/cluster-issuer: letsencrypt-prod`

---

## Bước 10 — Bootstrap lần đầu

Sau khi pods running, chạy bootstrap:

```bash
# Kiểm tra pods
kubectl get pods -n ai-context-engine

# Chờ pod ready
kubectl wait --for=condition=ready pod -l app=mcp-server -n ai-context-engine --timeout=120s

# Bootstrap
kubectl exec -n ai-context-engine deploy/mcp-server -- python -m app.cli bootstrap

# Kiểm tra
kubectl exec -n ai-context-engine deploy/mcp-server -- python -m app.cli list-connectors
kubectl exec -n ai-context-engine deploy/mcp-server -- python -m app.cli list-sources
```

---

## Bước 11 — Sync sources lần đầu

```bash
# Sync Git repos (có thể mất 30-60 phút lần đầu)
kubectl exec -n ai-context-engine deploy/mcp-server -- python -m app.cli sync-git-all

# Sync Confluence
kubectl exec -n ai-context-engine deploy/mcp-server -- python -m app.cli sync-confluence-all
```

---

## Bước 12 — Cấu hình Jenkins Quality Gate Webhook

Thêm vào Jenkinsfile để Jenkins gọi Context Engine kiểm tra quality gate:

```groovy
stage('Quality Gate') {
    steps {
        script {
            def diff = sh(script: 'git diff origin/main...HEAD', returnStdout: true)
            def response = httpRequest(
                url: 'https://ai-context.example.com/api/jenkins/quality-gate',
                httpMode: 'POST',
                contentType: 'APPLICATION_JSON',
                customHeaders: [[name: 'X-API-Key', value: env.AI_CONTEXT_API_KEY]],
                requestBody: groovy.json.JsonOutput.toJson([
                    source_id: env.GITLAB_SOURCE_ID,
                    diff: diff,
                    job_name: env.JOB_NAME,
                    build_number: env.BUILD_NUMBER.toInteger()
                ]),
                validResponseCodes: '200,422'
            )
            if (response.status == 422) {
                error("Quality gate FAILED: ${response.content}")
            }
        }
    }
}
```

Thêm `AI_CONTEXT_API_KEY` vào Jenkins Credentials.

---

## Bước 13 — Cấu hình Helm Deploy Jobs

Jenkins deploy jobs cần nhận parameters từ K8s promotion flow:

```groovy
parameters {
    string(name: 'SERVICE', description: 'Service name')
    string(name: 'BUILD_NUMBER', description: 'Build number to deploy')
    string(name: 'ENV', defaultValue: 'ci', description: 'Target environment: ci/uat/prod')
}

stage('Deploy') {
    steps {
        sh """
            helm upgrade --install ${params.SERVICE} ./charts/${params.SERVICE} \
                -f values-${params.ENV}.yaml \
                --set image.tag=${params.BUILD_NUMBER} \
                --namespace ${params.ENV}
        """
    }
}
```

---

## Maintenance

### Sync định kỳ (CronJob)

```bash
kubectl apply -f - <<EOF
apiVersion: batch/v1
kind: CronJob
metadata:
  name: sync-sources
  namespace: ai-context-engine
spec:
  schedule: "0 */6 * * *"
  jobTemplate:
    spec:
      template:
        spec:
          containers:
            - name: sync
              image: cr.fptcloud.com/<your-org>/ai-context-engine:latest
              command: ["python", "-m", "app.cli", "sync-all"]
              envFrom:
                - configMapRef:
                    name: ai-context-config
              env:
                - name: AI_CONTEXT_V2_GITLAB_TOKEN
                  valueFrom:
                    secretKeyRef:
                      name: ai-context-secrets
                      key: GITLAB_TOKEN
                - name: AI_CONTEXT_V2_CONFLUENCE_TOKEN
                  valueFrom:
                    secretKeyRef:
                      name: ai-context-secrets
                      key: CONFLUENCE_TOKEN
              volumeMounts:
                - name: data
                  mountPath: /app/data
          volumes:
            - name: data
              persistentVolumeClaim:
                claimName: ai-context-data
          restartPolicy: OnFailure
EOF
```

### Xem logs

```bash
kubectl logs -n ai-context-engine deploy/mcp-server -f
kubectl logs -n ai-context-engine deploy/api-server -f
```

### Xem audit logs

```bash
kubectl exec -n ai-context-engine deploy/mcp-server -- \
  python -m app.cli obs-audit-logs --limit 50
```

### Reset và rebuild

```bash
kubectl exec -n ai-context-engine deploy/mcp-server -- python -m app.cli reset-data
kubectl exec -n ai-context-engine deploy/mcp-server -- python -m app.cli bootstrap
kubectl exec -n ai-context-engine deploy/mcp-server -- python -m app.cli sync-all
```

### Update image

```bash
# Build và push image mới
docker build -t cr.fptcloud.com/<your-org>/ai-context-engine:v2.1.0 .
docker push cr.fptcloud.com/<your-org>/ai-context-engine:v2.1.0

# Rolling update
kubectl set image deployment/mcp-server \
  mcp-server=cr.fptcloud.com/<your-org>/ai-context-engine:v2.1.0 \
  -n ai-context-engine

kubectl set image deployment/api-server \
  api-server=cr.fptcloud.com/<your-org>/ai-context-engine:v2.1.0 \
  -n ai-context-engine

# Kiểm tra rollout
kubectl rollout status deployment/mcp-server -n ai-context-engine
```

### Backup PVC data

```bash
# Tạo snapshot PVC (FPT Cloud Block Storage)
kubectl apply -f - <<EOF
apiVersion: snapshot.storage.k8s.io/v1
kind: VolumeSnapshot
metadata:
  name: ai-context-data-backup-$(date +%Y%m%d)
  namespace: ai-context-engine
spec:
  volumeSnapshotClassName: fpt-snapshot-class
  source:
    persistentVolumeClaimName: ai-context-data
EOF
```

---

## Troubleshooting

### Pod không start — OOMKilled

```bash
kubectl describe pod -n ai-context-engine -l app=mcp-server
```

→ Tăng memory limit trong Deployment lên 6Gi.

### Pod CrashLoopBackOff

```bash
kubectl logs -n ai-context-engine deploy/mcp-server --previous
```

→ Thường do thiếu token hoặc sai config. Kiểm tra Secret.

### PVC không bind

```bash
kubectl get pvc -n ai-context-engine
kubectl describe pvc ai-context-data -n ai-context-engine
```

→ Kiểm tra StorageClass name đúng với FPT Cloud.

### Ingress không route

```bash
kubectl get ingress -n ai-context-engine
kubectl describe ingress ai-context-ingress -n ai-context-engine
```

→ Kiểm tra ingressClassName và TLS secret.
