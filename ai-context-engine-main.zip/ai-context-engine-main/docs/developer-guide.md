# Developer Guide — AI Context Engine V2

Hướng dẫn dành cho development team để kết nối và sử dụng hệ thống trong quy trình phát triển phần mềm.

---

## Phần 1 — Kết nối với hệ thống

### 1.1 Cấu hình MCP Client (Kiro / Cursor / Claude Desktop)

Thêm vào cấu hình MCP của tool bạn đang dùng:

**Kiro** (`.kiro/settings/mcp.json`):
```json
{
  "mcpServers": {
    "ai-context-engine": {
      "url": "http://ai-context.internal:3000/mcp",
      "headers": {
        "X-API-Key": "<api-key-từ-devops>"
      }
    }
  }
}
```

**Cursor** (`~/.cursor/mcp.json`):
```json
{
  "mcpServers": {
    "ai-context-engine": {
      "url": "http://ai-context.internal:3000/mcp"
    }
  }
}
```

**Claude Desktop** (`~/Library/Application Support/Claude/claude_desktop_config.json`):
```json
{
  "mcpServers": {
    "ai-context-engine": {
      "url": "http://ai-context.internal:3000/mcp"
    }
  }
}
```

> Hỏi DevOps để lấy URL và API key chính xác.

### 1.2 Kiểm tra kết nối

Sau khi cấu hình, restart tool và thử:
```
search_context("order service payment flow")
```

Nếu trả về kết quả → kết nối thành công.

### 1.3 Chạy local (dev cá nhân)

```bash
git clone <repo-url>
cd ict-ai-context-engine
cp .env.example .env
# Điền token GitLab, Confluence, Jira của bạn vào .env

pip install -r requirements.txt
python -m app.cli bootstrap
python -m app.mcp_server  # port 3000
```

---

## Phần 2 — Workflow phát triển phần mềm

Toàn bộ pipeline từ ý tưởng đến production:

```
Ý tưởng
  │
  ▼ Module 2: RDE
Requirements → Design
  │
  ▼ Module 1: Jira
Jira Epic → Story → Sub-task
  │
  ▼ Module 5: CGP
Code Generation → Branch → MR
  │
  ▼ Module 3: QGE
Quality Gate (code review tự động)
  │
  ▼ Module 4: Jenkins
Build → Test
  │
  ▼ Module 6: K8s
CI → UAT → PROD
  │
  ▼ Module 7: Observability
Audit → Confidence → HITL Approval
```

---

## Bước 1 — Sinh Requirements & Design từ ý tưởng

### Qua MCP (trong AI coding tool):

```
rde_generate_requirements("Tôi muốn thêm tính năng thanh toán trả góp cho đơn hàng dược phẩm")
```

Kết quả: tài liệu BRD/PRD với compliance clauses tự động (PCI-DSS, Luật Dược 2016).

```
rde_generate_design(<requirements_doc từ bước trên>)
```

Kết quả: HLD/LLD/ERD/OpenAPI spec + impact analysis.

### Qua CLI:

```bash
# Sinh requirements
python -m app.cli rde-requirements "thêm tính năng thanh toán trả góp" \
  --publish --space ICT

# Sinh design từ file requirements
python -m app.cli rde-design requirements.md \
  --publish --space ICT

# Kiểm tra compliance
python -m app.cli rde-check-compliance requirements.md --type requirements
```

---

## Bước 2 — Tạo Jira tickets từ requirements

### Qua MCP:

```
jira_create_from_intent(
  "Thêm tính năng thanh toán trả góp cho đơn hàng dược phẩm",
  "PROJ"
)
```

Kết quả: tự động tạo Epic → Story → Sub-task với acceptance criteria và story point estimate.

### Qua CLI:

```bash
python -m app.cli jira-create "thêm tính năng thanh toán trả góp" \
  --project-key PROJ
```

---

## Bước 3 — Sinh code từ design

### Qua MCP:

```
# Phân tích design doc → danh sách coding tasks
cgp_decompose_tasks(<design_doc>, source_id="gitlab:42")

# Sinh code cho từng task
cgp_generate_code(<task_json>, source_id="gitlab:42")

# Hoặc chạy toàn bộ pipeline
cgp_run_pipeline(<design_doc>, source_id="gitlab:42", branch_name="feature/installment-payment")
```

### Qua CLI:

```bash
# Phân tích design
python -m app.cli cgp-decompose design.md --source-id gitlab:42

# Chạy toàn bộ pipeline
python -m app.cli cgp-run-pipeline design.md \
  --source-id gitlab:42 \
  --branch feature/installment-payment
```

Kết quả: branch mới được tạo trên GitLab với code skeleton/generated, MR được tạo tự động.

---

## Bước 4 — Quality Gate trước khi merge

### Qua MCP:

```
qge_analyze(<git diff của MR>)
```

Kết quả: report với findings theo severity (CRITICAL/HIGH/MEDIUM/LOW), risk score, và test skeleton.

### Qua CLI:

```bash
# Lấy diff
git diff origin/main...HEAD > my-changes.diff

# Chạy quality gate
python -m app.cli qge-analyze my-changes.diff

# Sinh test skeleton
python -m app.cli qge-generate-tests my-changes.diff
```

> Jenkins tự động gọi quality gate webhook khi có MR — xem DevOps guide để cấu hình.

---

## Bước 5 — Sinh commit message chuẩn

```bash
git diff --staged > staged.diff
python -m app.cli cgp-commit-message staged.diff --desc "add installment payment feature"
# Output: feat(tasks): add installment payment feature
```

---

## Bước 6 — Deploy CI sau khi build pass

```bash
# Kiểm tra build status
python -m app.cli jenkins-status <build-job-name> <build-number>

# Trigger deploy CI
python -m app.cli k8s-promote-ci order-service \
  --build 42 \
  --job deploy-ci-order-service
```

---

## Bước 7 — Promote lên UAT

```bash
python -m app.cli k8s-promote-uat order-service \
  --build 42 \
  --job deploy-uat-order-service
```

Hệ thống tự động kiểm tra:
- CI deployment đã success chưa
- Không có CRITICAL finding từ quality gate
- Chưa có UAT deployment trùng build number

---

## Bước 8 — Kiểm tra PROD gate trước khi release

```bash
python -m app.cli k8s-prod-gate order-service \
  --build 42 \
  --job deploy-prod-order-service
```

Kết quả: checklist với status PASS/FAIL/WARN. Nếu approved, hệ thống trả về lệnh để trigger Jenkins deploy-prod.

> PROD deploy luôn cần human trigger — hệ thống không tự động deploy.

---

## Bước 9 — Correlate incident (khi có sự cố)

```bash
python -m app.cli k8s-correlate order-service \
  --time "2024-01-15T10:30:00Z"
```

Kết quả: deployment gần nhất, time delta, likely_cause, và suggested_action (rollback/investigate).

---

## Phần 3 — Các tính năng hỗ trợ khác

### Tìm kiếm context

```bash
# Tìm trong tất cả sources
python -m app.cli task-brief "order service payment flow"

# Tìm trong Jira
# (qua MCP) jira_search("payment installment feature")
```

### Xem audit logs

```bash
# Xem tất cả events gần đây
python -m app.cli obs-audit-logs --limit 50

# Filter theo module
python -m app.cli obs-audit-logs --type rde_generate_requirements --limit 20
python -m app.cli obs-audit-logs --type qge_analyze --limit 20

# Filter theo trace_id để trace một request
python -m app.cli obs-audit-logs --trace abc123def456

# Export CSV
python -m app.cli obs-audit-logs --format csv > audit.csv
```

### Confidence scoring

```bash
# Kiểm tra chất lượng output trước khi dùng
python -m app.cli obs-score requirements_doc requirements.md
python -m app.cli obs-score generated_code generated_code.py
```

### HITL Approval workflow

```bash
# Tạo approval request cho action quan trọng
python -m app.cli obs-request-approval deploy_prod \
  --desc "Deploy order-service v1.5.0 lên PROD" \
  --payload '{"job": "deploy-prod-order-service", "build": 42}'

# Xem pending approvals
python -m app.cli obs-list-approvals

# Approve
python -m app.cli obs-approve <request_id> \
  --by "manager@example.com" \
  --comment "Đã review, LGTM"

# Reject
python -m app.cli obs-reject <request_id> \
  --by "manager@example.com" \
  --comment "Cần fix bug #123 trước"
```

### Sinh Helm values.yaml

```bash
python -m app.cli k8s-helm-values order-service \
  --image registry.example.com/order-service \
  --tag 1.5.0 \
  --port 8080 \
  --env uat \
  --ingress order-uat.example.com
```

---

## Phần 4 — Tips & Best Practices

**Luôn sync trước khi code:**
```bash
python -m app.cli sync-source gitlab:<id>
```

**Dùng task brief để hiểu context:**
```bash
python -m app.cli task-brief "tính năng cần implement"
```

**Kiểm tra confidence score trước khi dùng generated code:**
```
obs_score_confidence("generated_code", <code>)
```

**Trace một request end-to-end:**
```bash
python -m app.cli obs-audit-logs --trace <trace_id>
```

**Không sửa code từ vector chunk** — luôn đọc file thực từ `local_path` trong task brief.
