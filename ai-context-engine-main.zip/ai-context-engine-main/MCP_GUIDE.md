# MCP Server Guide

MCP Server cho AI Context Engine — giúp Kiro, Cursor, Claude Desktop, hoặc bất kỳ AI coding tool nào truy vấn context từ GitLab + Confluence + Jira và thực thi toàn bộ SDLC pipeline.

## Yêu cầu

- Python 3.11+
- Git
- Token GitLab, Confluence, Jira, Jenkins (tùy module cần dùng)

## Cài đặt

```bash
git clone <repo-url>
cd ict-ai-context-engine
pip install -r requirements.txt
cp .env.example .env
# Điền token vào .env
python -m app.cli bootstrap
python -m app.mcp_server
```

## Kết nối với AI Tool

**Kiro** (`.kiro/settings/mcp.json`):
```json
{
  "mcpServers": {
    "ai-context-engine": {
      "url": "http://localhost:3000/mcp"
    }
  }
}
```

**Cursor** (Settings > MCP Servers):
```json
{ "ai-context-engine": { "url": "http://localhost:3000/mcp" } }
```

**Claude Desktop** (`~/Library/Application Support/Claude/claude_desktop_config.json`):
```json
{
  "mcpServers": {
    "ai-context-engine": { "url": "http://localhost:3000/mcp" }
  }
}
```

---

## Danh sách MCP Tools

### Core Context Tools

| Tool | Mô tả |
|------|-------|
| `search_context` | Tìm kiếm ngữ nghĩa trên GitLab + Confluence |
| `list_sources` | Liệt kê tất cả sources đã index |
| `get_confluence_page` | Lấy nội dung đầy đủ 1 trang Confluence |
| `get_repo_structure` | Xem cấu trúc thư mục + build commands của repo |
| `get_task_brief` | Tạo task brief tự động (code + business context) |
| `sync_sources` | Đồng bộ lại dữ liệu từ GitLab/Confluence |

### Module 1 — Jira Integration

| Tool | Mô tả |
|------|-------|
| `jira_sync_project` | Pull Jira issues vào ChromaDB |
| `jira_create_from_intent` | Tạo Epic/Story/Sub-task từ mô tả ý tưởng |
| `jira_brief_from_ticket` | Sinh task brief từ Jira ticket ID |
| `jira_link_dossier` | Liên kết task dossier với Jira issue |
| `jira_search` | Tìm kiếm Jira issues bằng natural language |

### Module 2 — Requirement & Design Engine

| Tool | Mô tả |
|------|-------|
| `rde_generate_requirements` | Sinh BRD/PRD từ intent text |
| `rde_generate_design` | Sinh HLD/LLD/ERD/OpenAPI từ requirements |
| `rde_analyze_impact` | Phân tích impact lên codebase |
| `rde_check_compliance` | Kiểm tra compliance theo domain |
| `rde_publish_to_confluence` | Publish tài liệu lên Confluence |

### Module 3 — Quality Gate Engine

| Tool | Mô tả |
|------|-------|
| `qge_analyze` | Chạy tất cả quality gate trên code diff |
| `qge_generate_tests` | Sinh pytest skeleton cho code mới |

### Module 4 — Jenkins Integration

| Tool | Mô tả |
|------|-------|
| `jenkins_trigger_pipeline` | Trigger Jenkins job |
| `jenkins_get_build_status` | Lấy trạng thái build |
| `jenkins_analyze_build_log` | Phân tích build log tìm root cause |
| `jenkins_get_deployments` | Xem lịch sử deployment |

### Module 5 — Code Generation Pipeline

| Tool | Mô tả |
|------|-------|
| `cgp_decompose_tasks` | Phân tích design doc → coding tasks |
| `cgp_generate_code` | Sinh code cho một coding task |
| `cgp_generate_commit_message` | Sinh conventional commit message |
| `cgp_run_pipeline` | Chạy toàn bộ pipeline: decompose → code → MR |

### Module 6 — K8s & Deployment Intelligence

| Tool | Mô tả |
|------|-------|
| `k8s_generate_helm_values` | Sinh Helm values.yaml |
| `k8s_promote_to_ci` | Trigger Jenkins deploy-ci |
| `k8s_promote_to_uat` | Trigger Jenkins deploy-uat (sau khi CI pass) |
| `k8s_check_prod_gate` | Sinh PROD promotion checklist |
| `k8s_correlate_incident` | Correlate incident với deployment gần nhất |

### Module 7 — Observability

| Tool | Mô tả |
|------|-------|
| `obs_query_audit_logs` | Query unified audit logs từ tất cả modules |
| `obs_score_confidence` | Tính confidence score cho AI output |
| `obs_request_approval` | Tạo HITL approval request |
| `obs_list_pending_approvals` | Xem pending approvals |
| `obs_approve` | Approve một request |
| `obs_reject` | Reject một request |

---

## Ví dụ sử dụng

### Tìm context trước khi code
```
search_context("order service payment flow")
get_task_brief("thêm tính năng thanh toán trả góp")
```

### Sinh requirements và design
```
rde_generate_requirements("Tôi muốn thêm tính năng thanh toán trả góp cho đơn hàng dược phẩm")
rde_generate_design(<requirements_doc>)
```

### Tạo Jira tickets
```
jira_create_from_intent("Thêm tính năng thanh toán trả góp", "PROJ")
```

### Chạy quality gate
```
qge_analyze(<git diff>)
```

### Deploy pipeline
```
k8s_promote_to_ci("order-service", 42, "deploy-ci")
k8s_promote_to_uat("order-service", 42, "deploy-uat")
k8s_check_prod_gate("order-service", 42, "deploy-prod")
```

---

## Xử lý lỗi thường gặp

**Server không start:**
```
ModuleNotFoundError: No module named 'mcp'
```
→ Chạy lại: `pip install -r requirements.txt`

**Không kết nối được GitLab/Confluence:**
```
401 Unauthorized
```
→ Kiểm tra token trong `.env` còn hiệu lực.

**Bootstrap mất nhiều thời gian:**
```bash
# Giới hạn số lượng
python -m app.cli bootstrap --cf-max-spaces 5 --cf-max-pages-per-space 50
```

---

## Nguyên tắc quan trọng

- ChromaDB chỉ để **tìm context** — không sửa code từ vector chunk
- Repo thật trong `data/workspaces/repos/` mới là nơi **đọc và sửa code**
- PROD deploy luôn cần **human trigger** — hệ thống không tự động deploy
- Luôn sync repo mới nhất trước khi implement: `sync_sources("gitlab:42")`
