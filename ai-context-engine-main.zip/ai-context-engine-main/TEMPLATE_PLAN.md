# TEMPLATE_PLAN.md

## Mục tiêu

Template này dùng khi user chỉ muốn phân tích, lập plan, chưa implement
code.

## Cách dùng

Trong chat, nhập:

```text
@TEMPLATE_PLAN.md
<nội dung task>
```

Ví dụ:

```text
@TEMPLATE_PLAN.md
[OMS] Cung cấp API tạo đơn hàng Service
```

## Yêu cầu bắt buộc

1. Tạo task dossier trong `data/tasks/...` bằng flow chuẩn.
2. Sinh brief cho task, xác định repo phù hợp, file liên quan, và đánh giá
   context đã đủ chưa.
3. Đọc context từ Confluence và Git theo repo được chọn.
4. Cập nhật dossier với các mục:
   - `plan`
   - `scope`
   - `impact`
   - `notes`
5. Không implement code.
6. Nếu thiếu context hoặc business rule thì dừng ở mức phân tích và nói rõ
   thiếu gì.

## Output bắt buộc

1. Brief
2. Repo
3. File chính liên quan
4. Dossier
5. Plan
6. Rủi ro
7. Đánh giá đủ context chưa

## Prompt chuẩn

```text
Phân tích task dưới đây theo flow chuẩn của project. Hãy tạo task dossier, sinh brief, chọn repo phù hợp, đọc context liên quan, và cập nhật dossier với plan/scope/impact/notes. Không implement code. Nếu thiếu context hoặc business rule thì dừng ở bước phân tích và nêu rõ phần còn thiếu.
```
