# Cấu trúc dự án

## Source code (`app/`)

```
app/
├── main.py              # FastAPI app entrypoint, lifespan, CORS, mount router
├── mcp_server.py        # MCP server cho AI agent tool integration
├── cli.py               # CLI entrypoint (python -m app.cli)
├── api/
│   ├── routes.py        # Toàn bộ REST API route handlers
│   └── schemas.py       # Pydantic request/response models
├── core/
│   ├── config.py        # Settings dataclass, path helpers, danh sách file extension
│   ├── config_yaml.py   # YAML-based config loader
│   ├── auth.py          # API key authentication dependency
│   ├── crypto.py        # Fernet mã hoá/giải mã token lưu trong DB
│   ├── logging.py       # Cấu hình logging
│   └── utils.py         # Tiện ích dùng chung
├── catalog/
│   ├── database.py      # SQLite catalog.db — connectors, sources, sync runs
│   └── reports.py       # Export/reporting helpers
├── connectors/
│   ├── gitlab.py        # GitLab API client (discover repos, fetch files)
│   └── confluence.py    # Confluence API client (discover spaces/pages)
├── sync/
│   ├── service.py       # Orchestration: bootstrap, discover, sync, ingest
│   ├── git_sync.py      # Clone/pull Git repos về workspace
│   ├── git_utils.py     # Git helpers
│   ├── confluence_sync.py # Fetch Confluence pages về workspace
│   └── discovery.py     # Logic discover sources
├── ingest/
│   ├── pipeline.py      # Ingest pipeline: đọc → chunk → embed → lưu
│   ├── chunker.py       # Text splitting (repo vs confluence chunk sizes)
│   ├── embedder.py      # sentence-transformers embedding
│   └── store.py         # ChromaDB đọc/ghi
├── retrieval/
│   └── search.py        # Vector similarity search với metadata filters
├── tasks/
│   ├── brief.py         # Sinh task brief từ context đã retrieve
│   └── dossier.py       # Tạo/cập nhật task dossier files
└── internal/
    └── runtime_hook.py  # Internal runtime hooks
```

## Dữ liệu runtime (`data/`) — gitignored

```
data/
├── catalog.db                          # SQLite: connectors, sources, trạng thái sync
├── chroma/                             # ChromaDB vector store
├── workspaces/
│   ├── repos/<org>/<project>/<repo>/   # Git repos đã clone
│   └── confluence/<space>/<page_id>.html
├── tasks/<year>/<year-month>/<task-id>/
│   ├── task.json
│   ├── brief.md
│   ├── plan.md
│   ├── scope.md
│   ├── impact.md
│   ├── notes.md
│   ├── result.md
│   └── timeline.jsonl
├── reports/
└── logs/
```

## Tests (`tests/`)

File test đặt tên theo module tương ứng: `test_api_auth.py`, `test_catalog.py`, `test_sync_service.py`, v.v.

## Quy ước quan trọng

- `app/core/config.py` là nguồn duy nhất cho tất cả paths và settings — dùng `settings.*` ở mọi nơi, không hardcode path
- `catalog.db` là nguồn sự thật về sources; ChromaDB là dữ liệu phái sinh
- Tất cả token lưu trong `catalog.db` đều được mã hoá Fernet qua `app/core/crypto.py`
- `sync/service.py` là lớp orchestration chính — cả CLI lẫn API routes đều gọi vào đây
- Các file extension được ingest định nghĩa trong `SUPPORTED_EXTENSIONS` ở `config.py`
- Các thư mục bị bỏ qua khi duyệt repo định nghĩa trong `DEFAULT_IGNORED_DIRS` ở `config.py`
