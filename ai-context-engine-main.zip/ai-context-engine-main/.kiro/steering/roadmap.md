# Roadmap: Intent → Impact Pipeline

Mục tiêu: AI Context Engine trở thành bộ não trung tâm của toàn bộ SDLC —
từ ý tưởng đến production — cho hệ sinh thái: nhà thuốc, xét nghiệm, tiêm chủng, thiết bị thông minh.

```
Ý tưởng / Yêu cầu
       ↓
  [AI Context Engine]
       ↓
Jira (ticket + story)  →  GitLab (branch + MR)  →  Jenkins (CI/CD)  →  K8s (UAT → PROD)
       ↑                        ↑                        ↑
  Confluence               Code Review              Quality Gates
  (business context)       (AI review)         (test, security, perf, SEO)
```

---

## Module 1 — Jira Integration ✅ HOÀN THÀNH
- Đọc Jira: pull ticket, epic, sprint context vào ChromaDB
- Ghi Jira: từ intent tự động tạo Epic → Story → Sub-task với acceptance criteria, story point estimate
- Sync 2 chiều: task dossier cập nhật status → Jira ticket tự cập nhật
- Jira → Brief: từ ticket ID sinh task brief đầy đủ business + technical context

## Module 2 — Requirement & Design Engine ✅ HOÀN THÀNH
- Requirement generator: phân tích intent → sinh BRD/PRD chuẩn
- Design generator: requirement + codebase context → HLD, LLD, ERD, OpenAPI spec
- Impact analyzer: xác định service nào bị ảnh hưởng trong hệ sinh thái
- Confluence writer: tự động tạo/cập nhật page Confluence

## Module 3 — Quality Gate Engine ✅ HOÀN THÀNH
- Code quality: SonarQube/Semgrep, convention, complexity, duplication
- Security scan: SAST, secret detection, dependency vulnerability
- Test generator: từ code diff sinh unit test + integration test
- Regression analyzer: dependency graph, risk score cho MR
- Performance check: N+1 query, missing index, heavy loop
- SEO audit: Lighthouse, meta tags, structured data (cho frontend)
- API contract validation: đảm bảo code đúng OpenAPI spec

## Module 4 — Jenkins Integration ✅ HOÀN THÀNH
- Pipeline trigger: MR tạo → tự động trigger Jenkins job
- Build status reader: đọc kết quả Jenkins → dossier, AI phân tích log lỗi
- Quality gate enforcer: Jenkins gọi Context Engine lấy gate result trước khi merge
- Deployment tracker: theo dõi deployment history per service/environment

## Module 5 — Code Generation Pipeline ✅ HOÀN THÀNH
- Task decomposer: từ design chia coding tasks nhỏ theo dependency
- Code generator: sinh code đúng convention từng repo
- Branch manager: tạo branch, MR/PR trên GitLab tự động
- Commit message generator: conventional commits chuẩn

## Module 6 — K8s & Deployment Intelligence ✅ HOÀN THÀNH
- Manifest generator: sinh K8s deployment, service, ingress, configmap
- UAT promotion: pass quality gate → tự động deploy UAT + smoke test
- PROD promotion gate: checklist tự động trước khi lên PROD
- Incident correlation: alert PROD → correlate với deployment gần nhất

## Module 7 — Observability cho Engine ✅ HOÀN THÀNH
- Structured audit log: mọi action AI đều có trace đầy đủ
- Confidence scoring: output thấp confidence → flag human review
- Human-in-the-loop gates: merge to main, deploy PROD luôn cần human approve
