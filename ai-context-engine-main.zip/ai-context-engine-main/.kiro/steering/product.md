# Sản phẩm: AI Context Engine V2

AI-CONTEXT-ENGINE-V2 là backend hỗ trợ AI coding agent hiểu codebase bằng cách tổng hợp context từ GitLab repositories và Confluence pages.

## Mục tiêu cốt lõi

Giúp AI agent trả lời câu hỏi kỹ thuật và implement code bằng cách:
1. Discover và sync Git repos + Confluence pages về workspace local
2. Chunk và embed nội dung vào ChromaDB (vector store)
3. Retrieve context liên quan cho từng task
4. Sinh task brief và dossier để hướng dẫn implement

## Nguyên tắc quan trọng nhất

> **ChromaDB dùng để hiểu. Repo thật trong `data/workspaces/repos/` mới dùng để sửa code.**

Không bao giờ sửa code dựa trên vector chunk — luôn đọc file thật từ repo đã clone.

## Nguồn dữ liệu

- GitLab repositories (clone về `data/workspaces/repos/<org>/<project>/<repo>`)
- Confluence pages (fetch về `data/workspaces/confluence/`)
- Metadata lưu trong `data/catalog.db` (SQLite — nguồn sự thật về connectors/sources)

## Quy trình task

Mỗi task kỹ thuật đều theo: `task-start` → lấy context → lập plan → sync repo thật → implement → test → tạo branch → commit → cập nhật dossier
