# Tech Stack

## Ngôn ngữ & Runtime

- Python 3.11+
- Toàn bộ cấu hình qua file `.env` (prefix: `AI_CONTEXT_V2_`)

## Thư viện chính

| Thư viện | Mục đích |
|---|---|
| FastAPI + Uvicorn | REST API server (port 8100) |
| ChromaDB | Vector store lưu embeddings |
| sentence-transformers | Embedding model (mặc định `all-MiniLM-L6-v2`) |
| langchain-text-splitters | Chunking source code và tài liệu |
| MCP (`mcp[cli]`) | MCP server cho AI agent tool integration (port 3000) |
| cryptography (Fernet) | Mã hoá GitLab/Confluence token trong catalog.db |
| requests + beautifulsoup4 | HTTP calls và parse HTML Confluence |
| PyYAML | Hỗ trợ config YAML |
| pytest | Testing |

## Các lệnh thường dùng

```bash
# Cài dependencies
pip install -r requirements.txt

# Khởi động REST API server (dev)
uvicorn app.main:app --host 0.0.0.0 --port 8100 --reload

# Khởi động MCP server
python -m app.mcp_server

# Chạy tests
pytest tests/

# Bootstrap lần đầu
python -m app.cli bootstrap
python -m app.cli bootstrap --sync-git --sync-confluence

# Reset toàn bộ dữ liệu
python -m app.cli reset-data

# Docker
docker-compose up -d
```

## CLI Entry Point

Tất cả thao tác đều qua `python -m app.cli <command>`:

```bash
python -m app.cli bootstrap
python -m app.cli sync-git-all
python -m app.cli sync-confluence-all
python -m app.cli sync-source "<source_id>"
python -m app.cli add-git "<repo_url>"
python -m app.cli add-confluence "<page_url>"
python -m app.cli task-start "<mô tả task>"
python -m app.cli task-plan "<task_id>" --plan "..." --scope "..." --impact "..."
python -m app.cli task-result "<task_id>" --result "..."
python -m app.cli task-show "<task_id>"
python -m app.cli list-sources
python -m app.cli list-connectors
```

## Cấu hình

Tất cả settings trong `app/core/config.py` qua dataclass `Settings`. Các biến env quan trọng:

- `AI_CONTEXT_V2_API_HOST/PORT` — bind server (mặc định `0.0.0.0:8100`)
- `AI_CONTEXT_V2_SECRET_KEY` — Fernet key để mã hoá token
- `AI_CONTEXT_V2_API_KEY` — API key bảo vệ REST API (để trống = tắt auth)
- `AI_CONTEXT_V2_EMBEDDING_MODEL` — tên model HuggingFace
- `AI_CONTEXT_V2_REPO_CHUNK_SIZE/OVERLAP` — chunking cho source code (mặc định 350/70)
- `AI_CONTEXT_V2_CONFLUENCE_CHUNK_SIZE/OVERLAP` — chunking cho Confluence (mặc định 700/140)
- `AI_CONTEXT_V2_GITLAB_*` — cấu hình GitLab connector
- `AI_CONTEXT_V2_CONFLUENCE_*` — cấu hình Confluence connector
