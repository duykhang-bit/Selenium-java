# Tiêu chuẩn & Compliance

Áp dụng cho toàn bộ hệ sinh thái: nhà thuốc, xét nghiệm, tiêm chủng, thiết bị thông minh.
Mọi requirement, design, code, test đều phải đáp ứng các tiêu chuẩn dưới đây.

---

## 1. Quy định pháp luật Việt Nam

### Nghị định 13/2023/NĐ-CP — Bảo vệ dữ liệu cá nhân
- Dữ liệu cá nhân nhạy cảm (sức khỏe, sinh trắc học) phải được **mã hoá khi lưu trữ và truyền tải**
- Phải có **cơ chế xin đồng ý** (consent) trước khi thu thập dữ liệu cá nhân
- Phải có khả năng **xoá dữ liệu theo yêu cầu** (right to erasure)
- Phải lưu **audit log** cho mọi truy cập vào dữ liệu cá nhân nhạy cảm, lưu tối thiểu **2 năm**
- Dữ liệu cá nhân không được lưu ra ngoài lãnh thổ Việt Nam nếu không có cơ chế bảo vệ tương đương
- Thông báo vi phạm dữ liệu cho cơ quan có thẩm quyền trong vòng **72 giờ**

### Luật Dược 2016 (sửa đổi 2023) — Nhà thuốc & Dược phẩm
- Hệ thống bán lẻ thuốc phải lưu trữ **thông tin kê đơn** đầy đủ: tên thuốc, liều lượng, bác sĩ kê đơn, ngày kê
- Thuốc kê đơn (Rx) phải có **xác nhận đơn thuốc hợp lệ** trước khi bán — hệ thống phải có validation rule này
- Phải lưu **lịch sử giao dịch thuốc** tối thiểu **5 năm**
- Thông tin thuốc phải khớp với **danh mục thuốc Bộ Y tế**
- Báo cáo **ADR (Adverse Drug Reaction)** phải được ghi nhận và báo cáo định kỳ

### Thông tư 27/2021/TT-BYT — Hệ thống thông tin quản lý bệnh viện
- Hệ thống phải có khả năng **kết nối và chia sẻ dữ liệu** với hệ thống của Bộ Y tế
- Dữ liệu y tế phải tuân thủ **chuẩn HL7 FHIR** hoặc chuẩn tương đương được Bộ Y tế chấp thuận
- Phải có **phân quyền truy cập** theo chức danh: bác sĩ, dược sĩ, điều dưỡng, admin
- Hồ sơ bệnh án điện tử phải có **chữ ký số** của bác sĩ phụ trách
- Lưu trữ hồ sơ bệnh án điện tử tối thiểu **10 năm** (người lớn), **15 năm** (trẻ em)

### Nghị định 96/2023/NĐ-CP — Khám chữa bệnh & Hồ sơ bệnh án điện tử
- Hồ sơ bệnh án điện tử phải đảm bảo **tính toàn vẹn** — không được sửa đổi sau khi ký số
- Phải có **audit trail** cho mọi thao tác trên hồ sơ bệnh án: ai xem, ai sửa, khi nào
- Dữ liệu xét nghiệm phải được liên kết với **mã bệnh nhân duy nhất**
- Kết quả xét nghiệm phải có **giá trị tham chiếu** và **đơn vị đo** chuẩn quốc tế

### Thông tư 09/2023/TT-BYT — Tiêm chủng
- Hệ thống tiêm chủng phải kết nối với **Hệ thống thông tin tiêm chủng quốc gia**
- Mỗi mũi tiêm phải ghi nhận: tên vắc xin, số lô, hạn dùng, người tiêm, phản ứng sau tiêm
- Phải có **cảnh báo chống chỉ định** tự động dựa trên lịch sử bệnh án
- Dữ liệu tiêm chủng phải được lưu trữ tối thiểu **20 năm**

### Luật An toàn thông tin mạng 2015 — Phân loại hệ thống
- Hệ thống y tế được phân loại **cấp độ 3** (hệ thống thông tin quan trọng quốc gia)
- Phải có **phương án ứng phó sự cố** an toàn thông tin được phê duyệt
- Phải thực hiện **kiểm tra, đánh giá an toàn thông tin** định kỳ (ít nhất 1 lần/năm)
- Phải có **backup và disaster recovery** với RTO ≤ 4 giờ, RPO ≤ 1 giờ
- Phải báo cáo sự cố an toàn thông tin cho **VNCERT/CC** trong vòng **24 giờ**

---

## 2. Tiêu chuẩn quốc tế

### ISO 27001 — Quản lý bảo mật thông tin
- Phân loại tài sản thông tin theo **mức độ nhạy cảm**: Public, Internal, Confidential, Restricted
- Kiểm soát truy cập theo nguyên tắc **least privilege** và **need-to-know**
- Phải có **Business Continuity Plan (BCP)** và **Disaster Recovery Plan (DRP)**
- Mọi thay đổi hệ thống phải qua **Change Management Process**
- Quét **vulnerability scan** hàng quý, **penetration test** hàng năm

### PCI-DSS — Bảo mật dữ liệu thanh toán
- Không lưu CVV, full PAN sau khi giao dịch hoàn thành
- Dữ liệu thẻ phải được mã hoá bằng **AES-256** hoặc tương đương
- Mọi truy cập vào dữ liệu thanh toán phải được **log và monitor**
- Phải có **network segmentation** giữa môi trường xử lý thanh toán và các hệ thống khác

### Healthcare Data (tương đương HIPAA principles)
- **Minimum necessary**: chỉ truy cập dữ liệu sức khỏe ở mức tối thiểu cần thiết
- **De-identification**: khi dùng dữ liệu cho AI/analytics, phải ẩn danh hoá trước
- **Access control**: phân quyền theo role, không ai có quyền truy cập toàn bộ dữ liệu bệnh nhân
- **Breach notification**: phát hiện và thông báo vi phạm dữ liệu trong vòng **72 giờ**

### TCVN/QCVN — Thiết bị y tế thông minh
- Thiết bị y tế kết nối IoT phải tuân thủ **QCVN 117:2020/BTTTT**
- Dữ liệu từ thiết bị y tế phải có **timestamp chính xác** (đồng bộ NTP)
- Phải có cơ chế **phát hiện dữ liệu bất thường** từ thiết bị (outlier detection)
- Firmware thiết bị phải có cơ chế **cập nhật an toàn** (secure OTA update)

---

## 3. Bảo mật kỹ thuật (Security Engineering)

### Authentication & Authorization
- Tất cả API phải yêu cầu xác thực — không có endpoint public nào trả về dữ liệu nhạy cảm
- Sử dụng **token có thời hạn** (expiry), không dùng token vĩnh viễn cho production
- Implement **rate limiting** trên mọi endpoint: tối đa 100 req/phút cho external API
- Mọi thao tác ghi (POST/PUT/DELETE) phải có **CSRF protection** hoặc API key validation

### Mã hoá
- Dữ liệu nhạy cảm (token, credential, PII) lưu trong DB phải mã hoá bằng **Fernet (AES-128-CBC)**
- Kết nối đến Jira, GitLab, Confluence phải qua **HTTPS/TLS 1.2+**
- Không bao giờ log token, password, secret key dưới dạng plaintext

### Input Validation
- Mọi input từ bên ngoài phải được **validate và sanitize** trước khi xử lý
- Chống **SQL injection**: dùng parameterized query, không string concatenation
- Chống **SSRF**: validate URL trước khi gọi external service
- Giới hạn kích thước input: body request tối đa 10MB, string field tối đa 10.000 ký tự

### Dependency Security
- Không dùng thư viện có **CVE nghiêm trọng (CVSS ≥ 7.0)** chưa được vá
- Định kỳ chạy `pip audit` hoặc Snyk để kiểm tra dependency vulnerability

---

## 4. Performance SLA

| Loại | Target | Hard Limit |
|------|--------|------------|
| Internal API (service-to-service) | < 10ms p99 | < 50ms |
| External API (user-facing) | < 500ms p99 | < 2000ms |
| Background job (sync, ingest) | < 5 phút/1000 items | < 30 phút |
| ChromaDB vector search | < 100ms | < 500ms |
| Uptime | 99.99% | — |
| RTO (Recovery Time Objective) | ≤ 4 giờ | — |
| RPO (Recovery Point Objective) | ≤ 1 giờ | — |

### Performance Engineering Rules
- Không có **N+1 query** — mọi loop phải dùng batch query
- Database query phải có **index** trên các cột dùng trong WHERE/JOIN
- Kết nối đến external service phải có **timeout** cấu hình được (mặc định: connect 5s, read 30s)
- Implement **connection pooling** cho SQLite và HTTP client
- Background task nặng (sync, ingest) phải chạy **async/non-blocking**

---

## 5. Code Quality Standards

### Clean Code
- Hàm không quá **50 dòng**, file không quá **500 dòng**
- Mỗi hàm chỉ làm **một việc** (Single Responsibility)
- Không có **magic number/string** — dùng constant hoặc config
- Tên biến/hàm phải **mô tả rõ ý nghĩa**, không dùng tên viết tắt khó hiểu
- Không có **dead code** (code không bao giờ được gọi)

### Exception Handling
- Mọi lời gọi external service (Jira, GitLab, Confluence, ChromaDB) phải có **try/except cụ thể**
- Không dùng bare `except:` — phải catch exception type cụ thể
- Exception phải được **log với đủ context** (input, stack trace, timestamp)
- Lỗi từ external service phải được **wrap thành domain exception** của ứng dụng
- Phân biệt rõ **recoverable error** (retry được) và **fatal error** (dừng lại, alert)

### Logging Standards
- Log format: **JSON structured** với các field: `timestamp` (ISO 8601 UTC), `level`, `service`, `trace_id`, `message`, `context`
- Log levels: DEBUG (dev only), INFO (normal flow), WARNING (recoverable issue), ERROR (action required), CRITICAL (system down)
- Không log **PII hoặc credential** ở bất kỳ level nào
- Mọi request phải có **trace_id** xuyên suốt từ đầu đến cuối

### Testing Standards
- **Unit test coverage ≥ 80%** cho business logic
- Mọi public function phải có ít nhất **1 happy path test** và **1 error path test**
- Integration test phải dùng **mock/stub** cho external service — không gọi Jira/GitLab thật trong CI
- **Property-based test** cho các hàm xử lý dữ liệu quan trọng (idempotency, invariants)

---

## 6. Definition of Done (DoD)

Một task/story chỉ được coi là DONE khi:

- [ ] Code đã pass tất cả unit test và integration test
- [ ] Code coverage ≥ 80% cho module mới
- [ ] Không có lỗi SAST (Semgrep/Bandit) ở mức HIGH hoặc CRITICAL
- [ ] Không có dependency vulnerability CVSS ≥ 7.0
- [ ] Có exception handling cho mọi lời gọi external service
- [ ] Có structured logging với trace_id
- [ ] Có input validation cho mọi endpoint/function nhận input từ ngoài
- [ ] Performance đáp ứng SLA (có benchmark hoặc load test nếu là critical path)
- [ ] Không có PII/credential trong log hoặc response body không cần thiết
- [ ] Code review bởi ít nhất 1 người khác (hoặc AI review pass)
- [ ] Tài liệu (docstring, README, Confluence) được cập nhật nếu có thay đổi interface

---

## 7. Tiêu chí Verify cho AI-generated Output

Khi AI Context Engine sinh ra requirement, design, hoặc code, phải verify:

### Verify Requirement
- Có đủ **actor, action, outcome** (user story format)
- Có **acceptance criteria** đo lường được (không mơ hồ)
- Đã xem xét **security implication** của requirement
- Đã xem xét **data privacy** — requirement có xử lý PII không, nếu có thì có điều khoản bảo vệ không
- Kiểm tra **compliance checklist** theo domain:
  - Nhà thuốc: tuân thủ Luật Dược? Có validation kê đơn Rx? Lưu trữ 5 năm?
  - Xét nghiệm/Bệnh án: audit trail đầy đủ? Lưu trữ 10-15 năm? Chữ ký số?
  - Tiêm chủng: kết nối hệ thống quốc gia? Cảnh báo chống chỉ định? Lưu trữ 20 năm?
  - Thanh toán: tuân thủ PCI-DSS? Mask PAN/CVV? Network segmentation?
  - Thiết bị y tế: timestamp NTP? Outlier detection? Secure OTA?
  - An toàn thông tin: RTO ≤ 4h / RPO ≤ 1h? Báo cáo VNCERT/CC trong 24h?
- Không mâu thuẫn với requirement khác

### Verify Design
- Có **threat model** cơ bản: ai có thể tấn công, tấn công như thế nào, phòng thủ ra sao
- Có **data flow diagram** thể hiện dữ liệu nhạy cảm đi qua đâu
- Có **data retention policy** cho từng loại dữ liệu (xem bảng mục 8)
- Có **error handling strategy** rõ ràng
- Có **performance estimation** cho critical path
- Tuân thủ **existing architecture patterns** của codebase
- Có **backup & recovery strategy** đáp ứng RTO ≤ 4h / RPO ≤ 1h

### Verify Code
- Chạy qua **SAST scanner** trước khi merge
- Có **test coverage** đủ theo DoD
- Không có **hardcoded credential hoặc PII**
- Exception handling đúng pattern của dự án
- Logging đúng format JSON structured

---

## 8. Data Retention Policy

| Loại dữ liệu | Thời gian lưu tối thiểu | Căn cứ pháp lý |
|---|---|---|
| Hồ sơ bệnh án điện tử (người lớn) | 10 năm | Nghị định 96/2023 |
| Hồ sơ bệnh án điện tử (trẻ em) | 15 năm | Nghị định 96/2023 |
| Lịch sử giao dịch thuốc | 5 năm | Luật Dược 2016 |
| Lịch sử tiêm chủng | 20 năm | Thông tư 09/2023 |
| Audit log truy cập dữ liệu cá nhân | 2 năm | Nghị định 13/2023 |
| Log giao dịch thanh toán | 5 năm | PCI-DSS |
| Log hệ thống (security events) | 1 năm | ISO 27001 / Luật ATTTM |
