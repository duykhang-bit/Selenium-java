# Tài liệu Thiết kế: Jenkins Integration

## Tổng quan

Jenkins Integration (Module 4) kết nối AI Context Engine với Jenkins CI/CD. Module gồm 4 thành phần chính: Jenkins connector, pipeline trigger, build log analyzer, và deployment tracker. Ngoài ra expose webhook endpoint để Jenkins gọi ngược lại lấy quality gate result.

### Vị trí trong hệ thống

```
GitLab MR / Task Dossier
        │
        ▼
┌───────────────────────────────────────────┐
│           Jenkins Integration              │
│                                            │
│  Jenkins_Connector (HTTP client)           │
│       │              │                     │
│  Pipeline_Trigger  Build_Status_Reader     │
│       │              │                     │
│  Deployment_Tracker  Build_Log_Analyzer    │
└───────────────────────────────────────────┘
        │                    ↑
        ▼                    │ webhook
  Jenkins Server      POST /jenkins/quality-gate
        │
        ▼
  CI/CD Pipeline
```

---

## Kiến trúc

### Nguyên tắc

- **Jenkins REST API**: dùng `requests` gọi Jenkins API v2 (`/api/json`, `/build`, `/logText/progressiveText`)
- **Stateless connector**: `JenkinsConnector` là pure HTTP client, không giữ state
- **Catalog lưu history**: trigger records và deployment records lưu vào SQLite catalog (bảng mới)
- **Build log analyzer**: pure Python regex — không gọi LLM
- **Webhook endpoint**: Jenkins gọi vào `/jenkins/quality-gate` → chạy QGE → trả kết quả

### Luồng dữ liệu

```mermaid
sequenceDiagram
    participant Agent as AI Agent / MCP
    participant API as FastAPI
    participant JC as Jenkins_Connector
    participant Jenkins
    participant Catalog as SQLite Catalog
    participant QGE as Quality_Gate_Engine

    Agent->>API: POST /jenkins/trigger {job_name, params}
    API->>JC: trigger_job(job_name, params)
    JC->>Jenkins: POST /job/{name}/buildWithParameters
    Jenkins-->>JC: 201 + Location header (queue item)
    JC->>Jenkins: GET /queue/item/{id}/api/json (poll)
    Jenkins-->>JC: {executable: {number: 42}}
    JC-->>API: TriggerResult(build_number=42, build_url=...)
    API->>Catalog: save trigger_record
    API-->>Agent: TriggerResult

    Jenkins->>API: POST /jenkins/quality-gate {source_id, diff}
    API->>QGE: run_all_gates(diff)
    QGE-->>API: QualityGateReport
    API-->>Jenkins: 200 PASS / 422 FAIL
```

---

## Components

### `app/connectors/jenkins.py`

```python
class JenkinsConnectionError(Exception): ...
class JenkinsJobNotFoundError(Exception): ...

class JenkinsConnector:
    def __init__(self, base_url: str, username: str, token: str): ...

    def check_connection(self) -> bool:
        """GET /api/json — kiểm tra kết nối và credentials."""

    def trigger_job(
        self,
        job_name: str,
        parameters: dict | None = None,
        timeout: int = 10,
    ) -> int:
        """POST /job/{name}/buildWithParameters → poll queue → trả về build_number."""

    def get_build_status(self, job_name: str, build_number: int) -> dict:
        """GET /job/{name}/{number}/api/json → {status, duration, timestamp, url}."""

    def get_build_log(self, job_name: str, build_number: int, max_bytes: int = 51200) -> str:
        """GET /job/{name}/{number}/logText/progressiveText → console output."""

    def list_jobs(self, folder: str | None = None) -> list[dict]:
        """GET /api/json?tree=jobs[name,url,color] → list jobs."""
```

### `app/tasks/jenkins/models.py`

```python
@dataclass
class TriggerResult:
    job_name: str
    build_number: int
    build_url: str
    triggered_at: str   # ISO 8601 UTC
    trace_id: str

@dataclass
class BuildStatus:
    job_name: str
    build_number: int
    status: str         # "SUCCESS" | "FAILURE" | "RUNNING" | "ABORTED" | "UNSTABLE"
    duration_ms: int
    timestamp: str
    url: str

@dataclass
class BuildAnalysis:
    error_type: str     # "compilation" | "test_failure" | "dependency" | "timeout" | "oom" | "unknown"
    error_message: str
    affected_files: list[str]
    suggested_fix: str
    raw_snippet: str    # đoạn log liên quan

@dataclass
class DeploymentRecord:
    record_id: str
    service: str
    environment: str    # "dev" | "uat" | "prod"
    build_number: int
    job_name: str
    status: str         # "success" | "failure" | "running"
    deployed_at: str
    deployed_by: str    # "system" | task_id
    build_url: str
```

### `app/tasks/jenkins/log_analyzer.py`

Pure Python regex — phân tích Jenkins console log:

```python
_ERROR_PATTERNS = [
    ("compilation", re.compile(r"error: |ERROR: |COMPILATION ERROR", re.I)),
    ("test_failure", re.compile(r"FAILED|Tests run:.*Failures: [1-9]|FAIL:", re.I)),
    ("dependency", re.compile(r"Could not resolve|dependency.*not found|ModuleNotFoundError", re.I)),
    ("timeout", re.compile(r"Timeout|timed out|TIMEOUT", re.I)),
    ("oom", re.compile(r"OutOfMemoryError|java.lang.OutOfMemory|MemoryError", re.I)),
]

def analyze_log(log_text: str) -> BuildAnalysis: ...
```

### `app/tasks/jenkins/trigger.py`

```python
def trigger_pipeline(
    job_name: str,
    parameters: dict | None = None,
    triggered_by: str = "system",
    trace_id: str | None = None,
) -> TriggerResult: ...
```

### `app/tasks/jenkins/tracker.py`

```python
def record_deployment(
    service: str,
    environment: str,
    build_number: int,
    job_name: str,
    status: str,
    deployed_by: str = "system",
    build_url: str = "",
) -> DeploymentRecord: ...

def get_deployments(
    service: str | None = None,
    environment: str | None = None,
    limit: int = 20,
) -> list[DeploymentRecord]: ...

def get_latest_deployment(service: str, environment: str) -> DeploymentRecord | None: ...
```

### Database schema (bổ sung vào `catalog.db`)

```sql
CREATE TABLE IF NOT EXISTS jenkins_triggers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_name TEXT NOT NULL,
    build_number INTEGER NOT NULL,
    build_url TEXT DEFAULT '',
    triggered_by TEXT DEFAULT 'system',
    parameters_json TEXT DEFAULT '{}',
    triggered_at TEXT NOT NULL,
    trace_id TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS jenkins_deployments (
    record_id TEXT PRIMARY KEY,
    service TEXT NOT NULL,
    environment TEXT NOT NULL,
    build_number INTEGER NOT NULL,
    job_name TEXT NOT NULL,
    status TEXT NOT NULL,
    deployed_at TEXT NOT NULL,
    deployed_by TEXT DEFAULT 'system',
    build_url TEXT DEFAULT ''
);
```

---

## API Contract

### REST Endpoints

#### POST `/jenkins/trigger`
```
Request: { job_name, parameters: dict | null, triggered_by: str }
Response 200: TriggerResult
Response 404: job not found
Response 503: Jenkins unavailable
```

#### GET `/jenkins/builds/{job_name}/{build_number}`
```
Response 200: { status: BuildStatus, analysis: BuildAnalysis | null }
```

#### POST `/jenkins/quality-gate`
```
Request: { source_id: str, diff: str, job_name: str, build_number: int }
Response 200: { overall: "PASS"|"WARN", report: QualityGateReport }
Response 422: { overall: "FAIL", report: QualityGateReport }
```

#### POST `/jenkins/deployments`
```
Request: DeploymentRecord fields
Response 201: DeploymentRecord
```

#### GET `/jenkins/deployments`
```
Query: service, environment, limit
Response 200: { deployments: list[DeploymentRecord] }
```

### MCP Tools

```python
@mcp.tool()
def jenkins_trigger_pipeline(job_name: str, parameters: dict | None = None) -> dict: ...

@mcp.tool()
def jenkins_get_build_status(job_name: str, build_number: int) -> dict: ...

@mcp.tool()
def jenkins_analyze_build_log(job_name: str, build_number: int) -> dict: ...

@mcp.tool()
def jenkins_get_deployments(
    service: str | None = None,
    environment: str | None = None,
    limit: int = 10,
) -> dict: ...
```

### CLI Commands

```bash
python -m app.cli jenkins-trigger <job_name> [--param key=value ...]
python -m app.cli jenkins-status <job_name> <build_number>
python -m app.cli jenkins-log <job_name> <build_number>
python -m app.cli jenkins-deployments [--service NAME] [--env uat|prod] [--limit 20]
python -m app.cli jenkins-record-deploy <service> <env> <build_number> <job_name>
```

---

## Config (`.env`)

```env
AI_CONTEXT_V2_JENKINS_BASE_URL=https://jenkins.example.com
AI_CONTEXT_V2_JENKINS_USERNAME=admin
AI_CONTEXT_V2_JENKINS_TOKEN=your-api-token
AI_CONTEXT_V2_JENKINS_QUEUE_POLL_INTERVAL=2   # seconds
AI_CONTEXT_V2_JENKINS_QUEUE_POLL_TIMEOUT=30   # seconds
```
