# Tài liệu Yêu cầu: Jenkins Integration

## Giới thiệu

Jenkins Integration là Module 4 trong roadmap Intent → Impact Pipeline. Module này kết nối AI Context Engine với Jenkins CI/CD để:
1. Trigger Jenkins pipeline khi có MR/task mới
2. Đọc build status và phân tích log lỗi
3. Cung cấp quality gate result cho Jenkins trước khi merge (webhook)
4. Theo dõi deployment history per service/environment

Pattern nhất quán với các module trước: Jenkins connector → catalog → sync/trigger → REST API + MCP + CLI.

---

## Bảng chú giải

- **Jenkins_Connector**: Client gọi Jenkins REST API (trigger job, đọc build status, lấy log)
- **Build**: Một lần chạy Jenkins job, có build number, status, log
- **Pipeline**: Jenkins job được cấu hình (Jenkinsfile), có thể trigger thủ công hoặc tự động
- **Quality_Gate_Webhook**: Endpoint trong Context Engine để Jenkins gọi vào lấy gate result trước khi merge
- **Deployment_Record**: Bản ghi một lần deploy: service, environment, build number, timestamp, status
- **Build_Log_Analyzer**: Phân tích Jenkins build log để tìm root cause của failure
- **Environment**: Môi trường deploy — dev, uat, prod

---

## Yêu cầu

### Yêu cầu 1: Jenkins Connector

**User Story:** Là một AI agent, tôi muốn kết nối với Jenkins để trigger job và đọc build status, để tôi có thể tự động hoá CI/CD pipeline.

#### Acceptance Criteria

1. WHEN Jenkins base URL và credentials được cấu hình, THE Jenkins_Connector SHALL xác thực bằng API token và kiểm tra kết nối trong vòng 5 giây
2. THE Jenkins_Connector SHALL hỗ trợ trigger Jenkins job với parameters tùy chỉnh
3. THE Jenkins_Connector SHALL đọc build status: RUNNING, SUCCESS, FAILURE, ABORTED, UNSTABLE
4. THE Jenkins_Connector SHALL lấy build log (console output) với giới hạn kích thước (mặc định 50KB)
5. THE Jenkins_Connector SHALL list tất cả jobs trong một folder/view
6. IF Jenkins không khả dụng, THEN THE Jenkins_Connector SHALL raise `JenkinsConnectionError` với message rõ ràng

### Yêu cầu 2: Pipeline Trigger

**User Story:** Là một AI agent, tôi muốn tự động trigger Jenkins pipeline khi có task mới hoặc MR được tạo, để tôi có thể đảm bảo CI chạy ngay sau khi code được push.

#### Acceptance Criteria

1. WHEN `trigger_pipeline(job_name, parameters)` được gọi, THE system SHALL trigger Jenkins job và trả về build number trong vòng 10 giây
2. THE system SHALL lưu trigger record vào catalog với: job_name, build_number, triggered_at, triggered_by (task_id hoặc source_id), parameters
3. WHEN trigger thành công, THE system SHALL trả về `TriggerResult` với build_url để theo dõi
4. IF job không tồn tại, THEN THE system SHALL raise `JenkinsJobNotFoundError`

### Yêu cầu 3: Build Status Reader

**User Story:** Là một AI agent, tôi muốn đọc kết quả build Jenkins và phân tích log lỗi, để tôi có thể hiểu nguyên nhân failure và đề xuất fix.

#### Acceptance Criteria

1. WHEN `get_build_status(job_name, build_number)` được gọi, THE system SHALL trả về `BuildStatus` với: status, duration, timestamp, url
2. WHEN build FAILURE, THE system SHALL tự động lấy console log và chạy `Build_Log_Analyzer`
3. THE Build_Log_Analyzer SHALL phát hiện các pattern lỗi phổ biến: compilation error, test failure, dependency error, timeout, OOM
4. THE Build_Log_Analyzer SHALL trả về `BuildAnalysis` với: error_type, error_message, affected_files, suggested_fix
5. THE system SHALL lưu build result vào catalog để tra cứu lịch sử

### Yêu cầu 4: Quality Gate Webhook

**User Story:** Là một Jenkins pipeline, tôi muốn gọi Context Engine để lấy quality gate result trước khi merge, để tôi có thể enforce code quality tự động.

#### Acceptance Criteria

1. THE system SHALL expose endpoint `POST /jenkins/quality-gate` nhận: `source_id`, `diff` (hoặc `mr_url`), `job_name`, `build_number`
2. WHEN endpoint được gọi, THE system SHALL chạy QGE gate runner trên diff và trả về `QualityGateResult` trong vòng 60 giây
3. IF overall = FAIL, THE system SHALL trả về HTTP 422 để Jenkins pipeline có thể fail build
4. IF overall = PASS hoặc WARN, THE system SHALL trả về HTTP 200
5. THE system SHALL ghi audit record cho mỗi quality gate check được trigger từ Jenkins

### Yêu cầu 5: Deployment Tracker

**User Story:** Là một AI agent, tôi muốn theo dõi lịch sử deployment per service/environment, để tôi có thể biết version nào đang chạy ở đâu và correlate với incident.

#### Acceptance Criteria

1. WHEN `record_deployment(service, environment, build_number, status)` được gọi, THE system SHALL lưu `DeploymentRecord` vào catalog
2. THE system SHALL hỗ trợ query: "deployment gần nhất của service X ở environment Y là gì?"
3. THE system SHALL hỗ trợ query: "tất cả deployment trong 24h qua"
4. WHEN deployment FAILURE, THE system SHALL tự động correlate với build log để tìm root cause

### Yêu cầu 6: MCP Tools

**User Story:** Là một AI coding agent, tôi muốn trigger Jenkins và đọc build result qua MCP, để tôi có thể tích hợp CI/CD vào workflow coding.

#### Acceptance Criteria

1. THE system SHALL expose MCP tool `jenkins_trigger_pipeline(job_name, parameters)` 
2. THE system SHALL expose MCP tool `jenkins_get_build_status(job_name, build_number)`
3. THE system SHALL expose MCP tool `jenkins_get_deployments(service, environment, limit)`
4. THE system SHALL expose MCP tool `jenkins_analyze_build_log(job_name, build_number)`

---

## Correctness Properties

### Invariant: Build Record Immutability
Một build record đã được lưu không được thay đổi — chỉ được thêm record mới với status update.

### Invariant: Audit Trail
Mọi trigger và quality gate check đều phải có audit record trong `data/logs/jenkins_audit.jsonl`.

### Error Condition: Jenkins Unavailable
Khi Jenkins không khả dụng, tất cả operations phải fail fast với `JenkinsConnectionError` — không được retry vô hạn.
