# Kế hoạch Triển khai: Jenkins Integration

## Tasks

- [ ] 1. Thêm Jenkins config vào `app/core/config.py`
  - Thêm fields: `jenkins_base_url`, `jenkins_username`, `jenkins_token`, `jenkins_queue_poll_interval`, `jenkins_queue_poll_timeout`
  - _Yêu cầu: 1.1_

- [ ] 2. Tạo `app/connectors/jenkins.py`
  - `JenkinsConnectionError`, `JenkinsJobNotFoundError` exceptions
  - `JenkinsConnector` class với: `check_connection()`, `trigger_job()`, `get_build_status()`, `get_build_log()`, `list_jobs()`
  - `trigger_job()` poll queue item để lấy build_number (retry tối đa `queue_poll_timeout` giây)
  - _Yêu cầu: 1.1–1.6_

  - [ ] 2.1 Viết unit test cho jenkins connector
    - Test `check_connection()` với mock HTTP 200 và 401
    - Test `trigger_job()` với mock queue polling
    - Test `get_build_status()` với mock build JSON
    - Test `get_build_log()` với mock console output
    - Test `JenkinsConnectionError` khi server không khả dụng

- [ ] 3. Tạo `app/tasks/jenkins/` package với models
  - `app/tasks/jenkins/__init__.py`
  - `app/tasks/jenkins/models.py`: `TriggerResult`, `BuildStatus`, `BuildAnalysis`, `DeploymentRecord`
  - _Yêu cầu: 2.3, 3.1, 5.1_

  - [ ] 3.1 Viết unit test cho models
    - Test dataclass fields và defaults

- [ ] 4. Bổ sung Jenkins tables vào `app/catalog/database.py`
  - Thêm `jenkins_triggers` table vào `init_database()`
  - Thêm `jenkins_deployments` table vào `init_database()`
  - Thêm CRUD functions: `save_trigger_record()`, `save_deployment_record()`, `list_deployments()`, `get_latest_deployment()`
  - _Yêu cầu: 2.2, 5.1_

  - [ ] 4.1 Viết unit test cho catalog functions mới
    - Test save và query trigger records
    - Test save và query deployment records
    - Test `get_latest_deployment()` trả về record mới nhất

- [ ] 5. Checkpoint — models, connector, catalog pass test
  - Chạy `pytest tests/test_jenkins_connector.py tests/test_jenkins_models.py tests/test_jenkins_catalog.py -v`

- [ ] 6. Tạo `app/tasks/jenkins/log_analyzer.py`
  - Implement `analyze_log(log_text: str) -> BuildAnalysis`
  - Detect error types: compilation, test_failure, dependency, timeout, oom, unknown
  - Extract affected files từ error message (regex tìm file path patterns)
  - Sinh `suggested_fix` dựa trên error_type
  - _Yêu cầu: 3.3, 3.4_

  - [ ] 6.1 Viết unit test cho log_analyzer
    - Test detect compilation error
    - Test detect test failure
    - Test detect dependency error
    - Test detect timeout
    - Test detect OOM
    - Test unknown error fallback
    - Test extract affected files từ log

- [ ] 7. Tạo `app/tasks/jenkins/trigger.py`
  - Implement `trigger_pipeline(job_name, parameters, triggered_by, trace_id) -> TriggerResult`
  - Gọi `JenkinsConnector.trigger_job()`, lưu trigger record vào catalog
  - Ghi audit record vào `data/logs/jenkins_audit.jsonl`
  - _Yêu cầu: 2.1–2.4_

  - [ ] 7.1 Viết unit test cho trigger
    - Test trigger thành công → TriggerResult với build_number
    - Test trigger record được lưu vào catalog
    - Test audit record được ghi
    - Test `JenkinsJobNotFoundError` propagated

- [ ] 8. Tạo `app/tasks/jenkins/tracker.py`
  - Implement `record_deployment()`, `get_deployments()`, `get_latest_deployment()`
  - _Yêu cầu: 5.1–5.4_

  - [ ] 8.1 Viết unit test cho tracker
    - Test record và query deployment
    - Test get_latest_deployment
    - Test filter by service + environment

- [ ] 9. Checkpoint — log_analyzer, trigger, tracker pass test
  - Chạy `pytest tests/test_jenkins_*.py -v`

- [ ] 10. Thêm Jenkins schemas vào `app/api/schemas.py`
  - `JenkinsTriggerRequest`, `JenkinsQualityGateRequest`, `JenkinsRecordDeployRequest`

- [ ] 11. Thêm Jenkins endpoints vào `app/api/routes.py`
  - `POST /jenkins/trigger`
  - `GET /jenkins/builds/{job_name}/{build_number}`
  - `POST /jenkins/quality-gate` (webhook cho Jenkins)
  - `POST /jenkins/deployments`
  - `GET /jenkins/deployments`
  - _Yêu cầu: 4.1–4.5_

  - [ ] 11.1 Viết integration test cho Jenkins endpoints
    - Test `/jenkins/quality-gate` PASS → 200
    - Test `/jenkins/quality-gate` FAIL → 422
    - Test `/jenkins/deployments` CRUD

- [ ] 12. Thêm Jenkins MCP tools vào `app/mcp_server.py`
  - `jenkins_trigger_pipeline`, `jenkins_get_build_status`, `jenkins_analyze_build_log`, `jenkins_get_deployments`
  - _Yêu cầu: 6.1–6.4_

- [ ] 13. Thêm Jenkins CLI commands vào `app/cli.py`
  - `jenkins-trigger`, `jenkins-status`, `jenkins-log`, `jenkins-deployments`, `jenkins-record-deploy`

- [ ] 14. Checkpoint cuối
  - Chạy `pytest tests/ --ignore=tests/test_brief_enhanced.py --ignore=tests/test_mcp_integration.py -v --tb=short`
  - Kiểm tra import: `python -c "from app.tasks.jenkins import trigger, tracker, log_analyzer; print('OK')"`
