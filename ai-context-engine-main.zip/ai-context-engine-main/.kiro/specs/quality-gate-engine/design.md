# Tài liệu Thiết kế: Quality Gate Engine

## Tổng quan

Quality Gate Engine (QGE) là Module 3 trong Intent → Impact Pipeline. Module phân tích code diff qua nhiều gate song song, không cần LLM hay external server — toàn bộ là pure Python static analysis.

### Vị trí trong hệ thống

```
GitLab MR / Code Diff
        │
        ▼
┌───────────────────────────────────────────────────────┐
│                  Quality Gate Engine                   │
│                                                        │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐            │
│  │ Code     │  │ Security │  │ Secret   │  ...        │
│  │ Quality  │  │ SAST     │  │ Detection│            │
│  └──────────┘  └──────────┘  └──────────┘            │
│                      │                                 │
│              Gate_Runner (parallel)                    │
│                      │                                 │
│              QualityGateReport                         │
└───────────────────────────────────────────────────────┘
        │                    │
        ▼                    ▼
  MCP / REST API        qge_audit.jsonl
```

---

## Kiến trúc

### Nguyên tắc

- **Pure Python, no LLM**: tất cả gate dùng `ast`, `re`, `tokenize` — không gọi external service
- **Parallel execution**: `ThreadPoolExecutor` chạy tất cả gate đồng thời
- **Graceful degradation**: exception trong một gate không abort các gate khác
- **Stateless**: mỗi gate là pure function `run(diff: CodeDiff) -> GateReport`
- **Offline first**: không cần network (trừ Dependency Gate — graceful degrade khi offline)

### Luồng dữ liệu

```mermaid
sequenceDiagram
    participant API
    participant GR as Gate_Runner
    participant CQ as Code_Quality_Gate
    participant SEC as Security_Gate
    participant SD as Secret_Gate
    participant DEP as Dependency_Gate
    participant TC as Test_Coverage_Gate
    participant PERF as Performance_Gate
    participant AC as API_Contract_Gate
    participant RA as Regression_Analyzer
    participant TG as Test_Generator

    API->>GR: run_all_gates(diff, config)
    par parallel execution
        GR->>CQ: run(diff)
        GR->>SEC: run(diff)
        GR->>SD: run(diff)
        GR->>DEP: run(diff)
        GR->>TC: run(diff)
        GR->>PERF: run(diff)
        GR->>AC: run(diff)
        GR->>RA: run(diff, collection)
        GR->>TG: run(diff)
    end
    GR->>GR: aggregate_results()
    GR-->>API: QualityGateReport
```

---

## Components

### Data Classes (`app/tasks/quality_gate/models.py`)

```python
@dataclass
class Finding:
    gate: str           # "code_quality" | "security" | "secret" | ...
    severity: str       # "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "INFO"
    file: str
    line: int | None
    message: str
    rule_id: str        # "CQ-001", "SEC-001", ...
    suggestion: str     # hướng dẫn khắc phục

@dataclass
class GateReport:
    gate: str
    passed: bool        # False nếu có CRITICAL/HIGH finding
    findings: list[Finding]
    duration_ms: int
    error: str | None   # exception message nếu gate bị lỗi

@dataclass
class QualityGateReport:
    overall: str        # "PASS" | "WARN" | "FAIL"
    gate_reports: list[GateReport]
    all_findings: list[Finding]
    total_critical: int
    total_high: int
    total_medium: int
    total_low: int
    generated_test_code: str | None   # từ Test_Generator
    risk_score: int                   # 0-100, từ Regression_Analyzer
    analyzed_at: str
    trace_id: str

@dataclass
class ParsedDiff:
    """Kết quả parse unified diff."""
    files: list[DiffFile]

@dataclass
class DiffFile:
    path: str
    old_path: str | None
    change_type: str        # "added" | "modified" | "deleted"
    added_lines: list[tuple[int, str]]    # (line_number, content)
    removed_lines: list[tuple[int, str]]
    full_new_content: str | None          # nếu là file mới hoàn toàn
```

### Module structure

```
app/tasks/quality_gate/
├── __init__.py
├── models.py           # data classes
├── diff_parser.py      # parse unified diff → ParsedDiff
├── gate_runner.py      # orchestration, parallel execution
├── gates/
│   ├── __init__.py
│   ├── code_quality.py     # cyclomatic complexity, line count, duplication
│   ├── security.py         # SAST: SQL injection, eval, subprocess, pickle
│   ├── secret_detection.py # hardcoded secrets, API keys, PEM blocks
│   ├── dependency.py       # requirements.txt / package.json vulnerability check
│   ├── test_coverage.py    # missing test file detection
│   ├── performance.py      # N+1 query, sleep, SELECT *
│   ├── api_contract.py     # OpenAPI spec validation
│   └── regression.py       # dependency graph, risk score
└── test_generator.py   # sinh pytest skeleton từ diff
```

### Gate Interface

Mỗi gate implement interface đơn giản:

```python
def run(diff: ParsedDiff, **kwargs) -> GateReport:
    """
    Args:
        diff: Parsed diff object
        **kwargs: gate-specific options (collection_name, spec_path, ...)
    Returns:
        GateReport với findings và passed status
    """
```

### `diff_parser.py`

Parse unified diff format thành `ParsedDiff`. Xử lý:
- `--- a/file.py` / `+++ b/file.py` headers
- `@@ -L,N +L,N @@` hunk headers
- `+` added lines, `-` removed lines, ` ` context lines
- Detect file add/modify/delete từ `/dev/null`

### `gate_runner.py`

```python
def run_all_gates(
    diff_text: str,
    collection_name: str = "knowledge",
    enabled_gates: list[str] | None = None,  # None = all
    trace_id: str | None = None,
) -> QualityGateReport:
    parsed = parse_diff(diff_text)
    gates = _get_enabled_gates(enabled_gates)
    
    with ThreadPoolExecutor(max_workers=len(gates)) as executor:
        futures = {executor.submit(gate.run, parsed): gate.name for gate in gates}
        reports = []
        for future in as_completed(futures, timeout=60):
            try:
                reports.append(future.result())
            except Exception as e:
                reports.append(GateReport(gate=futures[future], error=str(e), ...))
    
    return _aggregate(reports, trace_id)
```

### `gates/code_quality.py`

Dùng `ast.parse()` để phân tích Python code:
- **Cyclomatic complexity**: đếm `if`, `elif`, `for`, `while`, `except`, `and`, `or`, `with` trong AST
- **Function length**: đếm số dòng từ `FunctionDef.lineno` đến `end_lineno`
- **Duplication**: sliding window 6 dòng trên added_lines, hash và so sánh

### `gates/security.py`

Dùng `ast.parse()` + `re` trên added lines:
- SQL injection: tìm `ast.JoinedStr` (f-string) hoặc `%` format trong argument của DB call
- `eval`/`exec`: tìm `ast.Call` với `func.id in {"eval", "exec"}`
- subprocess shell=True: tìm `ast.keyword(arg="shell", value=Constant(True))`
- pickle/yaml: tìm `ast.Attribute` với `attr in {"loads"}` trên `pickle`/`yaml` module

### `gates/secret_detection.py`

Dùng `re` trên raw added lines (không parse AST — cần detect trong string literals):

```python
SECRET_PATTERNS = [
    (r"glpat-[A-Za-z0-9_-]{20,}", "CRITICAL", "GitLab PAT"),
    (r"ghp_[A-Za-z0-9]{36}", "CRITICAL", "GitHub PAT"),
    (r"sk-[A-Za-z0-9]{32,}", "CRITICAL", "OpenAI API Key"),
    (r"AKIA[0-9A-Z]{16}", "CRITICAL", "AWS Access Key"),
    (r"-----BEGIN (?:RSA |EC )?PRIVATE KEY-----", "CRITICAL", "Private Key"),
    (r"(password|secret|token|api_key|private_key)\s*=\s*['\"][^'\"]{8,}['\"]", "CRITICAL", "Hardcoded credential"),
    (r"[a-zA-Z][a-zA-Z0-9+.-]*://[^:]+:[^@]+@", "CRITICAL", "Credentials in URL"),
]
SKIP_PATHS = {"tests/", ".example", ".sample", ".template", ".env.example"}
```

### `gates/test_coverage.py`

Dùng `ast.parse()` để tìm function/class definitions trong added files:
- Map `app/tasks/foo.py` → `tests/test_foo.py`
- Map `app/api/routes.py` → `tests/test_rde_endpoints.py` (pattern matching)
- Kiểm tra file test tồn tại và chứa test function cho symbol mới

### `test_generator.py`

Dùng `ast.parse()` để extract function signatures từ added lines:

```python
def generate_tests(diff: ParsedDiff) -> str:
    """Sinh pytest skeleton cho tất cả function/method mới trong diff."""
    # Extract new functions từ added_lines
    # Sinh test class + happy path + error case
    # Return as string (không ghi file)
```

Template output:
```python
class Test{FunctionName}:
    def test_{function_name}_happy_path(self):
        # TODO: implement
        result = {function_name}({args})
        assert result is not None

    def test_{function_name}_raises_on_invalid_input(self):
        # TODO: implement
        with pytest.raises(Exception):
            {function_name}({invalid_args})
```

### `gates/regression.py`

```python
def run(diff: ParsedDiff, collection_name: str = "knowledge") -> GateReport:
    changed_files = [f.path for f in diff.files]
    risk_score = _calculate_base_risk(diff)  # từ diff size
    
    try:
        # Tìm modules phụ thuộc vào changed files qua ChromaDB
        dependents = _find_dependents(changed_files, collection_name)
        risk_score = _calculate_full_risk(diff, dependents)
    except Exception:
        pass  # graceful degrade
    
    return GateReport(...)
```

Risk score formula:
```
base = min(len(changed_files) * 5, 30)
+ interface_change_bonus (20 nếu có thay đổi function signature)
+ schema_change_bonus (20 nếu có thay đổi DB model)
+ dependent_modules_bonus (min(len(dependents) * 3, 30))
```

---

## API Contract

### REST Endpoints (`app/api/routes.py`)

#### POST `/qge/analyze`
```
Request:
  diff: str (required) — unified diff text
  collection: str = "knowledge"
  enabled_gates: list[str] | null  — null = all gates
  source_id: str | null            — GitLab source_id để lấy context

Response 200:
  report: QualityGateReport
  trace_id: str

Response 422:
  detail: { overall: "FAIL", critical_count: N, findings: [...] }
```

#### GET `/qge/gates`
```
Response 200:
  gates: list[{ name, description, enabled }]
```

### MCP Tools (`app/mcp_server.py`)

```python
@mcp.tool()
def qge_analyze(diff: str, collection: str = "knowledge") -> dict:
    """Chạy tất cả quality gate trên code diff.
    
    Args:
        diff: Unified diff text (output của git diff)
        collection: ChromaDB collection name
    """

@mcp.tool()
def qge_generate_tests(diff: str) -> dict:
    """Sinh pytest skeleton cho code mới trong diff."""
```

### CLI Commands (`app/cli.py`)

```bash
python -m app.cli qge-analyze "<diff_file_or_stdin>" [--collection knowledge] [--gates code_quality,security]
python -m app.cli qge-generate-tests "<diff_file>"
```

---

## Audit Log (`qge_audit.jsonl`)

```json
{
  "event_type": "qge_analyze",
  "created_at": "...",
  "details": {
    "trace_id": "...",
    "overall": "FAIL",
    "total_critical": 1,
    "total_high": 2,
    "gates_run": ["code_quality", "security", "secret_detection"],
    "duration_ms": 450,
    "diff_lines_added": 120,
    "diff_files_changed": 3
  }
}
```

Không lưu nội dung diff (có thể chứa secret).
