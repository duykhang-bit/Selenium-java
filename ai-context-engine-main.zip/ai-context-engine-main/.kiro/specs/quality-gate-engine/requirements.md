# Tài liệu Yêu cầu: Quality Gate Engine

## Giới thiệu

Quality Gate Engine là Module 3 trong roadmap Intent → Impact Pipeline của AI Context Engine V2. Module này tự động phân tích chất lượng code, bảo mật, và tính đúng đắn của một MR/PR trước khi merge — không cần LLM, không cần external server (SonarQube, Jenkins). Toàn bộ chạy offline bằng Python static analysis.

Module nhận đầu vào là **code diff** (unified diff format) hoặc **danh sách file thay đổi** từ GitLab MR, sau đó chạy các gate song song và trả về `QualityGateReport` tổng hợp.

---

## Bảng chú giải

- **Quality_Gate**: Một kiểm tra tự động trên code diff, trả về PASS/FAIL/WARN với chi tiết
- **Gate_Runner**: Orchestrator chạy tất cả gate song song và tổng hợp kết quả
- **Code_Diff**: Nội dung thay đổi dạng unified diff (output của `git diff`)
- **Gate_Report**: Kết quả của một gate đơn lẻ (passed, severity, findings)
- **QualityGateReport**: Báo cáo tổng hợp tất cả gate, quyết định PASS/FAIL cuối cùng
- **Finding**: Một vấn đề cụ thể được phát hiện (file, line, message, severity)
- **Severity**: Mức độ nghiêm trọng — CRITICAL, HIGH, MEDIUM, LOW, INFO
- **SAST**: Static Application Security Testing — phân tích bảo mật tĩnh trên source code
- **Secret**: Credential, API key, token bị hardcode trong code
- **N+1 Query**: Anti-pattern truy vấn database trong vòng lặp gây performance issue
- **OpenAPI Spec**: Tài liệu mô tả API contract theo chuẩn OpenAPI 3.x

---

## Yêu cầu

### Yêu cầu 1: Gate Runner — Orchestration

**User Story:** Là một AI agent, tôi muốn chạy tất cả quality gate song song trên một code diff, để tôi có thể nhận kết quả tổng hợp nhanh nhất có thể.

#### Acceptance Criteria

1. WHEN code diff được cung cấp, THE Gate_Runner SHALL chạy tất cả gate được enable song song bằng `concurrent.futures.ThreadPoolExecutor` và trả về `QualityGateReport` trong vòng 60 giây
2. THE Gate_Runner SHALL tổng hợp kết quả: nếu bất kỳ gate nào có severity CRITICAL hoặc HIGH fail, overall result là FAIL; chỉ WARN/INFO thì là WARN; tất cả pass thì PASS
3. IF một gate bị exception, THEN THE Gate_Runner SHALL ghi lỗi vào report và tiếp tục chạy các gate còn lại (không abort toàn bộ)
4. THE Gate_Runner SHALL hỗ trợ enable/disable từng gate qua config
5. WHEN report được sinh ra, THE Gate_Runner SHALL ghi audit record vào `data/logs/qge_audit.jsonl`

### Yêu cầu 2: Code Quality Gate

**User Story:** Là một tech lead, tôi muốn AI tự động phát hiện code smell và convention violation trong diff, để tôi có thể đảm bảo code quality trước khi merge.

#### Acceptance Criteria

1. WHEN diff chứa function/method có độ phức tạp cyclomatic > 10, THE Code_Quality_Gate SHALL sinh ra finding với severity HIGH và gợi ý refactor
2. WHEN diff chứa function/method có số dòng > 50, THE Code_Quality_Gate SHALL sinh ra finding với severity MEDIUM
3. WHEN diff chứa đoạn code trùng lặp (≥ 6 dòng giống nhau trong cùng diff), THE Code_Quality_Gate SHALL sinh ra finding với severity MEDIUM
4. WHEN diff thêm file Python mới mà thiếu `from __future__ import annotations`, THE Code_Quality_Gate SHALL sinh ra finding với severity LOW
5. WHEN diff thêm function/method mới mà thiếu docstring, THE Code_Quality_Gate SHALL sinh ra finding với severity LOW
6. WHEN diff chứa `print()` statement (không phải trong test file), THE Code_Quality_Gate SHALL sinh ra finding với severity LOW

### Yêu cầu 3: Security Gate — SAST

**User Story:** Là một security officer, tôi muốn AI tự động phát hiện lỗ hổng bảo mật trong code diff, để tôi có thể ngăn chặn security issue trước khi vào production.

#### Acceptance Criteria

1. WHEN diff chứa SQL query được build bằng string concatenation (f-string hoặc `%` format với user input), THE Security_Gate SHALL sinh ra finding với severity CRITICAL (SQL Injection risk)
2. WHEN diff chứa `eval()`, `exec()`, hoặc `__import__()` với dynamic input, THE Security_Gate SHALL sinh ra finding với severity CRITICAL
3. WHEN diff chứa `subprocess` call với `shell=True`, THE Security_Gate SHALL sinh ra finding với severity HIGH (Command Injection risk)
4. WHEN diff chứa `pickle.loads()` hoặc `yaml.load()` (không phải `yaml.safe_load()`), THE Security_Gate SHALL sinh ra finding với severity HIGH (Deserialization risk)
5. WHEN diff chứa hardcoded IP address (không phải `0.0.0.0`, `127.0.0.1`, `localhost`), THE Security_Gate SHALL sinh ra finding với severity MEDIUM
6. WHEN diff chứa `verify=False` trong requests call, THE Security_Gate SHALL sinh ra finding với severity HIGH (SSL verification disabled)
7. WHEN diff chứa `DEBUG = True` hoặc `debug=True` trong non-test context, THE Security_Gate SHALL sinh ra finding với severity MEDIUM

### Yêu cầu 4: Secret Detection Gate

**User Story:** Là một security officer, tôi muốn AI tự động phát hiện secret bị hardcode trong code diff, để tôi có thể ngăn chặn credential leak trước khi push lên remote.

#### Acceptance Criteria

1. WHEN diff chứa string khớp pattern API key (ví dụ: `sk-`, `glpat-`, `ghp_`, `AKIA`), THE Secret_Gate SHALL sinh ra finding với severity CRITICAL
2. WHEN diff chứa assignment với tên biến chứa `password`, `secret`, `token`, `api_key`, `private_key` và giá trị là string literal (không phải empty string, env var, hoặc placeholder), THE Secret_Gate SHALL sinh ra finding với severity CRITICAL
3. WHEN diff chứa private key PEM block (`-----BEGIN ... PRIVATE KEY-----`), THE Secret_Gate SHALL sinh ra finding với severity CRITICAL
4. WHEN diff chứa connection string với credentials embedded (ví dụ: `postgresql://user:password@host`), THE Secret_Gate SHALL sinh ra finding với severity CRITICAL
5. THE Secret_Gate SHALL bỏ qua các file trong `tests/`, `*.example`, `*.sample`, `*.template` để tránh false positive

### Yêu cầu 5: Dependency Vulnerability Gate

**User Story:** Là một security officer, tôi muốn AI kiểm tra dependency mới được thêm vào có CVE đã biết không, để tôi có thể ngăn chặn supply chain attack.

#### Acceptance Criteria

1. WHEN diff thêm hoặc thay đổi `requirements.txt`, `pyproject.toml`, hoặc `package.json`, THE Dependency_Gate SHALL phân tích các package mới/thay đổi
2. THE Dependency_Gate SHALL kiểm tra package version có trong danh sách known vulnerable versions (offline lookup từ bundled advisory database)
3. WHEN package có CVE với severity CRITICAL hoặc HIGH, THE Dependency_Gate SHALL sinh ra finding với severity tương ứng và link đến advisory
4. IF không có mạng hoặc advisory database không khả dụng, THEN THE Dependency_Gate SHALL sinh ra finding với severity INFO và ghi chú "manual review required"

### Yêu cầu 6: Test Coverage Gate

**User Story:** Là một tech lead, tôi muốn AI kiểm tra code mới có test tương ứng không, để tôi có thể đảm bảo coverage không giảm sau mỗi MR.

#### Acceptance Criteria

1. WHEN diff thêm function/method/class mới trong `app/`, THE Test_Coverage_Gate SHALL kiểm tra xem có file test tương ứng trong `tests/` không
2. IF function/method mới không có test tương ứng, THEN THE Test_Coverage_Gate SHALL sinh ra finding với severity MEDIUM
3. WHEN diff thêm API endpoint mới (route decorator), THE Test_Coverage_Gate SHALL kiểm tra xem có integration test cho endpoint đó không; IF không có, sinh ra finding với severity HIGH
4. THE Test_Coverage_Gate SHALL bỏ qua các file `__init__.py`, config files, và migration files

### Yêu cầu 7: Test Generator

**User Story:** Là một developer, tôi muốn AI tự động sinh ra unit test skeleton cho code mới trong diff, để tôi có thể tiết kiệm thời gian viết boilerplate test.

#### Acceptance Criteria

1. WHEN diff thêm function/method mới, THE Test_Generator SHALL sinh ra pytest test skeleton với: test class, test method cho happy path, test method cho error case
2. THE Test_Generator SHALL phân tích function signature để sinh ra mock fixtures phù hợp
3. WHEN function có type hints, THE Test_Generator SHALL sử dụng type hints để sinh ra test data hợp lệ
4. THE Test_Generator SHALL sinh ra test file path theo convention: `tests/test_{module_name}.py`
5. THE Test_Generator SHALL không ghi file trực tiếp — chỉ trả về generated test code dạng string trong report

### Yêu cầu 8: Performance Gate

**User Story:** Là một tech lead, tôi muốn AI phát hiện performance anti-pattern trong code diff, để tôi có thể ngăn chặn performance regression trước khi merge.

#### Acceptance Criteria

1. WHEN diff chứa database query call bên trong vòng lặp `for`/`while`, THE Performance_Gate SHALL sinh ra finding với severity HIGH (N+1 query pattern)
2. WHEN diff chứa `time.sleep()` trong non-test, non-retry context, THE Performance_Gate SHALL sinh ra finding với severity MEDIUM
3. WHEN diff thêm list comprehension hoặc loop xử lý collection mà không có pagination/limit, THE Performance_Gate SHALL sinh ra finding với severity LOW
4. WHEN diff chứa `SELECT *` trong SQL query string, THE Performance_Gate SHALL sinh ra finding với severity MEDIUM

### Yêu cầu 9: API Contract Validation Gate

**User Story:** Là một tech lead, tôi muốn AI kiểm tra code thay đổi có vi phạm OpenAPI contract không, để tôi có thể đảm bảo backward compatibility.

#### Acceptance Criteria

1. WHEN diff thay đổi API route handler và có file OpenAPI spec trong repo, THE API_Contract_Gate SHALL so sánh signature của handler với spec
2. IF handler thêm required parameter mới mà không có trong spec, THE API_Contract_Gate SHALL sinh ra finding với severity HIGH (breaking change)
3. IF handler xóa parameter có trong spec, THE API_Contract_Gate SHALL sinh ra finding với severity HIGH (breaking change)
4. IF không tìm thấy OpenAPI spec, THE API_Contract_Gate SHALL sinh ra finding với severity INFO và skip validation

### Yêu cầu 10: Regression Analyzer

**User Story:** Là một tech lead, tôi muốn AI phân tích risk score của MR dựa trên dependency graph, để tôi có thể ưu tiên review những MR có risk cao.

#### Acceptance Criteria

1. WHEN diff được cung cấp, THE Regression_Analyzer SHALL xây dựng dependency graph từ ChromaDB context để xác định các module phụ thuộc vào code bị thay đổi
2. THE Regression_Analyzer SHALL tính risk score từ 0-100 dựa trên: số file thay đổi, số module phụ thuộc, có thay đổi interface không, có thay đổi database schema không
3. WHEN risk score ≥ 70, THE Regression_Analyzer SHALL sinh ra finding với severity HIGH và liệt kê các module cần regression test
4. THE Regression_Analyzer SHALL graceful degrade khi ChromaDB không khả dụng — trả về risk score dựa trên diff size only

---

## Correctness Properties

### Invariant: Gate Independence
Mỗi gate phải hoạt động độc lập — failure của một gate không được ảnh hưởng đến kết quả của gate khác.

`∀ gate_i, gate_j : exception(gate_i) → result(gate_j) = result(gate_j)`

### Invariant: Severity Aggregation
Overall result phải là FAIL nếu có ít nhất một finding CRITICAL hoặc HIGH fail; WARN nếu chỉ có MEDIUM/LOW; PASS nếu không có finding nào.

`overall = FAIL ↔ ∃ f ∈ findings : f.severity ∈ {CRITICAL, HIGH}`

### Invariant: No False Negatives on Secrets
Secret detection phải không bao giờ bỏ qua hardcoded credential rõ ràng (string literal assignment với tên biến nhạy cảm).

### Error Condition: Empty Diff
Khi diff rỗng hoặc chỉ chứa whitespace changes, tất cả gate phải trả về PASS với 0 findings — không được sinh ra false positive.
