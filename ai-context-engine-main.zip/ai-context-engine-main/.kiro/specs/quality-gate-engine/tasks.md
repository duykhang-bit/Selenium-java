# Kế hoạch Triển khai: Quality Gate Engine

## Tổng quan

Triển khai Module 3 — Quality Gate Engine. Các bước xây dựng tuần tự từ data models → diff parser → từng gate → gate runner → wiring API + CLI + MCP.

Pattern nhất quán với Module 2: pure Python, no LLM, stateless functions, graceful degradation.

## Tasks

- [x] 1. Tạo `app/tasks/quality_gate/` package với data models
  - Tạo `app/tasks/quality_gate/__init__.py`
  - Tạo `app/tasks/quality_gate/models.py` với dataclasses: `Finding`, `GateReport`, `QualityGateReport`, `DiffFile`, `ParsedDiff`
  - `Finding`: gate, severity, file, line, message, rule_id, suggestion
  - `GateReport`: gate, passed, findings, duration_ms, error
  - `QualityGateReport`: overall (PASS/WARN/FAIL), gate_reports, all_findings, totals, generated_test_code, risk_score, analyzed_at, trace_id
  - Tạo `app/tasks/quality_gate/gates/__init__.py`
  - _Yêu cầu: 1.1, 1.2_

  - [ ] 1.1 Viết unit test cho models
    - Test `QualityGateReport.overall` logic: FAIL nếu có CRITICAL/HIGH, WARN nếu chỉ MEDIUM/LOW, PASS nếu không có finding
    - Test `GateReport.passed` = False khi có CRITICAL/HIGH finding
    - _Validates: Invariant "Severity Aggregation"_

- [ ] 2. Tạo `app/tasks/quality_gate/diff_parser.py`
  - Implement `parse_diff(diff_text: str) -> ParsedDiff`
  - Parse unified diff format: file headers, hunk headers, added/removed lines
  - Detect change_type: "added" (old = /dev/null), "deleted" (new = /dev/null), "modified"
  - Extract `full_new_content` cho file mới hoàn toàn (ghép tất cả added lines)
  - Xử lý edge cases: empty diff, binary files, rename
  - _Yêu cầu: 1.1_

  - [ ] 2.1 Viết unit test cho diff_parser
    - Test parse file mới (added)
    - Test parse file modified
    - Test parse file deleted
    - Test parse empty diff → ParsedDiff với files=[]
    - Test parse diff với nhiều files
    - Test extract line numbers chính xác
    - _Validates: Error Condition "Empty Diff"_

- [ ] 3. Checkpoint — Đảm bảo models và diff_parser pass test
  - Chạy `pytest tests/test_qge_models.py tests/test_qge_diff_parser.py -v`

- [ ] 4. Tạo `app/tasks/quality_gate/gates/code_quality.py`
  - Implement `run(diff: ParsedDiff) -> GateReport`
  - Cyclomatic complexity: dùng `ast.parse()` đếm branching nodes (if/elif/for/while/except/and/or/with) — threshold > 10 → HIGH
  - Function length: `FunctionDef.end_lineno - FunctionDef.lineno` > 50 → MEDIUM
  - Duplication: sliding window 6 dòng trên added_lines, hash so sánh → MEDIUM
  - Missing `from __future__ import annotations` trong file Python mới → LOW
  - Missing docstring cho function/method mới → LOW
  - `print()` statement trong non-test file → LOW
  - Rule IDs: CQ-001 đến CQ-006
  - _Yêu cầu: 2.1–2.6_

  - [ ] 4.1 Viết unit test cho code_quality gate
    - Test cyclomatic complexity > 10 → HIGH finding
    - Test function length > 50 → MEDIUM finding
    - Test duplication detection
    - Test missing `__future__` import
    - Test print() detection
    - Test empty diff → 0 findings
    - Test non-Python file → skip gracefully

- [ ] 5. Tạo `app/tasks/quality_gate/gates/security.py`
  - Implement `run(diff: ParsedDiff) -> GateReport`
  - SQL injection: tìm f-string/format trong DB call context → CRITICAL (SEC-001)
  - `eval()`/`exec()` với dynamic input → CRITICAL (SEC-002)
  - `subprocess` với `shell=True` → HIGH (SEC-003)
  - `pickle.loads()` / `yaml.load()` (không phải safe_load) → HIGH (SEC-004)
  - Hardcoded IP (không phải localhost/0.0.0.0) → MEDIUM (SEC-005)
  - `verify=False` trong requests → HIGH (SEC-006)
  - `DEBUG = True` trong non-test → MEDIUM (SEC-007)
  - Dùng `ast.parse()` cho Python files, `re` cho non-Python
  - _Yêu cầu: 3.1–3.7_

  - [ ] 5.1 Viết unit test cho security gate
    - Test mỗi rule với code snippet có/không có vi phạm
    - Test SQL injection detection
    - Test eval/exec detection
    - Test subprocess shell=True
    - Test pickle.loads detection
    - Test verify=False detection
    - Test empty diff → 0 findings

- [ ] 6. Tạo `app/tasks/quality_gate/gates/secret_detection.py`
  - Implement `run(diff: ParsedDiff) -> GateReport`
  - Regex patterns cho: GitLab PAT (`glpat-`), GitHub PAT (`ghp_`), OpenAI key (`sk-`), AWS key (`AKIA`), PEM private key, hardcoded credential assignment, credentials in URL
  - Skip paths: `tests/`, `.example`, `.sample`, `.template`, `.env.example`
  - Rule IDs: SD-001 đến SD-007, tất cả CRITICAL
  - _Yêu cầu: 4.1–4.5_

  - [ ] 6.1 Viết unit test cho secret_detection gate
    - Test detect GitLab PAT
    - Test detect hardcoded password assignment
    - Test detect PEM private key
    - Test detect credentials in URL
    - Test skip test files (no false positive)
    - Test skip .env.example (no false positive)
    - Test empty diff → 0 findings
    - _Validates: Invariant "No False Negatives on Secrets"_

- [ ] 7. Checkpoint — Đảm bảo code_quality, security, secret_detection pass test
  - Chạy `pytest tests/test_qge_code_quality.py tests/test_qge_security.py tests/test_qge_secret_detection.py -v`

- [ ] 8. Tạo `app/tasks/quality_gate/gates/dependency.py`
  - Implement `run(diff: ParsedDiff) -> GateReport`
  - Detect thay đổi trong `requirements.txt`, `pyproject.toml`, `package.json`
  - Parse package name + version từ diff
  - Lookup offline advisory database (bundled JSON file với known CVEs)
  - Graceful degrade khi không có advisory data → INFO finding
  - Rule IDs: DEP-001 đến DEP-004
  - _Yêu cầu: 5.1–5.4_

  - [ ] 8.1 Viết unit test cho dependency gate
    - Test detect thay đổi requirements.txt
    - Test lookup known vulnerable package → HIGH finding
    - Test unknown package → no finding
    - Test graceful degrade khi không có advisory DB

- [ ] 9. Tạo `app/tasks/quality_gate/gates/test_coverage.py`
  - Implement `run(diff: ParsedDiff) -> GateReport`
  - Map `app/tasks/foo.py` → `tests/test_foo.py`
  - Dùng `ast.parse()` tìm function/class mới trong added files
  - Kiểm tra file test tồn tại (check path, không đọc nội dung)
  - Detect route decorator (`@router.get`, `@router.post`, etc.) → HIGH nếu thiếu test
  - Skip `__init__.py`, config files
  - Rule IDs: TC-001 đến TC-003
  - _Yêu cầu: 6.1–6.4_

  - [ ] 9.1 Viết unit test cho test_coverage gate
    - Test detect missing test file cho module mới
    - Test detect missing test cho new API endpoint
    - Test skip __init__.py
    - Test existing test file → no finding

- [ ] 10. Tạo `app/tasks/quality_gate/gates/performance.py`
  - Implement `run(diff: ParsedDiff) -> GateReport`
  - N+1 query: tìm DB call (`.query(`, `.execute(`, `.filter(`, `.get(`) bên trong `for`/`while` loop trong AST → HIGH (PERF-001)
  - `time.sleep()` trong non-test, non-retry context → MEDIUM (PERF-002)
  - `SELECT *` trong SQL string → MEDIUM (PERF-003)
  - List comprehension không có limit trên large collection → LOW (PERF-004)
  - _Yêu cầu: 8.1–8.4_

  - [ ] 10.1 Viết unit test cho performance gate
    - Test N+1 query detection
    - Test time.sleep detection
    - Test SELECT * detection
    - Test empty diff → 0 findings

- [ ] 11. Tạo `app/tasks/quality_gate/gates/api_contract.py`
  - Implement `run(diff: ParsedDiff, spec_path: str | None = None) -> GateReport`
  - Detect thay đổi route handler trong diff
  - Load OpenAPI spec từ `spec_path` hoặc tìm `openapi.yaml`/`openapi.json` trong repo root
  - So sánh function signature với spec: required params, response codes
  - IF không tìm thấy spec → INFO finding, skip
  - Rule IDs: AC-001 đến AC-003
  - _Yêu cầu: 9.1–9.4_

  - [ ] 11.1 Viết unit test cho api_contract gate
    - Test detect breaking change (new required param)
    - Test detect removed param
    - Test no spec found → INFO finding only
    - Test no route change → 0 findings

- [ ] 12. Tạo `app/tasks/quality_gate/gates/regression.py`
  - Implement `run(diff: ParsedDiff, collection_name: str = "knowledge") -> GateReport`
  - Tính base risk score từ diff size (số file, số dòng thay đổi)
  - Bonus: interface change (+20), schema change (+20), dependent modules (+3 mỗi module, max 30)
  - ChromaDB search để tìm dependent modules (graceful degrade nếu không có)
  - Risk score ≥ 70 → HIGH finding với danh sách modules cần regression test
  - Rule IDs: REG-001 đến REG-002
  - _Yêu cầu: 10.1–10.4_

  - [ ] 12.1 Viết unit test cho regression gate
    - Test risk score calculation với mock ChromaDB
    - Test graceful degrade khi ChromaDB không khả dụng
    - Test risk ≥ 70 → HIGH finding
    - Test risk < 70 → no HIGH finding

- [ ] 13. Tạo `app/tasks/quality_gate/test_generator.py`
  - Implement `generate_tests(diff: ParsedDiff) -> str`
  - Dùng `ast.parse()` extract function/method definitions mới từ added lines
  - Sinh pytest skeleton: test class, happy path, error case
  - Phân tích type hints để sinh test data gợi ý
  - Trả về string (không ghi file)
  - _Yêu cầu: 7.1–7.5_

  - [ ] 13.1 Viết unit test cho test_generator
    - Test sinh test skeleton cho function đơn giản
    - Test sinh test skeleton cho function có type hints
    - Test sinh test skeleton cho class method
    - Test empty diff → empty string

- [ ] 14. Checkpoint — Đảm bảo tất cả gate tests pass
  - Chạy `pytest tests/test_qge_*.py -v`

- [ ] 15. Tạo `app/tasks/quality_gate/gate_runner.py`
  - Implement `run_all_gates(diff_text, collection_name, enabled_gates, trace_id) -> QualityGateReport`
  - Parse diff bằng `diff_parser.parse_diff()`
  - Chạy tất cả gate song song bằng `ThreadPoolExecutor`
  - Aggregate results: tính overall PASS/WARN/FAIL, tổng hợp all_findings
  - Ghi audit record vào `data/logs/qge_audit.jsonl` (không lưu diff content)
  - _Yêu cầu: 1.1–1.5_

  - [ ] 15.1 Viết unit test cho gate_runner
    - Test parallel execution (tất cả gate được gọi)
    - Test aggregate FAIL khi có CRITICAL finding
    - Test aggregate WARN khi chỉ có MEDIUM finding
    - Test aggregate PASS khi không có finding
    - Test gate exception không abort các gate khác
    - Test audit record được ghi
    - _Validates: Invariant "Gate Independence", Invariant "Severity Aggregation"_

- [ ] 16. Thêm Pydantic schemas vào `app/api/schemas.py`
  - `QGEAnalyzeRequest`: diff, collection, enabled_gates, source_id
  - `QGEAnalyzeResponse`: report (QualityGateReport), trace_id
  - _Yêu cầu: 1.1_

- [ ] 17. Thêm QGE endpoints vào `app/api/routes.py`
  - `POST /qge/analyze` — gọi `run_all_gates`, trả về report; HTTP 422 nếu overall = FAIL
  - `GET /qge/gates` — trả về danh sách gate và trạng thái enable
  - Dùng `asyncio.to_thread()` để non-blocking
  - _Yêu cầu: 1.1_

  - [ ] 17.1 Viết integration test cho QGE endpoints
    - Test `POST /qge/analyze` với diff hợp lệ
    - Test HTTP 422 khi overall = FAIL
    - Test `GET /qge/gates`

- [ ] 18. Thêm QGE MCP tools vào `app/mcp_server.py`
  - `qge_analyze(diff, collection)` — chạy tất cả gate
  - `qge_generate_tests(diff)` — sinh test skeleton
  - _Yêu cầu: 1.1_

- [ ] 19. Thêm QGE CLI commands vào `app/cli.py`
  - `qge-analyze <diff_file>` với options `--collection`, `--gates`
  - `qge-generate-tests <diff_file>`
  - _Yêu cầu: 1.1_

- [ ] 20. Checkpoint cuối — Toàn bộ hệ thống hoạt động đúng
  - Chạy `pytest tests/ -v --tb=short` (bỏ qua test cần model download)
  - Kiểm tra import: `python -c "from app.tasks.quality_gate import gate_runner; print('OK')"`
  - Đảm bảo tất cả test pass
