# Kế hoạch Triển khai: K8s & Deployment Intelligence

## Tasks

- [x] 1. Thêm K8s config vào `app/core/config.py`
  - Thêm `k8s_ci_health_url`, `k8s_uat_health_url`, `k8s_prod_soak_minutes`
  - _Yêu cầu: 2.5, 3.5, 4.1_

- [x] 2. Tạo `app/tasks/k8s/` package với models
  - `app/tasks/k8s/__init__.py`
  - `app/tasks/k8s/models.py`: `HelmValues`, `ChecklistItem`, `GateResult`, `PromotionResult`, `CorrelationResult`
  - _Yêu cầu: 1.6, 2.3, 4.2, 5.3_

  - [x] 2.1 Viết unit test cho models
    - Test dataclass fields và defaults
    - Test `GateResult.approved = False` khi có blocking_items

- [x] 3. Tạo `app/tasks/k8s/helm_generator.py`
  - Implement `generate_helm_values(...) -> HelmValues`
  - Sinh YAML với: image, replicas, resources, probes, ingress (optional), env_vars (optional), HPA (optional)
  - Validate YAML output bằng `yaml.safe_load()`
  - _Yêu cầu: 1.1–1.6_

  - [x] 3.1 Viết unit test cho helm_generator
    - Test output YAML hợp lệ (parse được)
    - Test ingress được thêm khi có `ingress_host`
    - Test HPA được thêm khi `hpa_enabled=True`
    - Test env_vars được inject đúng
    - Test không có ingress/HPA khi không cấu hình

- [x] 4. Checkpoint — models và helm_generator pass test
  - Chạy `pytest tests/test_k8s_models.py tests/test_k8s_helm_generator.py -v`

- [ ] 5. Tạo `app/tasks/k8s/ci_promoter.py`
  - Implement `promote_to_ci(service, build_number, jenkins_deploy_job, ci_health_url, trace_id) -> PromotionResult`
  - Kiểm tra: Jenkins build SUCCESS
  - Trigger Jenkins job, lưu DeploymentRecord(environment="ci")
  - HTTP health check nếu có `ci_health_url`
  - Ghi audit record vào `data/logs/k8s_audit.jsonl`
  - _Yêu cầu: 2.1–2.5_

  - [ ] 5.1 Viết unit test cho ci_promoter
    - Test approved khi build SUCCESS
    - Test blocked khi build FAILURE
    - Test DeploymentRecord được lưu với environment="ci"
    - Test audit record được ghi
    - Test health check cập nhật status

- [ ] 6. Tạo `app/tasks/k8s/uat_promoter.py`
  - Implement `promote_to_uat(service, build_number, jenkins_deploy_job, uat_health_url, trace_id) -> PromotionResult`
  - Kiểm tra: CI deployment success, không có CRITICAL finding, không có UAT duplicate
  - Trigger Jenkins job, lưu DeploymentRecord(environment="uat")
  - HTTP health check nếu có `uat_health_url`
  - Ghi audit record
  - _Yêu cầu: 3.1–3.5_

  - [ ] 6.1 Viết unit test cho uat_promoter
    - Test approved khi CI success và không có duplicate
    - Test blocked khi không có CI deployment success
    - Test blocked khi đã có UAT deployment với cùng build_number
    - Test audit record được ghi

- [ ] 7. Tạo `app/tasks/k8s/prod_gate.py`
  - Implement `check_prod_gate(service, build_number, jenkins_deploy_job, soak_minutes) -> GateResult`
  - 5 checklist items: UAT exists, UAT success, soak time, no CRITICAL findings, no running PROD deploy
  - Sinh `suggested_command` nếu approved
  - Ghi audit record
  - _Yêu cầu: 4.1–4.5_

  - [ ] 7.1 Viết unit test cho prod_gate
    - Test approved khi tất cả checklist PASS
    - Test blocked khi không có UAT deployment
    - Test blocked khi UAT status != "success"
    - Test WARN khi soak time chưa đủ
    - Test `suggested_command` được sinh khi approved

- [ ] 8. Tạo `app/tasks/k8s/incident_correlator.py`
  - Implement `correlate_incident(service, incident_time, collection_name) -> CorrelationResult`
  - Query deployment history (ci + uat + prod), tính time_delta, determine likely_cause và suggested_action
  - ChromaDB search để lấy context_snippets
  - _Yêu cầu: 5.1–5.5_

  - [ ] 8.1 Viết unit test cho incident_correlator
    - Test `likely_cause=True` khi deployment trong vòng 30 phút
    - Test `likely_cause=False` khi không có deployment trong 24h
    - Test `suggested_action="rollback"` khi likely_cause=True
    - Test graceful degrade khi ChromaDB không khả dụng

- [ ] 9. Checkpoint — ci_promoter, uat_promoter, prod_gate, incident_correlator pass test
  - Chạy `pytest tests/test_k8s_*.py -v`

- [ ] 10. Thêm K8s schemas vào `app/api/schemas.py`
  - `K8sHelmValuesRequest`, `K8sPromoteCIRequest`, `K8sPromoteUATRequest`, `K8sProdGateRequest`, `K8sCorrelateRequest`

- [ ] 11. Thêm K8s endpoints vào `app/api/routes.py`
  - `POST /k8s/helm-values`
  - `POST /k8s/promote-ci`
  - `POST /k8s/promote-uat`
  - `POST /k8s/prod-gate`
  - `POST /k8s/correlate-incident`

  - [ ] 11.1 Viết integration test cho K8s endpoints
    - Test `POST /k8s/helm-values` trả về YAML hợp lệ
    - Test `POST /k8s/prod-gate` trả về checklist
    - Test `POST /k8s/correlate-incident` với mock deployment history

- [ ] 12. Thêm K8s MCP tools vào `app/mcp_server.py`
  - `k8s_generate_helm_values`, `k8s_promote_to_ci`, `k8s_promote_to_uat`, `k8s_check_prod_gate`, `k8s_correlate_incident`

- [ ] 13. Thêm K8s CLI commands vào `app/cli.py`
  - `k8s-helm-values`, `k8s-promote-ci`, `k8s-promote-uat`, `k8s-prod-gate`, `k8s-correlate`

- [ ] 14. Checkpoint cuối
  - Chạy `pytest tests/ --ignore=tests/test_brief_enhanced.py --ignore=tests/test_mcp_integration.py --tb=short`
  - Kiểm tra import: `python -c "from app.tasks.k8s import helm_generator, ci_promoter, uat_promoter, prod_gate, incident_correlator; print('OK')"`
