# Tài liệu Yêu cầu: K8s & Deployment Intelligence

## Giới thiệu

K8s & Deployment Intelligence là Module 6 trong roadmap Intent → Impact Pipeline. Module này tích hợp với Jenkins CI/CD pipeline hiện có (Helm-based deploy, manual trigger) để:

1. Sinh Helm `values.yaml` từ service metadata
2. Kiểm tra điều kiện và trigger Jenkins deploy-ci sau khi code được merge và build pass
3. Kiểm tra CI pass và trigger Jenkins deploy-uat
4. Cung cấp PROD promotion checklist để người dùng quyết định trigger Jenkins deploy-prod
5. Correlate incident/alert với deployment gần nhất để tìm root cause nhanh

**Flow deploy**: CI → UAT → PROD (mỗi bước đều có gate kiểm tra trước khi promote)

**Nguyên tắc**: Context Engine là "bộ não" cung cấp thông tin và kiểm tra điều kiện — Jenkins vẫn là nơi thực thi deploy. PROD deploy luôn cần human trigger.

---

## Bảng chú giải

- **Helm_Values**: File `values.yaml` dùng cho Helm chart deploy
- **Manifest_Generator**: Sinh Helm values.yaml từ service metadata
- **CI_Promoter**: Kiểm tra build pass → trigger Jenkins job deploy-ci
- **UAT_Promoter**: Kiểm tra CI deployment success → trigger Jenkins job deploy-uat
- **PROD_Gate**: Sinh checklist tự động để người dùng quyết định trigger Jenkins deploy-prod
- **Incident_Correlator**: Correlate alert với deployment history để tìm root cause
- **PromotionResult**: Kết quả kiểm tra điều kiện promote (approved, blocking_reasons)
- **GateResult**: Kết quả PROD gate checklist (approved, checklist items, blocking_items)
- **CorrelationResult**: Kết quả correlate incident với deployment

---

## Yêu cầu

### Yêu cầu 1: Helm Values Generator

**User Story:** Là một DevOps engineer, tôi muốn AI tự động sinh Helm `values.yaml` từ service metadata, để tôi có thể tiết kiệm thời gian viết YAML boilerplate và đảm bảo nhất quán giữa các service.

#### Acceptance Criteria

1. WHEN service name, image, tag, và port được cung cấp, THE Manifest_Generator SHALL sinh ra `values.yaml` với: image repository/tag, replicas, resource requests/limits, service port, liveness/readiness probe path
2. IF `ingress_host` được cung cấp, THEN THE Manifest_Generator SHALL thêm ingress config vào values.yaml với host và TLS settings
3. IF `env_vars` dict được cung cấp, THEN THE Manifest_Generator SHALL thêm environment variables vào values.yaml
4. IF `hpa_enabled=True`, THEN THE Manifest_Generator SHALL thêm HPA config với min/max replicas và CPU threshold
5. THE Manifest_Generator SHALL validate YAML output — không được sinh ra YAML không hợp lệ
6. THE Manifest_Generator SHALL trả về `HelmValues` dataclass với: `filename` ("values.yaml"), `content` (YAML string), `service_name`, `environment`

### Yêu cầu 2: CI Promotion

**User Story:** Là một AI agent, tôi muốn tự động trigger Jenkins deploy-ci sau khi build pass, để tôi có thể kiểm tra code trên môi trường CI trước khi lên UAT.

#### Acceptance Criteria

1. WHEN `promote_to_ci(service, build_number, jenkins_deploy_job)` được gọi, THE CI_Promoter SHALL kiểm tra: build Jenkins tương ứng có status SUCCESS
2. IF điều kiện pass, THEN THE CI_Promoter SHALL trigger Jenkins job deploy-ci và ghi `DeploymentRecord` với environment="ci", status="running"
3. IF điều kiện fail, THEN THE CI_Promoter SHALL trả về `PromotionResult` với `approved=False` và `blocking_reasons`
4. THE CI_Promoter SHALL ghi audit record vào `data/logs/k8s_audit.jsonl`
5. WHEN CI promotion thành công, IF `ci_health_url` được cung cấp, THEN THE system SHALL thực hiện HTTP health check và cập nhật DeploymentRecord status thành "success" hoặc "failure"

### Yêu cầu 3: UAT Promotion

**User Story:** Là một AI agent, tôi muốn tự động kiểm tra CI deployment success và trigger Jenkins deploy-uat, để tôi có thể đảm bảo chỉ code đã được verify trên CI mới lên UAT.

#### Acceptance Criteria

1. WHEN `promote_to_uat(service, build_number, jenkins_deploy_job)` được gọi, THE UAT_Promoter SHALL kiểm tra các điều kiện sau:
   - CI deployment tồn tại và status="success" cho build_number này
   - Không có CRITICAL finding từ quality gate (nếu có record trong catalog)
   - Chưa có UAT deployment thành công cho cùng build_number (tránh duplicate)
2. IF tất cả điều kiện pass, THEN THE UAT_Promoter SHALL trigger Jenkins job deploy-uat và ghi `DeploymentRecord` với environment="uat", status="running"
3. IF bất kỳ điều kiện nào fail, THEN THE UAT_Promoter SHALL trả về `PromotionResult` với `approved=False` và `blocking_reasons` mô tả rõ lý do
4. THE UAT_Promoter SHALL ghi audit record vào `data/logs/k8s_audit.jsonl`
5. WHEN UAT promotion thành công, IF `uat_health_url` được cung cấp, THEN THE system SHALL thực hiện HTTP health check và cập nhật DeploymentRecord status thành "success" hoặc "failure"

### Yêu cầu 4: PROD Promotion Gate

**User Story:** Là một release manager, tôi muốn AI tự động sinh checklist trước khi lên PROD, để tôi có thể review nhanh và quyết định có trigger Jenkins deploy-prod không.

#### Acceptance Criteria

1. WHEN `check_prod_gate(service, build_number)` được gọi, THE PROD_Gate SHALL kiểm tra và trả về checklist gồm các item:
   - UAT deployment tồn tại và status="success" cho build_number này
   - Không có CRITICAL/HIGH security finding trong quality gate record
   - UAT deployment đã chạy ít nhất N phút (soak time, default 30 phút)
   - Không có PROD deployment đang chạy (status="running")
2. THE PROD_Gate SHALL trả về `GateResult` với: `approved` (bool — True nếu tất cả PASS), `checklist` (list `ChecklistItem` với status PASS/FAIL/WARN và message), `blocking_items` (list item FAIL)
3. THE PROD_Gate SHALL KHÔNG tự động trigger Jenkins deploy-prod — chỉ trả về checklist để người dùng quyết định
4. WHEN gate được check, THE system SHALL ghi audit record với đầy đủ checklist result
5. IF `approved=True`, THE PROD_Gate SHALL trả về `suggested_command` là lệnh CLI để trigger Jenkins deploy-prod

### Yêu cầu 5: Incident Correlator

**User Story:** Là một on-call engineer, tôi muốn AI tự động correlate alert với deployment gần nhất, để tôi có thể nhanh chóng xác định nguyên nhân incident và quyết định có rollback không.

#### Acceptance Criteria

1. WHEN `correlate_incident(service, incident_time)` được gọi, THE Incident_Correlator SHALL tìm deployment gần nhất của service trước `incident_time` trong catalog (tất cả environments: ci, uat, prod)
2. THE Incident_Correlator SHALL tính `time_delta_minutes` giữa deployment và incident — nếu ≤ 30 phút thì `likely_cause=True`
3. THE Incident_Correlator SHALL trả về `CorrelationResult` với: deployment record, time_delta_minutes, likely_cause, suggested_action ("rollback" nếu likely_cause=True và env=prod/uat, "investigate_infra" nếu không có deployment gần, "investigate_app" nếu có deployment nhưng > 30 phút)
4. IF không tìm thấy deployment nào trong 24h trước incident, THEN `likely_cause=False` và `suggested_action="investigate_infra"`
5. THE Incident_Correlator SHALL search ChromaDB để tìm thêm context về service (recent changes, known issues)

---

## Correctness Properties

### Invariant: Human-in-the-loop for PROD
PROD deployment KHÔNG BAO GIỜ được tự động trigger bởi Context Engine — luôn phải có human action.

### Invariant: CI before UAT before PROD
- `promote_to_uat` phải fail nếu chưa có CI deployment thành công cho cùng build_number
- `check_prod_gate` phải fail nếu chưa có UAT deployment thành công cho cùng build_number

### Error Condition: Promote with Failing Gate
Nếu build Jenkins FAILURE hoặc có CRITICAL finding, promotion phải bị block với lý do rõ ràng.
