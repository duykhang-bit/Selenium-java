# Tài liệu Thiết kế: K8s & Deployment Intelligence

## Tổng quan

Module 6 tích hợp với Jenkins Helm-based pipeline hiện có. Context Engine đóng vai trò kiểm tra điều kiện và cung cấp thông tin — Jenkins vẫn là nơi thực thi deploy.

### Vị trí trong hệ thống

```
Quality Gate (Module 3) + Jenkins Build (Module 4)
                │
                ▼
┌──────────────────────────────────────────────────┐
│         K8s & Deployment Intelligence             │
│                                                   │
│  Helm_Values_Generator                            │
│       │                                           │
│  CI_Promoter ──→ Jenkins trigger deploy-ci        │
│       │                                           │
│  UAT_Promoter ──→ Jenkins trigger deploy-uat      │
│       │                                           │
│  PROD_Gate ──→ Checklist report (human decides)   │
│       │                                           │
│  Incident_Correlator ──→ CorrelationResult        │
└──────────────────────────────────────────────────┘
        │
        ▼
  k8s_audit.jsonl + DeploymentRecord (catalog)
```

---

## Kiến trúc

### Nguyên tắc

- **Pure Python, no kubectl**: không cần kubectl hay K8s API — chỉ sinh YAML và gọi Jenkins
- **Jenkins connector tái dụng**: dùng `JenkinsConnector` từ Module 4 để trigger job
- **Deployment catalog tái dụng**: dùng `DeploymentRecord` và `save_deployment_record` từ Module 4
- **Stateless functions**: mỗi component là pure function

### Module structure

```
app/tasks/k8s/
├── __init__.py
├── models.py               # HelmValues, PromotionResult, GateResult, ChecklistItem, CorrelationResult
├── helm_generator.py       # Sinh Helm values.yaml
├── ci_promoter.py          # Kiểm tra build pass → trigger Jenkins deploy-ci
├── uat_promoter.py         # Kiểm tra CI success → trigger Jenkins deploy-uat
├── prod_gate.py            # PROD promotion checklist
└── incident_correlator.py  # Correlate alert với deployment history
```

---

## Components

### `models.py`

```python
@dataclass
class HelmValues:
    filename: str           # "values.yaml"
    content: str            # YAML string
    service_name: str
    environment: str

@dataclass
class ChecklistItem:
    name: str
    status: str             # "PASS" | "FAIL" | "WARN"
    message: str

@dataclass
class GateResult:
    approved: bool
    checklist: list[ChecklistItem]
    blocking_items: list[ChecklistItem]
    suggested_command: str  # CLI command để trigger Jenkins nếu approved
    checked_at: str

@dataclass
class PromotionResult:
    approved: bool
    service: str
    build_number: int
    environment: str
    blocking_reasons: list[str]
    jenkins_build_number: int | None    # build number của Jenkins deploy job
    promoted_at: str

@dataclass
class CorrelationResult:
    service: str
    incident_time: str
    deployment: dict | None             # DeploymentRecord as dict, None nếu không tìm thấy
    time_delta_minutes: float | None
    likely_cause: bool
    suggested_action: str               # "rollback" | "investigate_app" | "investigate_infra"
    context_snippets: list[str]         # từ ChromaDB search
    analyzed_at: str
```

### `helm_generator.py`

Sinh Helm `values.yaml` bằng Python string template — không dùng Jinja2 để tránh dependency.

```python
def generate_helm_values(
    service_name: str,
    image_repository: str,
    image_tag: str,
    port: int,
    environment: str = "uat",
    replicas: int = 1,
    cpu_request: str = "100m",
    cpu_limit: str = "500m",
    memory_request: str = "128Mi",
    memory_limit: str = "512Mi",
    ingress_host: str | None = None,
    env_vars: dict | None = None,
    hpa_enabled: bool = False,
    hpa_min_replicas: int = 1,
    hpa_max_replicas: int = 5,
    hpa_cpu_threshold: int = 70,
    health_path: str = "/health",
) -> HelmValues: ...
```

Output YAML structure:
```yaml
replicaCount: 1
image:
  repository: registry.example.com/my-service
  tag: "1.0.0"
  pullPolicy: IfNotPresent
service:
  port: 8080
resources:
  requests:
    cpu: 100m
    memory: 128Mi
  limits:
    cpu: 500m
    memory: 512Mi
livenessProbe:
  httpGet:
    path: /health
    port: 8080
readinessProbe:
  httpGet:
    path: /health
    port: 8080
ingress:
  enabled: true
  host: my-service.example.com
  tls: true
env: []
autoscaling:
  enabled: false
```

### `ci_promoter.py`

```python
def promote_to_ci(
    service: str,
    build_number: int,
    jenkins_deploy_job: str,
    ci_health_url: str | None = None,
    trace_id: str | None = None,
) -> PromotionResult:
    """Kiểm tra build pass và trigger Jenkins deploy-ci."""
```

**Luồng kiểm tra:**
1. Lấy build status từ Jenkins connector → phải SUCCESS
2. Nếu pass → trigger `JenkinsConnector.trigger_job(jenkins_deploy_job, {"SERVICE": service, "BUILD_NUMBER": build_number})`
3. Lưu `DeploymentRecord(service, "ci", build_number, status="running")`
4. Nếu `ci_health_url` → HTTP GET, cập nhật status

### `uat_promoter.py`

```python
def promote_to_uat(
    service: str,
    build_number: int,
    jenkins_deploy_job: str,
    uat_health_url: str | None = None,
    trace_id: str | None = None,
) -> PromotionResult:
    """Kiểm tra CI success và trigger Jenkins deploy-uat."""
```

**Luồng kiểm tra:**
1. Kiểm tra catalog: `list_deployments(service, "ci")` → phải có record với build_number và status="success"
2. Kiểm tra không có CRITICAL finding (từ `qge_audit.jsonl` nếu có)
3. Kiểm tra chưa có UAT deployment trùng build_number
4. Nếu pass → trigger Jenkins job, lưu DeploymentRecord("uat")
5. Nếu `uat_health_url` → HTTP GET, cập nhật status

### `prod_gate.py`

```python
def check_prod_gate(
    service: str,
    build_number: int,
    jenkins_deploy_job: str = "",
    soak_minutes: int = 30,
) -> GateResult:
    """Sinh PROD promotion checklist."""
```

**Checklist items:**

| Item | Logic | Status |
|------|-------|--------|
| UAT deployment exists | `get_latest_deployment(service, "uat")` với build_number | PASS/FAIL |
| UAT deployment success | record.status == "success" | PASS/FAIL |
| UAT soak time | `now - deployed_at >= soak_minutes` | PASS/WARN |
| No CRITICAL findings | Kiểm tra `data/logs/qge_audit.jsonl` cho service | PASS/WARN |
| No PROD deployment running | `list_deployments(service, "prod")` không có status="running" | PASS/FAIL |
`suggested_command` nếu approved:
```
python -m app.cli jenkins-trigger <jenkins_deploy_job> --param SERVICE=<service> --param BUILD_NUMBER=<build_number> --param ENV=prod
```

### `incident_correlator.py`

```python
def correlate_incident(
    service: str,
    incident_time: str,     # ISO 8601
    collection_name: str = "knowledge",
) -> CorrelationResult:
    """Correlate incident với deployment gần nhất."""
```

**Luồng:**
1. `list_deployments(service=service, limit=10)` → sort theo `deployed_at` desc
2. Tìm deployment gần nhất trước `incident_time`
3. Tính `time_delta_minutes`
4. Determine `likely_cause` và `suggested_action`
5. ChromaDB search: `search(f"{service} error incident", collection_name, top_k=3)` → `context_snippets`

---

## Config bổ sung (`.env`)

```env
AI_CONTEXT_V2_K8S_UAT_HEALTH_URL=https://uat.example.com/health
AI_CONTEXT_V2_K8S_PROD_SOAK_MINUTES=30
```

---

## API Contract

### REST Endpoints

```
POST /k8s/helm-values          — sinh Helm values.yaml
POST /k8s/promote-ci           — kiểm tra + trigger Jenkins deploy-ci
POST /k8s/promote-uat          — kiểm tra CI success + trigger Jenkins deploy-uat
POST /k8s/prod-gate            — sinh PROD checklist
POST /k8s/correlate-incident   — correlate alert với deployment
```

### MCP Tools

```python
@mcp.tool()
def k8s_generate_helm_values(service_name, image_repository, image_tag, port, ...) -> dict

@mcp.tool()
def k8s_promote_to_ci(service, build_number, jenkins_deploy_job) -> dict

@mcp.tool()
def k8s_promote_to_uat(service, build_number, jenkins_deploy_job) -> dict

@mcp.tool()
def k8s_check_prod_gate(service, build_number, jenkins_deploy_job) -> dict

@mcp.tool()
def k8s_correlate_incident(service, incident_time, collection) -> dict
```

### CLI

```bash
python -m app.cli k8s-helm-values <service> --image registry/svc --tag 1.0.0 --port 8080
python -m app.cli k8s-promote-ci <service> --build 42 --job deploy-ci
python -m app.cli k8s-promote-uat <service> --build 42 --job deploy-uat
python -m app.cli k8s-prod-gate <service> --build 42 --job deploy-prod
python -m app.cli k8s-correlate <service> --time "2024-01-15T10:00:00Z"
```

---

## Audit Log (`k8s_audit.jsonl`)

```json
{
  "event_type": "k8s_promote_uat | k8s_prod_gate | k8s_correlate",
  "created_at": "...",
  "details": {
    "trace_id": "...",
    "service": "order-service",
    "build_number": 42,
    "approved": true,
    "blocking_reasons": [],
    "duration_ms": 150
  }
}
```
