# Tài liệu Yêu cầu: Observability cho Engine

## Giới thiệu

Observability Engine là Module 7 — module cuối cùng trong roadmap Intent → Impact Pipeline. Module này bổ sung khả năng quan sát và kiểm soát cho toàn bộ AI Context Engine:

1. **Structured Audit Log**: mọi action AI đều có trace đầy đủ, có thể query và export
2. **Confidence Scoring**: output thấp confidence → flag để human review
3. **Human-in-the-loop Gates**: các action quan trọng (merge to main, deploy PROD) luôn cần human approve trước khi thực thi

Module này không thêm external dependency mới — tận dụng audit logs đã có từ các module trước (rde_audit.jsonl, qge_audit.jsonl, jenkins_audit.jsonl, k8s_audit.jsonl, cgp_audit.jsonl) và bổ sung unified query interface.

---

## Bảng chú giải

- **Audit_Log**: File JSONL chứa structured events từ tất cả modules
- **Audit_Query**: Interface để query, filter, và export audit logs
- **Confidence_Score**: Điểm tin cậy (0.0–1.0) của một AI output
- **Confidence_Scorer**: Component tính confidence score cho output của từng module
- **HITL_Gate**: Human-in-the-loop gate — yêu cầu human approve trước khi thực thi action
- **Approval_Request**: Yêu cầu approve được lưu vào catalog, chờ human confirm
- **ApprovalStatus**: pending | approved | rejected

---

## Yêu cầu

### Yêu cầu 1: Unified Audit Log Query

**User Story:** Là một DevOps engineer, tôi muốn query tất cả audit logs từ mọi module trong một interface thống nhất, để tôi có thể trace một action từ đầu đến cuối.

#### Acceptance Criteria

1. WHEN `query_audit_logs(event_types, since, until, limit)` được gọi, THE Audit_Query SHALL đọc và merge tất cả `*.jsonl` files trong `data/logs/` và trả về danh sách events đã filter
2. THE Audit_Query SHALL hỗ trợ filter theo: `event_type` (list), `since` (ISO timestamp), `until` (ISO timestamp), `trace_id`, `service`
3. THE Audit_Query SHALL trả về events đã sort theo `created_at` desc
4. THE Audit_Query SHALL hỗ trợ export ra CSV hoặc JSON
5. WHEN query không có filter, THE Audit_Query SHALL giới hạn tối đa 1000 records để tránh OOM

### Yêu cầu 2: Confidence Scoring

**User Story:** Là một AI agent, tôi muốn tự động tính confidence score cho output của mình, để tôi có thể flag những output cần human review.

#### Acceptance Criteria

1. WHEN `score_confidence(output_type, output_data, context)` được gọi, THE Confidence_Scorer SHALL tính score từ 0.0 đến 1.0 dựa trên các heuristics
2. THE Confidence_Scorer SHALL hỗ trợ các output types: `requirements_doc`, `design_doc`, `generated_code`, `commit_message`, `helm_values`
3. Heuristics cho `requirements_doc`: số lượng acceptance criteria, có compliance section không, có correctness properties không
4. Heuristics cho `generated_code`: mode ("llm" > "skeleton"), có docstring không, có type hints không
5. IF score < threshold (default 0.6), THEN THE Confidence_Scorer SHALL trả về `low_confidence=True` và `review_reasons` mô tả lý do
6. THE Confidence_Scorer SHALL ghi confidence record vào `data/logs/confidence.jsonl`

### Yêu cầu 3: Human-in-the-loop Gate

**User Story:** Là một release manager, tôi muốn các action quan trọng phải chờ human approve trước khi thực thi, để tôi có thể kiểm soát những thay đổi ảnh hưởng lớn.

#### Acceptance Criteria

1. THE HITL_Gate SHALL hỗ trợ các action types cần approve: `merge_to_main`, `deploy_prod`, `create_jira_epic`, `publish_confluence`
2. WHEN `request_approval(action_type, description, payload, requested_by)` được gọi, THE HITL_Gate SHALL lưu `ApprovalRequest` vào catalog với status="pending" và trả về `request_id`
3. WHEN `approve(request_id, approved_by, comment)` được gọi, THE HITL_Gate SHALL cập nhật status="approved" và trả về payload để caller thực thi
4. WHEN `reject(request_id, rejected_by, comment)` được gọi, THE HITL_Gate SHALL cập nhật status="rejected"
5. THE HITL_Gate SHALL hỗ trợ `list_pending_approvals()` để xem tất cả request đang chờ
6. WHEN approval request quá hạn (default 24h), THE HITL_Gate SHALL tự động set status="expired"
7. THE HITL_Gate SHALL ghi audit record cho mỗi approve/reject action

---

## Correctness Properties

### Invariant: Audit Completeness
Mọi event từ tất cả modules đều phải có `created_at`, `event_type`, và `details.trace_id`.

### Invariant: HITL for Critical Actions
`deploy_prod` và `merge_to_main` KHÔNG BAO GIỜ được thực thi mà không có ApprovalRequest với status="approved".

### Invariant: Confidence Score Range
Score luôn trong khoảng [0.0, 1.0].
