# Tài liệu Thiết kế: Observability Engine

## Tổng quan

Module 7 bổ sung observability layer cho toàn bộ engine. Tận dụng audit logs đã có từ các module trước, không thêm external dependency.

### Vị trí trong hệ thống

```
data/logs/
├── rde_audit.jsonl      (Module 2)
├── qge_audit.jsonl      (Module 3)
├── jenkins_audit.jsonl  (Module 4)
├── cgp_audit.jsonl      (Module 5)
├── k8s_audit.jsonl      (Module 6)
├── confidence.jsonl     (Module 7 — mới)
└── hitl_audit.jsonl     (Module 7 — mới)
         │
         ▼
┌─────────────────────────────────────┐
│         Observability Engine         │
│                                      │
│  Audit_Query  ←── query/export       │
│  Confidence_Scorer ←── score output  │
│  HITL_Gate ←── approve/reject        │
└─────────────────────────────────────┘
         │
         ▼
  catalog.db (approval_requests table)
```

---

## Module structure

```
app/tasks/observability/
├── __init__.py
├── audit_query.py      # Query và export unified audit logs
├── confidence.py       # Confidence scoring cho AI outputs
└── hitl_gate.py        # Human-in-the-loop approval gate
```

---

## Components

### `audit_query.py`

```python
@dataclass
class AuditEvent:
    event_type: str
    created_at: str
    details: dict

def query_audit_logs(
    event_types: list[str] | None = None,
    since: str | None = None,
    until: str | None = None,
    trace_id: str | None = None,
    service: str | None = None,
    limit: int = 1000,
) -> list[AuditEvent]:
    """Đọc và merge tất cả *.jsonl trong data/logs/, filter và sort."""

def export_audit_logs(
    events: list[AuditEvent],
    format: str = "json",   # "json" | "csv"
) -> str:
    """Export events ra JSON string hoặc CSV string."""
```

**Logic:**
- Scan `settings.logs_dir` cho tất cả `*.jsonl` files
- Parse từng line thành dict, filter theo params
- Sort theo `created_at` desc, giới hạn `limit`

### `confidence.py`

```python
@dataclass
class ConfidenceResult:
    output_type: str
    score: float            # 0.0 – 1.0
    low_confidence: bool    # True nếu score < threshold
    review_reasons: list[str]
    scored_at: str

def score_confidence(
    output_type: str,
    output_data: str | dict,
    threshold: float = 0.6,
) -> ConfidenceResult:
    """Tính confidence score cho AI output."""
```

**Heuristics theo output_type:**

| output_type | Signals tăng score | Signals giảm score |
|---|---|---|
| `requirements_doc` | Có "Acceptance Criteria", có "Compliance", có "Correctness Properties" | Quá ngắn (< 500 chars) |
| `design_doc` | Có "Mermaid", có "API Contract", có "Threat Model" | Quá ngắn |
| `generated_code` | mode="llm", có docstring, có type hints | mode="skeleton", có NotImplementedError |
| `commit_message` | Đúng format `type(scope): desc`, desc ≤ 72 chars | Không có scope, quá dài |
| `helm_values` | YAML hợp lệ, có ingress, có resources | Thiếu resources |

### `hitl_gate.py`

```python
@dataclass
class ApprovalRequest:
    request_id: str
    action_type: str        # "merge_to_main" | "deploy_prod" | "create_jira_epic" | "publish_confluence"
    description: str
    payload: dict           # data cần thiết để thực thi action sau khi approved
    requested_by: str
    status: str             # "pending" | "approved" | "rejected" | "expired"
    created_at: str
    expires_at: str         # created_at + 24h
    approved_by: str | None
    comment: str | None

def request_approval(
    action_type: str,
    description: str,
    payload: dict,
    requested_by: str = "system",
    expires_hours: int = 24,
) -> str:
    """Tạo ApprovalRequest, lưu vào catalog. Trả về request_id."""

def approve(request_id: str, approved_by: str, comment: str = "") -> ApprovalRequest:
    """Approve request. Trả về ApprovalRequest với payload để caller thực thi."""

def reject(request_id: str, rejected_by: str, comment: str = "") -> ApprovalRequest:
    """Reject request."""

def list_pending(action_type: str | None = None) -> list[ApprovalRequest]:
    """List tất cả pending requests (chưa expired)."""

def get_request(request_id: str) -> ApprovalRequest | None:
    """Lấy request theo ID."""
```

### Database schema (bổ sung vào `catalog.db`)

```sql
CREATE TABLE IF NOT EXISTS approval_requests (
    request_id TEXT PRIMARY KEY,
    action_type TEXT NOT NULL,
    description TEXT NOT NULL,
    payload_json TEXT DEFAULT '{}',
    requested_by TEXT DEFAULT 'system',
    status TEXT DEFAULT 'pending',
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    approved_by TEXT DEFAULT '',
    comment TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_approval_status ON approval_requests(status, action_type);
```

---

## API Contract

### REST Endpoints

```
GET  /obs/audit-logs              — query audit logs (query params: event_type, since, until, trace_id, service, limit, format)
POST /obs/confidence              — score confidence cho một output
POST /obs/approvals               — tạo approval request
GET  /obs/approvals               — list pending approvals
GET  /obs/approvals/{request_id}  — lấy approval request
POST /obs/approvals/{request_id}/approve
POST /obs/approvals/{request_id}/reject
```

### MCP Tools

```python
@mcp.tool()
def obs_query_audit_logs(event_types, since, until, trace_id, limit) -> dict

@mcp.tool()
def obs_score_confidence(output_type, output_data) -> dict

@mcp.tool()
def obs_request_approval(action_type, description, payload, requested_by) -> dict

@mcp.tool()
def obs_list_pending_approvals(action_type) -> dict

@mcp.tool()
def obs_approve(request_id, approved_by, comment) -> dict

@mcp.tool()
def obs_reject(request_id, rejected_by, comment) -> dict
```

### CLI

```bash
python -m app.cli obs-audit-logs [--type event_type] [--since ISO] [--until ISO] [--trace trace_id] [--limit 100] [--format json|csv]
python -m app.cli obs-score <output_type> <content_file>
python -m app.cli obs-request-approval <action_type> --desc "..." --payload '{}'
python -m app.cli obs-list-approvals [--type action_type]
python -m app.cli obs-approve <request_id> --by "username" [--comment "..."]
python -m app.cli obs-reject <request_id> --by "username" [--comment "..."]
```
