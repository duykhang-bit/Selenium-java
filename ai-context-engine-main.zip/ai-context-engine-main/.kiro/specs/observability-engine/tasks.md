# Kế hoạch Triển khai: Observability Engine

## Tasks

- [ ] 1. Bổ sung `approval_requests` table vào `app/catalog/database.py`
  - Thêm schema vào `init_database()`
  - Thêm CRUD functions: `save_approval_request()`, `update_approval_status()`, `list_approval_requests()`, `get_approval_request()`
  - _Yêu cầu: 3.2–3.6_

  - [ ] 1.1 Viết unit test cho approval catalog functions
    - Test save và retrieve approval request
    - Test update status (approved/rejected/expired)
    - Test list_pending filter theo action_type

- [ ] 2. Tạo `app/tasks/observability/` package
  - `app/tasks/observability/__init__.py`
  - _Yêu cầu: 1.1_

- [ ] 3. Tạo `app/tasks/observability/audit_query.py`
  - `AuditEvent` dataclass
  - `query_audit_logs(event_types, since, until, trace_id, service, limit) -> list[AuditEvent]`
  - `export_audit_logs(events, format) -> str` — hỗ trợ "json" và "csv"
  - Scan tất cả `*.jsonl` trong `settings.logs_dir`
  - _Yêu cầu: 1.1–1.5_

  - [ ] 3.1 Viết unit test cho audit_query
    - Test query filter theo event_type
    - Test query filter theo since/until
    - Test query filter theo trace_id
    - Test limit hoạt động đúng
    - Test export JSON hợp lệ
    - Test export CSV hợp lệ
    - Test graceful khi không có log file nào

- [ ] 4. Tạo `app/tasks/observability/confidence.py`
  - `ConfidenceResult` dataclass
  - `score_confidence(output_type, output_data, threshold) -> ConfidenceResult`
  - Heuristics cho: requirements_doc, design_doc, generated_code, commit_message, helm_values
  - Ghi vào `data/logs/confidence.jsonl`
  - _Yêu cầu: 2.1–2.6_

  - [ ] 4.1 Viết unit test cho confidence scorer
    - Test requirements_doc score cao khi có đủ sections
    - Test generated_code score cao khi mode="llm"
    - Test generated_code score thấp khi có NotImplementedError
    - Test commit_message score cao khi đúng format
    - Test low_confidence=True khi score < threshold
    - Test score luôn trong [0.0, 1.0]

- [ ] 5. Checkpoint — audit_query và confidence pass test
  - Chạy `pytest tests/test_obs_audit_query.py tests/test_obs_confidence.py -v`

- [ ] 6. Tạo `app/tasks/observability/hitl_gate.py`
  - `ApprovalRequest` dataclass
  - `request_approval(action_type, description, payload, requested_by, expires_hours) -> str`
  - `approve(request_id, approved_by, comment) -> ApprovalRequest`
  - `reject(request_id, rejected_by, comment) -> ApprovalRequest`
  - `list_pending(action_type) -> list[ApprovalRequest]`
  - `get_request(request_id) -> ApprovalRequest | None`
  - Auto-expire: check và update expired requests khi list_pending được gọi
  - Ghi audit record vào `data/logs/hitl_audit.jsonl`
  - _Yêu cầu: 3.1–3.7_

  - [ ] 6.1 Viết unit test cho hitl_gate
    - Test request_approval tạo record với status="pending"
    - Test approve cập nhật status="approved" và trả về payload
    - Test reject cập nhật status="rejected"
    - Test list_pending chỉ trả về pending requests
    - Test expired request không xuất hiện trong list_pending
    - Test audit record được ghi khi approve/reject

- [ ] 7. Checkpoint — hitl_gate pass test
  - Chạy `pytest tests/test_obs_hitl_gate.py -v`

- [ ] 8. Thêm Observability schemas vào `app/api/schemas.py`
  - `ObsConfidenceRequest`, `ObsApprovalRequest`, `ObsApproveRequest`, `ObsRejectRequest`

- [ ] 9. Thêm Observability endpoints vào `app/api/routes.py`
  - `GET /obs/audit-logs`
  - `POST /obs/confidence`
  - `POST /obs/approvals`
  - `GET /obs/approvals`
  - `GET /obs/approvals/{request_id}`
  - `POST /obs/approvals/{request_id}/approve`
  - `POST /obs/approvals/{request_id}/reject`

  - [ ] 9.1 Viết integration test cho Observability endpoints
    - Test `GET /obs/audit-logs` trả về list
    - Test `POST /obs/confidence` trả về score
    - Test approval workflow: create → approve → get

- [ ] 10. Thêm Observability MCP tools vào `app/mcp_server.py`
  - `obs_query_audit_logs`, `obs_score_confidence`, `obs_request_approval`, `obs_list_pending_approvals`, `obs_approve`, `obs_reject`

- [ ] 11. Thêm Observability CLI commands vào `app/cli.py`
  - `obs-audit-logs`, `obs-score`, `obs-request-approval`, `obs-list-approvals`, `obs-approve`, `obs-reject`

- [ ] 12. Checkpoint cuối — toàn bộ hệ thống
  - Chạy `pytest tests/ --ignore=tests/test_brief_enhanced.py --ignore=tests/test_mcp_integration.py --tb=short`
  - Kiểm tra import: `python -c "from app.tasks.observability import audit_query, confidence, hitl_gate; print('OK')"`
  - Cập nhật roadmap Module 7 ✅ HOÀN THÀNH
