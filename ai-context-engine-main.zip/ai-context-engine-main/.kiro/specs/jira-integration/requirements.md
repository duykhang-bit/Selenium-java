# Tài liệu Yêu cầu: Jira Integration

## Giới thiệu

Module Jira Integration là Module 1 trong roadmap **Intent → Impact Pipeline** của AI Context Engine V2.
Module này kết nối AI Context Engine với hệ thống **Jira Server / Data Center** (tự dựng, không phải Cloud)
để thực hiện bốn nhóm chức năng chính:

1. **Đọc Jira** — pull ticket, epic, sprint context vào ChromaDB để AI có thể search
2. **Ghi Jira** — từ intent tự động tạo Epic → Story → Sub-task qua AI quality gate
3. **Sync 2 chiều** — task dossier cập nhật status → Jira ticket tự cập nhật transition
4. **Jira → Brief** — từ ticket ID sinh task brief đầy đủ business + technical context

Hệ thống phục vụ hệ sinh thái: nhà thuốc, xét nghiệm, tiêm chủng, thiết bị thông minh
với hàng triệu giao dịch mỗi ngày — đòi hỏi enterprise-grade reliability, audit trail đầy đủ,
và idempotency ở mọi thao tác ghi.

---

## Bảng chú giải

- **Jira_Connector**: Client kết nối đến Jira Server/Data Center REST API v2/v3
- **Jira_Syncer**: Service pull dữ liệu từ Jira về ChromaDB
- **Jira_Writer**: Service tạo/cập nhật ticket trên Jira qua API
- **AI_Quality_Gate**: Thành phần kiểm tra chất lượng AI output trước khi ghi vào Jira
- **Dossier_Sync**: Service đồng bộ trạng thái task dossier → Jira ticket transition
- **Brief_Builder**: Service sinh task brief từ Jira ticket ID kết hợp context đa nguồn
- **Catalog_DB**: SQLite database (`data/catalog.db`) — nguồn sự thật về connectors và sources
- **ChromaDB**: Vector store lưu embeddings của Jira issues, Confluence pages, Git code
- **Task_Dossier**: Bộ file JSON + Markdown lưu trạng thái và tài liệu của một task kỹ thuật
- **Issue_Key**: Định danh duy nhất của Jira issue, ví dụ `PROJ-123`
- **Epic**: Jira issue type cấp cao nhất, chứa nhiều Story
- **Story**: Jira issue type mô tả một user story, thuộc một Epic
- **Sub_task**: Jira issue type mô tả công việc nhỏ, thuộc một Story
- **Sprint**: Iteration trong Jira Scrum/Kanban board
- **Transition**: Thao tác chuyển trạng thái Jira issue (ví dụ: To Do → In Progress → Done)
- **Story_Point**: Đơn vị ước lượng độ phức tạp của Story
- **Acceptance_Criteria**: Tiêu chí nghiệm thu của Story, lưu trong description hoặc custom field
- **Audit_Trail**: Bản ghi đầy đủ mọi thao tác tạo/cập nhật ticket, lưu trong `timeline.jsonl`
- **Idempotency_Key**: Khóa duy nhất để phát hiện và ngăn tạo duplicate ticket
- **Confidence_Score**: Điểm tin cậy [0.0, 1.0] của AI output từ Quality Gate

---

## Yêu cầu

### Yêu cầu 1: Đăng ký và xác thực Jira Connector

**User Story:** Là một DevOps engineer, tôi muốn đăng ký kết nối đến Jira Server/Data Center,
để AI Context Engine có thể đọc và ghi dữ liệu Jira một cách bảo mật.

#### Tiêu chí nghiệm thu

1. THE Jira_Connector SHALL hỗ trợ xác thực bằng Personal Access Token (PAT) với Jira Server/Data Center.
2. WHEN một Jira connector được đăng ký với `base_url` và `token` hợp lệ, THE Catalog_DB SHALL lưu connector record với token được mã hoá bằng Fernet.
3. WHEN cùng một `base_url` được đăng ký lại, THE Catalog_DB SHALL cập nhật connector hiện có thay vì tạo bản ghi mới (upsert idempotent).
4. WHEN token Jira được đọc từ Catalog_DB, THE Jira_Connector SHALL giải mã token trước khi sử dụng để gọi API.
5. IF kết nối đến Jira Server thất bại, THEN THE Jira_Connector SHALL trả về thông báo lỗi mô tả nguyên nhân cụ thể (network error, authentication error, permission error).
6. THE Jira_Connector SHALL xác thực kết nối bằng cách gọi endpoint `/rest/api/2/serverInfo` và kiểm tra response hợp lệ.
7. WHERE biến môi trường `AI_CONTEXT_V2_JIRA_BASE_URL` và `AI_CONTEXT_V2_JIRA_TOKEN` được cấu hình, THE Jira_Connector SHALL tự động đăng ký connector khi khởi động.

#### Thuộc tính đúng đắn (Correctness Properties)

- **Round-trip bảo mật**: `decrypt(encrypt(token)) == token` — mọi token Jira lưu trong Catalog_DB đều phải giải mã lại được chính xác giá trị gốc.
- **Idempotency upsert**: Gọi `register_jira_connector(url, token)` N lần với cùng tham số → Catalog_DB chỉ có đúng 1 connector record cho `url` đó.

---

### Yêu cầu 2: Pull Jira Issues vào ChromaDB (Đọc Jira)

**User Story:** Là một AI agent, tôi muốn tìm kiếm Jira issues liên quan đến task hiện tại,
để có đủ context về yêu cầu nghiệp vụ và trạng thái công việc.

#### Tiêu chí nghiệm thu

1. WHEN lệnh sync Jira được kích hoạt, THE Jira_Syncer SHALL pull toàn bộ issues từ các project được cấu hình về ChromaDB.
2. THE Jira_Syncer SHALL pull các issue type: Epic, Story, Sub-task, Bug, Task, Improvement và các custom issue type được cấu hình.
3. THE Jira_Syncer SHALL pull thông tin Sprint hiện tại và lịch sử Sprint cho mỗi issue.
4. WHEN một issue đã tồn tại trong ChromaDB, THE Jira_Syncer SHALL cập nhật document thay vì tạo mới (upsert theo `issue_key`).
5. THE Jira_Syncer SHALL lưu metadata của mỗi issue bao gồm: `issue_key`, `issue_type`, `status`, `priority`, `assignee`, `sprint_name`, `epic_key`, `story_points`, `project_key`.
6. WHEN pull issues, THE Jira_Syncer SHALL sử dụng pagination với page size tối đa 100 issues mỗi request để tránh timeout.
7. IF Jira API trả về lỗi 429 (rate limit), THEN THE Jira_Syncer SHALL retry với exponential backoff tối đa 3 lần trước khi báo lỗi.
8. IF một issue không thể pull do lỗi permission, THEN THE Jira_Syncer SHALL ghi log cảnh báo và tiếp tục pull các issue còn lại (không dừng toàn bộ batch).
9. THE Jira_Syncer SHALL ghi sync run record vào Catalog_DB với trạng thái `running` → `success` hoặc `failed` sau khi hoàn thành.
10. WHILE sync đang chạy, THE Jira_Syncer SHALL cập nhật tiến độ (số issue đã pull / tổng số) vào sync run record.

#### Thuộc tính đúng đắn (Correctness Properties)

- **Idempotency sync**: Chạy sync cùng project 2 lần liên tiếp → tổng số document trong ChromaDB không tăng (upsert, không insert duplicate).
- **Invariant metadata**: Mọi document Jira trong ChromaDB đều phải có `issue_key` trong metadata và `issue_key` phải khớp với nội dung document.
- **Completeness pagination**: Tổng số issue sau khi sync đầy đủ ≥ tổng số issue trả về từ Jira API với cùng JQL filter.
- **Invariant retry**: Số lần retry cho một request không vượt quá `max_retries` (mặc định 3).

---

### Yêu cầu 3: AI Quality Gate cho thao tác ghi Jira

**User Story:** Là một Tech Lead, tôi muốn mọi ticket được AI tạo ra đều phải qua kiểm tra chất lượng,
để đảm bảo ticket đủ thông tin và đúng chuẩn trước khi xuất hiện trên Jira board.

#### Tiêu chí nghiệm thu

1. THE AI_Quality_Gate SHALL kiểm tra mọi Jira issue được AI sinh ra trước khi gọi Jira API tạo ticket.
2. THE AI_Quality_Gate SHALL kiểm tra các tiêu chí bắt buộc: summary không rỗng, description có độ dài tối thiểu 50 ký tự, issue type hợp lệ.
3. WHEN kiểm tra Story, THE AI_Quality_Gate SHALL yêu cầu có ít nhất 1 acceptance criteria trong description.
4. WHEN kiểm tra Epic, THE AI_Quality_Gate SHALL yêu cầu có business objective rõ ràng trong description.
5. THE AI_Quality_Gate SHALL trả về `confidence_score` trong khoảng [0.0, 1.0] cho mỗi issue được kiểm tra.
6. IF `confidence_score` < 0.7, THEN THE AI_Quality_Gate SHALL từ chối tạo ticket và trả về danh sách vấn đề cụ thể cần sửa.
7. WHERE ngưỡng `confidence_score` được cấu hình qua biến môi trường `AI_CONTEXT_V2_JIRA_QUALITY_THRESHOLD`, THE AI_Quality_Gate SHALL sử dụng ngưỡng đó thay vì giá trị mặc định 0.7.
8. THE AI_Quality_Gate SHALL ghi kết quả kiểm tra (pass/fail, score, issues) vào Audit_Trail trước khi trả về kết quả.

#### Thuộc tính đúng đắn (Correctness Properties)

- **Invariant confidence range**: `confidence_score` luôn nằm trong [0.0, 1.0] với mọi input hợp lệ hoặc không hợp lệ.
- **Invariant audit completeness**: Mọi lần gọi Quality Gate đều tạo ra đúng 1 audit record trong Audit_Trail, bất kể kết quả pass hay fail.
- **Error condition**: Input với `summary` rỗng hoặc `issue_type` không hợp lệ → Quality Gate luôn trả về `confidence_score` = 0.0 và danh sách lỗi không rỗng.

---

### Yêu cầu 4: Tạo Jira Issues từ Intent (Ghi Jira)

**User Story:** Là một Product Manager, tôi muốn mô tả ý tưởng bằng ngôn ngữ tự nhiên và nhận được
Epic → Story → Sub-task đã được tạo trên Jira, để tiết kiệm thời gian viết ticket thủ công.

#### Tiêu chí nghiệm thu

1. WHEN một intent được cung cấp, THE Jira_Writer SHALL sinh cấu trúc Epic → Story → Sub-task phù hợp với intent đó.
2. THE Jira_Writer SHALL tạo Epic trước, sau đó tạo Story với `parent` là Epic key vừa tạo, sau đó tạo Sub-task với `parent` là Story key vừa tạo.
3. THE Jira_Writer SHALL điền `story_points` ước lượng cho mỗi Story dựa trên độ phức tạp mô tả (thang điểm Fibonacci: 1, 2, 3, 5, 8, 13).
4. THE Jira_Writer SHALL điền acceptance criteria vào description của Story theo định dạng chuẩn của dự án.
5. WHEN tạo issue, THE Jira_Writer SHALL gán `project_key` đúng với project được cấu hình.
6. THE Jira_Writer SHALL sử dụng `idempotency_key` (hash của intent + project_key) để phát hiện và ngăn tạo duplicate ticket khi cùng intent được gửi nhiều lần.
7. IF Jira_Writer phát hiện `idempotency_key` đã tồn tại trong Catalog_DB, THEN THE Jira_Writer SHALL trả về issue đã tạo trước đó thay vì tạo mới.
8. IF Jira API trả về lỗi khi tạo Story sau khi Epic đã được tạo thành công, THEN THE Jira_Writer SHALL ghi lại Epic key đã tạo vào Audit_Trail để có thể rollback hoặc retry thủ công.
9. THE Jira_Writer SHALL chỉ gọi Jira API sau khi AI_Quality_Gate đã xác nhận pass với `confidence_score` ≥ ngưỡng cấu hình.
10. WHEN tạo issue thành công, THE Jira_Writer SHALL lưu mapping `{intent_hash → issue_key}` vào Catalog_DB.

#### Thuộc tính đúng đắn (Correctness Properties)

- **Idempotency tạo ticket**: Gọi `create_from_intent(intent, project)` N lần với cùng intent → Jira chỉ có đúng 1 Epic (và các Story/Sub-task tương ứng) được tạo.
- **Invariant hierarchy**: Mọi Story được tạo đều có `epic_key` hợp lệ; mọi Sub-task được tạo đều có `story_key` hợp lệ — không có orphan issue.
- **Invariant story points**: `story_points` của mọi Story được tạo đều thuộc tập {1, 2, 3, 5, 8, 13}.
- **Invariant quality gate**: Không có issue nào được tạo trên Jira mà không có audit record Quality Gate pass tương ứng trong Audit_Trail.

---

### Yêu cầu 5: Đồng bộ 2 chiều — Task Dossier → Jira Transition

**User Story:** Là một developer, tôi muốn khi cập nhật trạng thái task dossier thì Jira ticket
tự động chuyển trạng thái tương ứng, để không phải cập nhật thủ công 2 nơi.

#### Tiêu chí nghiệm thu

1. THE Dossier_Sync SHALL ánh xạ trạng thái task dossier sang Jira transition theo bảng cấu hình: `started` → `In Progress`, `planned` → `In Progress`, `completed` → `Done`, `blocked` → `Blocked`.
2. WHEN trạng thái task dossier thay đổi và dossier có `jira_issue_key` được liên kết, THE Dossier_Sync SHALL gọi Jira transition API để cập nhật trạng thái ticket tương ứng.
3. IF trạng thái Jira hiện tại đã bằng trạng thái đích, THEN THE Dossier_Sync SHALL bỏ qua transition (không gọi API thừa).
4. THE Dossier_Sync SHALL ghi mọi transition thành công và thất bại vào `timeline.jsonl` của task dossier với timestamp và kết quả.
5. IF Jira transition thất bại do lỗi mạng hoặc lỗi API, THEN THE Dossier_Sync SHALL ghi lỗi vào Audit_Trail và tiếp tục hoạt động bình thường (không block cập nhật dossier).
6. THE Dossier_Sync SHALL hỗ trợ liên kết một task dossier với nhiều Jira issue key (ví dụ: một task ảnh hưởng nhiều Story).
7. WHEN một task dossier được liên kết với `jira_issue_key`, THE Dossier_Sync SHALL lưu mapping này vào `task.json` của dossier.

#### Thuộc tính đúng đắn (Correctness Properties)

- **Idempotency transition**: Gọi sync với cùng trạng thái 2 lần liên tiếp → Jira API chỉ được gọi tối đa 1 lần (lần thứ 2 bị bỏ qua vì trạng thái đã đúng).
- **Invariant audit**: Mọi lần Dossier_Sync cố gắng thực hiện transition (thành công hay thất bại) đều có đúng 1 record trong `timeline.jsonl`.
- **Invariant no-block**: Lỗi Jira transition không được làm thay đổi kết quả của thao tác cập nhật dossier — dossier vẫn được cập nhật thành công.

---

### Yêu cầu 6: Sinh Task Brief từ Jira Ticket ID

**User Story:** Là một AI agent, tôi muốn nhận task brief đầy đủ từ một Jira ticket ID,
để có đủ business context (Confluence), technical context (GitLab) và Jira context để implement.

#### Tiêu chí nghiệm thu

1. WHEN một `issue_key` hợp lệ được cung cấp, THE Brief_Builder SHALL sinh task brief bao gồm: Jira context, Confluence business context, và GitLab technical context.
2. THE Brief_Builder SHALL pull thông tin Jira issue trực tiếp từ Jira API (không chỉ từ ChromaDB) để đảm bảo dữ liệu mới nhất.
3. THE Brief_Builder SHALL tìm kiếm Confluence pages liên quan đến `summary` và `description` của issue bằng vector search.
4. THE Brief_Builder SHALL tìm kiếm GitLab code context liên quan đến `summary` và `description` của issue bằng vector search.
5. THE Brief_Builder SHALL bao gồm thông tin Epic cha (nếu có) và các Story/Sub-task liên quan trong brief.
6. THE Brief_Builder SHALL bao gồm Sprint hiện tại, story points, và acceptance criteria trong brief.
7. IF `issue_key` không tồn tại trên Jira, THEN THE Brief_Builder SHALL trả về lỗi mô tả rõ ràng thay vì brief rỗng.
8. THE Brief_Builder SHALL tạo task dossier mới với brief đã sinh và liên kết `jira_issue_key` vào `task.json`.
9. WHERE task dossier đã tồn tại cho `issue_key` đó, THE Brief_Builder SHALL cập nhật brief trong dossier hiện có thay vì tạo dossier mới.

#### Thuộc tính đúng đắn (Correctness Properties)

- **Invariant completeness**: Brief sinh từ `issue_key` hợp lệ luôn chứa ít nhất: `issue_key`, `summary`, `status`, `issue_type` trong output — không bao giờ trả về brief rỗng cho issue tồn tại.
- **Metamorphic enrichment**: Brief với Confluence context phải có `confluence_results` không rỗng khi có Confluence pages liên quan đã được index; brief với GitLab context phải có `git_results` không rỗng khi có code liên quan đã được index.
- **Round-trip dossier**: `create_brief_from_jira(issue_key)` → `get_task_dossier(task_id)` → dossier phải chứa `jira_issue_key` = `issue_key` ban đầu.

---

### Yêu cầu 7: REST API và CLI cho Jira Integration

**User Story:** Là một developer, tôi muốn thao tác với Jira Integration qua REST API và CLI,
để tích hợp vào workflow tự động hoá và sử dụng thủ công khi cần.

#### Tiêu chí nghiệm thu

1. THE System SHALL cung cấp REST API endpoint `POST /setup/jira` để đăng ký Jira connector.
2. THE System SHALL cung cấp REST API endpoint `POST /jira/sync` để kích hoạt pull issues từ Jira vào ChromaDB.
3. THE System SHALL cung cấp REST API endpoint `POST /jira/create-from-intent` để tạo Epic/Story/Sub-task từ intent.
4. THE System SHALL cung cấp REST API endpoint `POST /jira/brief/{issue_key}` để sinh task brief từ Jira ticket.
5. THE System SHALL cung cấp REST API endpoint `POST /jira/link-dossier` để liên kết task dossier với Jira issue key.
6. THE System SHALL cung cấp CLI command `python -m app.cli jira-sync` để pull issues từ Jira.
7. THE System SHALL cung cấp CLI command `python -m app.cli jira-create "<intent>"` để tạo ticket từ intent.
8. THE System SHALL cung cấp CLI command `python -m app.cli jira-brief "<issue_key>"` để sinh brief từ ticket.
9. WHEN API key authentication được bật (`AI_CONTEXT_V2_API_KEY` không rỗng), THE System SHALL yêu cầu API key hợp lệ cho tất cả Jira endpoints.
10. THE System SHALL trả về HTTP 404 khi `issue_key` không tồn tại, HTTP 422 khi request body không hợp lệ, HTTP 502 khi Jira Server không khả dụng.

#### Thuộc tính đúng đắn (Correctness Properties)

- **Invariant HTTP status**: Mọi lỗi validation (input không hợp lệ) đều trả về HTTP 4xx; mọi lỗi Jira server đều trả về HTTP 5xx — không bao giờ trả về HTTP 200 kèm error message trong body.
- **Invariant auth**: Khi API key được bật, mọi request không có API key hợp lệ đều trả về HTTP 401 — không có endpoint Jira nào bypass authentication.

---

### Yêu cầu 8: MCP Tools cho Jira Integration

**User Story:** Là một AI agent kết nối qua MCP, tôi muốn có các tool để thao tác với Jira,
để có thể tự động hoá workflow từ intent đến ticket mà không cần gọi REST API trực tiếp.

#### Tiêu chí nghiệm thu

1. THE System SHALL cung cấp MCP tool `jira_sync_project` để pull issues của một project vào ChromaDB.
2. THE System SHALL cung cấp MCP tool `jira_create_from_intent` để tạo Epic/Story/Sub-task từ intent text.
3. THE System SHALL cung cấp MCP tool `jira_brief_from_ticket` để sinh task brief từ issue key.
4. THE System SHALL cung cấp MCP tool `jira_link_dossier` để liên kết task dossier với Jira issue.
5. THE System SHALL cung cấp MCP tool `jira_search` để tìm kiếm Jira issues trong ChromaDB bằng natural language query.
6. WHEN MCP tool được gọi với tham số không hợp lệ, THE System SHALL trả về error message mô tả rõ ràng thay vì exception không xử lý.

#### Thuộc tính đúng đắn (Correctness Properties)

- **Invariant tool schema**: Mọi MCP tool đều có `name`, `description`, và `inputSchema` hợp lệ — không có tool nào thiếu schema.

---

### Yêu cầu 9: Audit Trail và Observability

**User Story:** Là một Tech Lead, tôi muốn có audit trail đầy đủ cho mọi thao tác Jira,
để có thể trace lại nguyên nhân khi có sự cố và đảm bảo compliance.

#### Tiêu chí nghiệm thu

1. THE System SHALL ghi audit record cho mọi thao tác ghi Jira (tạo issue, cập nhật issue, transition) bao gồm: timestamp UTC, action type, actor (API key hash hoặc "system"), input parameters, kết quả (success/failure), Jira issue key (nếu có).
2. THE System SHALL ghi audit record cho mọi lần AI_Quality_Gate được gọi bao gồm: timestamp, input summary, confidence_score, pass/fail, danh sách vấn đề (nếu fail).
3. THE System SHALL lưu audit records vào `timeline.jsonl` của task dossier liên quan (nếu có) và vào structured log file.
4. WHEN một thao tác Jira thất bại, THE System SHALL ghi đủ thông tin để retry thủ công: endpoint, payload, error response.
5. THE System SHALL expose metric `jira_sync_issues_total` (tổng số issue đã sync) và `jira_create_tickets_total` (tổng số ticket đã tạo) qua log có thể parse.

#### Thuộc tính đúng đắn (Correctness Properties)

- **Invariant audit completeness**: Với mọi thao tác ghi Jira thành công, tồn tại đúng 1 audit record tương ứng trong log — không có thao tác nào không được ghi lại.
- **Invariant timestamp ordering**: Các audit record trong `timeline.jsonl` của một dossier luôn có `created_at` tăng dần (monotonic) — không có record nào có timestamp nhỏ hơn record trước đó.

---

### Yêu cầu 10: Cấu hình và Bảo mật

**User Story:** Là một DevOps engineer, tôi muốn cấu hình Jira Integration hoàn toàn qua biến môi trường,
để triển khai an toàn trong môi trường container mà không hardcode credential.

#### Tiêu chí nghiệm thu

1. THE System SHALL đọc toàn bộ cấu hình Jira từ biến môi trường với prefix `AI_CONTEXT_V2_JIRA_*`.
2. THE System SHALL hỗ trợ các biến môi trường: `AI_CONTEXT_V2_JIRA_BASE_URL`, `AI_CONTEXT_V2_JIRA_TOKEN`, `AI_CONTEXT_V2_JIRA_PROJECT_KEYS` (danh sách project key cách nhau bằng dấu phẩy), `AI_CONTEXT_V2_JIRA_QUALITY_THRESHOLD` (mặc định 0.7).
3. THE System SHALL mã hoá Jira token bằng Fernet trước khi lưu vào Catalog_DB, sử dụng cùng `AI_CONTEXT_V2_SECRET_KEY` với các connector khác.
4. IF `AI_CONTEXT_V2_JIRA_BASE_URL` không được cấu hình, THEN THE System SHALL bỏ qua việc đăng ký Jira connector khi bootstrap (không raise exception).
5. THE System SHALL không ghi Jira token dưới dạng plaintext vào bất kỳ log file nào.
6. THE System SHALL validate `AI_CONTEXT_V2_JIRA_BASE_URL` là URL hợp lệ (scheme http/https, có hostname) trước khi đăng ký connector.

#### Thuộc tính đúng đắn (Correctness Properties)

- **Invariant no plaintext token**: Với mọi log record được sinh ra bởi hệ thống, không có record nào chứa chuỗi khớp với Jira token plaintext.
- **Invariant config isolation**: Thay đổi `AI_CONTEXT_V2_JIRA_*` không ảnh hưởng đến hoạt động của GitLab connector hoặc Confluence connector.
