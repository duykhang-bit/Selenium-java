# Tài liệu Thiết kế: Jira Integration

## Tổng quan

Jira Integration là Module 1 trong roadmap **Intent → Impact Pipeline** của AI Context Engine V2.
Module này bổ sung khả năng kết nối hai chiều với **Jira Server / Data Center** (self-hosted),
cho phép AI agent đọc context từ Jira, tạo ticket từ intent, đồng bộ trạng thái dossier,
và sinh task brief đầy đủ từ ticket ID.

Module tuân thủ hoàn toàn các pattern hiện có của codebase:
- Connector pattern: `app/connectors/jira.py` (tương tự `gitlab.py`, `confluence.py`)
- Sync pattern: `app/sync/jira_sync.py` (tương tự `confluence_sync.py`)
- Service orchestration: mở rộng `app/sync/service.py`
- Catalog DB: mở rộng schema SQLite hiện có
- Fernet encryption: tái sử dụng `app/core/crypto.py`
- Structured logging: tái sử dụng `app/core/logging.py`


---

## Kiến trúc

### Vị trí trong hệ thống

```
┌─────────────────────────────────────────────────────────────────────┐
│                        AI Context Engine V2                         │
│                                                                     │
│  REST API (port 8100)          MCP Server (port 3000)               │
│  ┌──────────────────┐          ┌──────────────────────┐             │
│  │  /jira/*         │          │  jira_sync_project   │             │
│  │  /setup/jira     │          │  jira_create_from_   │             │
│  │                  │          │  intent              │             │
│  └────────┬─────────┘          │  jira_brief_from_    │             │
│           │                    │  ticket              │             │
│           │                    │  jira_link_dossier   │             │
│           │                    │  jira_search         │             │
│           │                    └──────────┬───────────┘             │
│           │                               │                         │
│           └──────────────┬────────────────┘                         │
│                          ▼                                          │
│              ┌───────────────────────┐                              │
│              │   app/sync/service.py │  (orchestration layer)       │
│              └───────────┬───────────┘                              │
│                          │                                          │
│         ┌────────────────┼────────────────────┐                     │
│         ▼                ▼                    ▼                     │
│  ┌─────────────┐  ┌─────────────┐  ┌──────────────────┐            │
│  │ jira_sync   │  │ jira_writer │  │ jira_dossier_sync│            │
│  │ .py         │  │ .py         │  │ .py              │            │
│  └──────┬──────┘  └──────┬──────┘  └────────┬─────────┘            │
│         │                │                  │                       │
│         └────────────────┼──────────────────┘                       │
│                          ▼                                          │
│              ┌───────────────────────┐                              │
│              │  app/connectors/      │                              │
│              │  jira.py              │  (HTTP client layer)         │
│              └───────────┬───────────┘                              │
│                          │  HTTPS/TLS 1.2+                          │
└──────────────────────────┼──────────────────────────────────────────┘
                           ▼
              ┌────────────────────────┐
              │  Jira Server /         │
              │  Data Center           │
              │  REST API v2/v3        │
              └────────────────────────┘

Lưu trữ nội bộ:
  catalog.db (SQLite)  ←→  connectors, idempotency_keys, jira_sync_runs
  ChromaDB             ←→  jira_issues collection (vector embeddings)
  data/tasks/*/        ←→  task dossier + timeline.jsonl
```

### Luồng dữ liệu chính

```
[1] Đọc Jira (Sync):
  Trigger → JiraSyncer → JiraConnector → Jira API
          → PII Masker → Chunker → Embedder → ChromaDB (upsert)
          → catalog.db (sync_run record)

[2] Ghi Jira (Create from Intent):
  Intent → JiraWriter → AIQualityGate (score ≥ threshold)
         → IdempotencyCheck (catalog.db) → JiraConnector → Jira API
         → AuditTrail (timeline.jsonl)

[3] Sync 2 chiều (Dossier → Jira):
  DossierUpdate → DossierSync → JiraConnector → Jira Transition API
               → timeline.jsonl (audit)

[4] Brief từ Ticket:
  IssueKey → JiraConnector (live fetch) → BriefBuilder
           → VectorSearch (Confluence + GitLab context)
           → TaskDossier (create/update)
```


---

## Các Component và Interface

### 1. `app/connectors/jira.py` — Jira API Client

Tương tự `GitLabConnector` và `ConfluenceConnector`, class `JiraConnector` bọc toàn bộ
HTTP calls đến Jira Server/Data Center REST API v2.

```python
class JiraConnector:
    def __init__(self, base_url: str, token: str,
                 connect_timeout: float = 5.0, read_timeout: float = 30.0,
                 max_pool_size: int = 10): ...

    def verify_connection(self) -> dict:
        """Gọi /rest/api/2/serverInfo để xác thực kết nối."""

    def search_issues(self, jql: str, start_at: int = 0,
                      max_results: int = 100, fields: list[str] | None = None) -> dict:
        """JQL search với pagination. Trả về {issues, total, startAt, maxResults}."""

    def get_issue(self, issue_key: str) -> dict:
        """Lấy chi tiết một issue theo key (ví dụ PROJ-123)."""

    def create_issue(self, fields: dict) -> dict:
        """Tạo issue mới. Trả về {id, key, self}."""

    def get_transitions(self, issue_key: str) -> list[dict]:
        """Lấy danh sách transition khả dụng cho issue."""

    def do_transition(self, issue_key: str, transition_id: str) -> None:
        """Thực hiện transition cho issue."""

    def get_sprints(self, board_id: int) -> list[dict]:
        """Lấy danh sách sprint của một board (Agile API)."""
```

**Thiết kế kỹ thuật:**
- `requests.Session` với connection pooling (`HTTPAdapter(pool_maxsize=10)`)
- Timeout cấu hình được: connect 5s / read 30s (theo standards.md)
- Header `Authorization: Bearer <PAT>` cho Jira Server/Data Center
- Retry logic với exponential backoff cho HTTP 429 và 5xx (tối đa 3 lần)
- Mọi HTTP error được wrap thành `JiraConnectorError` subclass tương ứng

### 2. `app/sync/jira_sync.py` — Pull Issues vào ChromaDB

```python
def sync_jira_project(project_key: str, connector: dict,
                      collection_name: str = "knowledge") -> dict:
    """Pull toàn bộ issues của project vào ChromaDB.
    Trả về {synced, failed, total, sync_run_id}."""

def _build_issue_document(issue: dict) -> tuple[str, dict]:
    """Chuyển Jira issue thành (text_content, metadata) cho ChromaDB."""

def _mask_pii_in_text(text: str) -> str:
    """Áp dụng PII masking trước khi lưu vào ChromaDB."""
```

**Thiết kế kỹ thuật:**
- Pagination: page size 100 issues/request (theo Req 2.6)
- Upsert theo `issue_key` — không tạo duplicate (theo Req 2.4)
- Batch upsert vào ChromaDB (tái sử dụng `upsert_chunks` từ `store.py`)
- Ghi `sync_run` record vào `catalog.db` với trạng thái `running` → `success/failed`
- Lỗi permission trên từng issue: log WARNING, tiếp tục (không dừng batch)
- PII masking bắt buộc trước khi lưu ChromaDB (Nghị định 13/2023)

### 3. `app/tasks/jira_writer.py` — Tạo Epic/Story/Sub-task từ Intent

```python
def create_from_intent(intent: str, project_key: str,
                       connector: dict) -> dict:
    """Sinh và tạo cấu trúc Epic → Story → Sub-task từ intent text.
    Trả về {epic_key, stories: [{story_key, subtasks: [subtask_key]}],
            idempotency_key, audit_id}."""

def _generate_issue_structure(intent: str, project_key: str) -> dict:
    """Sinh cấu trúc issue từ intent (LLM hoặc template-based)."""

def _estimate_story_points(complexity_description: str) -> int:
    """Ước lượng story points theo Fibonacci: {1,2,3,5,8,13}."""
```

**Thiết kế kỹ thuật:**
- Idempotency key = `sha256(intent + project_key)` — lưu trong `idempotency_keys` table
- Thứ tự tạo: Epic → Story (với `parent=epic_key`) → Sub-task (với `parent=story_key`)
- Chỉ gọi Jira API sau khi `AIQualityGate.check()` trả về `confidence_score ≥ threshold`
- Nếu tạo Story thất bại sau khi Epic đã tạo: ghi Epic key vào audit trail để rollback thủ công
- Lưu mapping `{idempotency_key → epic_key}` vào `catalog.db` sau khi thành công

### 4. `app/tasks/jira_quality_gate.py` — AI Quality Gate

```python
class AIQualityGate:
    def __init__(self, threshold: float = 0.7): ...

    def check(self, issue_fields: dict) -> QualityGateResult:
        """Kiểm tra chất lượng issue fields.
        Trả về QualityGateResult(passed, confidence_score, issues)."""

@dataclass
class QualityGateResult:
    passed: bool
    confidence_score: float  # [0.0, 1.0]
    issues: list[str]        # danh sách vấn đề nếu fail
    audit_id: str            # ID của audit record đã ghi
```

**Thiết kế kỹ thuật:**
- Kiểm tra bắt buộc: summary không rỗng, description ≥ 50 ký tự, issue_type hợp lệ
- Story: phải có ≥ 1 acceptance criteria trong description
- Epic: phải có business objective rõ ràng trong description
- `confidence_score` luôn trong [0.0, 1.0] — invariant bất biến
- Ghi audit record vào `timeline.jsonl` TRƯỚC khi trả về kết quả (Req 3.8)
- Threshold cấu hình qua `AI_CONTEXT_V2_JIRA_QUALITY_THRESHOLD` (mặc định 0.7)

### 5. `app/tasks/jira_dossier_sync.py` — Sync Dossier Status → Jira Transition

```python
def sync_dossier_to_jira(task_id: str, connector: dict) -> dict:
    """Đọc trạng thái dossier và thực hiện Jira transition tương ứng.
    Trả về {transitioned: bool, skipped: bool, error: str | None}."""

DOSSIER_TO_JIRA_STATUS_MAP: dict[str, str] = {
    "started": "In Progress",
    "planned": "In Progress",
    "completed": "Done",
    "blocked": "Blocked",
}
```

**Thiết kế kỹ thuật:**
- Đọc `jira_issue_keys` từ `task.json` của dossier (hỗ trợ nhiều key)
- Kiểm tra trạng thái Jira hiện tại trước khi transition — bỏ qua nếu đã đúng (Req 5.3)
- Lỗi Jira transition: ghi vào `timeline.jsonl`, KHÔNG block cập nhật dossier (Req 5.5)
- Mọi lần cố gắng transition (thành công hay thất bại) đều có 1 record trong `timeline.jsonl`

### 6. `app/tasks/jira_brief.py` — Sinh Task Brief từ Jira Ticket

```python
def build_brief_from_jira(issue_key: str, collection_name: str = "knowledge",
                           top_k: int = 5) -> dict:
    """Sinh task brief đầy đủ từ Jira issue key.
    Trả về {issue_key, jira_context, confluence_results,
            git_results, brief, task_id}."""
```

**Thiết kế kỹ thuật:**
- Pull issue trực tiếp từ Jira API (không chỉ từ ChromaDB) để đảm bảo dữ liệu mới nhất
- Vector search Confluence và GitLab bằng `summary + description` của issue
- Bao gồm Epic cha và các Story/Sub-task liên quan
- Tạo hoặc cập nhật task dossier, lưu `jira_issue_key` vào `task.json`
- Nếu `issue_key` không tồn tại: raise `JiraIssueNotFoundError` (HTTP 404)

### 7. Cập nhật `app/api/routes.py` — Jira Endpoints

```
POST /setup/jira                    — Đăng ký Jira connector
POST /jira/sync                     — Pull issues vào ChromaDB
POST /jira/create-from-intent       — Tạo Epic/Story/Sub-task từ intent
POST /jira/brief/{issue_key}        — Sinh task brief từ ticket
POST /jira/link-dossier             — Liên kết dossier với Jira issue key
```

### 8. Cập nhật `app/mcp_server.py` — Jira MCP Tools

```
jira_sync_project       — Pull issues của project vào ChromaDB
jira_create_from_intent — Tạo Epic/Story/Sub-task từ intent text
jira_brief_from_ticket  — Sinh task brief từ issue key
jira_link_dossier       — Liên kết task dossier với Jira issue
jira_search             — Tìm kiếm Jira issues trong ChromaDB
```

### 9. Cập nhật `app/core/config.py` — Jira Settings

```python
jira_base_url: str = os.getenv("AI_CONTEXT_V2_JIRA_BASE_URL", "")
jira_token: str = os.getenv("AI_CONTEXT_V2_JIRA_TOKEN", "")
jira_project_keys: str = os.getenv("AI_CONTEXT_V2_JIRA_PROJECT_KEYS", "")
jira_quality_threshold: float = float(
    os.getenv("AI_CONTEXT_V2_JIRA_QUALITY_THRESHOLD", "0.7")
)
jira_name: str = os.getenv("AI_CONTEXT_V2_JIRA_NAME", "Jira")
```

### 10. Cập nhật `app/cli.py` — Jira CLI Commands

```bash
python -m app.cli jira-sync [--project-key PROJ] [--collection knowledge]
python -m app.cli jira-create "<intent>" --project-key PROJ
python -m app.cli jira-brief "<issue_key>" [--collection knowledge]
```


---

## Data Models

### 3.1 Schema mở rộng `catalog.db`

```sql
-- Bảng idempotency_keys: ngăn tạo duplicate ticket
CREATE TABLE IF NOT EXISTS idempotency_keys (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    key_hash        TEXT NOT NULL UNIQUE,   -- sha256(intent + project_key)
    connector_type  TEXT NOT NULL DEFAULT 'jira',
    result_ref      TEXT NOT NULL,          -- epic_key đã tạo (ví dụ: PROJ-42)
    created_at      TEXT NOT NULL,
    metadata_json   TEXT DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_idempotency_keys_hash ON idempotency_keys(key_hash);

-- Bảng jira_sync_runs: theo dõi tiến độ sync
-- (Tái sử dụng bảng sync_runs hiện có với action='jira_sync')
-- Thêm cột progress_json vào sync_runs nếu chưa có:
ALTER TABLE sync_runs ADD COLUMN progress_json TEXT DEFAULT '{}';
-- progress_json: {"synced": 45, "total": 200, "failed": 2}

-- Bảng jira_dossier_links: mapping dossier ↔ Jira issue keys
CREATE TABLE IF NOT EXISTS jira_dossier_links (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id         TEXT NOT NULL,
    issue_key       TEXT NOT NULL,          -- ví dụ: PROJ-123
    linked_at       TEXT NOT NULL,
    UNIQUE(task_id, issue_key)
);
CREATE INDEX IF NOT EXISTS idx_jira_dossier_links_task ON jira_dossier_links(task_id);
CREATE INDEX IF NOT EXISTS idx_jira_dossier_links_issue ON jira_dossier_links(issue_key);
```

Jira connector được lưu trong bảng `connectors` hiện có với `connector_type = 'jira'`.
Token được mã hoá Fernet qua `encrypt_token()` — tái sử dụng hoàn toàn pattern hiện có.

### 3.2 ChromaDB Document Structure cho Jira Issues

Collection name: `"knowledge"` (cùng collection với GitLab và Confluence)

```python
# Document text (nội dung để embed)
document_text = f"""
[JIRA] {issue_key}: {summary}
Type: {issue_type} | Status: {status} | Priority: {priority}
Sprint: {sprint_name} | Story Points: {story_points}
Epic: {epic_key} | Project: {project_key}

Description:
{masked_description}

Acceptance Criteria:
{masked_acceptance_criteria}
"""

# Metadata (dùng để filter trong ChromaDB)
metadata = {
    "source_type": "jira_issue",
    "source_id": f"jira:{issue_key}",
    "issue_key": issue_key,           # ví dụ: "PROJ-123"
    "issue_type": issue_type,         # "Epic", "Story", "Sub-task", "Bug", ...
    "status": status,                 # "To Do", "In Progress", "Done", ...
    "priority": priority,             # "Highest", "High", "Medium", "Low"
    "assignee": assignee_display,     # display name (không lưu email)
    "sprint_name": sprint_name,
    "epic_key": epic_key,             # key của Epic cha (nếu có)
    "story_points": story_points,     # int hoặc None
    "project_key": project_key,       # ví dụ: "PROJ"
    "connector_id": connector_id,     # int, FK đến connectors table
    "last_synced_at": utc_now_iso(),
}
```

**Lưu ý PII:** `description` và `acceptance_criteria` phải qua `_mask_pii_in_text()`
trước khi lưu vào ChromaDB (xem mục 3.3 và Security Design).

### 3.3 Task Dossier — Cập nhật `task.json`

Khi dossier được liên kết với Jira, `task.json` bổ sung các field:

```json
{
  "task_id": "task-20240115-120000-implement-order-api",
  "jira_issue_key": "PROJ-123",
  "jira_issue_keys": ["PROJ-123", "PROJ-124"],
  "jira_epic_key": "PROJ-100",
  "jira_project_key": "PROJ",
  "jira_linked_at": "2024-01-15T12:00:00Z"
}
```

### 3.4 Audit Record Schema trong `timeline.jsonl`

```json
{
  "event_type": "jira_transition",
  "created_at": "2024-01-15T12:00:00Z",
  "details": {
    "action": "transition",
    "issue_key": "PROJ-123",
    "from_status": "To Do",
    "to_status": "In Progress",
    "transition_id": "21",
    "result": "success",
    "actor": "system",
    "trace_id": "abc123"
  }
}
```

```json
{
  "event_type": "quality_gate_check",
  "created_at": "2024-01-15T12:00:00Z",
  "details": {
    "action": "quality_gate",
    "input_summary": "Implement order API",
    "issue_type": "Story",
    "confidence_score": 0.85,
    "passed": true,
    "issues": [],
    "trace_id": "abc123"
  }
}
```


---

## Security Design

### Threat Model

| Mối đe dọa | Vector tấn công | Biện pháp phòng thủ |
|---|---|---|
| Token leak | Log file, response body | Không log token; `_redact_for_cli()` mask token trong CLI output |
| SSRF | `base_url` do user cung cấp | Validate scheme (http/https), reject private IP ranges (RFC 1918) |
| Credential theft | catalog.db bị đọc trộm | Fernet encryption cho token; key trong env var |
| Replay attack | Cùng intent gửi nhiều lần | Idempotency key (sha256 hash) trong `idempotency_keys` table |
| Injection | JQL query từ user input | Parameterized JQL; không string concatenation |
| PII exposure | Jira description chứa CMND/SĐT | PII masking trước khi lưu ChromaDB |
| Unauthorized access | Endpoint không có auth | API key dependency trên mọi Jira endpoint |
| Man-in-the-middle | HTTP thay vì HTTPS | Enforce HTTPS/TLS 1.2+; reject http:// trong production |

### SSRF Prevention

```python
import ipaddress
from urllib.parse import urlparse

BLOCKED_PRIVATE_RANGES = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),  # link-local
]

def validate_jira_url(url: str) -> str:
    """Validate URL trước khi đăng ký connector.
    Raise JiraConfigError nếu URL không hợp lệ."""
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise JiraConfigError(f"URL scheme phải là http hoặc https: {url}")
    if not parsed.hostname:
        raise JiraConfigError(f"URL thiếu hostname: {url}")
    # Trong production, nên thêm DNS resolution check để block private IP
    return url.rstrip("/")
```

### PII Masking Strategy

Áp dụng trước khi lưu bất kỳ text nào vào ChromaDB (Nghị định 13/2023/NĐ-CP):

```python
import re

# Regex patterns cho PII Việt Nam
PII_PATTERNS = [
    # CMND/CCCD: 9 hoặc 12 chữ số
    (re.compile(r'\b\d{9}\b|\b\d{12}\b'), "[CMND/CCCD]"),
    # Số điện thoại VN: 0[3-9]xxxxxxxx hoặc +84[3-9]xxxxxxxx
    (re.compile(r'(?<!\d)(?:\+84|0)[3-9]\d{8}(?!\d)'), "[SĐT]"),
    # Email
    (re.compile(r'\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b'), "[EMAIL]"),
    # Số thẻ ngân hàng (16 chữ số, có thể có dấu cách/gạch)
    (re.compile(r'\b(?:\d[ \-]?){15,16}\b'), "[CARD]"),
]

def mask_pii(text: str) -> str:
    """Mask PII trong text trước khi lưu vào ChromaDB."""
    for pattern, replacement in PII_PATTERNS:
        text = pattern.sub(replacement, text)
    return text
```

### TLS Enforcement

```python
# Trong JiraConnector.__init__:
import ssl
adapter = HTTPAdapter(
    pool_maxsize=10,
    pool_connections=5,
    max_retries=Retry(total=0),  # retry logic tự quản lý
)
# Với HTTPS, requests tự dùng TLS. Để enforce TLS 1.2+:
# session.mount("https://", TLSEnforcingAdapter(ssl_minimum_version=ssl.TLSVersion.TLSv1_2))
```


---

## Exception Hierarchy

```
JiraError (base)
├── JiraConnectorError          — lỗi kết nối/HTTP
│   ├── JiraAuthError           — 401/403: token sai hoặc hết hạn
│   ├── JiraNotFoundError       — 404: issue/project không tồn tại
│   ├── JiraRateLimitError      — 429: rate limit, có thể retry
│   ├── JiraServerError         — 5xx: lỗi phía Jira server
│   └── JiraNetworkError        — timeout, connection refused
├── JiraConfigError             — cấu hình không hợp lệ (URL, token rỗng)
├── JiraQualityGateError        — issue không qua quality gate
│   └── fields: confidence_score, issues: list[str]
├── JiraIdempotencyError        — idempotency key đã tồn tại
│   └── fields: existing_ref (epic_key đã tạo trước đó)
└── JiraIssueNotFoundError      — issue_key không tồn tại (cho Brief Builder)
```

```python
class JiraError(Exception):
    """Base exception cho tất cả Jira-related errors."""

class JiraConnectorError(JiraError):
    def __init__(self, message: str, status_code: int | None = None,
                 response_body: str | None = None): ...

class JiraRateLimitError(JiraConnectorError):
    """HTTP 429 — có thể retry với exponential backoff."""

class JiraQualityGateError(JiraError):
    def __init__(self, confidence_score: float, issues: list[str]): ...
```

**Mapping sang HTTP status codes (trong `routes.py`):**

| Exception | HTTP Status |
|---|---|
| `JiraIssueNotFoundError` | 404 |
| `JiraQualityGateError` | 422 |
| `JiraConfigError` | 422 |
| `JiraAuthError` | 502 |
| `JiraServerError` | 502 |
| `JiraNetworkError` | 502 |
| `JiraRateLimitError` | 429 (propagate) |

---

## Performance Design

### Connection Pooling

```python
# JiraConnector sử dụng requests.Session với HTTPAdapter
from requests.adapters import HTTPAdapter

adapter = HTTPAdapter(
    pool_connections=5,   # số connection pool
    pool_maxsize=10,      # tối đa 10 connections (theo standards.md)
    pool_block=False,
)
session.mount("https://", adapter)
session.mount("http://", adapter)
```

### Async Strategy

Tất cả Jira sync và write operations chạy qua `asyncio.to_thread()` trong API routes
(tương tự pattern hiện có trong `routes.py`):

```python
@router.post("/jira/sync")
async def jira_sync(request: JiraSyncRequest) -> dict:
    return await asyncio.to_thread(sync_jira_project, request.project_key, ...)
```

Background sync jobs (khi trigger từ CLI hoặc scheduled) chạy non-blocking.

### Batch Upsert vào ChromaDB

Tái sử dụng `upsert_chunks()` từ `app/ingest/store.py` với batch size 5000 (đã có sẵn).
Jira issues được chunk thành `Chunk` objects trước khi upsert.

### Retry với Exponential Backoff

```python
import time

def _retry_with_backoff(func, max_retries: int = 3, base_delay: float = 1.0):
    """Retry function với exponential backoff cho HTTP 429 và 5xx."""
    for attempt in range(max_retries + 1):
        try:
            return func()
        except JiraRateLimitError:
            if attempt == max_retries:
                raise
            delay = base_delay * (2 ** attempt)  # 1s, 2s, 4s
            time.sleep(delay)
        except JiraServerError:
            if attempt == max_retries:
                raise
            time.sleep(base_delay * (2 ** attempt))
```

### Caching / Fallback

- Jira connector info được cache trong memory sau lần đầu load từ `catalog.db`
- Nếu Jira API không khả dụng khi sinh brief: fallback về ChromaDB data (có thể stale)
- Sync run progress được persist vào `catalog.db` để có thể resume sau crash

---

## Logging & Observability Design

### JSON Structured Log Format

```python
# Mọi log record phải có format:
{
    "timestamp": "2024-01-15T12:00:00.123Z",  # ISO 8601 UTC
    "level": "INFO",
    "service": "jira-integration",
    "trace_id": "abc123def456",               # xuyên suốt request
    "message": "Jira sync completed",
    "context": {
        "project_key": "PROJ",
        "synced": 150,
        "failed": 2,
        "duration_ms": 4523
    }
}
```

**Lưu ý:** `context` KHÔNG được chứa token, password, PII, hoặc bất kỳ credential nào.

### Trace ID Propagation

```python
import uuid
from contextvars import ContextVar

_trace_id: ContextVar[str] = ContextVar("trace_id", default="")

def get_trace_id() -> str:
    return _trace_id.get() or str(uuid.uuid4())[:8]

def set_trace_id(trace_id: str) -> None:
    _trace_id.set(trace_id)
```

Trong FastAPI middleware: set `trace_id` từ header `X-Trace-ID` hoặc generate mới.
Trong MCP tools: generate `trace_id` mới cho mỗi tool call.

### Audit Trail Schema

Audit records được ghi vào hai nơi:
1. **`timeline.jsonl`** của task dossier liên quan (nếu có)
2. **Structured log file** tại `data/logs/jira_audit.jsonl`

```python
def write_audit_record(
    action: str,
    actor: str,           # sha256(api_key)[:8] hoặc "system"
    issue_key: str | None,
    input_summary: str,   # KHÔNG chứa PII
    result: str,          # "success" | "failed"
    error: str | None,
    trace_id: str,
    task_id: str | None = None,
) -> str:
    """Ghi audit record. Trả về audit_id."""
```

### Metrics (qua log parsing)

```
jira_sync_issues_total{project_key="PROJ", status="success"} 150
jira_sync_issues_total{project_key="PROJ", status="failed"} 2
jira_create_tickets_total{issue_type="Epic", status="success"} 5
jira_quality_gate_total{result="pass"} 12
jira_quality_gate_total{result="fail"} 3
jira_transition_total{status="success"} 8
```

Các metric này được emit dưới dạng log record có `"metric": true` để có thể parse bằng log aggregator.

---

## API Contract

### `POST /setup/jira`

**Request:**
```json
{
  "base_url": "https://jira.company.com",
  "token": "PAT_TOKEN_HERE",
  "name": "Company Jira"
}
```

**Response 200:**
```json
{
  "connector": {
    "id": 3,
    "connector_type": "jira",
    "name": "Company Jira",
    "base_url": "https://jira.company.com",
    "created_at": "2024-01-15T12:00:00Z"
  }
}
```

**Errors:** 422 (URL không hợp lệ), 502 (không kết nối được Jira)

---

### `POST /jira/sync`

**Request:**
```json
{
  "project_keys": ["PROJ", "OMS"],
  "collection": "knowledge"
}
```

**Response 200:**
```json
{
  "results": [
    {
      "project_key": "PROJ",
      "synced": 150,
      "failed": 2,
      "total": 152,
      "sync_run_id": 42,
      "status": "success"
    }
  ]
}
```

**Errors:** 422 (project_keys rỗng), 502 (Jira không khả dụng)

---

### `POST /jira/create-from-intent`

**Request:**
```json
{
  "intent": "Xây dựng tính năng đặt lịch tiêm chủng online cho phụ huynh",
  "project_key": "VACC",
  "collection": "knowledge"
}
```

**Response 200:**
```json
{
  "epic_key": "VACC-42",
  "stories": [
    {
      "story_key": "VACC-43",
      "summary": "Màn hình đặt lịch tiêm chủng",
      "story_points": 5,
      "subtasks": ["VACC-44", "VACC-45"]
    }
  ],
  "idempotency_key": "sha256hash...",
  "quality_gate": {
    "confidence_score": 0.87,
    "passed": true
  }
}
```

**Errors:** 422 (quality gate fail, kèm `issues` list), 409 (idempotency key đã tồn tại, kèm `existing_ref`), 502 (Jira lỗi)

---

### `POST /jira/brief/{issue_key}`

**Path param:** `issue_key` — ví dụ `PROJ-123`

**Response 200:**
```json
{
  "issue_key": "PROJ-123",
  "task_id": "task-20240115-120000-proj-123",
  "jira_context": {
    "summary": "...",
    "description": "...",
    "status": "In Progress",
    "issue_type": "Story",
    "story_points": 5,
    "epic_key": "PROJ-100",
    "sprint_name": "Sprint 42",
    "acceptance_criteria": "..."
  },
  "confluence_results": [...],
  "git_results": [...],
  "brief": "..."
}
```

**Errors:** 404 (issue_key không tồn tại), 502 (Jira lỗi)

---

### `POST /jira/link-dossier`

**Request:**
```json
{
  "task_id": "task-20240115-120000-...",
  "issue_key": "PROJ-123"
}
```

**Response 200:**
```json
{
  "task_id": "task-20240115-120000-...",
  "issue_key": "PROJ-123",
  "linked_at": "2024-01-15T12:00:00Z"
}
```

**Errors:** 404 (task_id hoặc issue_key không tồn tại), 409 (đã liên kết)


---

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Token Encryption Round-Trip

*For any* Jira PAT token string, registering a connector with that token, reading the stored value from `catalog.db`, and decrypting it must produce a value identical to the original token — the stored value must never equal the plaintext token.

**Validates: Requirements 1.2, 1.4, 10.3**

---

### Property 2: Connector Upsert Idempotency

*For any* `base_url` and token, calling `register_jira_connector(base_url, token)` N times (N ≥ 1) must result in exactly 1 connector record in `catalog.db` for that `base_url` — no duplicate rows regardless of how many times registration is called.

**Validates: Requirements 1.3**

---

### Property 3: Connection Error Classification

*For any* HTTP error response from Jira (401, 403, 404, 429, 5xx) or network failure (timeout, connection refused), the `JiraConnector` must raise a specific subclass of `JiraConnectorError` that corresponds to the error type — never a generic `Exception` or `requests.RequestException`.

**Validates: Requirements 1.5**

---

### Property 4: Sync Idempotency

*For any* Jira project, running `sync_jira_project(project_key)` twice in succession must not increase the total number of documents in ChromaDB — the second run must upsert existing documents, not insert duplicates.

**Validates: Requirements 2.1, 2.4**

---

### Property 5: Jira Document Metadata Completeness

*For any* Jira issue document stored in ChromaDB after a sync, the document's metadata must contain all required fields: `issue_key`, `issue_type`, `status`, `priority`, `project_key`, `source_type` — and the `issue_key` in metadata must match the `issue_key` in the document text.

**Validates: Requirements 2.5**

---

### Property 6: Retry Count Invariant

*For any* Jira API request that fails with HTTP 429 or 5xx, the number of retry attempts must not exceed `max_retries` (default 3) — the system must raise the error after exhausting retries rather than retrying indefinitely.

**Validates: Requirements 2.7**

---

### Property 7: Batch Resilience — Permission Errors

*For any* batch of Jira issues where a subset fails with permission errors (403), the sync must complete for all remaining issues — the total number of successfully synced issues must equal the total issues minus those with permission errors, not zero.

**Validates: Requirements 2.8**

---

### Property 8: Quality Gate Confidence Range

*For any* input to `AIQualityGate.check()` — whether valid, empty, or malformed — the returned `confidence_score` must always be in the closed interval [0.0, 1.0]. Input with empty `summary` or invalid `issue_type` must return `confidence_score = 0.0` and a non-empty `issues` list.

**Validates: Requirements 3.2, 3.5, 3.6**

---

### Property 9: Quality Gate Audit Completeness

*For any* call to `AIQualityGate.check()`, regardless of whether the result is pass or fail, exactly 1 audit record must be written to the audit trail before the method returns — no call goes unrecorded.

**Validates: Requirements 3.8, 9.1**

---

### Property 10: Quality Gate Enforcement — No Bypass

*For any* call to `JiraWriter.create_from_intent()`, no Jira API call to create an issue must occur unless there exists a corresponding Quality Gate audit record with `passed=True` for that same intent — the gate cannot be bypassed.

**Validates: Requirements 3.1, 4.9**

---

### Property 11: Issue Hierarchy Invariant

*For any* Epic/Story/Sub-task structure created by `JiraWriter`, every Story must have a valid `epic_key` pointing to an Epic created in the same operation, and every Sub-task must have a valid `story_key` pointing to a Story created in the same operation — no orphan issues.

**Validates: Requirements 4.1, 4.2**

---

### Property 12: Story Points Fibonacci Invariant

*For any* Story created by `JiraWriter`, the `story_points` value must be a member of the Fibonacci set {1, 2, 3, 5, 8, 13} — no other integer values are valid.

**Validates: Requirements 4.3**

---

### Property 13: Create-from-Intent Idempotency

*For any* intent string and project key, calling `create_from_intent(intent, project_key)` N times (N ≥ 1) must result in exactly 1 Epic (and its associated Stories/Sub-tasks) being created on Jira — subsequent calls must return the previously created `epic_key` without creating new issues.

**Validates: Requirements 4.6**

---

### Property 14: Dossier-to-Jira Status Mapping

*For any* dossier status in the configured mapping (`started`, `planned`, `completed`, `blocked`), when `sync_dossier_to_jira()` is called with a dossier in that status, the Jira transition called must correspond to the mapped target status — the mapping must be applied consistently for all valid dossier statuses.

**Validates: Requirements 5.1**

---

### Property 15: Transition Idempotency

*For any* dossier and linked Jira issue, calling `sync_dossier_to_jira()` twice with the same dossier status must result in the Jira transition API being called at most once — the second call must be skipped because the Jira status already matches the target.

**Validates: Requirements 5.3**

---

### Property 16: Transition Audit Completeness

*For any* attempt by `DossierSync` to perform a Jira transition — whether it succeeds, fails, or is skipped — exactly 1 record must be appended to `timeline.jsonl` of the associated dossier.

**Validates: Requirements 5.4**

---

### Property 17: Transition Failure Non-Blocking

*For any* dossier update operation where the associated Jira transition fails (network error, API error), the dossier update itself must still complete successfully — the dossier's status and files must reflect the new state regardless of the Jira failure.

**Validates: Requirements 5.5**

---

### Property 18: Brief Completeness Invariant

*For any* valid `issue_key` that exists on Jira, the brief returned by `build_brief_from_jira(issue_key)` must contain at minimum: `issue_key`, `summary`, `status`, and `issue_type` — the brief must never be empty or missing these core fields for an existing issue.

**Validates: Requirements 6.1**

---

### Property 19: Brief Dossier Round-Trip

*For any* `issue_key`, calling `build_brief_from_jira(issue_key)` and then retrieving the resulting dossier via `get_task_dossier(task_id)` must return a dossier where `jira_issue_key` equals the original `issue_key` — the linkage must be persisted correctly.

**Validates: Requirements 6.8**

---

### Property 20: Authentication Invariant

*For any* Jira API endpoint when `AI_CONTEXT_V2_API_KEY` is configured, every HTTP request without a valid API key must receive HTTP 401 — no Jira endpoint must be accessible without authentication.

**Validates: Requirements 7.9**

---

### Property 21: HTTP Status Code Invariant

*For any* Jira endpoint request, validation errors (invalid input) must return HTTP 4xx status codes, and Jira server errors must return HTTP 5xx status codes — no endpoint must return HTTP 200 with an error message in the response body.

**Validates: Requirements 7.10**

---

### Property 22: No Plaintext Token in Logs

*For any* log record generated by the Jira integration module, the record must not contain any string that matches the plaintext Jira PAT token — tokens must be masked or absent from all log output.

**Validates: Requirements 10.5**

---

### Property 23: URL Validation Rejects Invalid Inputs

*For any* string passed as `base_url` to `register_jira_connector()` that is not a valid HTTP/HTTPS URL with a hostname, the function must raise `JiraConfigError` — invalid URLs must never be stored in `catalog.db`.

**Validates: Requirements 10.6**


---

## Error Handling

### Nguyên tắc chung

Tuân thủ pattern hiện có của codebase:
- Mọi lời gọi Jira API đều có `try/except` cụ thể — không dùng bare `except:`
- Exception từ Jira API được wrap thành `JiraConnectorError` subclass tương ứng
- Phân biệt rõ recoverable error (retry) và fatal error (dừng, alert)
- Mọi exception được log với đủ context: `trace_id`, `issue_key`, `action`, `error_type`

### Bảng xử lý lỗi

| Tình huống | Exception | Hành động | Retry? |
|---|---|---|---|
| HTTP 401/403 | `JiraAuthError` | Log ERROR, raise, trả về 502 | Không |
| HTTP 404 | `JiraNotFoundError` | Log WARNING, raise, trả về 404 | Không |
| HTTP 429 | `JiraRateLimitError` | Log WARNING, retry backoff | Có (≤3 lần) |
| HTTP 5xx | `JiraServerError` | Log ERROR, retry backoff | Có (≤3 lần) |
| Timeout | `JiraNetworkError` | Log ERROR, retry | Có (≤3 lần) |
| URL không hợp lệ | `JiraConfigError` | Log ERROR, raise, trả về 422 | Không |
| Quality gate fail | `JiraQualityGateError` | Log INFO, raise, trả về 422 | Không |
| Idempotency hit | `JiraIdempotencyError` | Log INFO, trả về existing ref | Không |
| Permission trên issue | Log WARNING | Bỏ qua issue, tiếp tục batch | Không |
| Transition fail | Log ERROR vào timeline | Không block dossier update | Không |

### Partial Failure trong Batch Sync

```python
# Pattern: collect errors, không dừng batch
results = {"synced": 0, "failed": 0, "errors": []}
for issue in issues:
    try:
        _upsert_issue(issue, collection)
        results["synced"] += 1
    except JiraPermissionError as exc:
        logger.warning("Permission denied for issue %s: %s",
                       issue["key"], exc,
                       extra={"trace_id": trace_id})
        results["failed"] += 1
        results["errors"].append({"issue_key": issue["key"], "error": str(exc)})
```

### Rollback Strategy cho Partial Write

Khi tạo Epic thành công nhưng Story thất bại:
1. Ghi Epic key vào `timeline.jsonl` với `event_type = "partial_create_epic_only"`
2. Ghi vào `audit_log` với đủ thông tin để retry thủ công
3. Không tự động xoá Epic đã tạo (tránh data loss)
4. Trả về HTTP 502 kèm `{"epic_key": "PROJ-42", "error": "Story creation failed", "rollback_required": true}`

---

## Testing Strategy

### Dual Testing Approach

Cả unit test và property-based test đều bắt buộc (theo standards.md: coverage ≥ 80%).

**Unit tests** tập trung vào:
- Specific examples: verify_connection() gọi đúng endpoint
- Integration points: routes.py → service.py → connector.py
- Edge cases: empty intent, issue_key không tồn tại, token rỗng
- Error conditions: mỗi HTTP error code → đúng exception type

**Property-based tests** tập trung vào:
- Universal properties từ mục Correctness Properties
- Randomized inputs để phát hiện edge cases không lường trước

### Property-Based Testing Configuration

Thư viện: **`hypothesis`** (Python, tích hợp tốt với pytest)

```bash
pip install hypothesis
```

Mỗi property test phải:
- Chạy tối thiểu **100 iterations** (`@settings(max_examples=100)`)
- Có comment tag tham chiếu property trong design document
- Dùng mock/stub cho Jira API — không gọi Jira thật trong CI

```python
from hypothesis import given, settings
from hypothesis import strategies as st

# Feature: jira-integration, Property 1: Token Encryption Round-Trip
@given(token=st.text(min_size=1, max_size=200))
@settings(max_examples=100)
def test_token_encryption_round_trip(token):
    """For any token string, encrypt then decrypt must return original value."""
    encrypted = encrypt_token(token)
    assert encrypted != token  # must not store plaintext
    assert decrypt_token(encrypted) == token

# Feature: jira-integration, Property 2: Connector Upsert Idempotency
@given(
    base_url=st.just("https://jira.example.com"),
    token=st.text(min_size=1, max_size=50),
    n=st.integers(min_value=2, max_value=5)
)
@settings(max_examples=100)
def test_connector_upsert_idempotency(base_url, token, n, tmp_catalog):
    """Registering N times with same base_url → exactly 1 record in DB."""
    for _ in range(n):
        register_jira_connector(base_url, token)
    connectors = list_connectors(connector_type="jira")
    jira_connectors = [c for c in connectors if c["base_url"] == base_url]
    assert len(jira_connectors) == 1

# Feature: jira-integration, Property 8: Quality Gate Confidence Range
@given(fields=st.fixed_dictionaries({
    "summary": st.text(),
    "description": st.text(),
    "issue_type": st.text(),
}))
@settings(max_examples=100)
def test_quality_gate_confidence_range(fields):
    """For any input, confidence_score must be in [0.0, 1.0]."""
    gate = AIQualityGate(threshold=0.7)
    result = gate.check(fields)
    assert 0.0 <= result.confidence_score <= 1.0

# Feature: jira-integration, Property 12: Story Points Fibonacci Invariant
FIBONACCI_SET = {1, 2, 3, 5, 8, 13}

@given(complexity=st.text(min_size=1, max_size=500))
@settings(max_examples=100)
def test_story_points_fibonacci(complexity):
    """For any complexity description, estimated story_points must be in Fibonacci set."""
    points = _estimate_story_points(complexity)
    assert points in FIBONACCI_SET
```

### Unit Test Structure

```
tests/
├── test_jira_connector.py       # JiraConnector HTTP client tests
├── test_jira_sync.py            # JiraSyncer sync logic tests
├── test_jira_writer.py          # JiraWriter create-from-intent tests
├── test_jira_quality_gate.py    # AIQualityGate validation tests
├── test_jira_dossier_sync.py    # DossierSync transition tests
├── test_jira_brief.py           # Brief builder tests
├── test_jira_routes.py          # API endpoint tests
├── test_jira_mcp_tools.py       # MCP tool tests
└── test_jira_pbt.py             # Property-based tests (hypothesis)
```

### Mock Strategy

```python
# Tất cả Jira API calls phải được mock trong CI
from unittest.mock import patch, MagicMock

@patch("app.connectors.jira.JiraConnector._get")
def test_sync_handles_permission_error(mock_get):
    mock_get.side_effect = [
        {"issues": [{"key": "PROJ-1", ...}], "total": 2},  # page 1
        JiraAuthError("403 Forbidden"),                      # PROJ-2 fails
    ]
    result = sync_jira_project("PROJ", connector=mock_connector)
    assert result["synced"] == 1
    assert result["failed"] == 1
```

