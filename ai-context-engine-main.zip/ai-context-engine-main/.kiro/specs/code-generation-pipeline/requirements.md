# Tài liệu Yêu cầu: Code Generation Pipeline

## Giới thiệu

Code Generation Pipeline là Module 5 trong roadmap Intent → Impact Pipeline. Module này tự động hoá vòng đời coding: từ design doc → chia tasks → sinh code → tạo branch/commit/MR trên GitLab.

Module hỗ trợ 2 mode cho Code Generator:
- **Skeleton mode** (no LLM, luôn available): sinh boilerplate/scaffold dựa trên pattern detect từ codebase hiện có
- **LLM mode** (optional): gọi LLM API nếu được cấu hình, graceful degrade về skeleton mode nếu không có

---

## Bảng chú giải

- **Task_Decomposer**: Phân tích design doc → sinh danh sách coding tasks có thứ tự dependency
- **CodingTask**: Một đơn vị công việc coding cụ thể (tạo file, thêm function, sửa class...)
- **Code_Generator**: Sinh code cho một CodingTask — skeleton mode hoặc LLM mode
- **Branch_Manager**: Tạo branch, commit file, tạo MR trên GitLab
- **Commit_Message_Generator**: Sinh conventional commit message từ diff hoặc task description
- **Conventional Commit**: Format commit message chuẩn: `type(scope): description`
- **MR**: Merge Request trên GitLab

---

## Yêu cầu

### Yêu cầu 1: Task Decomposer

**User Story:** Là một AI agent, tôi muốn tự động chia design doc thành danh sách coding tasks nhỏ có thứ tự dependency, để tôi có thể thực hiện từng bước một cách có hệ thống.

#### Acceptance Criteria

1. WHEN design doc được cung cấp, THE Task_Decomposer SHALL phân tích và sinh ra danh sách `CodingTask` trong vòng 10 giây
2. Mỗi `CodingTask` SHALL có: `task_id`, `title`, `type` (create_file/modify_file/add_function/add_class/add_endpoint), `target_file`, `description`, `depends_on` (list task_id), `priority` (1-5)
3. THE Task_Decomposer SHALL sắp xếp tasks theo dependency order — task không có dependency trước, task phụ thuộc sau
4. THE Task_Decomposer SHALL detect các task type phổ biến từ design doc: tạo model, tạo service, tạo API endpoint, tạo test
5. IF design doc chứa ERD, THE Task_Decomposer SHALL sinh task tạo model trước task tạo service
6. THE Task_Decomposer SHALL lấy codebase context từ ChromaDB để đề xuất `target_file` phù hợp với convention hiện có

### Yêu cầu 2: Code Generator — Skeleton Mode

**User Story:** Là một AI agent, tôi muốn sinh code skeleton cho coding task mà không cần LLM, để tôi có thể hoạt động offline và nhanh.

#### Acceptance Criteria

1. WHEN `CodingTask` với type `create_file` được cung cấp, THE Code_Generator SHALL sinh file Python với: `from __future__ import annotations`, module docstring, imports phù hợp với task type
2. WHEN task type là `add_function`, THE Code_Generator SHALL sinh function với: signature từ task description, docstring, type hints, `raise NotImplementedError` placeholder
3. WHEN task type là `add_class`, THE Code_Generator SHALL sinh class với: `__init__`, docstring, methods skeleton từ task description
4. WHEN task type là `add_endpoint`, THE Code_Generator SHALL sinh FastAPI route handler với: decorator, request/response type hints, docstring, `raise HTTPException(501)` placeholder
5. THE Code_Generator SHALL detect convention từ codebase context (dataclass vs Pydantic, sync vs async) và áp dụng vào skeleton
6. THE Code_Generator SHALL trả về `GeneratedCode` với: `file_path`, `content`, `mode` = "skeleton", `language`

### Yêu cầu 3: Code Generator — LLM Mode

**User Story:** Là một AI agent, tôi muốn dùng LLM để sinh code đầy đủ hơn khi được cấu hình, để tôi có thể tạo ra code gần với production-ready hơn.

#### Acceptance Criteria

1. WHEN `AI_CONTEXT_V2_LLM_API_KEY` được cấu hình, THE Code_Generator SHALL dùng LLM mode thay vì skeleton mode
2. THE Code_Generator SHALL build prompt từ: task description + codebase context (top 5 chunks từ ChromaDB) + existing file content (nếu modify)
3. THE Code_Generator SHALL hỗ trợ các LLM provider: OpenAI (`gpt-4o-mini` default), Anthropic (`claude-3-haiku` default) — detect từ API key prefix
4. IF LLM call thất bại hoặc timeout (30s), THEN THE Code_Generator SHALL graceful degrade về skeleton mode và log warning
5. THE Code_Generator SHALL trả về `GeneratedCode` với `mode` = "llm" khi dùng LLM thành công

### Yêu cầu 4: Branch Manager

**User Story:** Là một AI agent, tôi muốn tự động tạo branch, commit code, và tạo MR trên GitLab, để tôi có thể hoàn thiện vòng lặp coding → review.

#### Acceptance Criteria

1. WHEN `create_branch(source_id, branch_name, from_branch)` được gọi, THE Branch_Manager SHALL tạo branch mới trên GitLab từ `from_branch` (default: default branch của repo)
2. WHEN `commit_files(source_id, branch_name, files, message)` được gọi, THE Branch_Manager SHALL commit một hoặc nhiều file lên branch trong một commit
3. WHEN `create_mr(source_id, branch_name, title, description)` được gọi, THE Branch_Manager SHALL tạo MR từ branch về default branch với title và description
4. THE Branch_Manager SHALL đọc `source_id` từ catalog để lấy GitLab project ID và connector credentials
5. IF branch đã tồn tại, THEN `create_branch` SHALL raise `BranchAlreadyExistsError` thay vì overwrite
6. THE Branch_Manager SHALL trả về `MRResult` với: `mr_id`, `mr_url`, `branch_name`, `title`

### Yêu cầu 5: Commit Message Generator

**User Story:** Là một AI agent, tôi muốn tự động sinh conventional commit message từ diff hoặc task description, để tôi có thể đảm bảo commit history nhất quán.

#### Acceptance Criteria

1. WHEN diff text được cung cấp, THE Commit_Message_Generator SHALL phân tích và sinh commit message theo format: `type(scope): description`
2. THE Commit_Message_Generator SHALL detect commit type từ diff: `feat` (thêm code mới), `fix` (sửa bug), `refactor`, `test`, `docs`, `chore` (config/deps)
3. THE Commit_Message_Generator SHALL detect scope từ file paths trong diff (ví dụ: `app/tasks/foo.py` → scope = `tasks`)
4. THE Commit_Message_Generator SHALL sinh description ngắn gọn (≤ 72 ký tự) từ tên function/class mới nhất trong diff
5. IF task description được cung cấp thêm, THE Commit_Message_Generator SHALL ưu tiên dùng task description để sinh message chính xác hơn

### Yêu cầu 6: Pipeline Orchestration

**User Story:** Là một AI agent, tôi muốn chạy toàn bộ pipeline từ design doc → code → MR trong một lệnh, để tôi có thể tự động hoá hoàn toàn.

#### Acceptance Criteria

1. WHEN `run_pipeline(design_doc, source_id, branch_name)` được gọi, THE system SHALL: decompose tasks → generate code cho từng task → commit lên branch → tạo MR
2. THE system SHALL trả về `PipelineResult` với: danh sách tasks, generated files, MR URL, tổng thời gian
3. IF bất kỳ bước nào fail, THE system SHALL dừng pipeline và trả về error với context đủ để debug
4. THE system SHALL ghi audit record cho mỗi pipeline run vào `data/logs/cgp_audit.jsonl`

---

## Correctness Properties

### Invariant: Dependency Order
Tasks trong pipeline luôn được thực hiện theo đúng dependency order — không bao giờ thực hiện task B trước task A nếu B depends_on A.

### Invariant: Graceful Degrade
Code Generator luôn trả về kết quả (skeleton hoặc LLM) — không bao giờ raise exception ra ngoài khi LLM fail.

### Error Condition: Branch Conflict
Nếu branch đã tồn tại, pipeline phải fail rõ ràng với `BranchAlreadyExistsError` — không được overwrite branch hiện có.
