# Kế hoạch Triển khai: Code Generation Pipeline

## Tasks

- [x] 1. Thêm LLM config vào `app/core/config.py`
  - Thêm fields: `llm_api_key`, `llm_model`, `llm_timeout`
  - _Yêu cầu: 3.1, 3.3_

- [x] 2. Mở rộng `app/connectors/gitlab.py` với write operations
  - Thêm `_post(path, json)` helper
  - Thêm `get_branch(project_id, branch_name) -> dict | None`
  - Thêm `create_branch(project_id, branch_name, ref) -> dict`
  - Thêm `commit_files(project_id, branch_name, files, message) -> dict`
  - Thêm `create_merge_request(project_id, source_branch, target_branch, title, description) -> dict`
  - _Yêu cầu: 4.1–4.4_

  - [x] 2.1 Viết unit test cho GitLab write operations
    - Test `create_branch` với mock HTTP 201
    - Test `create_branch` khi branch đã tồn tại (409)
    - Test `commit_files` với mock response
    - Test `create_merge_request` với mock response
    - Test `get_branch` trả về None khi 404

- [x] 3. Tạo `app/tasks/code_gen/` package với models
  - `app/tasks/code_gen/__init__.py`
  - `app/tasks/code_gen/models.py`: `CodingTask`, `GeneratedCode`, `MRResult`, `PipelineResult`, `BranchAlreadyExistsError`
  - _Yêu cầu: 1.2, 2.6, 4.6_

  - [x] 3.1 Viết unit test cho models
    - Test dataclass fields và defaults
    - Test `CodingTask` dependency list default empty

- [ ] 4. Checkpoint — GitLab write ops và models pass test
  - Chạy `pytest tests/test_gitlab_write.py tests/test_cgp_models.py -v`

- [x] 5. Tạo `app/tasks/code_gen/decomposer.py`
  - Implement `decompose(design_doc, collection_name) -> list[CodingTask]`
  - Detect task types từ design doc sections bằng regex
  - Suggest `target_file` từ ChromaDB context (graceful degrade nếu không có)
  - Sort tasks theo dependency order: create_file → add_class → add_function → add_endpoint
  - _Yêu cầu: 1.1–1.6_

  - [x] 5.1 Viết unit test cho decomposer
    - Test detect `add_endpoint` từ design doc có route patterns
    - Test detect `add_class` từ design doc có class/model patterns
    - Test dependency order: model tasks trước endpoint tasks
    - Test empty design doc → empty list
    - Test graceful degrade khi ChromaDB không khả dụng

- [x] 6. Tạo `app/tasks/code_gen/generator.py`
  - Implement `generate(task, collection_name, existing_content) -> GeneratedCode`
  - Skeleton mode: templates cho từng task type (create_file, add_function, add_class, add_endpoint)
  - LLM mode: build prompt + call LLM API + parse response
  - Graceful degrade: LLM fail → skeleton mode
  - _Yêu cầu: 2.1–2.6, 3.1–3.5_

  - [x] 6.1 Viết unit test cho generator — skeleton mode
    - Test `create_file` → file có `from __future__ import annotations`
    - Test `add_function` → function có docstring và `raise NotImplementedError`
    - Test `add_class` → class có `__init__` và docstring
    - Test `add_endpoint` → FastAPI route với `raise HTTPException(501)`
    - Test mode = "skeleton" khi không có LLM key

  - [x] 6.2 Viết unit test cho generator — LLM mode
    - Test LLM mode được dùng khi có API key (mock LLM call)
    - Test graceful degrade về skeleton khi LLM raise exception
    - Test mode = "llm" khi LLM thành công

- [x] 7. Tạo `app/tasks/code_gen/commit_message.py`
  - Implement `generate_message(diff, task_description) -> str`
  - Detect type từ diff patterns
  - Detect scope từ file paths
  - Sinh description ≤ 72 ký tự
  - _Yêu cầu: 5.1–5.5_

  - [x] 7.1 Viết unit test cho commit_message
    - Test detect `feat` khi diff thêm function mới
    - Test detect `test` khi diff trong `tests/`
    - Test detect `chore` khi diff trong `requirements.txt`
    - Test scope từ file path `app/tasks/foo.py` → `tasks`
    - Test description ≤ 72 ký tự
    - Test ưu tiên task_description khi được cung cấp

- [ ] 8. Checkpoint — decomposer, generator, commit_message pass test
  - Chạy `pytest tests/test_cgp_decomposer.py tests/test_cgp_generator.py tests/test_cgp_commit_message.py -v`

- [x] 9. Tạo `app/tasks/code_gen/branch_manager.py`
  - Implement `create_branch(source_id, branch_name, from_branch) -> dict`
  - Implement `commit_files(source_id, branch_name, files, message) -> dict`
  - Implement `create_mr(source_id, branch_name, title, description) -> MRResult`
  - Raise `BranchAlreadyExistsError` nếu branch đã tồn tại
  - _Yêu cầu: 4.1–4.6_

  - [x] 9.1 Viết unit test cho branch_manager
    - Test `create_branch` thành công
    - Test `create_branch` raise `BranchAlreadyExistsError` khi branch tồn tại
    - Test `commit_files` với mock connector
    - Test `create_mr` trả về `MRResult` đúng fields

- [x] 10. Tạo `app/tasks/code_gen/pipeline.py`
  - Implement `run_pipeline(design_doc, source_id, branch_name, collection_name, from_branch, trace_id) -> PipelineResult`
  - Orchestrate: decompose → generate → commit → MR
  - Ghi audit record vào `data/logs/cgp_audit.jsonl`
  - _Yêu cầu: 6.1–6.4_

  - [x] 10.1 Viết unit test cho pipeline
    - Test full pipeline với mock connector và mock ChromaDB
    - Test pipeline dừng và trả về error khi branch conflict
    - Test audit record được ghi
    - Test `PipelineResult` có đủ fields

- [ ] 11. Checkpoint — branch_manager và pipeline pass test
  - Chạy `pytest tests/test_cgp_branch_manager.py tests/test_cgp_pipeline.py -v`

- [x] 12. Thêm CGP schemas vào `app/api/schemas.py`
  - `CGPDecomposeRequest`, `CGPGenerateRequest`, `CGPCommitMessageRequest`, `CGPRunPipelineRequest`

- [x] 13. Thêm CGP endpoints vào `app/api/routes.py`
  - `POST /cgp/decompose`
  - `POST /cgp/generate`
  - `POST /cgp/commit-message`
  - `POST /cgp/run-pipeline`
  - _Yêu cầu: 6.1_

  - [x] 13.1 Viết integration test cho CGP endpoints
    - Test `POST /cgp/decompose` với mock decomposer
    - Test `POST /cgp/commit-message` với diff input
    - Test `POST /cgp/run-pipeline` với mock pipeline

- [x] 14. Thêm CGP MCP tools vào `app/mcp_server.py`
  - `cgp_decompose_tasks`, `cgp_generate_code`, `cgp_generate_commit_message`, `cgp_run_pipeline`

- [x] 15. Thêm CGP CLI commands vào `app/cli.py`
  - `cgp-decompose`, `cgp-generate`, `cgp-commit-message`, `cgp-run-pipeline`

- [ ] 16. Checkpoint cuối
  - Chạy `pytest tests/ --ignore=tests/test_brief_enhanced.py --ignore=tests/test_mcp_integration.py --tb=short`
  - Kiểm tra import: `python -c "from app.tasks.code_gen import pipeline; print('OK')"`
