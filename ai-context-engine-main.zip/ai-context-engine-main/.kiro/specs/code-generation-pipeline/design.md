# Tài liệu Thiết kế: Code Generation Pipeline

## Tổng quan

Code Generation Pipeline (CGP) tự động hoá vòng đời coding từ design doc đến MR. Module gồm 4 thành phần chính chạy tuần tự, kết nối với GitLab connector (mở rộng write operations) và ChromaDB context.

### Vị trí trong hệ thống

```
Design Doc (từ Module 2)
        │
        ▼
┌─────────────────────────────────────────────┐
│           Code Generation Pipeline           │
│                                              │
│  Task_Decomposer → [CodingTask list]         │
│        │                                     │
│  Code_Generator (skeleton | LLM)             │
│        │                                     │
│  Commit_Message_Generator                    │
│        │                                     │
│  Branch_Manager → GitLab MR                  │
└─────────────────────────────────────────────┘
        │                    │
        ▼                    ▼
  cgp_audit.jsonl      GitLab MR URL
```

---

## Kiến trúc

### Nguyên tắc

- **Tuần tự, không parallel**: tasks chạy theo dependency order — không parallel như QGE
- **2-mode Code Generator**: skeleton (always available) + LLM (optional, graceful degrade)
- **GitLab write via API**: dùng GitLab REST API v4 — không cần git CLI
- **Stateless functions**: mỗi component là pure function, không giữ state

### Luồng dữ liệu

```mermaid
sequenceDiagram
    participant Agent
    participant CGP as Pipeline Orchestrator
    participant TD as Task_Decomposer
    participant CG as Code_Generator
    participant CMG as Commit_Msg_Generator
    participant BM as Branch_Manager
    participant GL as GitLab API
    participant Chroma as ChromaDB

    Agent->>CGP: run_pipeline(design_doc, source_id, branch_name)
    CGP->>TD: decompose(design_doc, collection)
    TD->>Chroma: search(design_doc, top_k=10)
    Chroma-->>TD: codebase context
    TD-->>CGP: list[CodingTask] (ordered)

    loop for each task
        CGP->>CG: generate(task, context)
        CG->>Chroma: search(task.description, top_k=5)
        Chroma-->>CG: relevant code patterns
        CG-->>CGP: GeneratedCode
    end

    CGP->>CMG: generate_message(diff, task_descriptions)
    CMG-->>CGP: commit_message

    CGP->>BM: create_branch(source_id, branch_name)
    BM->>GL: POST /projects/{id}/repository/branches
    CGP->>BM: commit_files(source_id, branch_name, files, message)
    BM->>GL: POST /projects/{id}/repository/commits
    CGP->>BM: create_mr(source_id, branch_name, title, description)
    BM->>GL: POST /projects/{id}/merge_requests
    GL-->>BM: MR URL
    BM-->>CGP: MRResult
    CGP-->>Agent: PipelineResult
```

---

## Components

### Module structure

```
app/tasks/code_gen/
├── __init__.py
├── models.py           # CodingTask, GeneratedCode, MRResult, PipelineResult
├── decomposer.py       # Task_Decomposer
├── generator.py        # Code_Generator (skeleton + LLM)
├── commit_message.py   # Commit_Message_Generator
├── branch_manager.py   # Branch_Manager (dùng GitLab connector)
└── pipeline.py         # Orchestrator: run_pipeline()
```

### `models.py`

```python
@dataclass
class CodingTask:
    task_id: str
    title: str
    type: str           # "create_file" | "modify_file" | "add_function" | "add_class" | "add_endpoint"
    target_file: str    # đường dẫn file tương đối trong repo
    description: str
    depends_on: list[str] = field(default_factory=list)
    priority: int = 3   # 1 (cao) → 5 (thấp)

@dataclass
class GeneratedCode:
    file_path: str
    content: str
    mode: str           # "skeleton" | "llm"
    language: str = "python"
    task_id: str = ""

@dataclass
class MRResult:
    mr_id: int
    mr_url: str
    branch_name: str
    title: str
    source_id: str

@dataclass
class PipelineResult:
    tasks: list[CodingTask]
    generated_files: list[GeneratedCode]
    mr_result: MRResult | None
    duration_ms: int
    trace_id: str
    errors: list[str] = field(default_factory=list)
```

### `decomposer.py`

Phân tích design doc bằng regex + keyword matching (no LLM):

```python
# Detect task types từ design doc sections
_SECTION_PATTERNS = {
    "add_class":    re.compile(r"class\s+\w+|@dataclass|Model|Schema|Entity", re.I),
    "add_endpoint": re.compile(r"POST|GET|PUT|DELETE|/api/|endpoint|route", re.I),
    "add_function": re.compile(r"def |function|method|implement", re.I),
    "create_file":  re.compile(r"tạo file|create file|new module|new file", re.I),
}

def decompose(design_doc: str, collection_name: str = "knowledge") -> list[CodingTask]:
    """Phân tích design doc → list[CodingTask] đã sắp xếp theo dependency."""
```

**Dependency order logic:**
1. `create_file` tasks trước
2. `add_class` / model tasks trước service tasks
3. `add_endpoint` tasks sau cùng (phụ thuộc vào service)
4. `add_function` / `add_class` trong cùng file → sort theo thứ tự xuất hiện trong doc

**Target file suggestion:** search ChromaDB với task description → lấy `relative_source` từ metadata của top result → đề xuất file path tương tự.

### `generator.py`

```python
def generate(
    task: CodingTask,
    collection_name: str = "knowledge",
    existing_content: str | None = None,
) -> GeneratedCode:
    """Sinh code cho task — tự động chọn skeleton hoặc LLM mode."""
    if _llm_available():
        try:
            return _generate_llm(task, collection_name, existing_content)
        except Exception:
            logger.warning("LLM failed, falling back to skeleton mode")
    return _generate_skeleton(task, collection_name)
```

**Skeleton templates theo task type:**

`create_file`:
```python
"""Module docstring."""
from __future__ import annotations
# imports...
```

`add_function`:
```python
def {name}({args}) -> {return_type}:
    """{description}"""
    raise NotImplementedError
```

`add_class`:
```python
@dataclass  # hoặc class thường tùy convention detect
class {Name}:
    """{description}"""
    # fields...
    def __init__(self) -> None: ...
```

`add_endpoint`:
```python
@router.{method}("{path}")
async def {name}(request: {RequestType}) -> {ResponseType}:
    """{description}"""
    raise HTTPException(status_code=501, detail="Not implemented")
```

**LLM mode:**
- Build system prompt: "You are a Python developer. Generate code following the existing patterns."
- Build user prompt: task description + top 5 context chunks + existing file content
- Call LLM API với timeout 30s
- Parse response: extract code block từ markdown response

**LLM provider detection:**
```python
def _llm_available() -> bool:
    key = settings.llm_api_key
    return bool(key)

def _get_llm_client():
    key = settings.llm_api_key
    if key.startswith("sk-ant-"):  # Anthropic
        return AnthropicClient(key)
    return OpenAIClient(key)  # default OpenAI
```

### `commit_message.py`

```python
_TYPE_PATTERNS = {
    "feat":     re.compile(r"^\+.*def |^\+.*class |^\+.*@router\.", re.M),
    "fix":      re.compile(r"fix|bug|error|issue", re.I),
    "test":     re.compile(r"tests?/|test_\w+\.py"),
    "docs":     re.compile(r"\.md$|docstring|README"),
    "refactor": re.compile(r"refactor|rename|move|extract"),
    "chore":    re.compile(r"requirements\.txt|\.env|config|Dockerfile"),
}

def generate_message(
    diff: str,
    task_description: str | None = None,
) -> str:
    """Sinh conventional commit message từ diff."""
```

**Logic:**
1. Detect `type` từ diff patterns (ưu tiên theo thứ tự: feat > fix > test > docs > refactor > chore)
2. Detect `scope` từ file paths: `app/tasks/foo.py` → `tasks`, `app/api/routes.py` → `api`
3. Sinh `description`: nếu có `task_description` → truncate 72 chars; nếu không → tên function/class mới nhất từ diff
4. Output: `{type}({scope}): {description}`

### `branch_manager.py`

Mở rộng `GitLabConnector` với write operations:

```python
class BranchAlreadyExistsError(Exception): ...

# Thêm vào GitLabConnector:
def create_branch(self, project_id: int, branch_name: str, ref: str) -> dict:
    """POST /projects/{id}/repository/branches"""

def commit_files(
    self,
    project_id: int,
    branch_name: str,
    files: list[dict],   # [{"file_path": ..., "content": ..., "action": "create"|"update"}]
    commit_message: str,
) -> dict:
    """POST /projects/{id}/repository/commits"""

def create_merge_request(
    self,
    project_id: int,
    source_branch: str,
    target_branch: str,
    title: str,
    description: str = "",
) -> dict:
    """POST /projects/{id}/merge_requests"""

def get_branch(self, project_id: int, branch_name: str) -> dict | None:
    """GET /projects/{id}/repository/branches/{branch} — None nếu không tồn tại"""
```

`branch_manager.py` là thin wrapper dùng connector + catalog:

```python
def create_branch(source_id: str, branch_name: str, from_branch: str | None = None) -> dict:
    source = get_source(source_id)
    connector = _get_connector(source)
    project_id = int(source["external_id"])
    ref = from_branch or source.get("default_branch", "main")
    # Check branch không tồn tại
    if connector.get_branch(project_id, branch_name):
        raise BranchAlreadyExistsError(f"Branch '{branch_name}' already exists")
    return connector.create_branch(project_id, branch_name, ref)
```

### `pipeline.py`

```python
def run_pipeline(
    design_doc: str,
    source_id: str,
    branch_name: str,
    collection_name: str = "knowledge",
    from_branch: str | None = None,
    trace_id: str | None = None,
) -> PipelineResult:
    """Chạy toàn bộ pipeline: decompose → generate → commit → MR."""
```

---

## GitLab Connector — Write Operations bổ sung

Thêm vào `app/connectors/gitlab.py`:

```python
def _post(self, path: str, json: dict) -> dict:
    response = self.session.post(f"{self.api_url}{path}", json=json, timeout=30)
    response.raise_for_status()
    return response.json()

def create_branch(self, project_id: int, branch_name: str, ref: str) -> dict: ...
def get_branch(self, project_id: int, branch_name: str) -> dict | None: ...
def commit_files(self, project_id: int, branch_name: str, files: list[dict], message: str) -> dict: ...
def create_merge_request(self, project_id: int, source_branch: str, target_branch: str, title: str, description: str = "") -> dict: ...
```

---

## Config bổ sung (`.env`)

```env
AI_CONTEXT_V2_LLM_API_KEY=sk-...          # OpenAI hoặc sk-ant-... Anthropic
AI_CONTEXT_V2_LLM_MODEL=gpt-4o-mini       # override default model
AI_CONTEXT_V2_LLM_TIMEOUT=30              # seconds
```

---

## API Contract

### REST Endpoints

#### POST `/cgp/decompose`
```
Request: { design_doc, collection, source_id }
Response 200: { tasks: list[CodingTask] }
```

#### POST `/cgp/generate`
```
Request: { task: CodingTask, collection, source_id }
Response 200: { generated: GeneratedCode }
```

#### POST `/cgp/commit-message`
```
Request: { diff, task_description }
Response 200: { message: str }
```

#### POST `/cgp/run-pipeline`
```
Request: { design_doc, source_id, branch_name, collection, from_branch }
Response 200: PipelineResult
Response 422: { error, step, details }
```

### MCP Tools

```python
@mcp.tool()
def cgp_decompose_tasks(design_doc: str, source_id: str, collection: str = "knowledge") -> dict: ...

@mcp.tool()
def cgp_generate_code(task_json: str, source_id: str, collection: str = "knowledge") -> dict: ...

@mcp.tool()
def cgp_generate_commit_message(diff: str, task_description: str = "") -> dict: ...

@mcp.tool()
def cgp_run_pipeline(design_doc: str, source_id: str, branch_name: str, collection: str = "knowledge") -> dict: ...
```

### CLI

```bash
python -m app.cli cgp-decompose "<design_file>" --source-id gitlab:42
python -m app.cli cgp-generate "<task_json_file>" --source-id gitlab:42
python -m app.cli cgp-commit-message "<diff_file>"
python -m app.cli cgp-run-pipeline "<design_file>" --source-id gitlab:42 --branch feature/my-feature
```
