# Tài liệu Yêu cầu: Requirement & Design Engine

## Giới thiệu

Module Requirement & Design Engine là thành phần cốt lõi của AI Context Engine V2, chịu trách nhiệm tự động sinh ra tài liệu yêu cầu (BRD/PRD) và tài liệu thiết kế (HLD/LLD/ERD/OpenAPI) từ intent của người dùng. Module này tích hợp compliance checker tự động theo domain để đảm bảo mọi output đều tuân thủ các quy định pháp luật và tiêu chuẩn kỹ thuật liên quan.

---

## Bảng chú giải

- **Requirement_Generator**: Thành phần AI sinh ra tài liệu yêu cầu từ intent đầu vào
- **Design_Generator**: Thành phần AI sinh ra tài liệu thiết kế từ requirements và codebase context
- **Compliance_Checker**: Thành phần kiểm tra tự động tính tuân thủ của tài liệu theo domain
- **Domain_Detector**: Thành phần phát hiện domain từ nội dung intent/requirement
- **Intent**: Mô tả yêu cầu nghiệp vụ đầu vào từ người dùng
- **Compliance_Clause**: Điều khoản tuân thủ bắt buộc được inject vào tài liệu theo domain
- **Compliance_Report**: Báo cáo kết quả kiểm tra compliance, bao gồm danh sách vi phạm và cảnh báo
- **Domain**: Lĩnh vực nghiệp vụ được phát hiện (nhà thuốc, xét nghiệm, tiêm chủng, thanh toán, thiết bị y tế, an toàn thông tin)
- **Retention_Period**: Thời hạn lưu trữ dữ liệu tối thiểu theo quy định pháp luật
- **Rx**: Thuốc kê đơn (prescription drug) theo phân loại của Bộ Y tế

---

## Yêu cầu

### Yêu cầu 1: Requirement Generator

**User Story:** Là một product owner, tôi muốn AI tự động sinh ra tài liệu yêu cầu chuẩn từ mô tả intent, để tôi có thể tiết kiệm thời gian và đảm bảo chất lượng tài liệu.

#### Acceptance Criteria

1. WHEN người dùng cung cấp intent đầu vào, THE Requirement_Generator SHALL phân tích intent và sinh ra tài liệu requirements.md theo chuẩn EARS và INCOSE trong vòng 30 giây
2. THE Requirement_Generator SHALL sinh ra ít nhất một user story cho mỗi nhóm chức năng được xác định từ intent
3. WHEN tài liệu yêu cầu được sinh ra, THE Requirement_Generator SHALL đảm bảo mỗi acceptance criteria tuân theo đúng một trong sáu mẫu EARS (Ubiquitous, Event-driven, State-driven, Unwanted event, Optional feature, Complex)
4. IF intent đầu vào chứa mô tả mơ hồ hoặc thiếu thông tin, THEN THE Requirement_Generator SHALL sinh ra tài liệu với các giả định rõ ràng và đánh dấu các điểm cần làm rõ
5. THE Requirement_Generator SHALL sinh ra Glossary định nghĩa tất cả thuật ngữ kỹ thuật và tên hệ thống được sử dụng trong tài liệu
6. WHEN tài liệu yêu cầu được sinh ra, THE Compliance_Checker SHALL tự động kiểm tra và báo cáo compliance theo domain được phát hiện trước khi trả kết quả cho người dùng

### Yêu cầu 2: Design Generator

**User Story:** Là một software architect, tôi muốn AI tự động sinh ra tài liệu thiết kế từ requirements và codebase context, để tôi có thể đảm bảo thiết kế nhất quán với kiến trúc hiện tại.

#### Acceptance Criteria

1. WHEN requirements.md được cung cấp, THE Design_Generator SHALL sinh ra tài liệu thiết kế bao gồm HLD, LLD, ERD và OpenAPI spec trong vòng 60 giây
2. THE Design_Generator SHALL truy xuất codebase context từ ChromaDB để đảm bảo thiết kế nhất quán với kiến trúc hiện tại
3. WHEN tài liệu thiết kế được sinh ra, THE Compliance_Checker SHALL tự động kiểm tra sự hiện diện của data retention policy, threat model, data flow diagram, backup & recovery strategy
4. IF hệ thống được thiết kế là hệ thống y tế, THEN THE Design_Generator SHALL bao gồm phân quyền truy cập theo chức danh (bác sĩ, dược sĩ, điều dưỡng, admin)
5. THE Design_Generator SHALL sinh ra data flow diagram thể hiện luồng dữ liệu nhạy cảm qua các thành phần hệ thống
6. THE Design_Generator SHALL sinh ra threat model cơ bản xác định các vector tấn công tiềm năng và biện pháp phòng thủ tương ứng
7. THE Design_Generator SHALL sinh ra backup & recovery strategy đáp ứng RTO và RPO được xác định trong requirements

### Yêu cầu 3: Domain Detector

**User Story:** Là một AI engine, tôi muốn tự động phát hiện domain từ nội dung intent để áp dụng đúng compliance checklist, để tôi có thể đảm bảo mọi tài liệu đều tuân thủ quy định pháp luật liên quan.

#### Acceptance Criteria

1. WHEN intent hoặc requirement chứa từ khoá nhà thuốc (thuốc, dược, kê đơn, pharmacy, drug, prescription), THE Domain_Detector SHALL phân loại domain là PHARMACY và kích hoạt compliance checklist Luật Dược 2016
2. WHEN intent hoặc requirement chứa từ khoá xét nghiệm (xét nghiệm, bệnh án, lab, test result, medical record), THE Domain_Detector SHALL phân loại domain là LAB_EMR và kích hoạt compliance checklist Nghị định 96/2023 và Thông tư 27/2021
3. WHEN intent hoặc requirement chứa từ khoá tiêm chủng (tiêm, vắc xin, vaccine, immunization), THE Domain_Detector SHALL phân loại domain là VACCINATION và kích hoạt compliance checklist Thông tư 09/2023
4. WHEN intent hoặc requirement chứa từ khoá thanh toán (thanh toán, payment, thẻ, card, POS), THE Domain_Detector SHALL phân loại domain là PAYMENT và kích hoạt compliance checklist PCI-DSS
5. WHEN intent hoặc requirement chứa từ khoá thiết bị (thiết bị, device, IoT, sensor, monitor), THE Domain_Detector SHALL phân loại domain là MEDICAL_DEVICE và kích hoạt compliance checklist QCVN 117:2020
6. WHEN nhiều domain được phát hiện trong cùng một intent, THE Domain_Detector SHALL kích hoạt tất cả compliance checklist tương ứng và merge các compliance clause không trùng lặp
7. WHEN domain được phát hiện, THE Requirement_Generator SHALL tự động inject compliance requirements tương ứng vào tài liệu trước khi trả kết quả

### Yêu cầu 4: Compliance Checker cho Requirement Generator

**User Story:** Là một compliance officer, tôi muốn AI tự động kiểm tra tài liệu yêu cầu theo domain, để tôi có thể đảm bảo mọi requirement đều tuân thủ quy định pháp luật trước khi đưa vào phát triển.

#### Acceptance Criteria

**Nhà thuốc / Dược phẩm (Luật Dược 2016):**

1. WHEN requirement liên quan đến bán thuốc được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản validation kê đơn Rx; IF điều khoản này vắng mặt, THEN THE Compliance_Checker SHALL fail compliance check và trả về cảnh báo cụ thể: "PHARMACY-001: Thiếu điều khoản validation kê đơn Rx cho requirement bán thuốc"
2. WHEN requirement liên quan đến lưu trữ giao dịch thuốc được sinh ra, THE Compliance_Checker SHALL xác minh thời hạn lưu trữ được ghi rõ tối thiểu 5 năm theo Luật Dược 2016
3. WHEN requirement liên quan đến thông tin thuốc được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản đối chiếu danh mục Bộ Y tế
4. WHEN requirement liên quan đến ADR (Adverse Drug Reaction) được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản báo cáo định kỳ lên cơ quan quản lý

**Xét nghiệm / Bệnh án điện tử (Nghị định 96/2023, Thông tư 27/2021):**

5. WHEN requirement liên quan đến hồ sơ bệnh án được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản audit trail và chữ ký số theo Nghị định 96/2023
6. WHEN requirement liên quan đến lưu trữ bệnh án được sinh ra, THE Compliance_Checker SHALL xác minh thời hạn lưu trữ được ghi rõ: tối thiểu 10 năm cho người lớn và 15 năm cho trẻ em theo Thông tư 27/2021
7. WHEN requirement liên quan đến kết quả xét nghiệm được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản giá trị tham chiếu và đơn vị đo chuẩn
8. WHEN requirement liên quan đến chia sẻ dữ liệu y tế được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản tuân thủ HL7 FHIR

**Tiêm chủng (Thông tư 09/2023):**

9. WHEN requirement liên quan đến tiêm chủng được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản kết nối hệ thống tiêm chủng quốc gia theo Thông tư 09/2023
10. WHEN requirement liên quan đến lịch tiêm được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản cảnh báo chống chỉ định tự động
11. WHEN requirement liên quan đến lưu trữ lịch sử tiêm được sinh ra, THE Compliance_Checker SHALL xác minh thời hạn lưu trữ được ghi rõ tối thiểu 20 năm theo Thông tư 09/2023

**Thanh toán (PCI-DSS):**

12. WHEN requirement liên quan đến thanh toán được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản không lưu CVV và full PAN sau khi giao dịch hoàn thành
13. WHEN requirement liên quan đến dữ liệu thẻ được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản mã hoá AES-256
14. WHEN requirement liên quan đến môi trường thanh toán được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản network segmentation theo PCI-DSS

**Thiết bị y tế thông minh (QCVN 117:2020):**

15. WHEN requirement liên quan đến thiết bị IoT y tế được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản timestamp NTP và outlier detection theo QCVN 117:2020
16. WHEN requirement liên quan đến firmware thiết bị y tế được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản secure OTA update

**An toàn thông tin (Luật ATTTM 2015, ISO 27001):**

17. WHEN requirement liên quan đến hệ thống cấp độ 3 được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản RTO ≤ 4 giờ và RPO ≤ 1 giờ theo Luật ATTTM 2015
18. WHEN requirement liên quan đến sự cố bảo mật được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản báo cáo VNCERT/CC trong vòng 24 giờ
19. WHEN requirement liên quan đến dữ liệu cá nhân được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của điều khoản thông báo vi phạm dữ liệu trong vòng 72 giờ theo Nghị định 13/2023

### Yêu cầu 5: Compliance Checker cho Design Generator

**User Story:** Là một software architect, tôi muốn AI tự động kiểm tra tài liệu thiết kế theo các tiêu chuẩn bắt buộc, để tôi có thể đảm bảo thiết kế đáp ứng đầy đủ yêu cầu bảo mật và compliance trước khi triển khai.

#### Acceptance Criteria

1. WHEN tài liệu thiết kế được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của data retention policy cho từng loại dữ liệu theo bảng thời hạn lưu trữ trong standards.md
2. WHEN tài liệu thiết kế được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của threat model cơ bản bao gồm ít nhất: danh sách tác nhân đe doạ, vector tấn công và biện pháp phòng thủ
3. WHEN tài liệu thiết kế được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của data flow diagram thể hiện luồng dữ liệu nhạy cảm
4. WHEN tài liệu thiết kế được sinh ra, THE Compliance_Checker SHALL xác minh sự hiện diện của backup & recovery strategy với RTO và RPO được định nghĩa rõ ràng
5. IF tài liệu thiết kế mô tả hệ thống y tế, THEN THE Compliance_Checker SHALL xác minh sự hiện diện của phân quyền truy cập theo chức danh bao gồm ít nhất: bác sĩ, dược sĩ, điều dưỡng và admin
6. IF bất kỳ kiểm tra nào trong các tiêu chí trên thất bại, THEN THE Compliance_Checker SHALL sinh ra Compliance_Report liệt kê đầy đủ các mục còn thiếu với mã lỗi và hướng dẫn khắc phục cụ thể

### Yêu cầu 6: Confluence Writer

**User Story:** Là một product owner, tôi muốn AI tự động tạo và cập nhật trang Confluence từ tài liệu requirements và design, để tôi có thể duy trì tài liệu dự án luôn đồng bộ.

#### Acceptance Criteria

1. WHEN tài liệu requirements.md hoặc design.md được sinh ra và xác nhận, THE Confluence_Writer SHALL tự động tạo hoặc cập nhật trang Confluence tương ứng trong vòng 10 giây
2. THE Confluence_Writer SHALL duy trì lịch sử phiên bản trên Confluence để có thể rollback về phiên bản trước
3. IF kết nối Confluence không khả dụng, THEN THE Confluence_Writer SHALL lưu tài liệu vào hàng đợi và thử lại sau tối đa 3 lần với khoảng cách 30 giây giữa các lần thử
4. WHEN trang Confluence được tạo hoặc cập nhật, THE Confluence_Writer SHALL ghi audit log bao gồm: timestamp, user, action, page_id và nội dung thay đổi

### Yêu cầu 7: Impact Analyzer

**User Story:** Là một software architect, tôi muốn AI xác định các service bị ảnh hưởng khi có requirement mới, để tôi có thể lập kế hoạch triển khai và kiểm thử phù hợp.

#### Acceptance Criteria

1. WHEN requirement mới được sinh ra, THE Impact_Analyzer SHALL phân tích codebase context và xác định danh sách service bị ảnh hưởng trong vòng 15 giây
2. THE Impact_Analyzer SHALL phân loại mức độ ảnh hưởng theo ba cấp: HIGH (thay đổi interface/schema), MEDIUM (thay đổi logic), LOW (thay đổi cấu hình)
3. WHEN impact analysis hoàn thành, THE Impact_Analyzer SHALL sinh ra impact report bao gồm: danh sách service, mức độ ảnh hưởng, file liên quan và đề xuất test strategy
4. IF requirement mới mâu thuẫn với requirement hiện có, THEN THE Impact_Analyzer SHALL phát hiện và báo cáo conflict với mô tả cụ thể về điểm mâu thuẫn

---

## Correctness Properties

### Invariant: Compliance Injection

Với mọi requirement document có domain được phát hiện bởi Domain_Detector, document phải chứa ít nhất một compliance clause tương ứng với mỗi domain được phát hiện. Tính chất này phải được duy trì bất kể thứ tự xử lý các domain hay số lượng domain được phát hiện.

Hình thức: `∀ doc, domain ∈ detected_domains(doc) → ∃ clause ∈ doc.compliance_clauses : clause.domain = domain`

### Invariant: Data Retention

Với mọi requirement liên quan đến lưu trữ dữ liệu y tế, thời hạn lưu trữ được ghi trong document phải lớn hơn hoặc bằng thời hạn tối thiểu theo pháp luật tương ứng:
- Giao dịch thuốc: ≥ 5 năm (Luật Dược 2016)
- Bệnh án người lớn: ≥ 10 năm (Thông tư 27/2021)
- Bệnh án trẻ em: ≥ 15 năm (Thông tư 27/2021)
- Lịch sử tiêm chủng: ≥ 20 năm (Thông tư 09/2023)

Hình thức: `∀ req ∈ storage_requirements(doc) : req.retention_period ≥ legal_minimum(req.data_type)`

### Error Condition: Rx Drug Without Prescription Validation

Requirement liên quan đến bán thuốc Rx mà không có điều khoản validation kê đơn phải bị phát hiện bởi Compliance_Checker. Khi điều kiện này xảy ra, Compliance_Checker phải fail và trả về cảnh báo cụ thể với mã lỗi PHARMACY-001, không được tiếp tục sinh ra tài liệu thiết kế cho đến khi vi phạm được khắc phục.

Hình thức: `∀ req : is_rx_sale(req) ∧ ¬has_prescription_validation(req) → compliance_check(req) = FAIL("PHARMACY-001")`
