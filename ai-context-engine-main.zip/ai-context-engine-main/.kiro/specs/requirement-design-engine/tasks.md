# Kế hoạch Triển khai: Requirement & Design Engine

## Tổng quan

Triển khai Module 2 của Intent → Impact Pipeline. Các bước xây dựng tuần tự từ domain detection → compliance checking → requirement/design generation → impact analysis → confluence writer → wiring API + CLI + MCP.

## Tasks

- [x] 1. Tạo `app/tasks/domain_detector.py` — phát hiện domain từ text
  - Định nghĩa dataclass `ComplianceClause` và `DomainDetectionResult`
  - Implement hàm `detect_domains(text: str) -> DomainDetectionResult` với keyword scoring (threshold ≥ 0.3)
  - Mapping đầy đủ 6 domain: PHARMACY, LAB_EMR, VACCINATION, PAYMENT, MEDICAL_DEVICE, INFOSEC
  - Xử lý multi-domain: merge compliance clauses không trùng lặp
  - _Yêu cầu: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7_

  - [x] 1.1 Viết property test cho domain detector
    - **Property 1: Compliance Injection Invariant** — với mọi domain được phát hiện, phải có ít nhất một compliance clause tương ứng
    - **Validates: Yêu cầu 3.6, 3.7 và Invariant "Compliance Injection"**

  - [x] 1.2 Viết unit test cho domain detector
    - Test từng domain với keyword VI và EN
    - Test multi-domain merge không trùng lặp
    - Test text không khớp domain nào → danh sách rỗng
    - _Yêu cầu: 3.1, 3.2, 3.3, 3.4, 3.5_

- [x] 2. Tạo `app/tasks/compliance_checker.py` — kiểm tra compliance tài liệu
  - Định nghĩa dataclass `ComplianceViolation` và `ComplianceReport`
  - Implement `check_requirements(doc: str, domains: list[str]) -> ComplianceReport`
  - Implement `check_design(doc: str, domains: list[str]) -> ComplianceReport`
  - Implement đầy đủ 19 error codes cho requirements (PHARMACY-001..004, LAB-001..004, VAC-001..003, PAY-001..003, DEV-001..002, SEC-001..003)
  - Implement 5 error codes cho design (DESIGN-001..005)
  - _Yêu cầu: 4.1–4.19, 5.1–5.6_

  - [x] 2.1 Viết property test cho compliance checker
    - **Property 2: Rx Drug Without Prescription Validation** — mọi requirement bán thuốc Rx mà thiếu validation kê đơn phải fail với mã PHARMACY-001
    - **Validates: Yêu cầu 4.1 và Error Condition "Rx Drug Without Prescription Validation"**

  - [x] 2.2 Viết property test cho data retention
    - **Property 3: Data Retention Invariant** — thời hạn lưu trữ trong document phải ≥ legal minimum theo từng loại dữ liệu
    - **Validates: Yêu cầu 4.2, 4.6, 4.11 và Invariant "Data Retention"**

  - [x] 2.3 Viết unit test cho compliance checker
    - Test từng violation code với document mẫu có/không có điều khoản tương ứng
    - Test `check_design` với các trường hợp thiếu threat model, data flow diagram, backup strategy
    - _Yêu cầu: 4.1–4.19, 5.1–5.6_

- [x] 3. Checkpoint — Đảm bảo tất cả test pass cho domain_detector và compliance_checker
  - Chạy `pytest tests/test_domain_detector.py tests/test_compliance_checker.py -v`
  - Đảm bảo tất cả test pass, hỏi người dùng nếu có vấn đề phát sinh.

- [x] 4. Tạo `app/tasks/requirement_generator.py` — sinh BRD/PRD từ intent
  - Định nghĩa dataclass `RequirementGeneratorResult`
  - Implement `generate_requirements(intent, collection_name, top_k, trace_id) -> RequirementGeneratorResult`
  - Tích hợp `detect_domains` → inject compliance clauses vào document
  - Tích hợp ChromaDB search để lấy codebase context (top_k=10)
  - Sinh document theo template chuẩn: Giới thiệu, Bảng chú giải, Yêu cầu (EARS format), Compliance Requirements, Correctness Properties
  - Gọi `check_requirements` sau khi sinh xong, đính kèm compliance_report vào result
  - Ghi audit record vào `data/logs/rde_audit.jsonl` (không chứa PII)
  - _Yêu cầu: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6_

  - [x] 4.1 Viết unit test cho requirement generator
    - Test với mock ChromaDB và mock LLM response
    - Test compliance clauses được inject đúng theo domain
    - Test audit record được ghi sau mỗi lần generate
    - _Yêu cầu: 1.1, 1.5, 1.6_

- [x] 5. Tạo `app/tasks/impact_analyzer.py` — phân tích impact lên codebase
  - Định nghĩa dataclass `ImpactedService` và `ImpactReport`
  - Implement `analyze_impact(requirements_doc, collection_name, top_k, trace_id) -> ImpactReport`
  - Phân loại impact level: HIGH (interface/schema), MEDIUM (logic), LOW (config)
  - Phát hiện conflict giữa requirement mới và requirement hiện có
  - _Yêu cầu: 7.1, 7.2, 7.3, 7.4_

  - [x] 5.1 Viết unit test cho impact analyzer
    - Test phân loại HIGH/MEDIUM/LOW với mock ChromaDB results
    - Test phát hiện conflict requirement
    - _Yêu cầu: 7.2, 7.4_

- [x] 6. Tạo `app/tasks/design_generator.py` — sinh HLD/LLD/ERD/OpenAPI
  - Định nghĩa dataclass `DesignGeneratorResult`
  - Implement `generate_design(requirements_doc, collection_name, top_k, trace_id) -> DesignGeneratorResult`
  - Tích hợp ChromaDB search để lấy codebase context (top_k=15)
  - Sinh document theo template chuẩn: Tổng quan, Kiến trúc (Mermaid), Components, ERD, Data Flow Diagram, Threat Model, Phân quyền (nếu healthcare), Data Retention Policy, Backup & Recovery, API Contract, Error Handling, Testing Strategy
  - Gọi `check_design` sau khi sinh xong, đính kèm compliance_report
  - Gọi `analyze_impact` và đính kèm impact_report
  - Ghi audit record vào `data/logs/rde_audit.jsonl`
  - _Yêu cầu: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7_

  - [x] 6.1 Viết unit test cho design generator
    - Test với mock ChromaDB và mock LLM response
    - Test healthcare domain → phân quyền theo chức danh được sinh ra
    - Test compliance_report và impact_report được đính kèm đúng
    - _Yêu cầu: 2.3, 2.4_

- [x] 7. Bổ sung methods vào `app/connectors/confluence.py`
  - Thêm `create_page(space_key, title, body_storage, parent_id) -> dict`
  - Thêm `update_page(page_id, title, body_storage, version_number, minor_edit) -> dict`
  - Thêm `search_pages(cql, limit) -> list[dict]`
  - Implement markdown → Confluence Storage Format converter (dùng thư viện `markdown` + post-processing)
  - _Yêu cầu: 6.1, 6.2_

  - [x] 7.1 Viết unit test cho confluence connector methods mới
    - Test `create_page` và `update_page` với mock HTTP responses
    - Test markdown → Storage Format conversion cho headings, code blocks, tables
    - _Yêu cầu: 6.1_

- [x] 8. Tạo `app/tasks/confluence_writer.py` — publish document lên Confluence
  - Định nghĩa dataclass `ConfluenceWriteResult`
  - Implement `write_document(title, content_markdown, space_key, parent_page_id, existing_page_id, actor, trace_id) -> ConfluenceWriteResult`
  - Implement retry policy: tối đa 3 lần, delay 30s, lưu queue vào `data/logs/confluence_write_queue.jsonl` khi thất bại
  - Ghi audit log: timestamp, user, action, page_id, nội dung thay đổi vào `data/logs/rde_audit.jsonl`
  - _Yêu cầu: 6.1, 6.2, 6.3, 6.4_

  - [x] 8.1 Viết unit test cho confluence writer
    - Test retry logic khi Confluence không khả dụng (mock connection error)
    - Test audit log được ghi đúng format sau mỗi write
    - Test lưu vào queue khi thất bại sau 3 lần retry
    - _Yêu cầu: 6.3, 6.4_

- [x] 9. Checkpoint — Đảm bảo tất cả test pass cho các task module mới
  - Chạy `pytest tests/ -v`
  - Đảm bảo tất cả test pass, hỏi người dùng nếu có vấn đề phát sinh.

- [x] 10. Thêm Pydantic schemas vào `app/api/schemas.py`
  - Thêm `RDEGenerateRequirementsRequest` và response schema
  - Thêm `RDEGenerateDesignRequest` và response schema
  - Thêm `RDEAnalyzeImpactRequest` và response schema
  - Thêm `RDECheckComplianceRequest` và response schema
  - _Yêu cầu: 1.1, 2.1, 7.1_

- [x] 11. Thêm RDE endpoints vào `app/api/routes.py`
  - Implement `POST /rde/generate-requirements` — gọi `generate_requirements`, trả về requirements_doc + compliance_report, publish Confluence nếu được yêu cầu
  - Implement `POST /rde/generate-design` — gọi `generate_design`, trả về design_doc + compliance_report + impact_report + confluence_url
  - Implement `POST /rde/analyze-impact` — gọi `analyze_impact`
  - Implement `POST /rde/check-compliance` — gọi `check_requirements` hoặc `check_design` theo `document_type`
  - Tất cả endpoints dùng `asyncio.to_thread()` để non-blocking
  - Trả về HTTP 422 khi compliance check fail
  - _Yêu cầu: 1.1, 1.6, 2.1, 2.3, 5.6, 7.1_

  - [x] 11.1 Viết integration test cho RDE endpoints
    - Test `POST /rde/generate-requirements` với mock generator
    - Test HTTP 422 khi compliance fail
    - Test `POST /rde/check-compliance` với document_type = "requirements" và "design"
    - _Yêu cầu: 1.6, 5.6_

- [x] 12. Thêm RDE MCP tools vào `app/mcp_server.py`
  - Thêm `rde_generate_requirements(intent, collection)` MCP tool
  - Thêm `rde_generate_design(requirements_doc, collection)` MCP tool
  - Thêm `rde_analyze_impact(requirements_doc, collection)` MCP tool
  - Thêm `rde_check_compliance(document, document_type, domains)` MCP tool
  - Thêm `rde_publish_to_confluence(title, content, space_key, parent_page_id)` MCP tool
  - _Yêu cầu: 1.1, 2.1, 6.1, 7.1_

- [x] 13. Thêm RDE CLI commands vào `app/cli.py`
  - Thêm command `rde-requirements "<intent>"` với options `--collection`, `--publish`, `--space`
  - Thêm command `rde-design "<requirements_file_path>"` với options `--publish`, `--space`
  - Thêm command `rde-impact "<requirements_file_path>"`
  - Thêm command `rde-check-compliance "<doc_file_path>"` với option `--type requirements|design`
  - _Yêu cầu: 1.1, 2.1, 6.1, 7.1_

- [x] 14. Mở rộng `app/core/config.py` với RDE settings
  - Thêm `rde_audit_log_path` trỏ đến `data/logs/rde_audit.jsonl`
  - Thêm `confluence_write_queue_path` trỏ đến `data/logs/confluence_write_queue.jsonl`
  - Thêm `rde_llm_model`, `rde_requirement_timeout_s = 30`, `rde_design_timeout_s = 60`
  - _Yêu cầu: 1.1, 2.1_

- [x] 15. Checkpoint cuối — Đảm bảo toàn bộ hệ thống hoạt động đúng
  - Chạy `pytest tests/ -v --tb=short`
  - Kiểm tra tất cả import không bị lỗi: `python -c "from app.tasks import domain_detector, compliance_checker, requirement_generator, design_generator, impact_analyzer, confluence_writer"`
  - Đảm bảo tất cả test pass, hỏi người dùng nếu có vấn đề phát sinh.

## Ghi chú

- Tasks đánh dấu `*` là optional, có thể bỏ qua để ra MVP nhanh hơn
- Mỗi task tham chiếu đến yêu cầu cụ thể trong `requirements.md` để đảm bảo traceability
- Checkpoints đảm bảo validate incremental trước khi tiếp tục
- Property tests validate các invariant quan trọng được định nghĩa trong `requirements.md`
