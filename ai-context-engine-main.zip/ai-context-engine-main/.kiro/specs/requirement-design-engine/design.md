# Tài liệu Thiết kế: Requirement & Design Engine

## Tổng quan

Requirement & Design Engine (RDE) là Module 2 trong roadmap Intent → Impact Pipeline của AI Context Engine V2. Module này tự động hoá toàn bộ vòng đời tài liệu kỹ thuật: từ intent thô của người dùng → BRD/PRD chuẩn EARS → HLD/LLD/ERD/OpenAPI spec → trang Confluence được cập nhật tự động.

RDE tích hợp chặt chẽ với hạ tầng hiện có: ChromaDB (context retrieval), Jira connector (traceability), Confluence connector (publish), và AI Quality Gate pattern (compliance enforcement).

### Vị trí trong hệ thống

```
Intent (text)
     │
     ▼
┌─────────────────────────────────────────────────────────┐
│                  Requirement & Design Engine             │
│                                                         │
│  Domain_Detector → Requirement_Generator → Compliance   │
│                          │                   Checker    │
│                          ▼                              │
│               Design_Generator ──────────────────────── │
│                          │                              │
│               Impact_Analyzer                           │
│                          │                              │
│               Confluence_Writer                         │
└─────────────────────────────────────────────────────────┘
     │                    │                    │
     ▼                    ▼                    ▼
  Jira Tickets      ChromaDB              Confluence Pages
  (traceability)    (context)             (documentation)
```


## Kiến trúc

### Luồng dữ liệu chính

```mermaid
sequenceDiagram
    participant User
    participant API as FastAPI / MCP
    participant DD as Domain_Detector
    participant RG as Requirement_Generator
    participant CC as Compliance_Checker
    participant DG as Design_Generator
    participant IA as Impact_Analyzer
    participant CW as Confluence_Writer
    participant Chroma as ChromaDB

    User->>API: POST /rde/generate-requirements {intent}
    API->>DD: detect_domains(intent)
    DD-->>API: domains[], compliance_clauses[]
    API->>RG: generate(intent, domains, clauses)
    RG->>Chroma: search(intent, top_k=10)
    Chroma-->>RG: context chunks
    RG-->>API: requirements_doc (draft)
    API->>CC: check_requirements(doc, domains)
    CC-->>API: compliance_report
    API-->>User: {requirements_doc, compliance_report}

    User->>API: POST /rde/generate-design {requirements_doc}
    API->>DG: generate(requirements_doc)
    DG->>Chroma: search(requirements, top_k=15)
    Chroma-->>DG: codebase context
    DG-->>API: design_doc (draft)
    API->>CC: check_design(design_doc, domains)
    CC-->>API: compliance_report
    API->>IA: analyze_impact(requirements_doc)
    IA->>Chroma: search(services, top_k=10)
    IA-->>API: impact_report
    API->>CW: publish(design_doc, space_key, parent_id)
    CW-->>API: {page_id, page_url, version}
    API-->>User: {design_doc, compliance_report, impact_report, confluence_url}
```

### Nguyên tắc kiến trúc

- **Async non-blocking**: mọi generation task chạy qua `asyncio.to_thread()` — không block event loop FastAPI
- **Stateless tasks**: mỗi module trong `app/tasks/` là pure function, không giữ state giữa các lần gọi
- **Orchestration qua service.py**: `app/sync/service.py` là lớp orchestration duy nhất — API routes và CLI đều gọi vào đây
- **Audit trail bắt buộc**: mọi thao tác ghi (Confluence write, compliance fail) đều ghi vào `data/logs/rde_audit.jsonl`
- **No PII in logs**: tất cả log chỉ chứa trace_id, action type, và metadata không nhạy cảm


## Components và Interfaces

### 1. `app/tasks/domain_detector.py`

Phát hiện domain từ text input bằng keyword scoring. Không gọi LLM — pure Python để đảm bảo tốc độ < 5ms.

```python
@dataclass
class DomainDetectionResult:
    domains: list[str]           # ["PHARMACY", "PAYMENT"]
    scores: dict[str, float]     # {"PHARMACY": 0.9, "PAYMENT": 0.6}
    compliance_clauses: list[ComplianceClause]
    detected_at: str             # ISO 8601 UTC

def detect_domains(text: str) -> DomainDetectionResult: ...
```

**Keyword mapping** (scoring: mỗi keyword match +0.3, threshold ≥ 0.3 để activate domain):

| Domain | Keywords (VI) | Keywords (EN) | Compliance |
|--------|--------------|---------------|------------|
| PHARMACY | thuốc, dược, kê đơn, nhà thuốc, dược sĩ | drug, pharmacy, prescription, Rx | Luật Dược 2016 |
| LAB_EMR | xét nghiệm, bệnh án, hồ sơ bệnh nhân | lab, medical record, EMR, test result | NĐ 96/2023, TT 27/2021 |
| VACCINATION | tiêm, vắc xin, tiêm chủng | vaccine, immunization, vaccination | TT 09/2023 |
| PAYMENT | thanh toán, thẻ, POS, giao dịch | payment, card, transaction, PCI | PCI-DSS |
| MEDICAL_DEVICE | thiết bị, IoT, cảm biến, monitor | device, IoT, sensor, wearable | QCVN 117:2020 |
| INFOSEC | bảo mật, an toàn thông tin, sự cố | security, incident, VNCERT | Luật ATTTM 2015 |

### 2. `app/tasks/compliance_checker.py`

Kiểm tra tài liệu requirements hoặc design theo domain rules. Trả về `ComplianceReport` với danh sách violations và warnings.

```python
@dataclass
class ComplianceViolation:
    code: str           # "PHARMACY-001"
    severity: str       # "ERROR" | "WARNING"
    message: str        # mô tả vi phạm
    section: str        # section trong document bị vi phạm
    remediation: str    # hướng dẫn khắc phục

@dataclass
class ComplianceReport:
    passed: bool
    domains_checked: list[str]
    violations: list[ComplianceViolation]
    warnings: list[ComplianceViolation]
    checked_at: str

def check_requirements(doc: str, domains: list[str]) -> ComplianceReport: ...
def check_design(doc: str, domains: list[str]) -> ComplianceReport: ...
```

**Error code schema**: `{DOMAIN}-{NNN}` — ví dụ `PHARMACY-001`, `LAB-002`, `PAYMENT-001`

| Code | Domain | Mô tả |
|------|--------|-------|
| PHARMACY-001 | PHARMACY | Thiếu điều khoản validation kê đơn Rx |
| PHARMACY-002 | PHARMACY | Thời hạn lưu trữ giao dịch thuốc < 5 năm |
| PHARMACY-003 | PHARMACY | Thiếu đối chiếu danh mục Bộ Y tế |
| PHARMACY-004 | PHARMACY | Thiếu điều khoản báo cáo ADR |
| LAB-001 | LAB_EMR | Thiếu audit trail và chữ ký số (NĐ 96/2023) |
| LAB-002 | LAB_EMR | Thời hạn lưu trữ bệnh án < 10 năm (người lớn) hoặc < 15 năm (trẻ em) |
| LAB-003 | LAB_EMR | Thiếu giá trị tham chiếu và đơn vị đo chuẩn |
| LAB-004 | LAB_EMR | Thiếu điều khoản tuân thủ HL7 FHIR |
| VAC-001 | VACCINATION | Thiếu kết nối hệ thống tiêm chủng quốc gia (TT 09/2023) |
| VAC-002 | VACCINATION | Thiếu cảnh báo chống chỉ định tự động |
| VAC-003 | VACCINATION | Thời hạn lưu trữ lịch sử tiêm < 20 năm |
| PAY-001 | PAYMENT | Thiếu điều khoản không lưu CVV/full PAN |
| PAY-002 | PAYMENT | Thiếu mã hoá AES-256 cho dữ liệu thẻ |
| PAY-003 | PAYMENT | Thiếu network segmentation (PCI-DSS) |
| DEV-001 | MEDICAL_DEVICE | Thiếu timestamp NTP và outlier detection (QCVN 117:2020) |
| DEV-002 | MEDICAL_DEVICE | Thiếu secure OTA update |
| SEC-001 | INFOSEC | Thiếu RTO ≤ 4h / RPO ≤ 1h (Luật ATTTM 2015) |
| SEC-002 | INFOSEC | Thiếu báo cáo VNCERT/CC trong 24h |
| SEC-003 | INFOSEC | Thiếu thông báo vi phạm dữ liệu trong 72h (NĐ 13/2023) |
| DESIGN-001 | ALL | Thiếu data retention policy |
| DESIGN-002 | ALL | Thiếu threat model |
| DESIGN-003 | ALL | Thiếu data flow diagram |
| DESIGN-004 | ALL | Thiếu backup & recovery strategy với RTO/RPO |
| DESIGN-005 | HEALTHCARE | Thiếu phân quyền theo chức danh y tế |


### 3. `app/tasks/requirement_generator.py`

Sinh BRD/PRD từ intent, sử dụng ChromaDB context và compliance clauses từ Domain_Detector.

```python
@dataclass
class RequirementGeneratorResult:
    document: str               # markdown content
    domains: list[str]
    compliance_report: ComplianceReport
    context_chunks_used: int
    generated_at: str
    trace_id: str

def generate_requirements(
    intent: str,
    collection_name: str = "knowledge",
    top_k: int = 10,
    trace_id: str | None = None,
) -> RequirementGeneratorResult: ...
```

**Template cấu trúc output** (requirements.md):
```
# Tài liệu Yêu cầu: {title}
## Giới thiệu
## Bảng chú giải
## Yêu cầu
### Yêu cầu N: {tên}
  User Story: ...
  Acceptance Criteria: (EARS format)
## Compliance Requirements (auto-injected theo domain)
## Correctness Properties
```

### 4. `app/tasks/design_generator.py`

Sinh HLD/LLD/ERD/OpenAPI từ requirements document và codebase context.

```python
@dataclass
class DesignGeneratorResult:
    document: str
    domains: list[str]
    compliance_report: ComplianceReport
    impact_report: ImpactReport
    context_chunks_used: int
    generated_at: str
    trace_id: str

def generate_design(
    requirements_doc: str,
    collection_name: str = "knowledge",
    top_k: int = 15,
    trace_id: str | None = None,
) -> DesignGeneratorResult: ...
```

**Template cấu trúc output** (design.md):
```
# Tài liệu Thiết kế: {title}
## Tổng quan
## Kiến trúc (Mermaid diagram)
## Components và Interfaces
## Data Models (ERD)
## Data Flow Diagram (Mermaid)
## Threat Model
## Phân quyền truy cập (nếu healthcare domain)
## Data Retention Policy
## Backup & Recovery Strategy (RTO/RPO)
## API Contract (OpenAPI-style)
## Error Handling
## Testing Strategy
```

### 5. `app/tasks/impact_analyzer.py`

Phân tích impact của requirements mới lên codebase hiện có bằng ChromaDB search.

```python
@dataclass
class ImpactedService:
    service_name: str
    impact_level: str       # "HIGH" | "MEDIUM" | "LOW"
    affected_files: list[str]
    reason: str
    test_strategy: str

@dataclass
class ImpactReport:
    impacted_services: list[ImpactedService]
    total_high: int
    total_medium: int
    total_low: int
    analyzed_at: str
    trace_id: str

def analyze_impact(
    requirements_doc: str,
    collection_name: str = "knowledge",
    top_k: int = 10,
    trace_id: str | None = None,
) -> ImpactReport: ...
```

**Impact level classification**:
- `HIGH`: thay đổi interface/schema/API contract
- `MEDIUM`: thay đổi business logic, thêm field
- `LOW`: thay đổi config, rename, update label

### 6. `app/tasks/confluence_writer.py`

Tạo/cập nhật trang Confluence từ markdown document. Sử dụng retry queue khi Confluence không khả dụng.

```python
@dataclass
class ConfluenceWriteResult:
    page_id: str
    page_url: str
    version: int
    action: str             # "created" | "updated"
    audit_id: str
    written_at: str

def write_document(
    title: str,
    content_markdown: str,
    space_key: str,
    parent_page_id: str | None = None,
    existing_page_id: str | None = None,
    actor: str = "system",
    trace_id: str | None = None,
) -> ConfluenceWriteResult: ...
```

**Retry policy**: tối đa 3 lần, delay 30s giữa các lần, lưu vào `data/logs/confluence_write_queue.jsonl` khi thất bại.

### 7. Bổ sung `app/connectors/confluence.py`

Thêm 3 methods mới vào `ConfluenceConnector`:

```python
def create_page(
    self,
    space_key: str,
    title: str,
    body_storage: str,          # Confluence Storage Format (HTML-like)
    parent_id: str | None = None,
) -> dict: ...                  # returns {id, title, _links.webui}

def update_page(
    self,
    page_id: str,
    title: str,
    body_storage: str,
    version_number: int,        # phải đúng version hiện tại để tránh conflict
    minor_edit: bool = False,
) -> dict: ...

def search_pages(
    self,
    cql: str,
    limit: int = 25,
) -> list[dict]: ...            # CQL: "space = 'KEY' AND title = 'My Page'"
```

Markdown → Confluence Storage Format: dùng thư viện `markdown` + custom post-processing để convert headings, code blocks, tables sang Storage Format.


## Data Models

### ComplianceClause

```python
@dataclass
class ComplianceClause:
    domain: str             # "PHARMACY"
    code: str               # "PHARMACY-001"
    title: str              # "Validation kê đơn Rx"
    requirement_text: str   # text inject vào document
    legal_basis: str        # "Luật Dược 2016, Điều 47"
    mandatory: bool         # True = phải có, False = khuyến nghị
```

### RDETask (lưu trong task dossier)

Mở rộng task dossier hiện có với các field mới trong `task.json`:

```json
{
  "task_id": "task-20240115-...",
  "rde_type": "requirements | design | full",
  "intent": "...",
  "domains": ["PHARMACY", "PAYMENT"],
  "requirements_doc_path": "data/tasks/.../requirements.md",
  "design_doc_path": "data/tasks/.../design.md",
  "compliance_report": { "passed": true, "violations": [] },
  "impact_report": { "impacted_services": [] },
  "confluence_page_id": "12345",
  "confluence_page_url": "https://...",
  "generated_at": "2024-01-15T10:00:00Z",
  "trace_id": "abc12345"
}
```

### Audit Record (rde_audit.jsonl)

```json
{
  "event_type": "rde_generate_requirements | rde_generate_design | rde_confluence_write | rde_compliance_fail",
  "created_at": "2024-01-15T10:00:00Z",
  "details": {
    "audit_id": "abc12345",
    "trace_id": "xyz67890",
    "action": "generate_requirements",
    "actor": "system | api_key_hash[:8]",
    "domains": ["PHARMACY"],
    "compliance_passed": true,
    "violations_count": 0,
    "confluence_page_id": null,
    "duration_ms": 1250
  }
}
```

**Lưu ý bảo mật**: audit record KHÔNG chứa nội dung document, intent text đầy đủ, hoặc bất kỳ PII nào. Chỉ lưu metadata.


## API Contract

### Endpoints mới trong `app/api/routes.py`

#### POST `/rde/generate-requirements`
```
Request:
  intent: str (required, max 10000 chars)
  collection: str = "knowledge"
  top_k: int = 10
  publish_to_confluence: bool = false
  confluence_space_key: str | null
  confluence_parent_page_id: str | null

Response 200:
  task_id: str
  requirements_doc: str          # markdown
  domains: list[str]
  compliance_report: ComplianceReport
  confluence_url: str | null
  trace_id: str

Response 422:
  detail: { message: "Compliance check failed", violations: [...] }
```

#### POST `/rde/generate-design`
```
Request:
  requirements_doc: str (required)
  collection: str = "knowledge"
  top_k: int = 15
  publish_to_confluence: bool = false
  confluence_space_key: str | null
  confluence_parent_page_id: str | null

Response 200:
  task_id: str
  design_doc: str                # markdown
  domains: list[str]
  compliance_report: ComplianceReport
  impact_report: ImpactReport
  confluence_url: str | null
  trace_id: str
```

#### POST `/rde/analyze-impact`
```
Request:
  requirements_doc: str (required)
  collection: str = "knowledge"
  top_k: int = 10

Response 200:
  impact_report: ImpactReport
  trace_id: str
```

#### POST `/rde/check-compliance`
```
Request:
  document: str (required)
  document_type: "requirements" | "design"
  domains: list[str] | null      # null = auto-detect

Response 200:
  compliance_report: ComplianceReport
  trace_id: str
```

### MCP Tools mới trong `app/mcp_server.py`

```python
@mcp.tool()
def rde_generate_requirements(intent: str, collection: str = "knowledge") -> dict:
    """Sinh tài liệu requirements từ intent text."""

@mcp.tool()
def rde_generate_design(requirements_doc: str, collection: str = "knowledge") -> dict:
    """Sinh tài liệu thiết kế từ requirements document."""

@mcp.tool()
def rde_analyze_impact(requirements_doc: str, collection: str = "knowledge") -> dict:
    """Phân tích impact của requirements mới lên codebase."""

@mcp.tool()
def rde_check_compliance(document: str, document_type: str, domains: list[str] | None = None) -> dict:
    """Kiểm tra compliance của document theo domain."""

@mcp.tool()
def rde_publish_to_confluence(
    title: str,
    content: str,
    space_key: str,
    parent_page_id: str | None = None,
) -> dict:
    """Tạo hoặc cập nhật trang Confluence từ markdown document."""
```

### CLI Commands mới trong `app/cli.py`

```bash
python -m app.cli rde-requirements "<intent>" [--collection knowledge] [--publish] [--space KEY]
python -m app.cli rde-design "<requirements_file_path>" [--publish] [--space KEY]
python -m app.cli rde-impact "<requirements_file_path>"
python -m app.cli rde-check-compliance "<doc_file_path>" --type requirements|design
```

