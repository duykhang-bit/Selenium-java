#!/usr/bin/env python3
"""Tạo trang Confluence cho Module 1–7 và đồng bộ remote link Jira đúng từng module.

Nếu trước đó module 2–7 trong state trùng URL/pageId với module 1 (fallback),
script **không** dùng `existing_page_id` đó — sẽ **tạo trang mới** dưới root,
tránh ghi đè nhầm nội dung trang module 1.

Chạy từ root repo, venv active:
  python scripts/sync_module_confluence_jira_links.py

Cần: data/roadmap_publish_state.json (có root_page_id, space_key).
"""

from __future__ import annotations

import importlib.util
import json
import logging
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
_log = logging.getLogger(__name__)

# Load MODULES + helpers từ publish script (tránh lệch dữ liệu)
_pub = Path(__file__).resolve().parent / "publish_roadmap_to_jira_confluence.py"
_spec = importlib.util.spec_from_file_location("roadmap_publish", _pub)
if _spec is None or _spec.loader is None:
    raise SystemExit("Cannot load publish_roadmap_to_jira_confluence.py")
_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_mod)

MODULES = _mod.MODULES
STATE_PATH = _mod.STATE_PATH
_read_md = _mod._read_md


def _page_url(base: str, webui: str) -> str:
    webui = webui or ""
    if webui.startswith("http"):
        return webui
    base = base.rstrip("/")
    if not webui.startswith("/"):
        webui = "/" + webui
    return f"{base}{webui}"


def _page_id_from_url(u: str | None) -> str | None:
    if not u or "pageId=" not in u:
        return None
    try:
        return u.split("pageId=")[-1].split("&")[0].strip()
    except Exception:
        return None


# Epic + Story keys đã tạo trong lượt publish Jira (AIN-3 … AIN-39)
EPIC_BY_MODULE = {
    1: "AIN-3",
    2: "AIN-8",
    3: "AIN-13",
    4: "AIN-21",
    5: "AIN-26",
    6: "AIN-31",
    7: "AIN-36",
}
STORIES_BY_MODULE: dict[int, list[str]] = {
    1: ["AIN-4", "AIN-5", "AIN-6", "AIN-7"],
    2: ["AIN-9", "AIN-10", "AIN-11", "AIN-12"],
    3: ["AIN-14", "AIN-15", "AIN-16", "AIN-17", "AIN-18", "AIN-19", "AIN-20"],
    4: ["AIN-22", "AIN-23", "AIN-24", "AIN-25"],
    5: ["AIN-27", "AIN-28", "AIN-29", "AIN-30"],
    6: ["AIN-32", "AIN-33", "AIN-34", "AIN-35"],
    7: ["AIN-37", "AIN-38", "AIN-39"],
}


def _confluence_urls_to_remove_from_jira() -> tuple[str, ...]:
    """Xóa remote link trỏ tới Confluence (để thay bằng URL đúng module)."""
    return ("confluence", "viewpage.action", "wiki/display", "/wiki/")


def _purge_confluence_remote_links(jira, issue_key: str) -> int:
    removed = 0
    for link in jira.list_remote_links(issue_key):
        lid = link.get("id")
        obj = link.get("object") or {}
        url = (obj.get("url") or "").lower()
        if not lid:
            continue
        if any(x in url for x in _confluence_urls_to_remove_from_jira()):
            try:
                jira.delete_remote_link(issue_key, int(lid))
                removed += 1
            except Exception as exc:
                _log.warning("Không xóa được remote link %s trên %s: %s", lid, issue_key, exc)
    return removed


def main() -> None:
    from app.catalog.database import list_connectors
    from app.connectors.jira import JiraConnector
    from app.core.config import settings
    from app.sync.service import initialize_runtime
    from app.tasks.confluence_writer import write_document

    initialize_runtime()
    jira_rows = list_connectors(connector_type="jira")
    if not jira_rows:
        raise SystemExit("Chưa có Jira connector")
    jira_base = jira_rows[0]["base_url"].rstrip("/")

    if not STATE_PATH.is_file():
        raise SystemExit(
            f"Thiếu {STATE_PATH}. Chạy publish roadmap trước hoặc tạo file state có root_page_id + space_key."
        )
    st = json.loads(STATE_PATH.read_text(encoding="utf-8"))
    space_key = st["space_key"]
    root_page_id = st["root_page_id"]
    root_url = st.get("root_url", "")
    mod_urls: dict[int, str] = {int(k): v for k, v in st.get("mod_urls", {}).items()}

    base_cf = settings.confluence_base_url.rstrip("/")

    # PageId của Module 1 — dùng để phát hiện state sai: module 2–7 trùng URL với module 1
    m1_url = mod_urls.get(1) or ""
    m1_pid = _page_id_from_url(m1_url)

    # --- 1) Tạo / cập nhật trang Confluence từng module (ghi đè nội dung specs mới nhất) ---
    created_pages: list[dict] = []
    for m in MODULES:
        spec_dir = PROJECT_ROOT / ".kiro" / "specs" / m["slug"]
        parts: list[str] = [
            f"# Module {m['num']} — {m['title']}\n",
            f"**Spec folder:** `.kiro/specs/{m['slug']}/`\n",
            f"**Jira Epic:** [{EPIC_BY_MODULE[m['num']]}|{jira_base}/browse/{EPIC_BY_MODULE[m['num']]}]\n",
        ]
        for fname in ("requirements.md", "design.md", "tasks.md"):
            fp = spec_dir / fname
            if fp.is_file():
                parts.append(f"\n## {fname}\n\n")
                parts.append(_read_md(fp))
        bundle_md = "\n".join(parts)
        mod_title = f"Module {m['num']} — {m['title']} (Specs)"
        # Chỉ update khi URL đã trỏ tới page **riêng** của module (không trùng module 1)
        existing_id: str | None = None
        if m["num"] in mod_urls:
            cand_pid = _page_id_from_url(mod_urls[m["num"]])
            if cand_pid:
                if m["num"] == 1:
                    existing_id = cand_pid
                elif m1_pid and cand_pid == m1_pid:
                    _log.warning(
                        "Module %s: URL trong state trùng pageId với Module 1 — bỏ qua update, "
                        "tạo trang Confluence mới.",
                        m["num"],
                    )
                    existing_id = None
                else:
                    existing_id = cand_pid

        res = write_document(
            title=mod_title,
            content_markdown=bundle_md,
            space_key=space_key,
            parent_page_id=root_page_id,
            existing_page_id=existing_id,
            actor="sync-module-links",
        )
        mod_url = _page_url(base_cf, res.page_url)
        mod_urls[m["num"]] = mod_url
        created_pages.append({"module": m["num"], "page_id": res.page_id, "url": mod_url, "action": res.action})

    STATE_PATH.write_text(
        json.dumps(
            {
                "space_key": space_key,
                "root_page_id": root_page_id,
                "root_url": root_url or f"{base_cf}/pages/viewpage.action?pageId={root_page_id}",
                "mod_urls": {str(k): v for k, v in sorted(mod_urls.items())},
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    # Kiểm tra: mỗi module phải có URL khác nhau (sau khi tạo trang)
    warnings: list[str] = []
    pids = {n: _page_id_from_url(v) for n, v in mod_urls.items()}
    for n in range(2, 8):
        if n not in mod_urls:
            warnings.append(f"Thiếu URL Confluence cho module {n}.")
            continue
        if pids.get(n) and m1_pid and pids[n] == m1_pid:
            warnings.append(
                f"Module {n} vẫn trùng pageId với Module 1 — không cập nhật Jira cho module này."
            )

    # --- 2) Jira: xóa link Confluence cũ, thêm link đúng module cho Epic + Story ---
    jira = JiraConnector(jira_rows[0]["base_url"], jira_rows[0]["token"])

    link_report: list[dict] = []
    for m in MODULES:
        num = m["num"]
        mod_url = mod_urls.get(num)
        if not mod_url:
            warnings.append(f"Không có URL Confluence cho module {num} sau bước publish.")
            continue
        if num >= 2 and pids.get(num) and m1_pid and pids.get(num) == m1_pid:
            for issue_key in [EPIC_BY_MODULE[num]] + STORIES_BY_MODULE[num]:
                link_report.append(
                    {
                        "issue": issue_key,
                        "skipped": True,
                        "reason": "Confluence URL still same as Module 1",
                    }
                )
            continue
        mod_title = f"Module {num} — {m['title']} (Specs)"
        keys = [EPIC_BY_MODULE[num]] + STORIES_BY_MODULE[num]
        for issue_key in keys:
            removed = _purge_confluence_remote_links(jira, issue_key)
            try:
                jira.add_remote_link(issue_key, mod_url, f"Specs: {mod_title}")
                link_report.append({"issue": issue_key, "url": mod_url, "removed_old": removed, "ok": True})
            except Exception as exc:
                link_report.append({"issue": issue_key, "error": str(exc), "ok": False})

    out = {
        "warnings": warnings,
        "confluence": created_pages,
        "jira_links": link_report,
        "state_file": str(STATE_PATH),
    }
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
