#!/usr/bin/env python3
"""Gán assignee = user hiện tại (PAT) và transition tất cả issue khớp JQL sang Done.

Chạy từ root repo (venv active):
  python scripts/jira_assign_me_and_done.py
  python scripts/jira_assign_me_and_done.py --dry-run
  python scripts/jira_assign_me_and_done.py --jql 'project = AIN AND key >= AIN-3 AND key <= AIN-50'

Mặc định JQL: project AIN + component \"AI Context Engine\", chưa Done.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app.connectors.jira import JiraConnector  # noqa: E402
from app.core.config import settings  # noqa: E402


def _assignee_payload(me: dict) -> dict:
    if me.get("accountId"):
        return {"accountId": me["accountId"]}
    if me.get("name"):
        return {"name": me["name"]}
    return {"name": me.get("key", "")}


def _find_done_transition(transitions: list[dict]) -> str | None:
    """Workflow FPT: trạng thái đích thường là COMPLETED (không phải tên Done)."""
    preferred = ("done", "completed")
    for want in preferred:
        for t in transitions:
            to_name = (t.get("to") or {}).get("name", "")
            if to_name.lower() == want:
                return t.get("id")
    for t in transitions:
        to_name = (t.get("to") or {}).get("name", "")
        if "done" in to_name.lower():
            return t.get("id")
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description="Assign current user + transition to Done")
    default_jql = (
        'project = AIN AND component = "AI Context Engine" '
        "AND statusCategory != Done ORDER BY key ASC"
    )
    parser.add_argument("--jql", default=default_jql, help="JQL (default: AIN roadmap component, not Done)")
    parser.add_argument("--dry-run", action="store_true", help="Chỉ in ra, không gọi API ghi")
    args = parser.parse_args()

    if not settings.jira_base_url or not settings.jira_token:
        print("Thiếu AI_CONTEXT_V2_JIRA_BASE_URL hoặc AI_CONTEXT_V2_JIRA_TOKEN trong .env", file=sys.stderr)
        return 1

    jira = JiraConnector(
        base_url=settings.jira_base_url,
        token=settings.jira_token,
        connect_timeout=settings.jira_connect_timeout,
        read_timeout=settings.jira_read_timeout,
        max_pool_size=settings.jira_max_pool_size,
    )

    me = jira.get_myself()
    assignee = _assignee_payload(me)
    print(
        f"User PAT: {me.get('displayName', '?')} ({me.get('emailAddress', me.get('name', ''))})",
        flush=True,
    )

    all_keys: list[str] = []
    start = 0
    page = 100
    while True:
        batch = jira.search_issues(
            args.jql,
            start_at=start,
            max_results=page,
            fields=["summary", "status", "assignee"],
        )
        issues = batch.get("issues") or []
        for iss in issues:
            all_keys.append(iss["key"])
        total = batch.get("total", 0)
        start += len(issues)
        if start >= total or not issues:
            break

    preview = ", ".join(all_keys[:20])
    if len(all_keys) > 20:
        preview += "..."
    print(f"JQL: {args.jql}\nTìm thấy {len(all_keys)} issue: {preview}", flush=True)

    if args.dry_run:
        print("[dry-run] Bỏ qua assign + transition.")
        return 0

    errors: list[str] = []
    for key in all_keys:
        try:
            jira.update_issue(key, {"assignee": assignee})
            print(f"  assignee → bạn: {key}", flush=True)
        except Exception as exc:
            errors.append(f"{key} assign: {exc}")
            print(f"  LỖI assign {key}: {exc}", file=sys.stderr, flush=True)

        try:
            transitions = jira.get_transitions(key)
            tid = _find_done_transition(transitions)
            if not tid:
                names = [(t.get("to") or {}).get("name") for t in transitions]
                errors.append(f"{key} transition: không có Done (có: {names})")
                print(f"  Bỏ qua transition {key}: không thấy Done — {names}", file=sys.stderr, flush=True)
                continue
            jira.do_transition(key, tid)
            print(f"  Done: {key}", flush=True)
        except Exception as exc:
            errors.append(f"{key} transition: {exc}")
            print(f"  LỖI transition {key}: {exc}", file=sys.stderr, flush=True)

    if errors:
        print(json.dumps({"ok": False, "errors": errors}, ensure_ascii=False, indent=2))
        return 2
    print(json.dumps({"ok": True, "updated": len(all_keys)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
