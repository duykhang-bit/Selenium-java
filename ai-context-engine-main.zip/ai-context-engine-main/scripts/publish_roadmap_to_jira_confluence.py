#!/usr/bin/env python3
"""Publish .kiro roadmap to Jira (AIN) + specs/docs to Confluence, link issues ↔ pages.

Usage (from repo root, venv active):
  export AI_CONTEXT_V2_CONFLUENCE_PUBLISH_SPACE=YOUR_SPACE_KEY   # optional; auto-detect AIN or first space
  python scripts/publish_roadmap_to_jira_confluence.py [--dry-run]

Requires: .env with Jira + Confluence connectors; project AIN must allow Epic, Story, Sub-task.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# Repo root = parent of scripts/
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import json

from app.catalog.database import list_connectors  # noqa: E402
from app.connectors.confluence import ConfluenceConnector  # noqa: E402
from app.connectors.jira import JiraConnector  # noqa: E402
from app.core.config import settings  # noqa: E402
from app.sync.service import initialize_runtime  # noqa: E402
from app.tasks.confluence_writer import write_document  # noqa: E402

MAX_MD_CHARS = 180_000
# Epic Link / Epic Name — id khác nhau theo Jira; AIN dùng GreenHopper 10101 / 10103
EPIC_LINK_FIELD = os.getenv("AI_CONTEXT_V2_JIRA_EPIC_LINK_FIELD", "customfield_10101")
EPIC_NAME_FIELD = os.getenv("AI_CONTEXT_V2_JIRA_EPIC_NAME_FIELD", "customfield_10103")
# Project AIN bắt buộc Component — cần ít nhất một component (đã tạo qua API hoặc trong UI)
JIRA_COMPONENT_NAME = os.getenv("AI_CONTEXT_V2_JIRA_COMPONENT_NAME", "AI Context Engine")

STATE_PATH = PROJECT_ROOT / "data" / "roadmap_publish_state.json"

MODULES: list[dict] = [
    {
        "num": 1,
        "slug": "jira-integration",
        "title": "Jira Integration",
        "stories": [
            "Đọc Jira: pull ticket, epic, sprint context vào ChromaDB",
            "Ghi Jira: từ intent tự động tạo Epic → Story → Sub-task với acceptance criteria, story point estimate",
            "Sync 2 chiều: task dossier cập nhật status → Jira ticket tự cập nhật",
            "Jira → Brief: từ ticket ID sinh task brief đầy đủ business + technical context",
        ],
    },
    {
        "num": 2,
        "slug": "requirement-design-engine",
        "title": "Requirement & Design Engine",
        "stories": [
            "Requirement generator: phân tích intent → sinh BRD/PRD chuẩn",
            "Design generator: requirement + codebase context → HLD, LLD, ERD, OpenAPI spec",
            "Impact analyzer: xác định service nào bị ảnh hưởng trong hệ sinh thái",
            "Confluence writer: tự động tạo/cập nhật page Confluence",
        ],
    },
    {
        "num": 3,
        "slug": "quality-gate-engine",
        "title": "Quality Gate Engine",
        "stories": [
            "Code quality: SonarQube/Semgrep, convention, complexity, duplication",
            "Security scan: SAST, secret detection, dependency vulnerability",
            "Test generator: từ code diff sinh unit test + integration test",
            "Regression analyzer: dependency graph, risk score cho MR",
            "Performance check: N+1 query, missing index, heavy loop",
            "SEO audit: Lighthouse, meta tags, structured data (cho frontend)",
            "API contract validation: đảm bảo code đúng OpenAPI spec",
        ],
    },
    {
        "num": 4,
        "slug": "jenkins-integration",
        "title": "Jenkins Integration",
        "stories": [
            "Pipeline trigger: MR tạo → tự động trigger Jenkins job",
            "Build status reader: đọc kết quả Jenkins → dossier, AI phân tích log lỗi",
            "Quality gate enforcer: Jenkins gọi Context Engine lấy gate result trước khi merge",
            "Deployment tracker: theo dõi deployment history per service/environment",
        ],
    },
    {
        "num": 5,
        "slug": "code-generation-pipeline",
        "title": "Code Generation Pipeline",
        "stories": [
            "Task decomposer: từ design chia coding tasks nhỏ theo dependency",
            "Code generator: sinh code đúng convention từng repo",
            "Branch manager: tạo branch, MR/PR trên GitLab tự động",
            "Commit message generator: conventional commits chuẩn",
        ],
    },
    {
        "num": 6,
        "slug": "k8s-deployment-intelligence",
        "title": "K8s & Deployment Intelligence",
        "stories": [
            "Manifest generator: sinh K8s deployment, service, ingress, configmap",
            "UAT promotion: pass quality gate → tự động deploy UAT + smoke test",
            "PROD promotion gate: checklist tự động trước khi lên PROD",
            "Incident correlation: alert PROD → correlate với deployment gần nhất",
        ],
    },
    {
        "num": 7,
        "slug": "observability-engine",
        "title": "Observability cho Engine",
        "stories": [
            "Structured audit log: mọi action AI đều có trace đầy đủ",
            "Confidence scoring: output thấp confidence → flag human review",
            "Human-in-the-loop gates: merge to main, deploy PROD luôn cần human approve",
        ],
    },
]


def _read_md(path: Path) -> str:
    text = path.read_text(encoding="utf-8")
    if len(text) > MAX_MD_CHARS:
        return (
            f"> **Cảnh báo:** Nội dung gốc quá dài; chỉ hiển thị {MAX_MD_CHARS} ký tự đầu.\n\n"
            + text[:MAX_MD_CHARS]
        )
    return text


def _page_url(base: str, webui: str) -> str:
    webui = webui or ""
    if webui.startswith("http"):
        return webui
    base = base.rstrip("/")
    if not webui.startswith("/"):
        webui = "/" + webui
    return f"{base}{webui}"


def _resolve_space_key(cf: ConfluenceConnector, dry_run: bool) -> str:
    env_key = os.getenv("AI_CONTEXT_V2_CONFLUENCE_PUBLISH_SPACE", "").strip()
    if env_key:
        return env_key
    if dry_run:
        return "DRY_RUN"
    spaces = cf.list_spaces(limit=500)
    keys = [s.get("key") for s in spaces if s.get("key")]
    for prefer in ("AIN", "ICT", "AL"):
        if prefer in keys:
            return prefer  # type: ignore[return-value]
    if keys:
        return keys[0]  # type: ignore[return-value]
    raise RuntimeError("Không tìm thấy Confluence space nào — đặt AI_CONTEXT_V2_CONFLUENCE_PUBLISH_SPACE")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true", help="Chỉ in kế hoạch, không gọi API")
    parser.add_argument(
        "--skip-confluence",
        action="store_true",
        help="Chỉ tạo/cập nhật Jira (dùng khi Confluence đã publish trước đó)",
    )
    parser.add_argument(
        "--skip-jira",
        action="store_true",
        help="Chỉ publish Confluence (không tạo ticket Jira)",
    )
    args = parser.parse_args()

    initialize_runtime()
    jira_rows = list_connectors(connector_type="jira")
    if not jira_rows:
        raise SystemExit("Chưa có Jira connector — chạy python -m app.cli setup-env")
    jc = jira_rows[0]
    jira = JiraConnector(jc["base_url"], jc["token"])

    cf = ConfluenceConnector(
        settings.confluence_base_url,
        settings.confluence_token,
        settings.confluence_username,
    )
    space_key = _resolve_space_key(cf, args.dry_run)
    base_cf = settings.confluence_base_url.rstrip("/")

    report: dict = {"space_key": space_key, "confluence_pages": [], "jira": [], "warnings": []}

    if args.dry_run:
        print("DRY RUN — space would be:", space_key)
        print("Modules:", len(MODULES))
        return

    root_result = None
    root_url = ""
    mod_urls: dict[int, str] = {}

    if not args.skip_confluence:
        roadmap_path = PROJECT_ROOT / ".kiro" / "steering" / "roadmap.md"
        root_md = _read_md(roadmap_path)
        resume = STATE_PATH.is_file()
        if resume:
            st0 = json.loads(STATE_PATH.read_text(encoding="utf-8"))
            space_key = st0.get("space_key", space_key)
            root_result = type("R", (), {"page_id": st0["root_page_id"]})()
            root_url = st0.get("root_url", "")
            mod_urls = {int(k): v for k, v in st0.get("mod_urls", {}).items()}
        else:
            root_intro = (
                "# AI Context Engine — Roadmap (AIN)\n\n"
                "Tài liệu được publish tự động từ repository `.kiro/steering/roadmap.md` "
                "và liên kết với Epic/Story trên Jira project **AIN**.\n\n"
                "---\n\n"
                + root_md
            )
            root_result = write_document(
                title="AI Context Engine — AIN Roadmap & Specifications",
                content_markdown=root_intro,
                space_key=space_key,
                parent_page_id=None,
                actor="roadmap-publish-script",
            )
            root_url = _page_url(base_cf, root_result.page_url)
            report["confluence_pages"].append({"title": "Root", "url": root_url, "id": root_result.page_id})

            steering_dir = PROJECT_ROOT / ".kiro" / "steering"
            for name in sorted(steering_dir.glob("*.md")):
                if name.name == "roadmap.md":
                    continue
                body = _read_md(name)
                title = f"Steering — {name.stem}"
                res = write_document(
                    title=title,
                    content_markdown=f"# {title}\n\n" + body,
                    space_key=space_key,
                    parent_page_id=root_result.page_id,
                    actor="roadmap-publish-script",
                )
                report["confluence_pages"].append(
                    {"title": title, "url": _page_url(base_cf, res.page_url), "id": res.page_id}
                )

            docs_dir = PROJECT_ROOT / "docs"
            for path in sorted(docs_dir.glob("*.md")):
                body = _read_md(path)
                title = f"Docs — {path.stem}"
                res = write_document(
                    title=title,
                    content_markdown=f"# {title}\n\n**Source:** `docs/{path.name}`\n\n---\n\n" + body,
                    space_key=space_key,
                    parent_page_id=root_result.page_id,
                    actor="roadmap-publish-script",
                )
                report["confluence_pages"].append(
                    {"title": title, "url": _page_url(base_cf, res.page_url), "id": res.page_id}
                )

        # --- Per-module spec pages (chỉ tạo module chưa có trong state) ---
        for mod in MODULES:
            if mod["num"] in mod_urls:
                continue
            spec_dir = PROJECT_ROOT / ".kiro" / "specs" / mod["slug"]
            parts: list[str] = [
                f"# Module {mod['num']} — {mod['title']}\n",
                f"**Spec folder:** `.kiro/specs/{mod['slug']}/`\n",
                f"**Jira Epic:** (sẽ cập nhật sau khi tạo ticket)\n",
            ]
            for fname in ("requirements.md", "design.md", "tasks.md"):
                fp = spec_dir / fname
                if fp.is_file():
                    parts.append(f"\n## {fname}\n\n")
                    parts.append(_read_md(fp))
            bundle_md = "\n".join(parts)
            mod_title = f"Module {mod['num']} — {mod['title']} (Specs)"
            mod_page = write_document(
                title=mod_title,
                content_markdown=bundle_md,
                space_key=space_key,
                parent_page_id=root_result.page_id,
                actor="roadmap-publish-script",
            )
            mod_url = _page_url(base_cf, mod_page.page_url)
            mod_urls[mod["num"]] = mod_url
            report["confluence_pages"].append({"title": mod_title, "url": mod_url, "id": mod_page.page_id})

    roadmap_md = _read_md(PROJECT_ROOT / ".kiro" / "steering" / "roadmap.md")

    if not args.skip_confluence and root_result is not None:
        STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        STATE_PATH.write_text(
            json.dumps(
                {
                    "space_key": space_key,
                    "root_page_id": root_result.page_id,
                    "root_url": root_url,
                    "mod_urls": {str(k): v for k, v in mod_urls.items()},
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

    if args.skip_confluence:
        env_urls = os.getenv("AI_CONTEXT_V2_ROADMAP_MODULE_URLS_JSON", "").strip()
        if env_urls:
            mod_urls = {int(k): v for k, v in json.loads(env_urls).items()}
            root_pid = os.getenv("AI_CONTEXT_V2_ROADMAP_ROOT_PAGE_ID", "269156602").strip()
            root_url = os.getenv("AI_CONTEXT_V2_ROADMAP_ROOT_URL", "").strip()
            if not root_url and mod_urls:
                root_url = next(iter(mod_urls.values()))
            space_key = os.getenv("AI_CONTEXT_V2_CONFLUENCE_PUBLISH_SPACE", "AIN").strip()
            root_result = type("R", (), {"page_id": root_pid})()
        elif STATE_PATH.is_file():
            st = json.loads(STATE_PATH.read_text(encoding="utf-8"))
            space_key = st["space_key"]
            mod_urls = {int(k): v for k, v in st.get("mod_urls", {}).items()}
            root_result = type("R", (), {"page_id": st["root_page_id"]})()
            root_url = st.get("root_url", "")
        else:
            raise SystemExit(
                f"Thiếu URL module: đặt AI_CONTEXT_V2_ROADMAP_MODULE_URLS_JSON hoặc tạo {STATE_PATH} "
                f"(chạy publish Confluence với --skip-jira trước)."
            )
        report["space_key"] = space_key

    if args.skip_jira:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return

    fallback_url = root_url or mod_urls.get(1) or ""
    if not mod_urls and not fallback_url:
        raise SystemExit(
            "Thiếu URL Confluence: cần roadmap_publish_state.json, env MODULE_URLS_JSON, "
            "hoặc ít nhất root_url / module 1."
        )

    jira_base = jira_rows[0]["base_url"].rstrip("/")

    for mod in MODULES:
        mod_url = mod_urls.get(mod["num"]) or mod_urls.get(1) or fallback_url
        if mod["num"] not in mod_urls:
            report["warnings"].append(
                f"Module {mod['num']}: chưa có trang Confluence riêng — dùng URL fallback cho link Jira."
            )
        mod_title = f"Module {mod['num']} — {mod['title']} (Specs)"
        epic_short_name = f"M{mod['num']} {mod['title']}"[:80]

        epic_summary = f"[AIN] Module {mod['num']} — {mod['title']}"
        epic_desc = (
            f"h2. Mục tiêu\n\n"
            f"Theo roadmap AI Context Engine — Module {mod['num']} ({mod['title']}).\n\n"
            f"h2. Tài liệu Confluence\n\n"
            f"[{mod_title}|{mod_url}]\n\n"
            f"h2. Acceptance\n\n"
            f"* Các hạng mục roadmap module được theo dõi qua Story con.\n"
            f"* Tài liệu specs (requirements/design/tasks) đã publish trên Confluence.\n"
        )
        epic_fields: dict = {
            "project": {"key": "AIN"},
            "summary": epic_summary[:254],
            "description": epic_desc,
            "issuetype": {"name": "Epic"},
            "components": [{"name": JIRA_COMPONENT_NAME}],
            EPIC_NAME_FIELD: epic_short_name,
        }
        epic_resp = jira.create_issue(epic_fields)
        epic_key = epic_resp["key"]
        report["jira"].append({"type": "epic", "key": epic_key, "summary": epic_summary})

        try:
            jira.add_remote_link(epic_key, mod_url, f"Confluence: {mod_title}")
        except Exception as exc:
            report["jira"].append({"epic_remote_link_error": str(exc), "epic": epic_key})

        for line in mod["stories"]:
            st_summary = f"[M{mod['num']}] {line[:200]}"
            st_desc = (
                f"h2. Mô tả\n\n{line}\n\n"
                f"h2. Liên kết\n\n"
                f"* Epic: [{epic_key}|{jira_base}/browse/{epic_key}]\n"
                f"* Specs Confluence: [{mod_title}|{mod_url}]\n"
            )
            story_fields: dict = {
                "project": {"key": "AIN"},
                "summary": st_summary[:254],
                "description": st_desc,
                "issuetype": {"name": "Story"},
                "components": [{"name": JIRA_COMPONENT_NAME}],
            }
            story_fields[EPIC_LINK_FIELD] = epic_key
            try:
                sr = jira.create_issue(story_fields)
                sk = sr["key"]
                report["jira"].append({"type": "story", "key": sk, "parent_epic": epic_key})
                try:
                    jira.add_remote_link(sk, mod_url, "Confluence — module specs")
                except Exception:
                    pass
            except Exception as exc:
                report["jira"].append(
                    {"type": "story_failed", "epic": epic_key, "summary": st_summary[:80], "error": str(exc)}
                )

    # Cập nhật trang root Confluence với danh sách Epic
    index_lines = ["# AI Context Engine — AIN Roadmap & Specifications\n"]
    index_lines.append("\n## Jira Epics (AIN)\n")
    for row in report["jira"]:
        if row.get("type") == "epic":
            k = row["key"]
            index_lines.append(f"* [{k}|{jira_base}/browse/{k}] — {row.get('summary', '')}\n")
    index_lines.append("\n---\n\n")
    index_lines.append(roadmap_md)
    write_document(
        title="AI Context Engine — AIN Roadmap & Specifications",
        content_markdown="".join(index_lines),
        space_key=space_key,
        existing_page_id=root_result.page_id,
        actor="roadmap-publish-script",
    )

    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
