# EXAMPLE_OMS_9_STEPS.md

## Mục tiêu

File này là ví dụ thực tế cho quy trình chuẩn 9 bước từ lúc nhận task đến
khi chuẩn bị commit code.

Task mẫu:

```text
[OMS] Cung cấp API tạo đơn hàng Service
```

## Cách dùng

Trong chat, có thể nhập:

```text
@EXAMPLE_OMS_9_STEPS.md
Làm theo đúng flow này cho task hiện tại
```

Hoặc dùng file này làm mẫu rồi thay tên task tương ứng.

## Quy trình 9 bước

### Bước 1. Khởi tạo task

Prompt:

```text
Phân tích task "[OMS] Cung cấp API tạo đơn hàng Service", tạo task dossier và brief trong data/tasks, chưa code vội.
```

Kết quả mong đợi:

- tạo dossier trong `data/tasks/...`
- sinh `brief.md`
- chọn repo phù hợp

### Bước 2. Sinh plan

Prompt:

```text
Dựa trên brief của task "[OMS] Cung cấp API tạo đơn hàng Service", hãy lập plan chi tiết, ghi vào dossier các mục plan, scope, impact, notes. Chưa implement code.
```

Kết quả mong đợi:

- `plan.md`: hướng xử lý API
- `scope.md`: file/module dự kiến sửa
- `impact.md`: ảnh hưởng tới order flow, service rule, integration
- `notes.md`: lưu ý business và kỹ thuật

### Bước 3. Kiểm tra context

Prompt:

```text
Kiểm tra context cho task "[OMS] Cung cấp API tạo đơn hàng Service". Nếu thiếu business rule hoặc repo liên quan, hãy chỉ ra thiếu gì trước khi code.
```

Kết quả mong đợi:

- xác nhận đủ hoặc thiếu context
- nếu thiếu thì dừng ở mức plan và nêu rõ phần thiếu

### Bước 4. Sync repo thật về latest

Prompt:

```text
Bắt đầu implement task "[OMS] Cung cấp API tạo đơn hàng Service". Trước tiên hãy sync repo thật về latest, sau đó mới mở repo trong data/workspaces/repos và đọc các file liên quan trước khi sửa.
```

Kết quả mong đợi:

- repo local được fetch/pull về mới nhất
- chỉ sau bước này mới đọc và sửa file

### Bước 5. Xác định file thật cần sửa

Prompt:

```text
Sau khi sync latest, hãy xác định các file thật cần sửa cho API tạo đơn hàng Service, giải thích ngắn gọn vai trò từng file, rồi mới bắt đầu implement.
```

Kết quả mong đợi:

- xác định đúng controller/API endpoint
- xác định application service/handler/domain/integration
- biết test hoặc build path liên quan

### Bước 6. Implement

Prompt:

```text
Hãy implement minimal và an toàn cho task "[OMS] Cung cấp API tạo đơn hàng Service" theo plan đã chốt, bám đúng pattern hiện có của repo.
```

Kết quả mong đợi:

- thay đổi đúng scope
- không mở rộng ngoài plan nếu chưa cập nhật lại dossier

### Bước 7. Build/Test

Prompt:

```text
Sau khi implement, hãy chạy build/test phù hợp cho repo này và báo rõ kết quả pass/fail cùng nguyên nhân nếu lỗi.
```

Kết quả mong đợi:

- có kết quả build/test rõ ràng
- nếu fail thì nói rõ lỗi và mức ảnh hưởng

### Bước 8. Cập nhật result vào dossier

Prompt:

```text
Cập nhật dossier của task "[OMS] Cung cấp API tạo đơn hàng Service" với kết quả implement, build/test, và các lưu ý còn lại.
```

Kết quả mong đợi:

- `result.md` được cập nhật
- timeline có thêm mốc hoàn thành

### Bước 9. Chuẩn bị commit

Prompt:

```text
Review nhanh thay đổi, tóm tắt ngắn gọn những gì đã sửa cho task "[OMS] Cung cấp API tạo đơn hàng Service", rồi chuẩn bị commit message phù hợp.
```

Commit message ví dụ:

```text
feat(oms): add service order creation api
```

Kết quả mong đợi:

- tóm tắt thay đổi rõ ràng
- commit message ngắn gọn, đúng nội dung

## Prompt full một phát

```text
Thực hiện task "[OMS] Cung cấp API tạo đơn hàng Service" theo đúng flow chuẩn: tạo task dossier, sinh brief, lập plan/scope/impact/notes, kiểm tra đủ context chưa, sync repo thật về latest trước khi code, đọc file thật trong data/workspaces/repos, implement minimal theo pattern hiện có, chạy build/test, cập nhật result vào dossier, rồi tóm tắt để chuẩn bị commit.
```

## Tóm tắt flow

```text
task-start -> task-plan -> check context -> sync-source -> read real files -> code -> build/test -> task-result -> commit
```
