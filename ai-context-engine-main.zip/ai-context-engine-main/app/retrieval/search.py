"""Search helpers for V2 retrieval."""

from __future__ import annotations

from dataclasses import dataclass

from app.ingest.embedder import embed_single
from app.ingest.store import query_collection


@dataclass
class SearchResult:
    content: str
    score: float
    metadata: dict

    def to_dict(self) -> dict:
        return {
            "content": self.content,
            "score": round(self.score, 4),
            "metadata": self.metadata,
        }


def build_where_filter(repo_id: str | None = None, source_id: str | None = None, source_type: str | None = None) -> dict | None:
    where = {}
    if repo_id:
        where["repo_id"] = repo_id
    if source_id:
        where["source_id"] = source_id
    if source_type:
        where["source_type"] = source_type
    return where or None


def search(
    query: str,
    collection_name: str,
    top_k: int = 5,
    repo_id: str | None = None,
    source_id: str | None = None,
    source_type: str | None = None,
) -> list[SearchResult]:
    query_embedding = embed_single(query)
    results = query_collection(
        collection_name=collection_name,
        query_embedding=query_embedding,
        top_k=top_k,
        where=build_where_filter(repo_id=repo_id, source_id=source_id, source_type=source_type),
    )

    parsed: list[SearchResult] = []
    if results and results["documents"] and results["documents"][0]:
        for document, metadata, distance in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
        ):
            parsed.append(SearchResult(content=document, score=1 - (distance / 2), metadata=metadata))
    return parsed
