"""Internal runtime helpers."""
