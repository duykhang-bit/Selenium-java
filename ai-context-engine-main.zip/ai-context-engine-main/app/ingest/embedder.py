"""Embedding helpers."""

from __future__ import annotations

from sentence_transformers import SentenceTransformer

from app.core.config import settings


_model: SentenceTransformer | None = None


def _get_model() -> SentenceTransformer:
    global _model
    if _model is None:
        print(f"Loading embedding model: {settings.embedding_model}")
        _model = SentenceTransformer(settings.embedding_model)
        print(f"Model loaded - dimension: {_model.get_sentence_embedding_dimension()}")
    return _model


def embed_texts(texts: list[str]) -> list[list[float]]:
    embeddings = _get_model().encode(texts, show_progress_bar=len(texts) > 50)
    return embeddings.tolist()


def embed_single(text: str) -> list[float]:
    return embed_texts([text])[0]
