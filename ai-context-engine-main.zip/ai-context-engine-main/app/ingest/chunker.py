"""Chunking helpers for repositories and documents."""

from __future__ import annotations

import os
from dataclasses import dataclass, field

from langchain_text_splitters import Language, RecursiveCharacterTextSplitter

from app.core.config import DEFAULT_IGNORED_DIRS, SUPPORTED_EXTENSIONS, settings
from app.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class Chunk:
    content: str
    metadata: dict = field(default_factory=dict)


_LANGUAGE_MAP = {
    ".py": Language.PYTHON,
    ".js": Language.JS,
    ".ts": Language.TS,
    ".jsx": Language.JS,
    ".tsx": Language.TS,
    ".java": Language.JAVA,
    ".go": Language.GO,
    ".rs": Language.RUST,
    ".html": Language.HTML,
    ".md": Language.MARKDOWN,
}


def _get_splitter(ext: str, *, chunk_size: int, chunk_overlap: int) -> RecursiveCharacterTextSplitter:
    lang = _LANGUAGE_MAP.get(ext)
    if lang:
        return RecursiveCharacterTextSplitter.from_language(
            language=lang,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )
    return RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )


def chunk_text(
    text: str,
    ext: str = ".txt",
    metadata: dict | None = None,
    *,
    chunk_size: int | None = None,
    chunk_overlap: int | None = None,
) -> list[Chunk]:
    splitter = _get_splitter(
        ext,
        chunk_size=chunk_size if chunk_size is not None else settings.chunk_size,
        chunk_overlap=chunk_overlap if chunk_overlap is not None else settings.chunk_overlap,
    )
    documents = splitter.create_documents([text])
    base_metadata = (metadata or {}).copy()
    base_metadata.setdefault("extension", ext)
    return [
        Chunk(content=document.page_content, metadata={**base_metadata, "chunk_index": str(index)})
        for index, document in enumerate(documents)
    ]


def chunk_file(
    filepath: str,
    metadata: dict | None = None,
    *,
    chunk_size: int | None = None,
    chunk_overlap: int | None = None,
) -> list[Chunk]:
    filepath = os.path.abspath(filepath)
    ext = os.path.splitext(filepath)[1].lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise ValueError(f"Unsupported file type: {ext}")
    with open(filepath, "r", encoding="utf-8", errors="ignore") as handle:
        text = handle.read()
    if not text.strip():
        return []
    file_metadata = {
        "source": filepath,
        "filename": os.path.basename(filepath),
        "extension": ext,
    }
    if metadata:
        file_metadata.update(metadata)
    return chunk_text(
        text,
        ext=ext,
        metadata=file_metadata,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )


def chunk_directory(
    dirpath: str,
    metadata: dict | None = None,
    extensions: set[str] | None = None,
    *,
    chunk_size: int | None = None,
    chunk_overlap: int | None = None,
) -> list[Chunk]:
    allowed = extensions or SUPPORTED_EXTENSIONS
    all_chunks: list[Chunk] = []
    for root, dirs, files in os.walk(dirpath):
        dirs[:] = [directory for directory in dirs if not directory.startswith(".") and directory not in DEFAULT_IGNORED_DIRS]
        for filename in sorted(files):
            ext = os.path.splitext(filename)[1].lower()
            if ext not in allowed:
                continue
            try:
                all_chunks.extend(
                    chunk_file(
                        os.path.join(root, filename),
                        metadata=metadata,
                        chunk_size=chunk_size,
                        chunk_overlap=chunk_overlap,
                    )
                )
            except Exception as exc:
                logger.warning("Skipped %s: %s", filename, exc)
    return all_chunks
