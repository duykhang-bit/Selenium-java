"""Unified ingestion pipeline for Git repositories and Confluence pages."""

from __future__ import annotations

import json
from pathlib import Path

from bs4 import BeautifulSoup

from app.core.config import (
    REPO_DOC_ROOT_HINTS,
    REPO_MANIFEST_HINTS,
    REPO_SOURCE_ROOT_HINTS,
    REPO_TEST_ROOT_HINTS,
    settings,
)
from app.core.utils import sha256_text, utc_now_iso
from app.ingest.chunker import Chunk, chunk_directory, chunk_file, chunk_text
from app.ingest.store import upsert_chunks


ROOT_MANIFEST_NAMES = {name.lower() for name in REPO_MANIFEST_HINTS}


def normalize_relative_source(source: str, root_path: Path) -> str:
    try:
        return Path(source).resolve().relative_to(root_path.resolve()).as_posix()
    except Exception:
        return Path(source).name


def enrich_chunks(chunks: list[Chunk], metadata: dict, root_path: Path | None = None) -> list[Chunk]:
    for chunk in chunks:
        chunk.metadata.update(metadata)
        if root_path and chunk.metadata.get("source"):
            relative_source = normalize_relative_source(chunk.metadata["source"], root_path)
            chunk.metadata["relative_source"] = relative_source
            chunk.metadata["source_root"] = relative_source.split("/", 1)[0]
    return chunks


def detect_repo_layout(repo_root: Path) -> dict:
    directories = {child.name for child in repo_root.iterdir() if child.is_dir()}
    files = {child.name for child in repo_root.iterdir() if child.is_file()}

    source_roots = [name for name in REPO_SOURCE_ROOT_HINTS if name in directories]
    docs_roots = [name for name in REPO_DOC_ROOT_HINTS if name in directories]
    test_roots = [name for name in REPO_TEST_ROOT_HINTS if name in directories]
    manifests = [name for name in files if name.lower() in ROOT_MANIFEST_NAMES or name.endswith((".sln", ".csproj"))]

    if not source_roots:
        source_roots = ["."]

    install_commands: list[str] = []
    build_commands: list[str] = []
    test_commands: list[str] = []

    sln_files = sorted(name for name in files if name.endswith(".sln"))
    csproj_files = sorted(name for name in files if name.endswith(".csproj"))

    if sln_files:
        solution = sln_files[0]
        install_commands.append(f"dotnet restore {solution}")
        build_commands.append(f"dotnet build {solution} --no-restore -v minimal")
    elif csproj_files:
        project = csproj_files[0]
        install_commands.append(f"dotnet restore {project}")
        build_commands.append(f"dotnet build {project} --no-restore -v minimal")
    elif "package.json" in files:
        install_commands.append("npm install")
        build_commands.append("npm run build")
        test_commands.append("npm test")
    elif "pyproject.toml" in files or "requirements.txt" in files:
        install_commands.append("python -m pip install -r requirements.txt")
        test_commands.append("pytest")

    return {
        "source_roots": source_roots,
        "docs_roots": docs_roots,
        "test_roots": test_roots,
        "manifests": sorted(set(manifests)),
        "install": install_commands,
        "build": build_commands,
        "test": test_commands,
    }


def build_repo_metadata(source: dict) -> dict:
    metadata = json.loads(source.get("metadata_json") or "{}")
    return {
        "source_id": source["source_id"],
        "source_type": source["source_type"],
        "connector_type": source["connector_type"],
        "repo_id": metadata.get("repo_id", source["source_id"]),
        "repo_name": source["title"],
        "path_with_namespace": source.get("path_with_namespace", ""),
        "clone_url": source.get("clone_url", ""),
        "default_branch": source.get("default_branch", ""),
    }


def collect_repository_chunks(source: dict) -> tuple[list[Chunk], dict]:
    repo_root = Path(source["local_path"])
    layout = detect_repo_layout(repo_root)
    metadata = build_repo_metadata(source)
    chunks: list[Chunk] = []
    visited_sources: set[str] = set()

    for relative_root in layout["source_roots"] + layout["docs_roots"] + layout["test_roots"]:
        root_path = repo_root / relative_root
        if not root_path.exists() or not root_path.is_dir():
            continue
        current_chunks = chunk_directory(
            str(root_path),
            metadata=metadata,
            chunk_size=settings.repo_chunk_size,
            chunk_overlap=settings.repo_chunk_overlap,
        )
        enrich_chunks(current_chunks, metadata, root_path=repo_root)
        chunks.extend(current_chunks)
        visited_sources.update(chunk.metadata.get("source", "") for chunk in current_chunks)

    for manifest_name in layout["manifests"]:
        file_path = repo_root / manifest_name
        if not file_path.exists() or not file_path.is_file():
            continue
        if str(file_path.resolve()) in visited_sources:
            continue
        try:
            current_chunks = chunk_file(
                str(file_path),
                metadata=metadata,
                chunk_size=settings.repo_chunk_size,
                chunk_overlap=settings.repo_chunk_overlap,
            )
        except ValueError:
            continue
        enrich_chunks(current_chunks, metadata, root_path=repo_root)
        chunks.extend(current_chunks)

    return chunks, layout


def html_to_text(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    return "\n".join(line.strip() for line in soup.get_text("\n").splitlines() if line.strip())


def collect_confluence_chunks(source: dict) -> tuple[list[Chunk], dict]:
    file_path = Path(source["local_path"])
    raw_html = file_path.read_text(encoding="utf-8", errors="ignore")
    metadata_json = json.loads(source.get("metadata_json") or "{}")
    text = html_to_text(raw_html)
    combined_text = f"Title: {source['title']}\nURL: {source['url']}\n\n{text}"
    metadata = {
        "source_id": source["source_id"],
        "source_type": source["source_type"],
        "connector_type": source["connector_type"],
        "page_id": source.get("external_id", ""),
        "space_key": metadata_json.get("space_key", ""),
        "title": source["title"],
        "source": source["url"],
    }
    chunks = chunk_text(
        combined_text,
        ext=".md",
        metadata=metadata,
        chunk_size=settings.confluence_chunk_size,
        chunk_overlap=settings.confluence_chunk_overlap,
    )
    return chunks, {"space_key": metadata_json.get("space_key", "")}


def ingest_source(source: dict, collection_name: str | None = None) -> dict:
    collection = collection_name or settings.default_collection
    if source["source_type"] == "git_repo":
        chunks, layout = collect_repository_chunks(source)
        chunk_count = upsert_chunks(chunks, collection, source["source_id"])
        return {
            "source_id": source["source_id"],
            "collection": collection,
            "chunks": chunk_count,
            "layout": layout,
            "last_ingested_at": utc_now_iso(),
        }

    if source["source_type"] == "confluence_page":
        chunks, details = collect_confluence_chunks(source)
        chunk_count = upsert_chunks(chunks, collection, source["source_id"])
        return {
            "source_id": source["source_id"],
            "collection": collection,
            "chunks": chunk_count,
            "layout": details,
            "last_ingested_at": utc_now_iso(),
            "content_hash": sha256_text("".join(chunk.content for chunk in chunks)),
        }

    raise ValueError(f"Unsupported source_type: {source['source_type']}")
