"""ChromaDB storage helpers."""

from __future__ import annotations

import uuid

import chromadb

from app.core.config import settings
from app.ingest.chunker import Chunk
from app.ingest.embedder import embed_texts


_client: chromadb.ClientAPI | None = None


def _get_client() -> chromadb.ClientAPI:
    global _client
    if _client is None:
        _client = chromadb.PersistentClient(path=str(settings.chroma_dir))
        print(f"ChromaDB initialized at: {settings.chroma_dir}")
    return _client


def get_or_create_collection(name: str) -> chromadb.Collection:
    return _get_client().get_or_create_collection(name=name, metadata={"hnsw:space": "cosine"})


def delete_source_documents(collection_name: str, source_id: str) -> None:
    collection = get_or_create_collection(collection_name)
    try:
        collection.delete(where={"source_id": source_id})
    except Exception:
        pass


def upsert_chunks(chunks: list[Chunk], collection_name: str, source_id: str) -> int:
    if not chunks:
        return 0
    collection = get_or_create_collection(collection_name)
    delete_source_documents(collection_name, source_id)
    batch_size = 5000
    total = 0
    for start in range(0, len(chunks), batch_size):
        batch = chunks[start:start + batch_size]
        texts = [chunk.content for chunk in batch]
        metadatas = [chunk.metadata for chunk in batch]
        ids = [str(uuid.uuid4()) for _ in batch]
        embeddings = embed_texts(texts)
        collection.add(ids=ids, documents=texts, embeddings=embeddings, metadatas=metadatas)
        total += len(batch)
    return total


def query_collection(collection_name: str, query_embedding: list[float], top_k: int = 5, where: dict | None = None) -> dict:
    collection = get_or_create_collection(collection_name)
    kwargs = {
        "query_embeddings": [query_embedding],
        "n_results": min(top_k, collection.count() or top_k),
        "include": ["documents", "metadatas", "distances"],
    }
    if where:
        kwargs["where"] = where
    return collection.query(**kwargs)


def list_collections() -> list[dict]:
    return [
        {"name": collection.name, "count": collection.count(), "metadata": collection.metadata}
        for collection in _get_client().list_collections()
    ]
