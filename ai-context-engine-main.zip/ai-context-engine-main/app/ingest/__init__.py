"""Ingest primitives for V2."""
