"""FastAPI entrypoint for AI Context Engine V2."""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager

import uvicorn
from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import router
from app.core.auth import api_key_dependency
from app.core.config import settings
from app.sync.service import initialize_runtime


@asynccontextmanager
async def lifespan(app: FastAPI):  # noqa: ARG001
    await asyncio.to_thread(initialize_runtime)
    yield


app = FastAPI(
    title="AI Context Engine V2",
    version="2.0.0",
    description="Auto-discover, sync, ingest, and retrieve Git/Confluence knowledge for AI coding.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix="/api", dependencies=[Depends(api_key_dependency)])


@app.get("/")
async def root() -> dict:
    return {"service": "AI Context Engine V2", "docs": "/docs", "status": "running"}


if __name__ == "__main__":
    uvicorn.run("app.main:app", host=settings.api_host, port=settings.api_port, reload=True)
