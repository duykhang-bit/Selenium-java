"""Deployment tracker — lưu và query deployment history."""

from __future__ import annotations

import uuid

from app.catalog.database import (
    get_latest_deployment,
    list_deployments,
    save_deployment_record,
)
from app.core.utils import utc_now_iso
from app.tasks.jenkins.models import DeploymentRecord


def record_deployment(
    service: str,
    environment: str,
    build_number: int,
    job_name: str,
    status: str,
    deployed_by: str = "system",
    build_url: str = "",
    record_id: str | None = None,
) -> DeploymentRecord:
    """Lưu deployment record vào catalog."""
    rid = record_id or uuid.uuid4().hex[:16]
    deployed_at = utc_now_iso()

    save_deployment_record(
        record_id=rid,
        service=service,
        environment=environment,
        build_number=build_number,
        job_name=job_name,
        status=status,
        deployed_at=deployed_at,
        deployed_by=deployed_by,
        build_url=build_url,
    )

    return DeploymentRecord(
        record_id=rid,
        service=service,
        environment=environment,
        build_number=build_number,
        job_name=job_name,
        status=status,
        deployed_at=deployed_at,
        deployed_by=deployed_by,
        build_url=build_url,
    )


def get_deployments(
    service: str | None = None,
    environment: str | None = None,
    limit: int = 20,
) -> list[DeploymentRecord]:
    """Query deployment history."""
    rows = list_deployments(service=service, environment=environment, limit=limit)
    return [
        DeploymentRecord(
            record_id=r["record_id"],
            service=r["service"],
            environment=r["environment"],
            build_number=r["build_number"],
            job_name=r["job_name"],
            status=r["status"],
            deployed_at=r["deployed_at"],
            deployed_by=r.get("deployed_by", "system"),
            build_url=r.get("build_url", ""),
        )
        for r in rows
    ]


def get_latest(service: str, environment: str) -> DeploymentRecord | None:
    """Lấy deployment gần nhất của service ở environment."""
    row = get_latest_deployment(service, environment)
    if not row:
        return None
    return DeploymentRecord(
        record_id=row["record_id"],
        service=row["service"],
        environment=row["environment"],
        build_number=row["build_number"],
        job_name=row["job_name"],
        status=row["status"],
        deployed_at=row["deployed_at"],
        deployed_by=row.get("deployed_by", "system"),
        build_url=row.get("build_url", ""),
    )
