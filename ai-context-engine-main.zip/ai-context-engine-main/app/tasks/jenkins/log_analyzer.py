"""Build Log Analyzer — phân tích Jenkins console log tìm root cause."""

from __future__ import annotations

import re

from app.tasks.jenkins.models import BuildAnalysis

_FILE_PATH = re.compile(r"(?:File \"([^\"]+)\"|at ([a-zA-Z0-9_/\\.-]+\.(?:py|java|kt|ts|js))[:\(])")

_PATTERNS: list[tuple[str, re.Pattern, str]] = [
    (
        "oom",
        re.compile(r"OutOfMemoryError|java\.lang\.OutOfMemory|MemoryError|Cannot allocate memory", re.I),
        "Hết bộ nhớ. Tăng heap size hoặc tối ưu memory usage.",
    ),
    (
        "dependency",
        re.compile(r"Could not resolve|dependency.*not found|ModuleNotFoundError|ImportError|No module named", re.I),
        "Kiểm tra requirements.txt và chạy pip install. Có thể thiếu package mới.",
    ),
    (
        "timeout",
        re.compile(r"Timeout|timed out|TIMEOUT|Build timed out|deadline exceeded", re.I),
        "Build bị timeout. Kiểm tra performance hoặc tăng timeout trong Jenkinsfile.",
    ),
    (
        "test_failure",
        re.compile(r"\bFAILED\b.*test|Tests run:.*(?:Failures|Errors): [1-9]|\bFAIL:\s|AssertionError|pytest.*failed", re.I),
        "Xem chi tiết test failure. Chạy pytest -v để debug.",
    ),
    (
        "compilation",
        re.compile(r"\berror:\s|COMPILATION ERROR|SyntaxError:|cannot find symbol|undefined reference", re.I),
        "Kiểm tra syntax và import. Chạy build local trước khi push.",
    ),
]

_SUGGESTED_FIXES = {
    "compilation": "Kiểm tra syntax và import. Chạy build local trước khi push.",
    "test_failure": "Xem chi tiết test failure. Chạy pytest -v để debug.",
    "dependency": "Kiểm tra requirements.txt và chạy pip install. Có thể thiếu package mới.",
    "timeout": "Build bị timeout. Kiểm tra performance hoặc tăng timeout trong Jenkinsfile.",
    "oom": "Hết bộ nhớ. Tăng heap size hoặc tối ưu memory usage.",
    "unknown": "Xem full console log để tìm nguyên nhân.",
}


def _extract_snippet(log_text: str, pattern: re.Pattern, context_lines: int = 3) -> str:
    """Trích xuất đoạn log xung quanh match đầu tiên."""
    lines = log_text.splitlines()
    for i, line in enumerate(lines):
        if pattern.search(line):
            start = max(0, i - context_lines)
            end = min(len(lines), i + context_lines + 1)
            return "\n".join(lines[start:end])
    return ""


def _extract_files(snippet: str) -> list[str]:
    """Trích xuất file paths từ error snippet."""
    files: list[str] = []
    for m in _FILE_PATH.finditer(snippet):
        path = m.group(1) or m.group(2)
        if path and path not in files:
            files.append(path)
    return files[:5]


def analyze_log(log_text: str) -> BuildAnalysis:
    """Phân tích Jenkins console log và trả về BuildAnalysis."""
    if not log_text or not log_text.strip():
        return BuildAnalysis(
            error_type="unknown",
            error_message="Log trống hoặc không có nội dung",
            suggested_fix=_SUGGESTED_FIXES["unknown"],
        )

    for error_type, pattern, fix in _PATTERNS:
        m = pattern.search(log_text)
        if m:
            snippet = _extract_snippet(log_text, pattern)
            return BuildAnalysis(
                error_type=error_type,
                error_message=m.group(0)[:200],
                affected_files=_extract_files(snippet),
                suggested_fix=fix,
                raw_snippet=snippet[:500],
            )

    # Tìm dòng cuối cùng có "ERROR" hoặc "FAILED"
    last_error = ""
    for line in reversed(log_text.splitlines()):
        if re.search(r"error|fail|exception", line, re.I):
            last_error = line.strip()[:200]
            break

    return BuildAnalysis(
        error_type="unknown",
        error_message=last_error or "Không xác định được lỗi cụ thể",
        suggested_fix=_SUGGESTED_FIXES["unknown"],
        raw_snippet=log_text[-500:] if len(log_text) > 500 else log_text,
    )
