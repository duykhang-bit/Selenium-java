"""Data models cho Jenkins Integration."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class TriggerResult:
    job_name: str
    build_number: int
    build_url: str
    triggered_at: str       # ISO 8601 UTC
    trace_id: str = ""
    triggered_by: str = "system"


@dataclass
class BuildStatus:
    job_name: str
    build_number: int
    status: str             # "SUCCESS" | "FAILURE" | "RUNNING" | "ABORTED" | "UNSTABLE"
    duration_ms: int = 0
    timestamp: str = ""
    url: str = ""


@dataclass
class BuildAnalysis:
    error_type: str         # "compilation" | "test_failure" | "dependency" | "timeout" | "oom" | "unknown"
    error_message: str
    affected_files: list[str] = field(default_factory=list)
    suggested_fix: str = ""
    raw_snippet: str = ""


@dataclass
class DeploymentRecord:
    record_id: str
    service: str
    environment: str        # "dev" | "uat" | "prod"
    build_number: int
    job_name: str
    status: str             # "success" | "failure" | "running"
    deployed_at: str        # ISO 8601 UTC
    deployed_by: str = "system"
    build_url: str = ""
