"""Pipeline trigger — trigger Jenkins job và lưu record."""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

from app.catalog.database import save_trigger_record
from app.connectors.jenkins import JenkinsConnector
from app.core.config import settings
from app.core.logging import get_logger
from app.core.utils import utc_now_iso
from app.tasks.jenkins.models import TriggerResult

logger = get_logger(__name__)


def _get_connector() -> JenkinsConnector:
    if not settings.jenkins_base_url:
        raise ValueError("Jenkins chưa được cấu hình. Đặt AI_CONTEXT_V2_JENKINS_BASE_URL trong .env")
    return JenkinsConnector(
        base_url=settings.jenkins_base_url,
        username=settings.jenkins_username,
        token=settings.jenkins_token,
    )


def _write_audit(trace_id: str, job_name: str, build_number: int, triggered_by: str) -> None:
    record = {
        "event_type": "jenkins_trigger",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "details": {
            "trace_id": trace_id,
            "job_name": job_name,
            "build_number": build_number,
            "triggered_by": triggered_by,
        },
    }
    log_path: Path = settings.logs_dir / "jenkins_audit.jsonl"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except OSError as exc:
        logger.warning("Failed to write Jenkins audit: %s", exc)


def trigger_pipeline(
    job_name: str,
    parameters: dict | None = None,
    triggered_by: str = "system",
    trace_id: str | None = None,
) -> TriggerResult:
    """Trigger Jenkins pipeline và trả về TriggerResult.

    Args:
        job_name: Tên Jenkins job
        parameters: Build parameters (key-value)
        triggered_by: task_id hoặc "system"
        trace_id: Trace ID xuyên suốt request
    """
    if trace_id is None:
        trace_id = uuid.uuid4().hex[:16]

    connector = _get_connector()
    build_number = connector.trigger_job(
        job_name,
        parameters=parameters,
        poll_interval=settings.jenkins_queue_poll_interval,
        poll_timeout=settings.jenkins_queue_poll_timeout,
    )

    build_url = f"{settings.jenkins_base_url}/job/{job_name}/{build_number}/"
    triggered_at = utc_now_iso()

    save_trigger_record(
        job_name=job_name,
        build_number=build_number,
        build_url=build_url,
        triggered_by=triggered_by,
        parameters=parameters,
        triggered_at=triggered_at,
        trace_id=trace_id,
    )

    _write_audit(trace_id, job_name, build_number, triggered_by)

    logger.info(
        "Jenkins pipeline triggered job=%s build=%d",
        job_name, build_number,
        extra={"trace_id": trace_id},
    )

    return TriggerResult(
        job_name=job_name,
        build_number=build_number,
        build_url=build_url,
        triggered_at=triggered_at,
        trace_id=trace_id,
        triggered_by=triggered_by,
    )
