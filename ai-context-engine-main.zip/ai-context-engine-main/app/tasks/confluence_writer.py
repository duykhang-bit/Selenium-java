"""Confluence Writer — publish document lên Confluence.

Tạo hoặc cập nhật trang Confluence từ markdown document.
Retry policy: tối đa 3 lần, delay 30s, lưu queue khi thất bại.
Ghi audit log vào data/logs/rde_audit.jsonl.
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from app.connectors.confluence import ConfluenceConnector, markdown_to_storage
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

_MAX_RETRIES = 3


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class ConfluenceWriteResult:
    page_id: str
    page_url: str
    version: int
    action: str         # "created" | "updated"
    audit_id: str
    written_at: str


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _get_connector() -> ConfluenceConnector:
    """Tạo ConfluenceConnector từ settings. Raise ValueError nếu chưa cấu hình."""
    base_url = settings.confluence_base_url
    if not base_url:
        raise ValueError(
            "Confluence chưa được cấu hình. "
            "Vui lòng đặt AI_CONTEXT_V2_CONFLUENCE_BASE_URL trong .env"
        )
    return ConfluenceConnector(
        base_url=base_url,
        token=settings.confluence_token,
        username=settings.confluence_username,
    )


def _write_queue_record(
    *,
    trace_id: str | None,
    title: str,
    space_key: str,
    parent_page_id: str | None,
    existing_page_id: str | None,
    actor: str,
    retry_count: int,
    last_error: str,
) -> None:
    """Lưu record vào confluence_write_queue.jsonl khi tất cả retry thất bại."""
    record = {
        "queued_at": datetime.now(timezone.utc).isoformat(),
        "trace_id": trace_id,
        "title": title,
        "space_key": space_key,
        "parent_page_id": parent_page_id,
        "existing_page_id": existing_page_id,
        "actor": actor,
        "retry_count": retry_count,
        "last_error": last_error,
    }
    queue_path: Path = settings.logs_dir / "confluence_write_queue.jsonl"
    try:
        queue_path.parent.mkdir(parents=True, exist_ok=True)
        with queue_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        logger.warning(
            "confluence_write queued after %d retries",
            retry_count,
            extra={"trace_id": trace_id, "title_len": len(title)},
        )
    except OSError as exc:
        logger.error(
            "Failed to write confluence queue record",
            extra={"error": str(exc), "trace_id": trace_id},
        )


def _write_audit_record(
    *,
    audit_id: str,
    trace_id: str | None,
    action: str,
    actor: str,
    page_id: str,
    page_url: str,
    version: int,
    title: str,
) -> None:
    """Ghi audit record vào rde_audit.jsonl. Không chứa content_markdown (PII-safe)."""
    record = {
        "event_type": "rde_confluence_write",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "details": {
            "audit_id": audit_id,
            "trace_id": trace_id,
            "action": action,
            "actor": actor,
            "page_id": page_id,
            "page_url": page_url,
            "version": version,
            "title": title,
        },
    }
    log_path: Path = settings.logs_dir / "rde_audit.jsonl"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except OSError as exc:
        logger.warning(
            "Failed to write audit record",
            extra={"error": str(exc), "trace_id": trace_id},
        )


def _do_write(
    connector: ConfluenceConnector,
    *,
    title: str,
    body_storage: str,
    space_key: str,
    parent_page_id: str | None,
    existing_page_id: str | None,
) -> tuple[str, str, int, str]:
    """Thực hiện create hoặc update page. Trả về (page_id, page_url, version, action)."""
    if existing_page_id:
        # Lấy version hiện tại trước khi update
        current = connector.get_page(existing_page_id)
        current_version: int = current["version"]["number"]
        new_version = current_version + 1

        data = connector.update_page(
            page_id=existing_page_id,
            title=title,
            body_storage=body_storage,
            version_number=new_version,
        )
        page_id = data.get("id", existing_page_id)
        page_url = data.get("_links", {}).get("webui", "")
        return page_id, page_url, new_version, "updated"
    else:
        data = connector.create_page(
            space_key=space_key,
            title=title,
            body_storage=body_storage,
            parent_id=parent_page_id,
        )
        page_id = data.get("id", "")
        page_url = data.get("_links", {}).get("webui", "")
        version = data.get("version", {}).get("number", 1) if isinstance(data.get("version"), dict) else 1
        return page_id, page_url, version, "created"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def write_document(
    title: str,
    content_markdown: str,
    space_key: str,
    parent_page_id: str | None = None,
    existing_page_id: str | None = None,
    actor: str = "system",
    trace_id: str | None = None,
    retry_delay_s: float = 30.0,
) -> ConfluenceWriteResult:
    """Tạo hoặc cập nhật trang Confluence từ markdown document.

    Retry policy: tối đa 3 lần, delay ``retry_delay_s`` giây giữa các lần.
    Nếu tất cả retry thất bại: lưu vào queue và raise exception.
    Ghi audit log sau mỗi lần write thành công.

    Args:
        title: Tiêu đề trang Confluence.
        content_markdown: Nội dung trang dạng Markdown.
        space_key: Confluence space key, ví dụ "PROJ".
        parent_page_id: ID trang cha (nếu tạo mới dưới trang cha).
        existing_page_id: ID trang đã tồn tại (nếu update).
        actor: Người/hệ thống thực hiện thao tác.
        trace_id: Trace ID xuyên suốt request.
        retry_delay_s: Số giây chờ giữa các lần retry (mặc định 30s).

    Returns:
        ConfluenceWriteResult với page_id, page_url, version, action, audit_id, written_at.

    Raises:
        ValueError: Nếu Confluence chưa được cấu hình.
        Exception: Nếu tất cả 3 lần retry đều thất bại.
    """
    if trace_id is None:
        trace_id = uuid.uuid4().hex[:16]

    connector = _get_connector()
    body_storage = markdown_to_storage(content_markdown)

    last_exc: Exception | None = None

    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            logger.info(
                "confluence_write attempt %d/%d",
                attempt,
                _MAX_RETRIES,
                extra={"trace_id": trace_id, "space_key": space_key},
            )
            page_id, page_url, version, action = _do_write(
                connector,
                title=title,
                body_storage=body_storage,
                space_key=space_key,
                parent_page_id=parent_page_id,
                existing_page_id=existing_page_id,
            )

            audit_id = uuid.uuid4().hex[:8]
            written_at = datetime.now(timezone.utc).isoformat()

            _write_audit_record(
                audit_id=audit_id,
                trace_id=trace_id,
                action=action,
                actor=actor,
                page_id=page_id,
                page_url=page_url,
                version=version,
                title=title,
            )

            logger.info(
                "confluence_write success action=%s page_id=%s version=%d",
                action,
                page_id,
                version,
                extra={"trace_id": trace_id, "audit_id": audit_id},
            )

            return ConfluenceWriteResult(
                page_id=page_id,
                page_url=page_url,
                version=version,
                action=action,
                audit_id=audit_id,
                written_at=written_at,
            )

        except Exception as exc:  # noqa: BLE001
            last_exc = exc
            logger.warning(
                "confluence_write attempt %d failed: %s",
                attempt,
                exc,
                extra={"trace_id": trace_id},
            )
            if attempt < _MAX_RETRIES:
                time.sleep(retry_delay_s)

    # Tất cả retry thất bại — lưu vào queue
    _write_queue_record(
        trace_id=trace_id,
        title=title,
        space_key=space_key,
        parent_page_id=parent_page_id,
        existing_page_id=existing_page_id,
        actor=actor,
        retry_count=_MAX_RETRIES,
        last_error=str(last_exc),
    )

    raise last_exc  # type: ignore[misc]
