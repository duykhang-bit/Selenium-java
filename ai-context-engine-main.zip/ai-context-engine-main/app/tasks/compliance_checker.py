"""Compliance checker — kiểm tra tài liệu requirements và design theo domain rules.

Pure Python, không gọi LLM. Trả về ComplianceReport với violations và warnings.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone

from app.core.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class ComplianceViolation:
    code: str           # "PHARMACY-001"
    severity: str       # "ERROR" | "WARNING"
    message: str        # mô tả vi phạm
    section: str        # section trong document bị vi phạm
    remediation: str    # hướng dẫn khắc phục


@dataclass
class ComplianceReport:
    passed: bool
    domains_checked: list[str]
    violations: list[ComplianceViolation]
    warnings: list[ComplianceViolation]
    checked_at: str


# ---------------------------------------------------------------------------
# Requirement check rules
# ---------------------------------------------------------------------------

_HEALTHCARE_DOMAINS = {"PHARMACY", "LAB_EMR", "VACCINATION"}

# Each rule: (code, domain, check_fn, message, section, remediation)
# check_fn(doc_lower: str) -> bool  — True = present (OK), False = missing (violation)

def _has(doc: str, *keywords: str) -> bool:
    """True nếu doc chứa ít nhất một keyword."""
    return any(kw in doc for kw in keywords)


def _has_retention_years(doc: str, min_years: int) -> bool:
    """True nếu doc đề cập thời hạn lưu trữ >= min_years năm."""
    for match in re.finditer(r"(\d+)\s*(?:năm|years?)", doc):
        if int(match.group(1)) >= min_years:
            return True
    return False


# (code, domain, checker, message, section, remediation)
_REQ_RULES: list[tuple[str, str, object, str, str, str]] = [
    (
        "PHARMACY-001", "PHARMACY",
        lambda d: _has(d, "kê đơn", "prescription", "validation", "rx"),
        "PHARMACY-001: Thiếu điều khoản validation kê đơn Rx cho requirement bán thuốc",
        "Yêu cầu bán thuốc",
        "Thêm điều khoản: Hệ thống PHẢI xác nhận đơn thuốc Rx hợp lệ trước khi cho phép bán (Luật Dược 2016, Điều 47)",
    ),
    (
        "PHARMACY-002", "PHARMACY",
        lambda d: _has_retention_years(d, 5),
        "PHARMACY-002: Thời hạn lưu trữ giao dịch thuốc < 5 năm hoặc chưa được ghi rõ",
        "Yêu cầu lưu trữ giao dịch thuốc",
        "Ghi rõ thời hạn lưu trữ tối thiểu 5 năm theo Luật Dược 2016, Điều 52",
    ),
    (
        "PHARMACY-003", "PHARMACY",
        lambda d: _has(d, "danh mục", "bộ y tế", "ministry of health"),
        "PHARMACY-003: Thiếu điều khoản đối chiếu danh mục thuốc Bộ Y tế",
        "Yêu cầu thông tin thuốc",
        "Thêm điều khoản đồng bộ danh mục thuốc với Bộ Y tế (Thông tư 30/2018/TT-BYT)",
    ),
    (
        "PHARMACY-004", "PHARMACY",
        lambda d: _has(d, "adr", "adverse drug reaction", "phản ứng có hại"),
        "PHARMACY-004: Thiếu điều khoản báo cáo ADR (Adverse Drug Reaction)",
        "Yêu cầu báo cáo ADR",
        "Thêm điều khoản ghi nhận và báo cáo ADR định kỳ (Thông tư 23/2011/TT-BYT)",
    ),
    (
        "LAB-001", "LAB_EMR",
        lambda d: _has(d, "audit trail", "chữ ký số", "digital signature"),
        "LAB-001: Thiếu điều khoản audit trail và chữ ký số theo Nghị định 96/2023",
        "Yêu cầu hồ sơ bệnh án",
        "Thêm điều khoản audit trail đầy đủ và chữ ký số bác sĩ (NĐ 96/2023, Điều 15)",
    ),
    (
        "LAB-002", "LAB_EMR",
        lambda d: _has_retention_years(d, 10),
        "LAB-002: Thời hạn lưu trữ bệnh án < 10 năm (người lớn) hoặc < 15 năm (trẻ em)",
        "Yêu cầu lưu trữ bệnh án",
        "Ghi rõ: tối thiểu 10 năm (người lớn), 15 năm (trẻ em) theo Thông tư 27/2021, Điều 8",
    ),
    (
        "LAB-003", "LAB_EMR",
        lambda d: _has(d, "giá trị tham chiếu", "reference value", "đơn vị đo", "unit"),
        "LAB-003: Thiếu điều khoản giá trị tham chiếu và đơn vị đo chuẩn",
        "Yêu cầu kết quả xét nghiệm",
        "Thêm điều khoản kết quả xét nghiệm phải có giá trị tham chiếu và SI units (NĐ 96/2023, Điều 18)",
    ),
    (
        "LAB-004", "LAB_EMR",
        lambda d: _has(d, "hl7", "fhir"),
        "LAB-004: Thiếu điều khoản tuân thủ chuẩn HL7 FHIR",
        "Yêu cầu chia sẻ dữ liệu y tế",
        "Thêm điều khoản hỗ trợ HL7 FHIR R4 (Thông tư 27/2021, Điều 6)",
    ),
    (
        "VAC-001", "VACCINATION",
        lambda d: _has(d, "tiêm chủng quốc gia", "national immunization", "thông tư 09"),
        "VAC-001: Thiếu điều khoản kết nối hệ thống tiêm chủng quốc gia (TT 09/2023)",
        "Yêu cầu tiêm chủng",
        "Thêm điều khoản kết nối và đồng bộ với hệ thống tiêm chủng quốc gia (TT 09/2023, Điều 5)",
    ),
    (
        "VAC-002", "VACCINATION",
        lambda d: _has(d, "chống chỉ định", "contraindication"),
        "VAC-002: Thiếu điều khoản cảnh báo chống chỉ định tự động",
        "Yêu cầu lịch tiêm",
        "Thêm điều khoản kiểm tra và cảnh báo chống chỉ định tự động (TT 09/2023, Điều 9)",
    ),
    (
        "VAC-003", "VACCINATION",
        lambda d: _has_retention_years(d, 20),
        "VAC-003: Thời hạn lưu trữ lịch sử tiêm chủng < 20 năm hoặc chưa được ghi rõ",
        "Yêu cầu lưu trữ lịch sử tiêm",
        "Ghi rõ thời hạn lưu trữ tối thiểu 20 năm theo Thông tư 09/2023, Điều 12",
    ),
    (
        "PAY-001", "PAYMENT",
        lambda d: _has(d, "cvv", "pan", "không lưu", "not store"),
        "PAY-001: Thiếu điều khoản không lưu CVV/full PAN sau giao dịch",
        "Yêu cầu thanh toán",
        "Thêm điều khoản: KHÔNG lưu CVV, full PAN sau giao dịch (PCI-DSS v4.0, Req 3.2)",
    ),
    (
        "PAY-002", "PAYMENT",
        lambda d: _has(d, "aes-256", "aes256", "mã hoá"),
        "PAY-002: Thiếu điều khoản mã hoá AES-256 cho dữ liệu thẻ",
        "Yêu cầu dữ liệu thẻ",
        "Thêm điều khoản mã hoá AES-256 cho dữ liệu thẻ lưu trữ (PCI-DSS v4.0, Req 3.5)",
    ),
    (
        "PAY-003", "PAYMENT",
        lambda d: _has(d, "network segmentation", "phân vùng mạng"),
        "PAY-003: Thiếu điều khoản network segmentation cho môi trường thanh toán",
        "Yêu cầu môi trường thanh toán",
        "Thêm điều khoản network segmentation tách biệt môi trường thanh toán (PCI-DSS v4.0, Req 1.3)",
    ),
    (
        "DEV-001", "MEDICAL_DEVICE",
        lambda d: _has(d, "ntp", "timestamp", "outlier"),
        "DEV-001: Thiếu điều khoản timestamp NTP và outlier detection (QCVN 117:2020)",
        "Yêu cầu thiết bị IoT y tế",
        "Thêm điều khoản đồng bộ NTP và outlier detection (QCVN 117:2020/BTTTT, Mục 4.3)",
    ),
    (
        "DEV-002", "MEDICAL_DEVICE",
        lambda d: _has(d, "ota", "firmware update", "cập nhật"),
        "DEV-002: Thiếu điều khoản secure OTA firmware update",
        "Yêu cầu firmware thiết bị y tế",
        "Thêm điều khoản secure OTA update với xác thực chữ ký số (QCVN 117:2020/BTTTT, Mục 5.2)",
    ),
    (
        "SEC-001", "INFOSEC",
        lambda d: _has(d, "rto", "rpo") or bool(re.search(r"\b4\s*giờ|\b4\s*hours?|\b1\s*giờ\b|\b1\s*hour\b", d)),
        "SEC-001: Thiếu điều khoản RTO ≤ 4h / RPO ≤ 1h (Luật ATTTM 2015)",
        "Yêu cầu an toàn thông tin",
        "Thêm điều khoản RTO ≤ 4 giờ và RPO ≤ 1 giờ (Luật ATTTM 2015, Điều 21)",
    ),
    (
        "SEC-002", "INFOSEC",
        lambda d: _has(d, "vncert", "24 giờ", "24 hours"),
        "SEC-002: Thiếu điều khoản báo cáo sự cố cho VNCERT/CC trong 24 giờ",
        "Yêu cầu xử lý sự cố bảo mật",
        "Thêm điều khoản báo cáo sự cố cho VNCERT/CC trong 24 giờ (Luật ATTTM 2015, Điều 23)",
    ),
    (
        "SEC-003", "INFOSEC",
        lambda d: _has(d, "72 giờ", "72 hours", "vi phạm dữ liệu", "data breach"),
        "SEC-003: Thiếu điều khoản thông báo vi phạm dữ liệu trong 72 giờ (NĐ 13/2023)",
        "Yêu cầu bảo vệ dữ liệu cá nhân",
        "Thêm điều khoản thông báo vi phạm dữ liệu trong 72 giờ (NĐ 13/2023, Điều 23)",
    ),
]

# ---------------------------------------------------------------------------
# Design check rules
# ---------------------------------------------------------------------------

_DESIGN_RULES: list[tuple[str, str | None, object, str, str, str]] = [
    (
        "DESIGN-001", None,
        lambda d, _: _has(d, "data retention", "lưu trữ dữ liệu", "retention policy"),
        "DESIGN-001: Thiếu data retention policy cho các loại dữ liệu",
        "Data Retention Policy",
        "Thêm bảng data retention policy theo standards.md mục 8",
    ),
    (
        "DESIGN-002", None,
        lambda d, _: _has(d, "threat model", "mô hình đe doạ", "threat"),
        "DESIGN-002: Thiếu threat model (tác nhân đe doạ, vector tấn công, biện pháp phòng thủ)",
        "Threat Model",
        "Thêm threat model cơ bản: danh sách tác nhân, vector tấn công, biện pháp phòng thủ",
    ),
    (
        "DESIGN-003", None,
        lambda d, _: _has(d, "data flow", "luồng dữ liệu", "dfd"),
        "DESIGN-003: Thiếu data flow diagram thể hiện luồng dữ liệu nhạy cảm",
        "Data Flow Diagram",
        "Thêm data flow diagram (Mermaid hoặc tương đương) cho luồng dữ liệu nhạy cảm",
    ),
    (
        "DESIGN-004", None,
        lambda d, _: _has(d, "backup", "recovery", "rto", "rpo"),
        "DESIGN-004: Thiếu backup & recovery strategy với RTO/RPO được định nghĩa",
        "Backup & Recovery Strategy",
        "Thêm backup & recovery strategy với RTO ≤ 4h và RPO ≤ 1h (Luật ATTTM 2015)",
    ),
    (
        "DESIGN-005", "HEALTHCARE",
        lambda d, domains: (
            not bool(_HEALTHCARE_DOMAINS & set(domains))
            or _has(d, "bác sĩ", "dược sĩ", "điều dưỡng", "doctor", "pharmacist", "nurse")
        ),
        "DESIGN-005: Thiếu phân quyền truy cập theo chức danh y tế (bác sĩ, dược sĩ, điều dưỡng)",
        "Phân quyền truy cập",
        "Thêm phân quyền theo chức danh: bác sĩ, dược sĩ, điều dưỡng, admin (TT 27/2021)",
    ),
]


# ---------------------------------------------------------------------------
# Core functions
# ---------------------------------------------------------------------------


def check_requirements(doc: str, domains: list[str]) -> ComplianceReport:
    """Kiểm tra compliance của tài liệu requirements theo domain rules.

    Args:
        doc: Nội dung tài liệu requirements (markdown).
        domains: Danh sách domain đã phát hiện (e.g. ["PHARMACY", "PAYMENT"]).

    Returns:
        ComplianceReport với violations (ERROR) và warnings (WARNING).
    """
    doc_lower = doc.lower()
    domain_set = set(domains)
    violations: list[ComplianceViolation] = []
    warnings: list[ComplianceViolation] = []

    for code, domain, checker, message, section, remediation in _REQ_RULES:
        if domain not in domain_set:
            continue
        if not checker(doc_lower):
            v = ComplianceViolation(
                code=code,
                severity="ERROR",
                message=message,
                section=section,
                remediation=remediation,
            )
            violations.append(v)

    logger.info(
        "check_requirements completed",
        extra={
            "domains_checked": domains,
            "violations_count": len(violations),
            "warnings_count": len(warnings),
        },
    )

    return ComplianceReport(
        passed=len(violations) == 0,
        domains_checked=list(domains),
        violations=violations,
        warnings=warnings,
        checked_at=datetime.now(timezone.utc).isoformat(),
    )


def check_design(doc: str, domains: list[str]) -> ComplianceReport:
    """Kiểm tra compliance của tài liệu design theo design rules.

    Args:
        doc: Nội dung tài liệu design (markdown).
        domains: Danh sách domain đã phát hiện.

    Returns:
        ComplianceReport với violations (ERROR) và warnings (WARNING).
    """
    doc_lower = doc.lower()
    violations: list[ComplianceViolation] = []
    warnings: list[ComplianceViolation] = []

    for code, _domain_filter, checker, message, section, remediation in _DESIGN_RULES:
        if not checker(doc_lower, domains):
            v = ComplianceViolation(
                code=code,
                severity="ERROR",
                message=message,
                section=section,
                remediation=remediation,
            )
            violations.append(v)

    logger.info(
        "check_design completed",
        extra={
            "domains_checked": domains,
            "violations_count": len(violations),
            "warnings_count": len(warnings),
        },
    )

    return ComplianceReport(
        passed=len(violations) == 0,
        domains_checked=list(domains),
        violations=violations,
        warnings=warnings,
        checked_at=datetime.now(timezone.utc).isoformat(),
    )
