"""Unified Audit Log Query — query và export tất cả audit logs từ mọi module."""

from __future__ import annotations

import csv
import io
import json
from dataclasses import dataclass, field
from pathlib import Path

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class AuditEvent:
    event_type: str
    created_at: str
    details: dict = field(default_factory=dict)
    source_file: str = ""


def _parse_line(line: str, source_file: str) -> AuditEvent | None:
    try:
        data = json.loads(line)
        return AuditEvent(
            event_type=data.get("event_type", "unknown"),
            created_at=data.get("created_at", ""),
            details=data.get("details", {}),
            source_file=source_file,
        )
    except Exception:
        return None


def _matches_filters(
    event: AuditEvent,
    event_types: list[str] | None,
    since: str | None,
    until: str | None,
    trace_id: str | None,
    service: str | None,
) -> bool:
    if event_types and event.event_type not in event_types:
        return False
    if since and event.created_at < since:
        return False
    if until and event.created_at > until:
        return False
    if trace_id and event.details.get("trace_id") != trace_id:
        return False
    if service and event.details.get("service") != service:
        return False
    return True


def query_audit_logs(
    event_types: list[str] | None = None,
    since: str | None = None,
    until: str | None = None,
    trace_id: str | None = None,
    service: str | None = None,
    limit: int = 1000,
) -> list[AuditEvent]:
    """Đọc và merge tất cả *.jsonl trong data/logs/, filter và sort.

    Args:
        event_types: Filter theo event type (None = tất cả)
        since: ISO timestamp — chỉ lấy events sau thời điểm này
        until: ISO timestamp — chỉ lấy events trước thời điểm này
        trace_id: Filter theo trace_id trong details
        service: Filter theo service trong details
        limit: Số lượng records tối đa (default 1000)

    Returns:
        Danh sách AuditEvent đã sort theo created_at desc.
    """
    logs_dir = settings.logs_dir
    if not logs_dir.exists():
        return []

    events: list[AuditEvent] = []
    for jsonl_file in sorted(logs_dir.glob("*.jsonl")):
        try:
            for line in jsonl_file.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                event = _parse_line(line, jsonl_file.name)
                if event and _matches_filters(event, event_types, since, until, trace_id, service):
                    events.append(event)
        except OSError as exc:
            logger.warning("Cannot read audit log %s: %s", jsonl_file, exc)

    events.sort(key=lambda e: e.created_at, reverse=True)
    return events[:limit]


def export_audit_logs(events: list[AuditEvent], format: str = "json") -> str:
    """Export events ra JSON string hoặc CSV string.

    Args:
        events: Danh sách AuditEvent
        format: "json" hoặc "csv"

    Returns:
        String content của file export.
    """
    if format == "csv":
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["event_type", "created_at", "trace_id", "service", "source_file", "details"])
        for e in events:
            writer.writerow([
                e.event_type,
                e.created_at,
                e.details.get("trace_id", ""),
                e.details.get("service", ""),
                e.source_file,
                json.dumps(e.details, ensure_ascii=False),
            ])
        return output.getvalue()

    # Default: JSON
    return json.dumps(
        [{"event_type": e.event_type, "created_at": e.created_at,
          "details": e.details, "source_file": e.source_file}
         for e in events],
        ensure_ascii=False, indent=2,
    )
