"""Human-in-the-loop Gate — approval workflow cho critical actions."""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path

from app.catalog.database import (
    get_approval_request,
    list_approval_requests,
    save_approval_request,
    update_approval_status,
)
from app.core.config import settings
from app.core.logging import get_logger
from app.core.utils import utc_now_iso

logger = get_logger(__name__)

VALID_ACTION_TYPES = {"merge_to_main", "deploy_prod", "create_jira_epic", "publish_confluence"}


@dataclass
class ApprovalRequest:
    request_id: str
    action_type: str
    description: str
    payload: dict
    requested_by: str
    status: str             # "pending" | "approved" | "rejected" | "expired"
    created_at: str
    expires_at: str
    approved_by: str | None = None
    comment: str | None = None


def _row_to_approval(row: dict) -> ApprovalRequest:
    import json as _json
    return ApprovalRequest(
        request_id=row["request_id"],
        action_type=row["action_type"],
        description=row["description"],
        payload=_json.loads(row.get("payload_json") or "{}"),
        requested_by=row.get("requested_by", "system"),
        status=row["status"],
        created_at=row["created_at"],
        expires_at=row["expires_at"],
        approved_by=row.get("approved_by") or None,
        comment=row.get("comment") or None,
    )


def _write_audit(event_type: str, details: dict) -> None:
    record = {
        "event_type": event_type,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "details": details,
    }
    log_path: Path = settings.logs_dir / "hitl_audit.jsonl"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except OSError as exc:
        logger.warning("Failed to write HITL audit: %s", exc)


def _expire_stale_requests() -> None:
    """Auto-expire requests quá hạn."""
    now = datetime.now(timezone.utc).isoformat()
    pending = list_approval_requests(status="pending")
    for row in pending:
        if row.get("expires_at", "") < now:
            update_approval_status(row["request_id"], "expired")


def request_approval(
    action_type: str,
    description: str,
    payload: dict | None = None,
    requested_by: str = "system",
    expires_hours: int = 24,
) -> str:
    """Tạo ApprovalRequest, lưu vào catalog.

    Args:
        action_type: Loại action (merge_to_main, deploy_prod, create_jira_epic, publish_confluence)
        description: Mô tả action cần approve
        payload: Data cần thiết để thực thi sau khi approved
        requested_by: Người/system yêu cầu
        expires_hours: Thời gian hết hạn (default 24h)

    Returns:
        request_id để caller theo dõi.
    """
    request_id = uuid.uuid4().hex[:16]
    now = datetime.now(timezone.utc)
    expires_at = (now + timedelta(hours=expires_hours)).isoformat()
    created_at = now.isoformat()

    save_approval_request(
        request_id=request_id,
        action_type=action_type,
        description=description,
        payload=payload or {},
        requested_by=requested_by,
        created_at=created_at,
        expires_at=expires_at,
    )

    _write_audit("hitl_request_created", {
        "request_id": request_id,
        "action_type": action_type,
        "requested_by": requested_by,
        "expires_at": expires_at,
    })

    logger.info("HITL approval requested: %s action=%s", request_id, action_type)
    return request_id


def approve(request_id: str, approved_by: str, comment: str = "") -> ApprovalRequest:
    """Approve request. Trả về ApprovalRequest với payload để caller thực thi."""
    row = get_approval_request(request_id)
    if not row:
        raise KeyError(f"Approval request not found: {request_id}")
    if row["status"] != "pending":
        raise ValueError(f"Request {request_id} is not pending (status={row['status']})")

    updated = update_approval_status(request_id, "approved", approved_by=approved_by, comment=comment)
    _write_audit("hitl_approved", {
        "request_id": request_id,
        "action_type": row["action_type"],
        "approved_by": approved_by,
        "comment": comment,
    })
    logger.info("HITL approved: %s by %s", request_id, approved_by)
    return _row_to_approval(updated)


def reject(request_id: str, rejected_by: str, comment: str = "") -> ApprovalRequest:
    """Reject request."""
    row = get_approval_request(request_id)
    if not row:
        raise KeyError(f"Approval request not found: {request_id}")
    if row["status"] != "pending":
        raise ValueError(f"Request {request_id} is not pending (status={row['status']})")

    updated = update_approval_status(request_id, "rejected", approved_by=rejected_by, comment=comment)
    _write_audit("hitl_rejected", {
        "request_id": request_id,
        "action_type": row["action_type"],
        "rejected_by": rejected_by,
        "comment": comment,
    })
    logger.info("HITL rejected: %s by %s", request_id, rejected_by)
    return _row_to_approval(updated)


def list_pending(action_type: str | None = None) -> list[ApprovalRequest]:
    """List tất cả pending requests (chưa expired)."""
    _expire_stale_requests()
    rows = list_approval_requests(status="pending", action_type=action_type)
    return [_row_to_approval(r) for r in rows]


def get_request(request_id: str) -> ApprovalRequest | None:
    """Lấy request theo ID."""
    row = get_approval_request(request_id)
    return _row_to_approval(row) if row else None
