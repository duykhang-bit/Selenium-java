"""Confidence Scorer — tính confidence score cho AI outputs."""

from __future__ import annotations

import json
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class ConfidenceResult:
    output_type: str
    score: float            # 0.0 – 1.0
    low_confidence: bool
    review_reasons: list[str] = field(default_factory=list)
    scored_at: str = ""


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, value))


def _score_requirements_doc(content: str) -> tuple[float, list[str]]:
    reasons: list[str] = []
    score = 0.5
    if len(content) < 500:
        score -= 0.2
        reasons.append("Document quá ngắn (< 500 chars)")
    if "Acceptance Criteria" in content or "acceptance criteria" in content.lower():
        score += 0.15
    else:
        reasons.append("Thiếu Acceptance Criteria")
    if "Compliance" in content or "compliance" in content.lower():
        score += 0.15
    else:
        reasons.append("Thiếu Compliance section")
    if "Correctness Properties" in content or "correctness" in content.lower():
        score += 0.1
    if "User Story" in content or "user story" in content.lower():
        score += 0.1
    return _clamp(score), reasons


def _score_design_doc(content: str) -> tuple[float, list[str]]:
    reasons: list[str] = []
    score = 0.5
    if len(content) < 500:
        score -= 0.2
        reasons.append("Document quá ngắn (< 500 chars)")
    if "mermaid" in content.lower() or "```mermaid" in content:
        score += 0.15
    else:
        reasons.append("Thiếu Mermaid diagram")
    if "API Contract" in content or "openapi" in content.lower():
        score += 0.15
    else:
        reasons.append("Thiếu API Contract")
    if "Threat Model" in content or "threat model" in content.lower():
        score += 0.1
    if "Data Retention" in content or "data retention" in content.lower():
        score += 0.1
    return _clamp(score), reasons


def _score_generated_code(data: str | dict) -> tuple[float, list[str]]:
    reasons: list[str] = []
    score = 0.5
    if isinstance(data, dict):
        mode = data.get("mode", "skeleton")
        content = data.get("content", "")
    else:
        mode = "skeleton" if "NotImplementedError" in data else "llm"
        content = data

    if mode == "llm":
        score += 0.2
    else:
        score -= 0.1
        reasons.append("Code được sinh bằng skeleton mode — cần review")

    if '"""' in content or "'''" in content:
        score += 0.1
    else:
        reasons.append("Thiếu docstring")

    if "-> " in content or ": str" in content or ": int" in content or ": dict" in content:
        score += 0.1
    else:
        reasons.append("Thiếu type hints")

    if "NotImplementedError" in content:
        score -= 0.2
        reasons.append("Có NotImplementedError — chưa implement")

    return _clamp(score), reasons


def _score_commit_message(content: str) -> tuple[float, list[str]]:
    reasons: list[str] = []
    score = 0.5
    # Check format: type(scope): description
    if re.match(r"^\w+\(\w+\): .+", content):
        score += 0.3
    elif re.match(r"^\w+: .+", content):
        score += 0.15
        reasons.append("Thiếu scope trong commit message")
    else:
        score -= 0.2
        reasons.append("Không đúng conventional commit format")

    desc = content.split(": ", 1)[1] if ": " in content else content
    if len(desc) > 72:
        score -= 0.1
        reasons.append(f"Description quá dài ({len(desc)} chars > 72)")

    return _clamp(score), reasons


def _score_helm_values(content: str | dict) -> tuple[float, list[str]]:
    reasons: list[str] = []
    score = 0.5
    if isinstance(content, dict):
        content = content.get("content", "")

    try:
        import yaml
        parsed = yaml.safe_load(content)
        if not isinstance(parsed, dict):
            raise ValueError("Not a dict")
        score += 0.1
    except Exception:
        score -= 0.3
        reasons.append("YAML không hợp lệ")
        return _clamp(score), reasons

    if "resources" in parsed:
        score += 0.15
    else:
        reasons.append("Thiếu resources (requests/limits)")

    if parsed.get("ingress", {}).get("enabled"):
        score += 0.1

    if "livenessProbe" in parsed or "readinessProbe" in parsed:
        score += 0.15
    else:
        reasons.append("Thiếu liveness/readiness probe")

    return _clamp(score), reasons


_SCORERS = {
    "requirements_doc": _score_requirements_doc,
    "design_doc": _score_design_doc,
    "generated_code": _score_generated_code,
    "commit_message": _score_commit_message,
    "helm_values": _score_helm_values,
}


def score_confidence(
    output_type: str,
    output_data: str | dict,
    threshold: float = 0.6,
) -> ConfidenceResult:
    """Tính confidence score cho AI output.

    Args:
        output_type: Loại output (requirements_doc, design_doc, generated_code, commit_message, helm_values)
        output_data: Nội dung output (string hoặc dict)
        threshold: Ngưỡng low_confidence (default 0.6)

    Returns:
        ConfidenceResult với score, low_confidence, và review_reasons.
    """
    scorer = _SCORERS.get(output_type)
    if scorer is None:
        return ConfidenceResult(
            output_type=output_type, score=0.5, low_confidence=True,
            review_reasons=[f"Unknown output_type: {output_type}"],
            scored_at=datetime.now(timezone.utc).isoformat(),
        )

    content = output_data if isinstance(output_data, str) else json.dumps(output_data)
    score, reasons = scorer(output_data if output_type in ("generated_code", "helm_values") else content)
    low_confidence = score < threshold
    scored_at = datetime.now(timezone.utc).isoformat()

    # Ghi vào confidence.jsonl
    record = {
        "event_type": "confidence_scored",
        "created_at": scored_at,
        "details": {
            "trace_id": uuid.uuid4().hex[:8],
            "output_type": output_type,
            "score": round(score, 3),
            "low_confidence": low_confidence,
            "review_reasons": reasons,
        },
    }
    log_path: Path = settings.logs_dir / "confidence.jsonl"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except OSError as exc:
        logger.warning("Failed to write confidence log: %s", exc)

    return ConfidenceResult(
        output_type=output_type,
        score=round(score, 3),
        low_confidence=low_confidence,
        review_reasons=reasons,
        scored_at=scored_at,
    )
