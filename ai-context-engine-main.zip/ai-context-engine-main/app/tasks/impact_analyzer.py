"""Impact Analyzer — phân tích impact của requirements mới lên codebase hiện có.

Pure Python, sử dụng ChromaDB search để tìm các file/service bị ảnh hưởng.
Graceful degradation khi ChromaDB không khả dụng.
"""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone

from app.core.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Constants — impact level keyword mapping
# ---------------------------------------------------------------------------

_HIGH_KEYWORDS = frozenset([
    "api", "schema", "interface", "contract", "endpoint",
    "database", "model", "migration", "route", "openapi",
])

_MEDIUM_KEYWORDS = frozenset([
    "logic", "service", "handler", "processor", "validator",
    "rule", "workflow", "business", "usecase",
])

_LOW_KEYWORDS = frozenset([
    "config", "setting", "label", "message", "text",
    "constant", "env", "configuration",
])

# Conflict pattern pairs: (negative_pattern, positive_pattern)
_CONFLICT_PATTERNS: list[tuple[str, str]] = [
    (r"không lưu\s+(\w+)", r"lưu\s+\1"),
    (r"tắt\s+(\w+)", r"bật\s+\1"),
    (r"disable\s+(\w+)", r"enable\s+\1"),
    (r"không\s+(\w+)", r"phải\s+\1"),
]


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class ImpactedService:
    service_name: str
    impact_level: str           # "HIGH" | "MEDIUM" | "LOW"
    affected_files: list[str]
    reason: str
    test_strategy: str


@dataclass
class ImpactReport:
    impacted_services: list[ImpactedService]
    total_high: int
    total_medium: int
    total_low: int
    conflicts: list[str] = field(default_factory=list)
    analyzed_at: str = ""
    trace_id: str = ""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _classify_impact(content: str, source_path: str) -> str:
    """Phân loại impact level dựa trên keywords trong content và source path."""
    text = (content + " " + source_path).lower()
    words = set(re.findall(r"\w+", text))

    if words & _HIGH_KEYWORDS:
        return "HIGH"
    if words & _MEDIUM_KEYWORDS:
        return "MEDIUM"
    return "LOW"


def _extract_service_name(source_path: str) -> str:
    """Trích xuất service name từ file path.

    Ví dụ: "app/api/routes.py" → "api", "app/tasks/brief.py" → "tasks"
    """
    parts = source_path.replace("\\", "/").split("/")
    # Tìm phần tử sau "app/" nếu có
    try:
        app_idx = parts.index("app")
        if app_idx + 1 < len(parts):
            return parts[app_idx + 1]
    except ValueError:
        pass
    # Fallback: lấy phần tử thứ hai từ đầu nếu có
    if len(parts) >= 2:
        return parts[-2] if parts[-2] not in (".", "") else parts[-1]
    return parts[0] if parts else "unknown"


def _build_test_strategy(impact_level: str, service_name: str) -> str:
    """Sinh test strategy dựa trên impact level."""
    if impact_level == "HIGH":
        return (
            f"Integration test + contract test cho {service_name}. "
            "Kiểm tra API contract, schema migration, backward compatibility."
        )
    if impact_level == "MEDIUM":
        return (
            f"Unit test + integration test cho {service_name}. "
            "Kiểm tra business logic, edge cases, regression."
        )
    return (
        f"Unit test cho {service_name}. "
        "Kiểm tra config values, label text, constant changes."
    )


def _detect_conflicts(requirements_doc: str) -> list[str]:
    """Phát hiện conflict trong requirements_doc.

    Tìm các cặp mâu thuẫn như "không lưu X" và "lưu X" cho cùng entity X.
    """
    doc_lower = requirements_doc.lower()
    conflicts: list[str] = []

    for neg_pattern, pos_pattern in _CONFLICT_PATTERNS:
        for neg_match in re.finditer(neg_pattern, doc_lower):
            entity = neg_match.group(1) if neg_match.lastindex else ""
            if not entity:
                continue
            resolved_pos = pos_pattern.replace(r"\1", entity)
            if re.search(resolved_pos, doc_lower):
                conflicts.append(
                    f"Conflict: '{neg_match.group(0)}' mâu thuẫn với '{resolved_pos}'"
                )

    return conflicts


# ---------------------------------------------------------------------------
# Core function
# ---------------------------------------------------------------------------


def analyze_impact(
    requirements_doc: str,
    collection_name: str = "knowledge",
    top_k: int = 10,
    trace_id: str | None = None,
) -> ImpactReport:
    """Phân tích impact của requirements mới lên codebase hiện có.

    Tìm kiếm ChromaDB để xác định các file/service bị ảnh hưởng,
    phân loại impact level và phát hiện conflict.

    Args:
        requirements_doc: Nội dung tài liệu requirements (markdown).
        collection_name: Tên ChromaDB collection để search.
        top_k: Số lượng kết quả tối đa từ ChromaDB.
        trace_id: ID để trace request xuyên suốt hệ thống.

    Returns:
        ImpactReport với danh sách impacted services và totals.
    """
    if trace_id is None:
        trace_id = uuid.uuid4().hex[:16]

    logger.info(
        "analyze_impact started",
        extra={"trace_id": trace_id, "collection_name": collection_name, "top_k": top_k},
    )

    # 1. Phát hiện conflict trong requirements
    conflicts = _detect_conflicts(requirements_doc)
    if conflicts:
        logger.warning(
            "Conflicts detected in requirements",
            extra={"trace_id": trace_id, "conflicts_count": len(conflicts)},
        )

    # 2. Search ChromaDB để tìm relevant codebase chunks
    search_results = _fetch_search_results(requirements_doc, collection_name, top_k, trace_id)

    if not search_results:
        logger.info(
            "analyze_impact completed with no results",
            extra={"trace_id": trace_id, "impacted_services": 0},
        )
        return ImpactReport(
            impacted_services=[],
            total_high=0,
            total_medium=0,
            total_low=0,
            conflicts=conflicts,
            analyzed_at=datetime.now(timezone.utc).isoformat(),
            trace_id=trace_id,
        )

    # 3. Group results by service, pick highest impact level per service
    service_map = _group_by_service(search_results)

    # 4. Build ImpactedService list
    impacted_services = _build_impacted_services(service_map)

    total_high = sum(1 for s in impacted_services if s.impact_level == "HIGH")
    total_medium = sum(1 for s in impacted_services if s.impact_level == "MEDIUM")
    total_low = sum(1 for s in impacted_services if s.impact_level == "LOW")

    logger.info(
        "analyze_impact completed",
        extra={
            "trace_id": trace_id,
            "impacted_services": len(impacted_services),
            "total_high": total_high,
            "total_medium": total_medium,
            "total_low": total_low,
            "conflicts_count": len(conflicts),
        },
    )

    return ImpactReport(
        impacted_services=impacted_services,
        total_high=total_high,
        total_medium=total_medium,
        total_low=total_low,
        conflicts=conflicts,
        analyzed_at=datetime.now(timezone.utc).isoformat(),
        trace_id=trace_id,
    )


def _fetch_search_results(
    query: str,
    collection_name: str,
    top_k: int,
    trace_id: str,
) -> list[object]:
    """Lấy kết quả từ ChromaDB. Trả về [] nếu không khả dụng."""
    try:
        from app.retrieval.search import search as chroma_search

        results = chroma_search(query=query, collection_name=collection_name, top_k=top_k)
        logger.info(
            "ChromaDB search completed",
            extra={"trace_id": trace_id, "results_count": len(results)},
        )
        return results
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "ChromaDB search failed, returning empty impact report",
            extra={"trace_id": trace_id, "error": str(exc)},
        )
        return []


def _group_by_service(
    search_results: list[object],
) -> dict[str, dict]:
    """Group search results by service name, collecting files and best impact level."""
    _level_rank = {"HIGH": 3, "MEDIUM": 2, "LOW": 1}
    service_map: dict[str, dict] = {}

    for result in search_results:
        metadata = getattr(result, "metadata", {}) or {}
        source_path = metadata.get("source", metadata.get("file_path", "unknown"))
        content = getattr(result, "content", "")

        service_name = _extract_service_name(source_path)
        impact_level = _classify_impact(content, source_path)

        if service_name not in service_map:
            service_map[service_name] = {
                "impact_level": impact_level,
                "affected_files": [source_path],
                "reasons": [content[:120].strip()],
            }
        else:
            entry = service_map[service_name]
            # Escalate impact level if higher
            if _level_rank[impact_level] > _level_rank[entry["impact_level"]]:
                entry["impact_level"] = impact_level
            if source_path not in entry["affected_files"]:
                entry["affected_files"].append(source_path)
            if content[:120].strip() not in entry["reasons"]:
                entry["reasons"].append(content[:120].strip())

    return service_map


def _build_impacted_services(service_map: dict[str, dict]) -> list[ImpactedService]:
    """Chuyển service_map thành danh sách ImpactedService."""
    services: list[ImpactedService] = []
    for service_name, data in service_map.items():
        impact_level = data["impact_level"]
        reason = "; ".join(data["reasons"][:2]) or "Liên quan đến requirements mới"
        services.append(
            ImpactedService(
                service_name=service_name,
                impact_level=impact_level,
                affected_files=data["affected_files"],
                reason=reason,
                test_strategy=_build_test_strategy(impact_level, service_name),
            )
        )
    return services
