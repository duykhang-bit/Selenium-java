"""AI Quality Gate cho Jira Integration — kiểm tra chất lượng issue trước khi tạo."""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass, field
from pathlib import Path

from app.core.config import settings
from app.core.utils import utc_now_iso

logger = logging.getLogger(__name__)

# Issue types hợp lệ (có thể mở rộng qua config)
_VALID_ISSUE_TYPES = {
    "epic", "story", "sub-task", "subtask", "bug", "task", "improvement",
}

# Placeholder text không được phép trong description
_PLACEHOLDER_PATTERNS = ("TODO", "TBD", "...", "FIXME", "PLACEHOLDER")

# Từ khoá bắt buộc có security note
_SECURITY_KEYWORDS = ("authentication", "auth", "payment", "thanh toán", "health", "sức khỏe", "bệnh nhân")

# Từ khoá bắt buộc có data privacy note
_PRIVACY_KEYWORDS = ("pii", "personal", "cá nhân", "bệnh nhân", "patient", "cmnd", "cccd", "sdt", "điện thoại")


@dataclass
class QualityGateResult:
    """Kết quả kiểm tra chất lượng của AI Quality Gate."""

    passed: bool
    confidence_score: float  # luôn trong [0.0, 1.0]
    issues: list[str] = field(default_factory=list)
    audit_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])


class AIQualityGate:
    """Kiểm tra chất lượng Jira issue fields trước khi tạo ticket.

    Threshold mặc định: 0.7 (cấu hình qua AI_CONTEXT_V2_JIRA_QUALITY_THRESHOLD).
    """

    def __init__(self, threshold: float | None = None) -> None:
        self.threshold = threshold if threshold is not None else settings.jira_quality_threshold

    def check(self, issue_fields: dict) -> QualityGateResult:
        """Kiểm tra chất lượng issue fields.

        Ghi audit record vào log TRƯỚC khi trả về kết quả.

        Args:
            issue_fields: dict chứa summary, description, issue_type, v.v.

        Returns:
            QualityGateResult với passed, confidence_score, issues, audit_id
        """
        problems: list[str] = []
        score = 1.0

        summary = (issue_fields.get("summary") or "").strip()
        description = (issue_fields.get("description") or "").strip()
        issue_type = (issue_fields.get("issuetype", {}) or {})
        if isinstance(issue_type, dict):
            issue_type_name = (issue_type.get("name") or "").strip()
        else:
            issue_type_name = str(issue_type).strip()

        # --- Kiểm tra bắt buộc ---
        if not summary:
            problems.append("summary không được để trống")
            score = 0.0  # fatal — trả về 0.0 ngay

        if len(description) < 50:
            problems.append(f"description quá ngắn ({len(description)} ký tự, tối thiểu 50)")
            if score > 0:
                score -= 0.2

        if not issue_type_name or issue_type_name.lower() not in _VALID_ISSUE_TYPES:
            problems.append(
                f"issue_type không hợp lệ: '{issue_type_name}'. "
                f"Hợp lệ: {', '.join(sorted(_VALID_ISSUE_TYPES))}"
            )
            score = 0.0  # fatal — trả về 0.0 ngay

        # --- Kiểm tra theo issue type ---
        type_lower = issue_type_name.lower()

        if type_lower == "story":
            if not _has_acceptance_criteria(description):
                problems.append("Story phải có ít nhất 1 acceptance criteria trong description")
                score -= 0.15

        if type_lower == "epic":
            if not _has_business_objective(description):
                problems.append("Epic phải có business objective rõ ràng trong description")
                score -= 0.15

        # --- Kiểm tra placeholder ---
        for placeholder in _PLACEHOLDER_PATTERNS:
            if placeholder in description.upper():
                problems.append(f"description chứa placeholder text: '{placeholder}'")
                score -= 0.05
                break

        # --- Kiểm tra security note ---
        combined = f"{summary} {description}".lower()
        if any(kw in combined for kw in _SECURITY_KEYWORDS):
            if "security" not in combined and "bảo mật" not in combined:
                problems.append(
                    "Issue liên quan đến auth/payment/health data phải có security note trong description"
                )
                score -= 0.1

        # --- Kiểm tra data privacy ---
        if any(kw in combined for kw in _PRIVACY_KEYWORDS):
            if "privacy" not in combined and "bảo vệ dữ liệu" not in combined and "nghị định" not in combined:
                problems.append(
                    "Issue xử lý PII phải có điều khoản bảo vệ dữ liệu trong acceptance criteria"
                )
                score -= 0.1

        # Clamp score vào [0.0, 1.0]
        score = max(0.0, min(1.0, score))
        passed = score >= self.threshold and not any(
            p for p in problems if "không được để trống" in p or "không hợp lệ" in p
        )

        result = QualityGateResult(
            passed=passed,
            confidence_score=round(score, 4),
            issues=problems,
        )

        # Ghi audit record TRƯỚC khi return
        _write_quality_gate_audit(result, issue_fields)

        return result


# ---------------------------------------------------------------------------
# Audit helpers
# ---------------------------------------------------------------------------

def _has_acceptance_criteria(description: str) -> bool:
    """Kiểm tra description có chứa acceptance criteria không."""
    lower = description.lower()
    return any(
        kw in lower
        for kw in (
            "acceptance criteria", "tiêu chí nghiệm thu", "given ", "when ", "then ",
            "ac:", "ac1", "- [ ]", "- [x]",
        )
    )


def _has_business_objective(description: str) -> bool:
    """Kiểm tra description có chứa business objective không."""
    lower = description.lower()
    return any(
        kw in lower
        for kw in (
            "objective", "mục tiêu", "goal", "business", "nghiệp vụ",
            "kết quả mong đợi", "expected outcome",
        )
    )


def _write_quality_gate_audit(result: QualityGateResult, issue_fields: dict) -> None:
    """Ghi audit record vào jira_audit.jsonl."""
    audit_record = {
        "event_type": "quality_gate_check",
        "created_at": utc_now_iso(),
        "details": {
            "audit_id": result.audit_id,
            "action": "quality_gate",
            "input_summary": (issue_fields.get("summary") or "")[:200],
            "issue_type": (
                (issue_fields.get("issuetype") or {}).get("name", "")
                if isinstance(issue_fields.get("issuetype"), dict)
                else str(issue_fields.get("issuetype", ""))
            ),
            "confidence_score": result.confidence_score,
            "passed": result.passed,
            "issues": result.issues,
        },
    }

    try:
        audit_path = settings.logs_dir / "jira_audit.jsonl"
        audit_path.parent.mkdir(parents=True, exist_ok=True)
        with audit_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(audit_record, ensure_ascii=False) + "\n")
    except Exception as exc:
        logger.error("Không thể ghi quality gate audit: %s", exc)


def write_audit_record(
    action: str,
    actor: str,
    issue_key: str | None,
    input_summary: str,
    result: str,
    error: str | None,
    trace_id: str,
    task_id: str | None = None,
    dossier_timeline_path: Path | None = None,
) -> str:
    """Ghi audit record cho mọi thao tác Jira.

    Args:
        action: loại thao tác (create_issue, transition, sync, v.v.)
        actor: sha256(api_key)[:8] hoặc "system"
        issue_key: Jira issue key nếu có
        input_summary: mô tả ngắn input (KHÔNG chứa PII)
        result: "success" hoặc "failed"
        error: thông báo lỗi nếu failed
        trace_id: trace ID xuyên suốt request
        task_id: task dossier ID nếu có
        dossier_timeline_path: path đến timeline.jsonl của dossier

    Returns:
        audit_id (str)
    """
    audit_id = str(uuid.uuid4())[:8]
    record = {
        "event_type": f"jira_{action}",
        "created_at": utc_now_iso(),
        "details": {
            "audit_id": audit_id,
            "action": action,
            "actor": actor,
            "issue_key": issue_key,
            "input_summary": input_summary[:200],
            "result": result,
            "error": error,
            "trace_id": trace_id,
            "task_id": task_id,
        },
    }

    record_line = json.dumps(record, ensure_ascii=False) + "\n"

    # Ghi vào jira_audit.jsonl
    try:
        audit_path = settings.logs_dir / "jira_audit.jsonl"
        audit_path.parent.mkdir(parents=True, exist_ok=True)
        with audit_path.open("a", encoding="utf-8") as f:
            f.write(record_line)
    except Exception as exc:
        logger.error("Không thể ghi jira audit: %s", exc)

    # Ghi vào dossier timeline nếu có
    if dossier_timeline_path is not None:
        try:
            with dossier_timeline_path.open("a", encoding="utf-8") as f:
                f.write(record_line)
        except Exception as exc:
            logger.error("Không thể ghi dossier timeline: %s", exc)

    return audit_id
