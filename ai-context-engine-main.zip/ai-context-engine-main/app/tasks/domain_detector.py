"""Domain detector — phát hiện domain từ text bằng keyword scoring.

Pure Python, không gọi LLM. Tốc độ < 5ms.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from app.core.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class ComplianceClause:
    domain: str           # "PHARMACY"
    code: str             # "PHARMACY-001"
    title: str            # "Validation kê đơn Rx"
    requirement_text: str # text inject vào document
    legal_basis: str      # "Luật Dược 2016, Điều 47"
    mandatory: bool       # True = phải có, False = khuyến nghị


@dataclass
class DomainDetectionResult:
    domains: list[str]
    scores: dict[str, float]
    compliance_clauses: list[ComplianceClause]
    detected_at: str      # ISO 8601 UTC


# ---------------------------------------------------------------------------
# Keyword mapping
# ---------------------------------------------------------------------------

_KEYWORD_MAP: dict[str, list[str]] = {
    "PHARMACY": [
        "thuốc", "dược", "kê đơn", "nhà thuốc", "dược sĩ",
        "drug", "pharmacy", "prescription", "rx",
    ],
    "LAB_EMR": [
        "xét nghiệm", "bệnh án", "hồ sơ bệnh nhân",
        "lab", "medical record", "emr", "test result",
    ],
    "VACCINATION": [
        "tiêm", "vắc xin", "tiêm chủng",
        "vaccine", "immunization", "vaccination",
    ],
    "PAYMENT": [
        "thanh toán", "thẻ", "pos", "giao dịch",
        "payment", "card", "transaction", "pci",
    ],
    "MEDICAL_DEVICE": [
        "thiết bị", "iot", "cảm biến", "monitor",
        "device", "sensor", "wearable",
    ],
    "INFOSEC": [
        "bảo mật", "an toàn thông tin", "sự cố",
        "security", "incident", "vncert",
    ],
}

_SCORE_PER_MATCH = 0.3
_THRESHOLD = 0.3

# ---------------------------------------------------------------------------
# Compliance clause catalogue
# ---------------------------------------------------------------------------

_CLAUSES: list[ComplianceClause] = [
    # PHARMACY
    ComplianceClause(
        domain="PHARMACY", code="PHARMACY-001",
        title="Validation kê đơn Rx",
        requirement_text=(
            "Hệ thống PHẢI xác nhận đơn thuốc Rx hợp lệ trước khi cho phép bán. "
            "Validation bao gồm: tên bác sĩ kê đơn, ngày kê, chữ ký số."
        ),
        legal_basis="Luật Dược 2016 (sửa đổi 2023), Điều 47",
        mandatory=True,
    ),
    ComplianceClause(
        domain="PHARMACY", code="PHARMACY-002",
        title="Lưu trữ giao dịch thuốc tối thiểu 5 năm",
        requirement_text=(
            "Hệ thống PHẢI lưu trữ toàn bộ lịch sử giao dịch thuốc tối thiểu 5 năm "
            "kể từ ngày giao dịch theo Luật Dược 2016."
        ),
        legal_basis="Luật Dược 2016, Điều 52",
        mandatory=True,
    ),
    ComplianceClause(
        domain="PHARMACY", code="PHARMACY-003",
        title="Đối chiếu danh mục thuốc Bộ Y tế",
        requirement_text=(
            "Thông tin thuốc trong hệ thống PHẢI khớp với danh mục thuốc được "
            "Bộ Y tế phê duyệt. Hệ thống phải có cơ chế đồng bộ danh mục định kỳ."
        ),
        legal_basis="Luật Dược 2016, Thông tư 30/2018/TT-BYT",
        mandatory=True,
    ),
    ComplianceClause(
        domain="PHARMACY", code="PHARMACY-004",
        title="Báo cáo ADR (Adverse Drug Reaction)",
        requirement_text=(
            "Hệ thống PHẢI ghi nhận và hỗ trợ báo cáo phản ứng có hại của thuốc (ADR) "
            "định kỳ lên cơ quan quản lý theo quy định."
        ),
        legal_basis="Luật Dược 2016, Thông tư 23/2011/TT-BYT",
        mandatory=True,
    ),
    # LAB_EMR
    ComplianceClause(
        domain="LAB_EMR", code="LAB-001",
        title="Audit trail và chữ ký số hồ sơ bệnh án",
        requirement_text=(
            "Hệ thống PHẢI duy trì audit trail đầy đủ cho mọi thao tác trên hồ sơ bệnh án "
            "(ai xem, ai sửa, khi nào). Hồ sơ bệnh án điện tử PHẢI có chữ ký số của bác sĩ "
            "phụ trách theo Nghị định 96/2023."
        ),
        legal_basis="Nghị định 96/2023/NĐ-CP, Điều 15",
        mandatory=True,
    ),
    ComplianceClause(
        domain="LAB_EMR", code="LAB-002",
        title="Lưu trữ bệnh án tối thiểu 10/15 năm",
        requirement_text=(
            "Hệ thống PHẢI lưu trữ hồ sơ bệnh án điện tử tối thiểu 10 năm cho người lớn "
            "và 15 năm cho trẻ em kể từ ngày kết thúc điều trị theo Thông tư 27/2021."
        ),
        legal_basis="Thông tư 27/2021/TT-BYT, Điều 8",
        mandatory=True,
    ),
    ComplianceClause(
        domain="LAB_EMR", code="LAB-003",
        title="Giá trị tham chiếu và đơn vị đo chuẩn",
        requirement_text=(
            "Kết quả xét nghiệm PHẢI bao gồm giá trị tham chiếu bình thường và đơn vị đo "
            "theo chuẩn quốc tế (SI units) theo Nghị định 96/2023."
        ),
        legal_basis="Nghị định 96/2023/NĐ-CP, Điều 18",
        mandatory=True,
    ),
    ComplianceClause(
        domain="LAB_EMR", code="LAB-004",
        title="Tuân thủ chuẩn HL7 FHIR",
        requirement_text=(
            "Hệ thống PHẢI hỗ trợ chia sẻ dữ liệu y tế theo chuẩn HL7 FHIR R4 "
            "hoặc chuẩn tương đương được Bộ Y tế chấp thuận theo Thông tư 27/2021."
        ),
        legal_basis="Thông tư 27/2021/TT-BYT, Điều 6",
        mandatory=True,
    ),
    # VACCINATION
    ComplianceClause(
        domain="VACCINATION", code="VAC-001",
        title="Kết nối hệ thống tiêm chủng quốc gia",
        requirement_text=(
            "Hệ thống PHẢI kết nối và đồng bộ dữ liệu với Hệ thống thông tin tiêm chủng "
            "quốc gia theo Thông tư 09/2023/TT-BYT."
        ),
        legal_basis="Thông tư 09/2023/TT-BYT, Điều 5",
        mandatory=True,
    ),
    ComplianceClause(
        domain="VACCINATION", code="VAC-002",
        title="Cảnh báo chống chỉ định tự động",
        requirement_text=(
            "Hệ thống PHẢI tự động kiểm tra và cảnh báo chống chỉ định tiêm chủng "
            "dựa trên lịch sử bệnh án và tiền sử dị ứng của bệnh nhân."
        ),
        legal_basis="Thông tư 09/2023/TT-BYT, Điều 9",
        mandatory=True,
    ),
    ComplianceClause(
        domain="VACCINATION", code="VAC-003",
        title="Lưu trữ lịch sử tiêm chủng tối thiểu 20 năm",
        requirement_text=(
            "Hệ thống PHẢI lưu trữ toàn bộ lịch sử tiêm chủng tối thiểu 20 năm "
            "kể từ ngày tiêm theo Thông tư 09/2023."
        ),
        legal_basis="Thông tư 09/2023/TT-BYT, Điều 12",
        mandatory=True,
    ),
    # PAYMENT
    ComplianceClause(
        domain="PAYMENT", code="PAY-001",
        title="Không lưu CVV và full PAN sau giao dịch",
        requirement_text=(
            "Hệ thống KHÔNG ĐƯỢC lưu trữ CVV, full PAN hoặc dữ liệu xác thực thẻ "
            "sau khi giao dịch hoàn thành theo PCI-DSS Requirement 3."
        ),
        legal_basis="PCI-DSS v4.0, Requirement 3.2",
        mandatory=True,
    ),
    ComplianceClause(
        domain="PAYMENT", code="PAY-002",
        title="Mã hoá AES-256 cho dữ liệu thẻ",
        requirement_text=(
            "Dữ liệu thẻ thanh toán khi lưu trữ PHẢI được mã hoá bằng AES-256 "
            "hoặc thuật toán tương đương theo PCI-DSS Requirement 3."
        ),
        legal_basis="PCI-DSS v4.0, Requirement 3.5",
        mandatory=True,
    ),
    ComplianceClause(
        domain="PAYMENT", code="PAY-003",
        title="Network segmentation môi trường thanh toán",
        requirement_text=(
            "Môi trường xử lý thanh toán PHẢI được tách biệt khỏi các hệ thống khác "
            "bằng network segmentation theo PCI-DSS Requirement 1."
        ),
        legal_basis="PCI-DSS v4.0, Requirement 1.3",
        mandatory=True,
    ),
    # MEDICAL_DEVICE
    ComplianceClause(
        domain="MEDICAL_DEVICE", code="DEV-001",
        title="Timestamp NTP và outlier detection",
        requirement_text=(
            "Thiết bị y tế IoT PHẢI đồng bộ thời gian qua NTP và hệ thống PHẢI có "
            "cơ chế phát hiện dữ liệu bất thường (outlier detection) theo QCVN 117:2020."
        ),
        legal_basis="QCVN 117:2020/BTTTT, Mục 4.3",
        mandatory=True,
    ),
    ComplianceClause(
        domain="MEDICAL_DEVICE", code="DEV-002",
        title="Secure OTA firmware update",
        requirement_text=(
            "Firmware thiết bị y tế PHẢI có cơ chế cập nhật an toàn qua mạng (secure OTA) "
            "với xác thực chữ ký số trước khi áp dụng bản cập nhật."
        ),
        legal_basis="QCVN 117:2020/BTTTT, Mục 5.2",
        mandatory=True,
    ),
    # INFOSEC
    ComplianceClause(
        domain="INFOSEC", code="SEC-001",
        title="RTO ≤ 4 giờ và RPO ≤ 1 giờ",
        requirement_text=(
            "Hệ thống PHẢI đáp ứng RTO ≤ 4 giờ và RPO ≤ 1 giờ. "
            "Phải có phương án backup và disaster recovery được kiểm tra định kỳ "
            "theo Luật ATTTM 2015."
        ),
        legal_basis="Luật An toàn thông tin mạng 2015, Điều 21",
        mandatory=True,
    ),
    ComplianceClause(
        domain="INFOSEC", code="SEC-002",
        title="Báo cáo sự cố cho VNCERT/CC trong 24 giờ",
        requirement_text=(
            "Hệ thống PHẢI có quy trình phát hiện và báo cáo sự cố an toàn thông tin "
            "cho VNCERT/CC trong vòng 24 giờ kể từ khi phát hiện."
        ),
        legal_basis="Luật An toàn thông tin mạng 2015, Điều 23",
        mandatory=True,
    ),
    ComplianceClause(
        domain="INFOSEC", code="SEC-003",
        title="Thông báo vi phạm dữ liệu trong 72 giờ",
        requirement_text=(
            "Khi phát hiện vi phạm dữ liệu cá nhân, hệ thống PHẢI thông báo cho "
            "cơ quan có thẩm quyền trong vòng 72 giờ theo Nghị định 13/2023."
        ),
        legal_basis="Nghị định 13/2023/NĐ-CP, Điều 23",
        mandatory=True,
    ),
]

# Index clauses by domain for fast lookup
_CLAUSES_BY_DOMAIN: dict[str, list[ComplianceClause]] = {}
for _clause in _CLAUSES:
    _CLAUSES_BY_DOMAIN.setdefault(_clause.domain, []).append(_clause)


# ---------------------------------------------------------------------------
# Core logic
# ---------------------------------------------------------------------------


def _score_text(text_lower: str) -> dict[str, float]:
    """Tính keyword score cho từng domain. O(keywords)."""
    scores: dict[str, float] = {}
    for domain, keywords in _KEYWORD_MAP.items():
        hits = sum(1 for kw in keywords if kw in text_lower)
        if hits:
            scores[domain] = round(hits * _SCORE_PER_MATCH, 4)
    return scores


def _merge_clauses(domains: list[str]) -> list[ComplianceClause]:
    """Trả về compliance clauses không trùng lặp cho các domain đã phát hiện."""
    seen_codes: set[str] = set()
    merged: list[ComplianceClause] = []
    for domain in domains:
        for clause in _CLAUSES_BY_DOMAIN.get(domain, []):
            if clause.code not in seen_codes:
                seen_codes.add(clause.code)
                merged.append(clause)
    return merged


def detect_domains(text: str) -> DomainDetectionResult:
    """Phát hiện domain từ text bằng keyword scoring.

    Args:
        text: Nội dung intent hoặc requirement cần phân tích.

    Returns:
        DomainDetectionResult với danh sách domain, scores và compliance clauses.
    """
    if not text or not text.strip():
        logger.debug("detect_domains called with empty text")
        return DomainDetectionResult(
            domains=[],
            scores={},
            compliance_clauses=[],
            detected_at=datetime.now(timezone.utc).isoformat(),
        )

    text_lower = text.lower()
    raw_scores = _score_text(text_lower)

    active_scores = {
        domain: score
        for domain, score in raw_scores.items()
        if score >= _THRESHOLD
    }

    # Sort by score descending for deterministic ordering
    domains = sorted(active_scores, key=lambda d: active_scores[d], reverse=True)
    clauses = _merge_clauses(domains)

    logger.info(
        "detect_domains completed",
        extra={"domains": domains, "domain_count": len(domains)},
    )

    return DomainDetectionResult(
        domains=domains,
        scores=active_scores,
        compliance_clauses=clauses,
        detected_at=datetime.now(timezone.utc).isoformat(),
    )
