"""Design Generator — sinh HLD/LLD/ERD/OpenAPI từ requirements document.

Pure Python, không gọi LLM. Sinh structured template document từ requirements_doc,
tích hợp domain detection, compliance checking, impact analysis và ChromaDB context.
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from app.core.config import settings
from app.core.logging import get_logger
from app.tasks.compliance_checker import ComplianceReport, check_design
from app.tasks.domain_detector import detect_domains
from app.tasks.impact_analyzer import ImpactReport, analyze_impact

logger = get_logger(__name__)

_HEALTHCARE_DOMAINS = frozenset(["PHARMACY", "LAB_EMR", "VACCINATION"])

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class DesignGeneratorResult:
    document: str
    domains: list[str]
    compliance_report: ComplianceReport
    impact_report: ImpactReport
    context_chunks_used: int
    generated_at: str           # ISO 8601 UTC
    trace_id: str


# ---------------------------------------------------------------------------
# Template builders — each under 50 lines
# ---------------------------------------------------------------------------


def _extract_title(requirements_doc: str) -> str:
    """Trích xuất tiêu đề từ header '# Tài liệu Yêu cầu:' hoặc dòng đầu tiên."""
    for line in requirements_doc.splitlines():
        line = line.strip()
        if line.startswith("# Tài liệu Yêu cầu:"):
            title = line.removeprefix("# Tài liệu Yêu cầu:").strip()
            return title[:120]
        if line.startswith("#"):
            title = line.lstrip("#").strip()
            return title[:120]
    first = requirements_doc.strip().splitlines()[0] if requirements_doc.strip() else "Hệ thống mới"
    return first.strip()[:120]


def _build_overview(title: str, domains: list[str]) -> str:
    domain_labels = {
        "PHARMACY": "nhà thuốc / dược phẩm",
        "LAB_EMR": "xét nghiệm / hồ sơ bệnh án điện tử",
        "VACCINATION": "tiêm chủng",
        "PAYMENT": "thanh toán",
        "MEDICAL_DEVICE": "thiết bị y tế thông minh",
        "INFOSEC": "an toàn thông tin",
    }
    domain_str = (
        ", ".join(domain_labels.get(d, d) for d in domains)
        if domains else "hệ thống tổng quát"
    )
    return "\n".join([
        "## Tổng quan",
        "",
        f"Tài liệu này mô tả thiết kế kỹ thuật cho hệ thống **{title}**.",
        f"Hệ thống thuộc lĩnh vực: **{domain_str}**.",
        "",
        "Thiết kế bao gồm kiến trúc tổng thể (HLD), thiết kế chi tiết (LLD), "
        "mô hình dữ liệu (ERD) và API contract (OpenAPI-style).",
        "",
    ])


def _build_architecture(title: str) -> str:
    return "\n".join([
        "## Kiến trúc (Mermaid diagram)",
        "",
        "```mermaid",
        "graph TD",
        f'    Client["Client / UI"] --> API["API Gateway\\n{title}"]',
        '    API --> Service["Business Service Layer"]',
        '    Service --> DB["Database\\n(PostgreSQL / SQLite)"]',
        '    Service --> Cache["Cache\\n(Redis)"]',
        '    Service --> Queue["Message Queue\\n(async tasks)"]',
        '    API --> Auth["Auth Service\\n(JWT / API Key)"]',
        "```",
        "",
    ])


def _build_components(domains: list[str]) -> str:
    lines = [
        "## Components và Interfaces",
        "",
        "| Component | Trách nhiệm | Interface |",
        "|-----------|-------------|-----------|",
        "| API Gateway | Nhận request, xác thực, routing | REST / MCP |",
        "| Business Service | Xử lý nghiệp vụ chính | Internal Python API |",
        "| Data Access Layer | CRUD operations, query | SQLAlchemy / raw SQL |",
        "| Auth Module | Xác thực và phân quyền | JWT Bearer / API Key |",
        "| Audit Logger | Ghi nhật ký mọi thao tác | Append-only JSONL |",
    ]
    if _HEALTHCARE_DOMAINS & set(domains):
        lines.append("| Compliance Engine | Kiểm tra tuân thủ quy định y tế | Internal |")
    lines.append("")
    return "\n".join(lines)


def _build_erd(domains: list[str]) -> str:
    lines = [
        "## Data Models (ERD)",
        "",
        "```mermaid",
        "erDiagram",
        '    USER {',
        '        string id PK',
        '        string username',
        '        string role',
        '        datetime created_at',
        '    }',
        '    RECORD {',
        '        string id PK',
        '        string user_id FK',
        '        string content',
        '        datetime created_at',
        '        datetime updated_at',
        '    }',
        '    AUDIT_LOG {',
        '        string id PK',
        '        string actor',
        '        string action',
        '        string resource_id',
        '        datetime timestamp',
        '    }',
        '    USER ||--o{ RECORD : "creates"',
        '    USER ||--o{ AUDIT_LOG : "generates"',
    ]
    if "PHARMACY" in domains:
        lines += [
            '    PRESCRIPTION {',
            '        string id PK',
            '        string patient_id FK',
            '        string doctor_id FK',
            '        string drug_code',
            '        datetime prescribed_at',
            '    }',
            '    RECORD ||--o{ PRESCRIPTION : "contains"',
        ]
    lines += ["```", ""]
    return "\n".join(lines)


def _build_data_flow() -> str:
    return "\n".join([
        "## Data Flow Diagram (Mermaid)",
        "",
        "```mermaid",
        "sequenceDiagram",
        "    participant Client",
        "    participant API",
        "    participant Service",
        "    participant DB",
        "    participant AuditLog",
        "",
        "    Client->>API: Request (authenticated)",
        "    API->>Service: Validated request",
        "    Service->>DB: Read / Write data",
        "    DB-->>Service: Result",
        "    Service->>AuditLog: Append audit record",
        "    Service-->>API: Response",
        "    API-->>Client: JSON response",
        "```",
        "",
    ])


def _build_threat_model() -> str:
    return "\n".join([
        "## Threat Model",
        "",
        "| Tác nhân | Vector tấn công | Biện pháp phòng thủ |",
        "|----------|-----------------|---------------------|",
        "| External attacker | SQL Injection | Parameterized queries, ORM |",
        "| External attacker | SSRF | URL validation, allowlist |",
        "| Insider threat | Unauthorized data access | RBAC, audit trail |",
        "| External attacker | Brute force auth | Rate limiting, account lockout |",
        "| External attacker | Data exfiltration | Encryption at rest & in transit |",
        "| Malicious input | XSS / Injection | Input validation, sanitization |",
        "",
    ])


def _build_access_control(domains: list[str]) -> str:
    """Sinh phần phân quyền — chỉ khi có healthcare domain."""
    if not (_HEALTHCARE_DOMAINS & set(domains)):
        return ""
    lines = [
        "## Phân quyền truy cập",
        "",
        "| Chức danh | Quyền xem | Quyền tạo | Quyền sửa | Quyền xoá | Ghi chú |",
        "|-----------|-----------|-----------|-----------|-----------|---------|",
        "| Bác sĩ | ✅ | ✅ | ✅ (hồ sơ của mình) | ❌ | Ký số bắt buộc |",
        "| Dược sĩ | ✅ (đơn thuốc) | ✅ (giao dịch) | ❌ | ❌ | Xác nhận Rx |",
        "| Điều dưỡng | ✅ | ✅ (ghi chú) | ❌ | ❌ | Không ký số |",
        "| Admin | ✅ | ✅ | ✅ | ✅ | Audit trail bắt buộc |",
        "| Bệnh nhân | ✅ (của mình) | ❌ | ❌ | ❌ | Consent required |",
        "",
        "*Căn cứ: Thông tư 27/2021/TT-BYT, Điều 5 — Phân quyền theo chức danh y tế.*",
        "",
    ]
    return "\n".join(lines)


def _build_data_retention(domains: list[str]) -> str:
    rows = [
        ("Log hệ thống (security events)", "1 năm", "ISO 27001 / Luật ATTTM"),
        ("Audit log truy cập dữ liệu cá nhân", "2 năm", "Nghị định 13/2023"),
    ]
    if "PHARMACY" in domains:
        rows.insert(0, ("Lịch sử giao dịch thuốc", "5 năm", "Luật Dược 2016"))
    if "PAYMENT" in domains:
        rows.insert(0, ("Log giao dịch thanh toán", "5 năm", "PCI-DSS"))
    if "LAB_EMR" in domains:
        rows.insert(0, ("Hồ sơ bệnh án (người lớn)", "10 năm", "Nghị định 96/2023"))
        rows.insert(1, ("Hồ sơ bệnh án (trẻ em)", "15 năm", "Nghị định 96/2023"))
    if "VACCINATION" in domains:
        rows.insert(0, ("Lịch sử tiêm chủng", "20 năm", "Thông tư 09/2023"))

    lines = [
        "## Data Retention Policy",
        "",
        "| Loại dữ liệu | Thời gian lưu tối thiểu | Căn cứ pháp lý |",
        "|---|---|---|",
    ]
    for data_type, retention, basis in rows:
        lines.append(f"| {data_type} | {retention} | {basis} |")
    lines.append("")
    return "\n".join(lines)


def _build_backup_recovery() -> str:
    return "\n".join([
        "## Backup & Recovery Strategy (RTO/RPO)",
        "",
        "| Chỉ số | Mục tiêu | Phương án |",
        "|--------|----------|-----------|",
        "| RTO (Recovery Time Objective) | ≤ 4 giờ | Hot standby + automated failover |",
        "| RPO (Recovery Point Objective) | ≤ 1 giờ | Incremental backup mỗi 30 phút |",
        "",
        "**Chiến lược backup:**",
        "- Full backup hàng ngày lúc 02:00 UTC",
        "- Incremental backup mỗi 30 phút",
        "- Backup lưu tại ít nhất 2 vị trí địa lý khác nhau",
        "- Kiểm tra restore định kỳ hàng tháng",
        "",
        "*Căn cứ: Luật An toàn thông tin mạng 2015, Điều 21.*",
        "",
    ])


def _build_api_contract(title: str) -> str:
    safe_title = title.lower().replace(" ", "-")[:30]
    return "\n".join([
        "## API Contract (OpenAPI-style)",
        "",
        "```yaml",
        "openapi: 3.0.3",
        "info:",
        f"  title: {title} API",
        "  version: 1.0.0",
        "paths:",
        f"  /api/v1/{safe_title}:",
        "    get:",
        "      summary: Lấy danh sách",
        "      security:",
        "        - bearerAuth: []",
        "      responses:",
        "        '200':",
        "          description: Thành công",
        "        '401':",
        "          description: Chưa xác thực",
        "        '403':",
        "          description: Không có quyền",
        "    post:",
        "      summary: Tạo mới",
        "      security:",
        "        - bearerAuth: []",
        "      responses:",
        "        '201':",
        "          description: Tạo thành công",
        "        '422':",
        "          description: Dữ liệu không hợp lệ",
        "components:",
        "  securitySchemes:",
        "    bearerAuth:",
        "      type: http",
        "      scheme: bearer",
        "```",
        "",
    ])


def _build_error_handling() -> str:
    return "\n".join([
        "## Error Handling",
        "",
        "| HTTP Code | Tình huống | Hành động |",
        "|-----------|------------|-----------|",
        "| 400 | Bad Request — input không hợp lệ | Trả về chi tiết lỗi validation |",
        "| 401 | Unauthorized — thiếu hoặc sai token | Yêu cầu xác thực lại |",
        "| 403 | Forbidden — không đủ quyền | Log audit, trả về 403 |",
        "| 404 | Not Found — resource không tồn tại | Trả về message rõ ràng |",
        "| 422 | Unprocessable — vi phạm business rule | Trả về danh sách violations |",
        "| 429 | Too Many Requests — rate limit | Retry-After header |",
        "| 500 | Internal Server Error | Log đầy đủ, trả về trace_id |",
        "",
        "Mọi lỗi đều trả về JSON: `{\"error\": \"...\", \"trace_id\": \"...\", \"code\": \"...\"}`",
        "",
    ])


def _build_testing_strategy(domains: list[str]) -> str:
    lines = [
        "## Testing Strategy",
        "",
        "| Loại test | Phạm vi | Công cụ | Coverage target |",
        "|-----------|---------|---------|-----------------|",
        "| Unit test | Business logic, validators | pytest | ≥ 80% |",
        "| Integration test | API endpoints, DB | pytest + httpx | ≥ 70% |",
        "| Property-based test | Invariants, edge cases | Hypothesis | Key properties |",
        "| Contract test | API contract | Schemathesis | 100% endpoints |",
        "| Security test | SAST, dependency scan | Bandit, pip-audit | 0 HIGH CVE |",
    ]
    if _HEALTHCARE_DOMAINS & set(domains):
        lines.append("| Compliance test | Domain rules | Custom checkers | 100% rules |")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Audit logging
# ---------------------------------------------------------------------------


def _write_audit_record(
    trace_id: str,
    domains: list[str],
    compliance_passed: bool,
    violations_count: int,
    duration_ms: int,
) -> None:
    """Ghi audit record vào rde_audit.jsonl. Không chứa PII."""
    record = {
        "event_type": "rde_generate_design",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "details": {
            "audit_id": uuid.uuid4().hex[:8],
            "trace_id": trace_id,
            "action": "generate_design",
            "actor": "system",
            "domains": domains,
            "compliance_passed": compliance_passed,
            "violations_count": violations_count,
            "confluence_page_id": None,
            "duration_ms": duration_ms,
        },
    }
    log_path: Path = settings.logs_dir / "rde_audit.jsonl"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except OSError as exc:
        logger.warning(
            "Failed to write audit record",
            extra={"error": str(exc), "trace_id": trace_id},
        )


# ---------------------------------------------------------------------------
# Core function
# ---------------------------------------------------------------------------


def generate_design(
    requirements_doc: str,
    collection_name: str = "knowledge",
    top_k: int = 15,
    trace_id: str | None = None,
) -> DesignGeneratorResult:
    """Sinh tài liệu HLD/LLD/ERD/OpenAPI từ requirements document.

    Không gọi LLM. Sinh structured template document từ requirements_doc,
    tích hợp domain detection, compliance checking và ChromaDB context.

    Args:
        requirements_doc: Nội dung tài liệu requirements (markdown).
        collection_name: Tên ChromaDB collection để lấy context.
        top_k: Số lượng context chunks tối đa lấy từ ChromaDB.
        trace_id: ID để trace request xuyên suốt hệ thống.

    Returns:
        DesignGeneratorResult với document markdown, domains, compliance_report, impact_report.
    """
    if trace_id is None:
        trace_id = uuid.uuid4().hex[:16]

    start_time = time.monotonic()
    logger.info(
        "generate_design started",
        extra={"trace_id": trace_id, "collection_name": collection_name, "top_k": top_k},
    )

    # 1. Detect domains từ requirements_doc
    detection = detect_domains(requirements_doc)
    domains = detection.domains

    # 2. Lấy codebase context từ ChromaDB (graceful degradation)
    context_chunks: list[str] = []
    try:
        from app.retrieval.search import search as chroma_search
        results = chroma_search(query=requirements_doc, collection_name=collection_name, top_k=top_k)
        context_chunks = [r.content for r in results]
        logger.info(
            "ChromaDB context retrieved",
            extra={"trace_id": trace_id, "chunks_count": len(context_chunks)},
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "ChromaDB search failed, proceeding without context",
            extra={"trace_id": trace_id, "error": str(exc)},
        )

    # 3. Sinh document theo template chuẩn
    title = _extract_title(requirements_doc)
    access_control_section = _build_access_control(domains)

    sections: list[str] = [
        f"# Tài liệu Thiết kế: {title}",
        "",
        _build_overview(title, domains),
        _build_architecture(title),
        _build_components(domains),
        _build_erd(domains),
        _build_data_flow(),
        _build_threat_model(),
    ]
    if access_control_section:
        sections.append(access_control_section)
    sections += [
        _build_data_retention(domains),
        _build_backup_recovery(),
        _build_api_contract(title),
        _build_error_handling(),
        _build_testing_strategy(domains),
    ]
    document = "\n".join(sections)

    # 4. Kiểm tra compliance design
    compliance_report = check_design(document, domains)

    # 5. Phân tích impact
    impact_report = analyze_impact(
        requirements_doc,
        collection_name=collection_name,
        top_k=min(top_k, 10),
        trace_id=trace_id,
    )

    duration_ms = int((time.monotonic() - start_time) * 1000)

    # 6. Ghi audit record (không chứa PII)
    _write_audit_record(
        trace_id=trace_id,
        domains=domains,
        compliance_passed=compliance_report.passed,
        violations_count=len(compliance_report.violations),
        duration_ms=duration_ms,
    )

    logger.info(
        "generate_design completed",
        extra={
            "trace_id": trace_id,
            "domains": domains,
            "context_chunks_used": len(context_chunks),
            "compliance_passed": compliance_report.passed,
            "violations_count": len(compliance_report.violations),
            "duration_ms": duration_ms,
        },
    )

    return DesignGeneratorResult(
        document=document,
        domains=domains,
        compliance_report=compliance_report,
        impact_report=impact_report,
        context_chunks_used=len(context_chunks),
        generated_at=datetime.now(timezone.utc).isoformat(),
        trace_id=trace_id,
    )
