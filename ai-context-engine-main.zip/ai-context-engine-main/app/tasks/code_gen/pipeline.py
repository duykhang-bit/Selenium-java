"""Pipeline Orchestrator — chạy toàn bộ flow: decompose → generate → commit → MR."""

from __future__ import annotations

import json
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from app.core.config import settings
from app.core.logging import get_logger
from app.tasks.code_gen import branch_manager
from app.tasks.code_gen.commit_message import generate_message
from app.tasks.code_gen.decomposer import decompose
from app.tasks.code_gen.generator import generate
from app.tasks.code_gen.models import BranchAlreadyExistsError, GeneratedCode, PipelineResult

logger = get_logger(__name__)


def _write_audit(trace_id: str, source_id: str, branch_name: str, result: PipelineResult) -> None:
    record = {
        "event_type": "cgp_run_pipeline",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "details": {
            "trace_id": trace_id,
            "source_id": source_id,
            "branch_name": branch_name,
            "tasks_count": len(result.tasks),
            "files_generated": len(result.generated_files),
            "mr_url": result.mr_result.mr_url if result.mr_result else None,
            "errors": result.errors,
            "duration_ms": result.duration_ms,
        },
    }
    log_path: Path = settings.logs_dir / "cgp_audit.jsonl"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except OSError as exc:
        logger.warning("Failed to write CGP audit: %s", exc)


def run_pipeline(
    design_doc: str,
    source_id: str,
    branch_name: str,
    collection_name: str = "knowledge",
    from_branch: str | None = None,
    trace_id: str | None = None,
) -> PipelineResult:
    """Chạy toàn bộ pipeline: decompose → generate → commit → MR.

    Args:
        design_doc: Nội dung design document.
        source_id: GitLab source_id từ catalog.
        branch_name: Tên branch mới cần tạo.
        collection_name: ChromaDB collection.
        from_branch: Branch gốc để tạo branch mới (default: repo default branch).
        trace_id: Trace ID.

    Returns:
        PipelineResult với tasks, generated_files, mr_result.

    Raises:
        BranchAlreadyExistsError: nếu branch đã tồn tại.
    """
    if trace_id is None:
        trace_id = uuid.uuid4().hex[:16]

    start = time.monotonic()
    errors: list[str] = []

    logger.info("CGP pipeline started source=%s branch=%s", source_id, branch_name,
                extra={"trace_id": trace_id})

    # 1. Decompose design doc → tasks
    tasks = decompose(design_doc, collection_name)
    if not tasks:
        logger.warning("No tasks decomposed from design doc", extra={"trace_id": trace_id})

    # 2. Generate code cho từng task
    generated_files: list[GeneratedCode] = []
    for task in tasks:
        try:
            code = generate(task, collection_name)
            generated_files.append(code)
        except Exception as exc:
            errors.append(f"generate failed for task '{task.title}': {exc}")
            logger.warning("Code generation failed for task %s: %s", task.task_id, exc)

    # 3. Tạo branch (raise BranchAlreadyExistsError nếu đã tồn tại)
    branch_manager.create_branch(source_id, branch_name, from_branch)

    # 4. Commit files
    mr_result = None
    if generated_files:
        commit_files_payload = [
            {
                "file_path": g.file_path,
                "content": g.content,
                "action": "create",
            }
            for g in generated_files
        ]
        # Sinh commit message từ tất cả content
        combined_diff = "\n".join(
            f"+++ b/{g.file_path}\n" + "\n".join(f"+{line}" for line in g.content.splitlines())
            for g in generated_files
        )
        commit_msg = generate_message(combined_diff, task_description=f"implement {branch_name}")

        try:
            branch_manager.commit_files(source_id, branch_name, commit_files_payload, commit_msg)
        except Exception as exc:
            errors.append(f"commit failed: {exc}")
            logger.error("Commit failed: %s", exc, extra={"trace_id": trace_id})

        # 5. Tạo MR
        try:
            mr_title = f"feat: {branch_name.replace('/', ' ').replace('-', ' ')}"
            mr_result = branch_manager.create_mr(source_id, branch_name, mr_title)
        except Exception as exc:
            errors.append(f"MR creation failed: {exc}")
            logger.error("MR creation failed: %s", exc, extra={"trace_id": trace_id})

    duration_ms = int((time.monotonic() - start) * 1000)
    result = PipelineResult(
        tasks=tasks,
        generated_files=generated_files,
        mr_result=mr_result,
        duration_ms=duration_ms,
        trace_id=trace_id,
        errors=errors,
    )

    _write_audit(trace_id, source_id, branch_name, result)
    logger.info("CGP pipeline completed tasks=%d files=%d duration_ms=%d",
                len(tasks), len(generated_files), duration_ms,
                extra={"trace_id": trace_id})
    return result
