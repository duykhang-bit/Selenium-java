"""Branch Manager — tạo branch, commit files, tạo MR trên GitLab."""

from __future__ import annotations

from app.catalog.database import get_connector, get_source
from app.connectors.gitlab import GitLabConnector
from app.core.logging import get_logger
from app.tasks.code_gen.models import BranchAlreadyExistsError, MRResult

logger = get_logger(__name__)


def _get_connector(source: dict) -> GitLabConnector:
    connector_row = get_connector(source["connector_id"]) if source.get("connector_id") else None
    if not connector_row:
        raise ValueError(f"No GitLab connector found for source {source['source_id']}")
    return GitLabConnector(connector_row["base_url"], connector_row["token"])


def _project_id(source: dict) -> int:
    return int(source["external_id"])


def create_branch(source_id: str, branch_name: str, from_branch: str | None = None) -> dict:
    """Tạo branch mới trên GitLab.

    Raises:
        BranchAlreadyExistsError: nếu branch đã tồn tại.
        ValueError: nếu source không tìm thấy hoặc không có connector.
    """
    source = get_source(source_id)
    if not source:
        raise KeyError(f"Unknown source_id: {source_id}")

    connector = _get_connector(source)
    project_id = _project_id(source)
    ref = from_branch or source.get("default_branch", "main")

    # Kiểm tra branch đã tồn tại chưa
    existing = connector.get_branch(project_id, branch_name)
    if existing:
        raise BranchAlreadyExistsError(f"Branch '{branch_name}' already exists in {source_id}")

    result = connector.create_branch(project_id, branch_name, ref)
    logger.info("Created branch '%s' from '%s' in %s", branch_name, ref, source_id)
    return result


def commit_files(
    source_id: str,
    branch_name: str,
    files: list[dict],
    message: str,
) -> dict:
    """Commit một hoặc nhiều file lên branch.

    files: [{"file_path": ..., "content": ..., "action": "create"|"update"|"delete"}]
    """
    source = get_source(source_id)
    if not source:
        raise KeyError(f"Unknown source_id: {source_id}")

    connector = _get_connector(source)
    project_id = _project_id(source)

    result = connector.commit_files(project_id, branch_name, files, message)
    logger.info("Committed %d files to '%s' in %s", len(files), branch_name, source_id)
    return result


def create_mr(
    source_id: str,
    branch_name: str,
    title: str,
    description: str = "",
    target_branch: str | None = None,
) -> MRResult:
    """Tạo MR từ branch về default branch."""
    source = get_source(source_id)
    if not source:
        raise KeyError(f"Unknown source_id: {source_id}")

    connector = _get_connector(source)
    project_id = _project_id(source)
    target = target_branch or source.get("default_branch", "main")

    result = connector.create_merge_request(project_id, branch_name, target, title, description)
    mr_id = result.get("iid", result.get("id", 0))
    mr_url = result.get("web_url", result.get("_links", {}).get("web", ""))

    logger.info("Created MR !%d '%s' in %s", mr_id, title, source_id)
    return MRResult(
        mr_id=mr_id,
        mr_url=mr_url,
        branch_name=branch_name,
        title=title,
        source_id=source_id,
    )
