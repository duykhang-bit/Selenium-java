"""Data models cho Code Generation Pipeline."""

from __future__ import annotations

from dataclasses import dataclass, field


class BranchAlreadyExistsError(Exception):
    """Branch đã tồn tại trên GitLab."""


@dataclass
class CodingTask:
    task_id: str
    title: str
    type: str           # "create_file" | "modify_file" | "add_function" | "add_class" | "add_endpoint"
    target_file: str    # đường dẫn file tương đối trong repo
    description: str
    depends_on: list[str] = field(default_factory=list)
    priority: int = 3   # 1 (cao) → 5 (thấp)


@dataclass
class GeneratedCode:
    file_path: str
    content: str
    mode: str           # "skeleton" | "llm"
    language: str = "python"
    task_id: str = ""


@dataclass
class MRResult:
    mr_id: int
    mr_url: str
    branch_name: str
    title: str
    source_id: str


@dataclass
class PipelineResult:
    tasks: list[CodingTask]
    generated_files: list[GeneratedCode]
    mr_result: MRResult | None
    duration_ms: int
    trace_id: str
    errors: list[str] = field(default_factory=list)
