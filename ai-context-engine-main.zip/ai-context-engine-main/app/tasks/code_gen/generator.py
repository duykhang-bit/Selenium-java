"""Code Generator — sinh code skeleton hoặc dùng LLM."""

from __future__ import annotations

from app.core.config import settings
from app.core.logging import get_logger
from app.tasks.code_gen.models import CodingTask, GeneratedCode

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Skeleton templates
# ---------------------------------------------------------------------------

_FILE_TEMPLATE = '''\
"""Module docstring."""

from __future__ import annotations
'''

_FUNCTION_TEMPLATE = '''\
def {name}({args}) -> {return_type}:
    """{description}"""
    raise NotImplementedError
'''

_ASYNC_FUNCTION_TEMPLATE = '''\
async def {name}({args}) -> {return_type}:
    """{description}"""
    raise NotImplementedError
'''

_CLASS_TEMPLATE = '''\
class {name}:
    """{description}"""

    def __init__(self) -> None:
        pass
'''

_ENDPOINT_TEMPLATE = '''\
@router.{method}("{path}")
async def {name}(request: dict) -> dict:
    """{description}"""
    raise HTTPException(status_code=501, detail="Not implemented")
'''


def _extract_name(description: str, fallback: str = "new_function") -> str:
    """Trích xuất tên function/class từ description."""
    import re
    m = re.search(r"`(\w+)`|`(\w+)\(", description)
    if m:
        return m.group(1) or m.group(2)
    words = re.findall(r"[a-z_][a-z0-9_]*", description.lower())
    return "_".join(words[:3]) if words else fallback


def _generate_skeleton(task: CodingTask) -> GeneratedCode:
    """Sinh code skeleton dựa trên task type."""
    desc = task.description[:100]
    name = _extract_name(task.description)

    if task.type == "create_file":
        content = _FILE_TEMPLATE
    elif task.type == "add_function":
        is_async = "async" in task.description.lower() or "endpoint" in task.description.lower()
        tmpl = _ASYNC_FUNCTION_TEMPLATE if is_async else _FUNCTION_TEMPLATE
        content = tmpl.format(name=name, args="", return_type="None", description=desc)
    elif task.type == "add_class":
        class_name = "".join(w.capitalize() for w in name.split("_")) or "NewClass"
        content = _CLASS_TEMPLATE.format(name=class_name, description=desc)
    elif task.type == "add_endpoint":
        import re
        method_m = re.search(r"\b(get|post|put|patch|delete)\b", task.description, re.I)
        method = method_m.group(1).lower() if method_m else "post"
        path_m = re.search(r"/[\w/{}_-]+", task.description)
        path = path_m.group(0) if path_m else f"/{name}"
        content = _ENDPOINT_TEMPLATE.format(method=method, path=path, name=name, description=desc)
    else:
        content = f"# TODO: {task.title}\n# {desc}\n"

    return GeneratedCode(
        file_path=task.target_file,
        content=content,
        mode="skeleton",
        task_id=task.task_id,
    )


# ---------------------------------------------------------------------------
# LLM mode
# ---------------------------------------------------------------------------

def _llm_available() -> bool:
    return bool(settings.llm_api_key)


def _build_prompt(task: CodingTask, context_chunks: list[str], existing_content: str | None) -> str:
    parts = [
        f"Task: {task.title}",
        f"Type: {task.type}",
        f"File: {task.target_file}",
        f"Description: {task.description}",
        "",
    ]
    if context_chunks:
        parts.append("Relevant codebase context:")
        for chunk in context_chunks[:3]:
            parts.append(f"```\n{chunk[:300]}\n```")
        parts.append("")
    if existing_content:
        parts.append(f"Existing file content:\n```python\n{existing_content[:500]}\n```\n")
    parts.append("Generate Python code for this task. Return only the code, no explanation.")
    return "\n".join(parts)


def _call_llm(prompt: str) -> str:
    """Gọi LLM API. Raise exception nếu thất bại."""
    import urllib.request
    import json as _json

    key = settings.llm_api_key
    model = settings.llm_model
    timeout = settings.llm_timeout

    # Detect provider từ key prefix
    if key.startswith("sk-ant-"):
        # Anthropic
        url = "https://api.anthropic.com/v1/messages"
        headers = {
            "x-api-key": key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        body = _json.dumps({
            "model": model if "claude" in model else "claude-3-haiku-20240307",
            "max_tokens": 1024,
            "messages": [{"role": "user", "content": prompt}],
        }).encode()
    else:
        # OpenAI
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
        }
        body = _json.dumps({
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 1024,
        }).encode()

    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = _json.loads(resp.read())

    if key.startswith("sk-ant-"):
        return data["content"][0]["text"]
    return data["choices"][0]["message"]["content"]


def _extract_code_block(text: str) -> str:
    """Trích xuất code block từ markdown response."""
    import re
    m = re.search(r"```(?:python)?\n(.*?)```", text, re.DOTALL)
    return m.group(1).strip() if m else text.strip()


def _generate_llm(task: CodingTask, collection_name: str, existing_content: str | None) -> GeneratedCode:
    """Sinh code dùng LLM."""
    context_chunks: list[str] = []
    try:
        from app.retrieval.search import search
        results = search(task.description, collection_name, top_k=5)
        context_chunks = [r.content for r in results]
    except Exception:
        pass

    prompt = _build_prompt(task, context_chunks, existing_content)
    raw = _call_llm(prompt)
    content = _extract_code_block(raw)

    return GeneratedCode(
        file_path=task.target_file,
        content=content,
        mode="llm",
        task_id=task.task_id,
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def generate(
    task: CodingTask,
    collection_name: str = "knowledge",
    existing_content: str | None = None,
) -> GeneratedCode:
    """Sinh code cho task — tự động chọn skeleton hoặc LLM mode.

    Graceful degrade: LLM fail → skeleton mode.
    """
    if _llm_available():
        try:
            return _generate_llm(task, collection_name, existing_content)
        except Exception as exc:
            logger.warning("LLM generation failed, falling back to skeleton: %s", exc)

    return _generate_skeleton(task)
