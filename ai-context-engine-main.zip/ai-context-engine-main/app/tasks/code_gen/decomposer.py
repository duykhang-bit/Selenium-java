"""Task Decomposer — phân tích design doc → list[CodingTask] theo dependency order."""

from __future__ import annotations

import re
import uuid

from app.core.logging import get_logger
from app.tasks.code_gen.models import CodingTask

logger = get_logger(__name__)

# Patterns detect task type từ design doc
_PATTERNS: dict[str, re.Pattern] = {
    "add_endpoint": re.compile(r"POST|GET|PUT|DELETE|PATCH|/api/|endpoint|route|@router", re.I),
    "add_class":    re.compile(r"\bclass\s+\w+|\b@dataclass\b|Model|Schema|Entity|ERD", re.I),
    "add_function": re.compile(r"\bdef \w+|\bfunction\b|\bmethod\b|\bimplement\b", re.I),
    "create_file":  re.compile(r"tạo file|create file|new module|new file|tạo module", re.I),
}

# Thứ tự ưu tiên để sort dependency
_TYPE_ORDER = {"create_file": 0, "add_class": 1, "add_function": 2, "add_endpoint": 3, "modify_file": 4}

# Patterns tìm file path gợi ý từ context
_FILE_PATH_PATTERN = re.compile(r"app/[\w/]+\.py")


def _detect_type(text: str) -> str:
    """Detect task type từ đoạn text."""
    for task_type, pattern in _PATTERNS.items():
        if pattern.search(text):
            return task_type
    return "modify_file"


def _suggest_target_file(description: str, collection_name: str) -> str:
    """Gợi ý target file từ ChromaDB context. Fallback về convention nếu không có."""
    try:
        from app.retrieval.search import search
        results = search(description, collection_name, top_k=3)
        for r in results:
            src = r.metadata.get("relative_source") or r.metadata.get("source", "")
            m = _FILE_PATH_PATTERN.search(src)
            if m:
                return m.group(0)
    except Exception:
        pass
    # Fallback: derive từ description
    words = re.findall(r"[a-z_]+", description.lower())
    slug = "_".join(words[:3]) if words else "module"
    return f"app/tasks/{slug}.py"


def _extract_sections(design_doc: str) -> list[tuple[str, str]]:
    """Tách design doc thành các section (heading, content)."""
    sections: list[tuple[str, str]] = []
    current_heading = "Overview"
    current_lines: list[str] = []
    for line in design_doc.splitlines():
        if line.startswith("##"):
            if current_lines:
                sections.append((current_heading, "\n".join(current_lines)))
            current_heading = line.lstrip("#").strip()
            current_lines = []
        else:
            current_lines.append(line)
    if current_lines:
        sections.append((current_heading, "\n".join(current_lines)))
    return sections


def decompose(design_doc: str, collection_name: str = "knowledge") -> list[CodingTask]:
    """Phân tích design doc → list[CodingTask] đã sắp xếp theo dependency order.

    Args:
        design_doc: Nội dung design document (markdown).
        collection_name: ChromaDB collection để gợi ý target_file.

    Returns:
        Danh sách CodingTask đã sort theo dependency order.
    """
    if not design_doc or not design_doc.strip():
        return []

    sections = _extract_sections(design_doc)
    tasks: list[CodingTask] = []
    seen_titles: set[str] = set()

    for heading, content in sections:
        if not content.strip():
            continue

        task_type = _detect_type(heading + " " + content)
        title = heading[:80]

        # Tránh duplicate
        if title in seen_titles:
            continue
        seen_titles.add(title)

        target_file = _suggest_target_file(heading + " " + content[:200], collection_name)

        task_id = uuid.uuid4().hex[:8]
        tasks.append(CodingTask(
            task_id=task_id,
            title=title,
            type=task_type,
            target_file=target_file,
            description=content.strip()[:300],
            priority=_TYPE_ORDER.get(task_type, 4) + 1,
        ))

    # Sort theo dependency order (type order)
    tasks.sort(key=lambda t: _TYPE_ORDER.get(t.type, 4))

    # Assign depends_on: mỗi task phụ thuộc vào task trước cùng target_file
    file_last_task: dict[str, str] = {}
    for task in tasks:
        if task.target_file in file_last_task:
            task.depends_on = [file_last_task[task.target_file]]
        file_last_task[task.target_file] = task.task_id

    logger.info("decompose: %d tasks from design doc", len(tasks))
    return tasks
