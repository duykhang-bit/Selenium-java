"""Commit Message Generator — sinh conventional commit message từ diff."""

from __future__ import annotations

import re

# Detect commit type từ diff content
_TYPE_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("test",     re.compile(r"tests?/|test_\w+\.py|def test_", re.I)),
    ("docs",     re.compile(r"\.md$|README|docstring|\.rst$", re.I)),
    ("chore",    re.compile(r"requirements\.txt|pyproject\.toml|Dockerfile|\.env|setup\.py", re.I)),
    ("fix",      re.compile(r"\bfix\b|\bbug\b|\berror\b|\bpatch\b", re.I)),
    ("refactor", re.compile(r"\brefactor\b|\brename\b|\bmove\b|\bextract\b", re.I)),
    ("feat",     re.compile(r"^\+.*def |^\+.*class |^\+.*@router\.", re.M)),
]

# Detect scope từ file path
_SCOPE_MAP: list[tuple[re.Pattern, str]] = [
    (re.compile(r"app/api/"),      "api"),
    (re.compile(r"app/tasks/"),    "tasks"),
    (re.compile(r"app/connectors/"), "connectors"),
    (re.compile(r"app/sync/"),     "sync"),
    (re.compile(r"app/ingest/"),   "ingest"),
    (re.compile(r"app/catalog/"),  "catalog"),
    (re.compile(r"app/core/"),     "core"),
    (re.compile(r"tests?/"),       "tests"),
]

_NEW_SYMBOL = re.compile(r"^\+\s*(?:async\s+)?def (\w+)|^\+\s*class (\w+)", re.M)
_FILE_HEADER = re.compile(r"^\+\+\+ b/(.+)$", re.M)


def _detect_type(diff: str) -> str:
    for commit_type, pattern in _TYPE_PATTERNS:
        if pattern.search(diff):
            return commit_type
    return "chore"


def _detect_scope(diff: str) -> str:
    for pattern, scope in _SCOPE_MAP:
        if pattern.search(diff):
            return scope
    # Fallback: lấy từ file path đầu tiên trong diff
    m = _FILE_HEADER.search(diff)
    if m:
        parts = m.group(1).split("/")
        return parts[1] if len(parts) > 1 else parts[0]
    return ""


def _detect_description(diff: str, task_description: str | None) -> str:
    if task_description:
        desc = task_description.strip().rstrip(".")
        return desc[:72]

    # Tìm tên function/class mới nhất trong diff
    matches = _NEW_SYMBOL.findall(diff)
    if matches:
        name = next((m[0] or m[1] for m in matches if m[0] or m[1]), "")
        if name:
            return f"add {name.replace('_', ' ')}"[:72]

    return "update code"


def generate_message(diff: str, task_description: str | None = None) -> str:
    """Sinh conventional commit message từ diff.

    Format: type(scope): description

    Args:
        diff: Unified diff text.
        task_description: Mô tả task (ưu tiên hơn diff analysis).

    Returns:
        Conventional commit message string.
    """
    if not diff and not task_description:
        return "chore: update"

    commit_type = _detect_type(diff)
    scope = _detect_scope(diff)
    description = _detect_description(diff, task_description)

    if scope:
        return f"{commit_type}({scope}): {description}"
    return f"{commit_type}: {description}"
