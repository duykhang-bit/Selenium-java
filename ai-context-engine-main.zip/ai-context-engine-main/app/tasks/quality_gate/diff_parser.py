"""Parse unified diff format thành ParsedDiff."""

from __future__ import annotations

import re

from app.tasks.quality_gate.models import DiffFile, ParsedDiff

_FILE_HEADER = re.compile(r"^--- (.+)$")
_FILE_NEW = re.compile(r"^\+\+\+ (.+)$")
_HUNK_HEADER = re.compile(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@")


def parse_diff(diff_text: str) -> ParsedDiff:
    """Parse unified diff text thành ParsedDiff.

    Xử lý: file add/modify/delete, hunk headers, added/removed lines.
    """
    if not diff_text or not diff_text.strip():
        return ParsedDiff()

    files: list[DiffFile] = []
    current: DiffFile | None = None
    current_line = 0

    for raw_line in diff_text.splitlines():
        # --- a/file.py
        m = _FILE_HEADER.match(raw_line)
        if m:
            old_path = m.group(1)
            if old_path.startswith("a/"):
                old_path = old_path[2:]
            _old_path_tmp = old_path
            continue

        # +++ b/file.py
        m = _FILE_NEW.match(raw_line)
        if m:
            new_path = m.group(1)
            is_deleted = new_path == "/dev/null"

            try:
                is_new = _old_path_tmp == "/dev/null"
            except NameError:
                is_new = False

            if new_path.startswith("b/"):
                new_path = new_path[2:]

            change_type = "added" if is_new else ("deleted" if is_deleted else "modified")
            path = new_path if not is_deleted else _old_path_tmp  # type: ignore[possibly-undefined]
            current = DiffFile(path=path, change_type=change_type)
            files.append(current)
            current_line = 0
            continue

        # @@ -L,N +L,N @@
        m = _HUNK_HEADER.match(raw_line)
        if m:
            current_line = int(m.group(1))
            continue

        if current is None:
            continue

        if raw_line.startswith("+") and not raw_line.startswith("+++"):
            content = raw_line[1:]
            current.added_lines.append((current_line, content))
            current_line += 1
        elif raw_line.startswith("-") and not raw_line.startswith("---"):
            content = raw_line[1:]
            current.removed_lines.append((current_line, content))
            # removed lines không tăng new line counter
        else:
            # context line
            current_line += 1

    # Build full_new_content cho file mới hoàn toàn
    for diff_file in files:
        if diff_file.change_type == "added" and diff_file.added_lines:
            diff_file.full_new_content = "\n".join(line for _, line in diff_file.added_lines)

    return ParsedDiff(files=files)
