"""Data models cho Quality Gate Engine."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class Finding:
    gate: str
    severity: str       # "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "INFO"
    file: str
    message: str
    rule_id: str
    suggestion: str
    line: int | None = None


@dataclass
class GateReport:
    gate: str
    findings: list[Finding] = field(default_factory=list)
    duration_ms: int = 0
    error: str | None = None

    @property
    def passed(self) -> bool:
        return not any(f.severity in {"CRITICAL", "HIGH"} for f in self.findings)


@dataclass
class DiffFile:
    path: str
    change_type: str        # "added" | "modified" | "deleted"
    added_lines: list[tuple[int, str]] = field(default_factory=list)
    removed_lines: list[tuple[int, str]] = field(default_factory=list)
    full_new_content: str | None = None
    old_path: str | None = None


@dataclass
class ParsedDiff:
    files: list[DiffFile] = field(default_factory=list)


@dataclass
class QualityGateReport:
    gate_reports: list[GateReport] = field(default_factory=list)
    generated_test_code: str | None = None
    risk_score: int = 0
    analyzed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    trace_id: str = ""

    @property
    def all_findings(self) -> list[Finding]:
        return [f for r in self.gate_reports for f in r.findings]

    @property
    def total_critical(self) -> int:
        return sum(1 for f in self.all_findings if f.severity == "CRITICAL")

    @property
    def total_high(self) -> int:
        return sum(1 for f in self.all_findings if f.severity == "HIGH")

    @property
    def total_medium(self) -> int:
        return sum(1 for f in self.all_findings if f.severity == "MEDIUM")

    @property
    def total_low(self) -> int:
        return sum(1 for f in self.all_findings if f.severity == "LOW")

    @property
    def overall(self) -> str:
        if self.total_critical > 0 or self.total_high > 0:
            return "FAIL"
        if self.total_medium > 0 or self.total_low > 0:
            return "WARN"
        return "PASS"
