"""Performance Gate — N+1 query, sleep, SELECT *, unbounded loops."""

from __future__ import annotations

import ast
import re
import time

from app.tasks.quality_gate.models import DiffFile, Finding, GateReport, ParsedDiff

_GATE = "performance"
_DB_CALL_ATTRS = {"query", "execute", "filter", "get", "all", "first", "fetchone", "fetchall"}
_SELECT_STAR = re.compile(r"SELECT\s+\*", re.IGNORECASE)


def _is_test_file(path: str) -> bool:
    return "test" in path.lower()


def _check_n_plus_one(tree: ast.AST, diff_file: DiffFile) -> list[Finding]:
    """Tìm DB call bên trong for/while loop."""
    findings: list[Finding] = []

    for node in ast.walk(tree):
        if not isinstance(node, (ast.For, ast.While)):
            continue
        for child in ast.walk(node):
            if child is node:
                continue
            if isinstance(child, ast.Call) and isinstance(child.func, ast.Attribute):
                if child.func.attr in _DB_CALL_ATTRS:
                    findings.append(Finding(
                        gate=_GATE, severity="HIGH", file=diff_file.path, line=child.lineno,
                        message=f"N+1 query pattern: DB call '{child.func.attr}()' bên trong vòng lặp",
                        rule_id="PERF-001",
                        suggestion="Dùng bulk query hoặc prefetch_related thay vì query trong loop",
                    ))
    return findings


def _check_sleep(tree: ast.AST, diff_file: DiffFile) -> list[Finding]:
    findings: list[Finding] = []
    is_test = _is_test_file(diff_file.path)
    if is_test:
        return findings

    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr == "sleep":
                findings.append(Finding(
                    gate=_GATE, severity="MEDIUM", file=diff_file.path, line=node.lineno,
                    message="time.sleep() trong production code — có thể gây blocking",
                    rule_id="PERF-002",
                    suggestion="Dùng asyncio.sleep() hoặc retry library thay vì sleep trực tiếp",
                ))
    return findings


def _check_select_star(diff_file: DiffFile) -> list[Finding]:
    findings: list[Finding] = []
    for line_num, content in diff_file.added_lines:
        if _SELECT_STAR.search(content):
            findings.append(Finding(
                gate=_GATE, severity="MEDIUM", file=diff_file.path, line=line_num,
                message="SELECT * — lấy tất cả columns có thể gây performance issue",
                rule_id="PERF-003",
                suggestion="Chỉ định rõ các column cần thiết thay vì SELECT *",
            ))
    return findings


def run(diff: ParsedDiff) -> GateReport:
    start = time.monotonic()
    findings: list[Finding] = []

    for diff_file in diff.files:
        if diff_file.change_type == "deleted":
            continue

        # SELECT * check trên tất cả file
        findings.extend(_check_select_star(diff_file))

        if not diff_file.path.endswith(".py"):
            continue

        content = diff_file.full_new_content or "\n".join(line for _, line in diff_file.added_lines)
        if not content.strip():
            continue
        try:
            tree = ast.parse(content)
        except SyntaxError:
            continue

        findings.extend(_check_n_plus_one(tree, diff_file))
        findings.extend(_check_sleep(tree, diff_file))

    return GateReport(
        gate=_GATE,
        findings=findings,
        duration_ms=int((time.monotonic() - start) * 1000),
    )
