"""Dependency Vulnerability Gate — kiểm tra package mới có CVE đã biết không."""

from __future__ import annotations

import re
import time
from pathlib import Path

from app.tasks.quality_gate.models import DiffFile, Finding, GateReport, ParsedDiff

_GATE = "dependency"

# Bundled advisory database — known vulnerable packages (name_lower: [(version_range, cve, severity, desc)])
# Format: version_range là string so sánh đơn giản "< X.Y.Z"
_ADVISORY_DB: dict[str, list[tuple[str, str, str, str]]] = {
    "pillow": [("< 10.0.1", "CVE-2023-44271", "HIGH", "Uncontrolled resource consumption")],
    "cryptography": [("< 41.0.6", "CVE-2023-49083", "HIGH", "NULL pointer dereference")],
    "requests": [("< 2.31.0", "CVE-2023-32681", "MEDIUM", "Proxy-Authorization header leak")],
    "urllib3": [("< 1.26.18", "CVE-2023-45803", "MEDIUM", "Cookie request header not stripped")],
    "werkzeug": [("< 3.0.1", "CVE-2023-46136", "HIGH", "DoS via multipart/form-data")],
    "pyyaml": [("< 6.0.1", "CVE-2023-6395", "HIGH", "Arbitrary code execution")],
    "setuptools": [("< 65.5.1", "CVE-2022-40897", "MEDIUM", "ReDoS vulnerability")],
}

_REQ_LINE = re.compile(r"^([A-Za-z0-9_\-\[\]]+)([>=<!~^]+)?([\d.]+)?")


def _parse_version(v: str) -> tuple[int, ...]:
    try:
        return tuple(int(x) for x in v.split(".")[:3])
    except ValueError:
        return (0,)


def _is_vulnerable(version_str: str, range_str: str) -> bool:
    """Kiểm tra version có nằm trong vulnerable range không. Chỉ hỗ trợ '< X.Y.Z'."""
    m = re.match(r"<\s*([\d.]+)", range_str.strip())
    if not m:
        return False
    threshold = _parse_version(m.group(1))
    current = _parse_version(version_str)
    return current < threshold


def _check_requirements_txt(diff_file: DiffFile) -> list[Finding]:
    findings: list[Finding] = []
    for line_num, content in diff_file.added_lines:
        content = content.strip()
        if not content or content.startswith("#"):
            continue
        m = _REQ_LINE.match(content)
        if not m:
            continue
        pkg_name = m.group(1).lower().split("[")[0]
        version = m.group(3) or ""

        if pkg_name not in _ADVISORY_DB:
            continue

        for vuln_range, cve, severity, desc in _ADVISORY_DB[pkg_name]:
            if not version or _is_vulnerable(version, vuln_range):
                findings.append(Finding(
                    gate=_GATE, severity=severity, file=diff_file.path, line=line_num,
                    message=f"{pkg_name}{m.group(2) or ''}{version} — {cve}: {desc}",
                    rule_id="DEP-002",
                    suggestion=f"Nâng cấp {pkg_name} lên phiên bản không có {cve}",
                ))
    return findings


def run(diff: ParsedDiff) -> GateReport:
    start = time.monotonic()
    findings: list[Finding] = []
    dep_files_found = False

    for diff_file in diff.files:
        if diff_file.change_type == "deleted":
            continue
        name = Path(diff_file.path).name
        if name in {"requirements.txt", "requirements-dev.txt"}:
            dep_files_found = True
            findings.extend(_check_requirements_txt(diff_file))

    if dep_files_found and not _ADVISORY_DB:
        findings.append(Finding(
            gate=_GATE, severity="INFO", file="requirements.txt", line=None,
            message="Advisory database không khả dụng — cần manual review",
            rule_id="DEP-004", suggestion="Chạy 'pip-audit' để kiểm tra vulnerability",
        ))

    return GateReport(
        gate=_GATE,
        findings=findings,
        duration_ms=int((time.monotonic() - start) * 1000),
    )
