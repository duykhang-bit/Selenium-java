"""API Contract Gate — kiểm tra code thay đổi có vi phạm OpenAPI spec không."""

from __future__ import annotations

import ast
import re
import time
from pathlib import Path

from app.tasks.quality_gate.models import DiffFile, Finding, GateReport, ParsedDiff

_GATE = "api_contract"
_ROUTE_PATTERN = re.compile(r"@\w+\.(get|post|put|patch|delete)\s*\(\s*['\"]([^'\"]+)['\"]", re.IGNORECASE)


def _find_spec_file() -> Path | None:
    for name in ("openapi.yaml", "openapi.json", "api_spec.yaml", "api_spec.json"):
        p = Path(name)
        if p.exists():
            return p
    return None


def _extract_route_changes(diff_file: DiffFile) -> list[tuple[int, str, str]]:
    """Trả về list (line_num, method, path) cho route mới trong diff."""
    routes = []
    for line_num, content in diff_file.added_lines:
        m = _ROUTE_PATTERN.search(content)
        if m:
            routes.append((line_num, m.group(1).upper(), m.group(2)))
    return routes


def run(diff: ParsedDiff, spec_path: str | None = None) -> GateReport:
    start = time.monotonic()
    findings: list[Finding] = []

    # Tìm route changes trong diff
    route_changes: list[tuple[str, int, str, str]] = []
    for diff_file in diff.files:
        if diff_file.change_type == "deleted" or not diff_file.path.endswith(".py"):
            continue
        for line_num, method, path in _extract_route_changes(diff_file):
            route_changes.append((diff_file.path, line_num, method, path))

    if not route_changes:
        return GateReport(gate=_GATE, findings=[], duration_ms=int((time.monotonic() - start) * 1000))

    # Tìm spec file
    spec = Path(spec_path) if spec_path else _find_spec_file()
    if not spec or not spec.exists():
        findings.append(Finding(
            gate=_GATE, severity="INFO", file="openapi.yaml", line=None,
            message="Không tìm thấy OpenAPI spec — bỏ qua API contract validation",
            rule_id="AC-003",
            suggestion="Tạo openapi.yaml ở root project để enable API contract validation",
        ))
        return GateReport(gate=_GATE, findings=findings, duration_ms=int((time.monotonic() - start) * 1000))

    # Load spec và kiểm tra (basic YAML/JSON parse)
    try:
        import yaml
        spec_content = yaml.safe_load(spec.read_text(encoding="utf-8"))
        spec_paths = spec_content.get("paths", {})
    except Exception:
        return GateReport(gate=_GATE, findings=findings, duration_ms=int((time.monotonic() - start) * 1000))

    for file_path, line_num, method, route_path in route_changes:
        if route_path not in spec_paths:
            findings.append(Finding(
                gate=_GATE, severity="INFO", file=file_path, line=line_num,
                message=f"Route {method} {route_path} không có trong OpenAPI spec",
                rule_id="AC-003",
                suggestion=f"Thêm {route_path} vào openapi.yaml",
            ))

    return GateReport(gate=_GATE, findings=findings, duration_ms=int((time.monotonic() - start) * 1000))
