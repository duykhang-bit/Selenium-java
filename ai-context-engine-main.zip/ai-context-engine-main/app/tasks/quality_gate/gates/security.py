"""Security Gate — SAST: SQL injection, eval, subprocess, pickle, SSL, debug."""

from __future__ import annotations

import ast
import re
import time

from app.tasks.quality_gate.models import DiffFile, Finding, GateReport, ParsedDiff

_GATE = "security"
_HARDCODED_IP = re.compile(r"\b(?!0\.0\.0\.0|127\.0\.0\.1|localhost)\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b")


def _is_test_file(path: str) -> bool:
    return "test" in path.lower()


def _check_python_ast(diff_file: DiffFile) -> list[Finding]:
    content = diff_file.full_new_content or "\n".join(line for _, line in diff_file.added_lines)
    if not content.strip():
        return []
    try:
        tree = ast.parse(content)
    except SyntaxError:
        return []

    findings: list[Finding] = []
    is_test = _is_test_file(diff_file.path)

    for node in ast.walk(tree):
        # eval() / exec() — CRITICAL
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id in {"eval", "exec"}:
                findings.append(Finding(
                    gate=_GATE, severity="CRITICAL", file=diff_file.path, line=node.lineno,
                    message=f"Sử dụng {node.func.id}() với dynamic input — Code Injection risk",
                    rule_id="SEC-002", suggestion=f"Tránh dùng {node.func.id}(). Dùng ast.literal_eval() nếu cần parse.",
                ))

        # subprocess shell=True — HIGH
        if isinstance(node, ast.Call):
            func = node.func
            is_subprocess = (
                (isinstance(func, ast.Attribute) and func.attr in {"run", "call", "Popen", "check_output"})
                or (isinstance(func, ast.Name) and func.id in {"run", "call", "Popen"})
            )
            if is_subprocess:
                for kw in node.keywords:
                    if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                        findings.append(Finding(
                            gate=_GATE, severity="HIGH", file=diff_file.path, line=node.lineno,
                            message="subprocess với shell=True — Command Injection risk",
                            rule_id="SEC-003", suggestion="Dùng list args thay vì shell=True",
                        ))

        # pickle.loads() / yaml.load() — HIGH
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr == "loads":
                obj = node.func.value
                if isinstance(obj, ast.Name) and obj.id == "pickle":
                    findings.append(Finding(
                        gate=_GATE, severity="HIGH", file=diff_file.path, line=node.lineno,
                        message="pickle.loads() — Deserialization risk",
                        rule_id="SEC-004", suggestion="Tránh deserialize dữ liệu không tin cậy bằng pickle",
                    ))
            if node.func.attr == "load" and not is_test:
                obj = node.func.value
                if isinstance(obj, ast.Name) and obj.id == "yaml":
                    findings.append(Finding(
                        gate=_GATE, severity="HIGH", file=diff_file.path, line=node.lineno,
                        message="yaml.load() — Deserialization risk. Dùng yaml.safe_load()",
                        rule_id="SEC-004", suggestion="Thay bằng yaml.safe_load()",
                    ))

        # requests verify=False — HIGH
        if isinstance(node, ast.Call):
            for kw in node.keywords:
                if kw.arg == "verify" and isinstance(kw.value, ast.Constant) and kw.value.value is False:
                    findings.append(Finding(
                        gate=_GATE, severity="HIGH", file=diff_file.path, line=node.lineno,
                        message="verify=False — SSL certificate verification disabled",
                        rule_id="SEC-006", suggestion="Không tắt SSL verification trong production",
                    ))

    return findings


def _check_raw_lines(diff_file: DiffFile) -> list[Finding]:
    findings: list[Finding] = []
    is_test = _is_test_file(diff_file.path)

    for line_num, content in diff_file.added_lines:
        # DEBUG = True — MEDIUM
        if not is_test and re.search(r"\bDEBUG\s*=\s*True\b", content):
            findings.append(Finding(
                gate=_GATE, severity="MEDIUM", file=diff_file.path, line=line_num,
                message="DEBUG = True trong non-test context",
                rule_id="SEC-007", suggestion="Đảm bảo DEBUG=False trong production config",
            ))

        # Hardcoded IP — MEDIUM
        m = _HARDCODED_IP.search(content)
        if m and not is_test:
            findings.append(Finding(
                gate=_GATE, severity="MEDIUM", file=diff_file.path, line=line_num,
                message=f"Hardcoded IP address: {m.group()}",
                rule_id="SEC-005", suggestion="Dùng config/env var thay vì hardcode IP",
            ))

    return findings


def run(diff: ParsedDiff) -> GateReport:
    start = time.monotonic()
    findings: list[Finding] = []

    for diff_file in diff.files:
        if diff_file.change_type == "deleted":
            continue
        if diff_file.path.endswith(".py"):
            findings.extend(_check_python_ast(diff_file))
        findings.extend(_check_raw_lines(diff_file))

    return GateReport(
        gate=_GATE,
        findings=findings,
        duration_ms=int((time.monotonic() - start) * 1000),
    )
