"""Regression Analyzer — risk score dựa trên dependency graph và diff size."""

from __future__ import annotations

import re
import time

from app.tasks.quality_gate.models import DiffFile, Finding, GateReport, ParsedDiff

_GATE = "regression"
_INTERFACE_PATTERNS = re.compile(r"^\+\s*def |^\+\s*async def |^\+\s*class ")
_SCHEMA_PATTERNS = re.compile(r"class\s+\w+.*(?:Base|Model|Schema|Table)\b|__tablename__\s*=")


def _has_interface_change(diff: ParsedDiff) -> bool:
    for diff_file in diff.files:
        for _, content in diff_file.added_lines:
            if _INTERFACE_PATTERNS.match("+" + content.lstrip()):
                return True
    return False


def _has_schema_change(diff: ParsedDiff) -> bool:
    for diff_file in diff.files:
        content = "\n".join(line for _, line in diff_file.added_lines)
        if _SCHEMA_PATTERNS.search(content):
            return True
    return False


def _base_risk(diff: ParsedDiff) -> int:
    files_changed = len([f for f in diff.files if f.change_type != "deleted"])
    lines_added = sum(len(f.added_lines) for f in diff.files)
    return min(files_changed * 5 + lines_added // 20, 30)


def _find_dependents(changed_files: list[str], collection_name: str) -> list[str]:
    """Tìm modules phụ thuộc vào changed files qua ChromaDB."""
    from app.retrieval.search import search
    dependents: set[str] = set()
    for file_path in changed_files[:3]:  # limit để tránh quá nhiều queries
        module_name = file_path.replace("/", ".").replace(".py", "")
        try:
            results = search(f"import {module_name}", collection_name, top_k=5)
            for r in results:
                src = r.metadata.get("source", "")
                if src and src not in changed_files:
                    dependents.add(src)
        except Exception:
            pass
    return list(dependents)


def run(diff: ParsedDiff, collection_name: str = "knowledge") -> GateReport:
    start = time.monotonic()
    findings: list[Finding] = []

    risk_score = _base_risk(diff)

    if _has_interface_change(diff):
        risk_score += 20
    if _has_schema_change(diff):
        risk_score += 20

    # Graceful degrade khi ChromaDB không khả dụng
    dependents: list[str] = []
    try:
        changed_files = [f.path for f in diff.files]
        dependents = _find_dependents(changed_files, collection_name)
        risk_score += min(len(dependents) * 3, 30)
    except Exception:
        pass

    risk_score = min(risk_score, 100)

    if risk_score >= 70:
        dep_list = ", ".join(dependents[:5]) or "không xác định được (ChromaDB không khả dụng)"
        findings.append(Finding(
            gate=_GATE, severity="HIGH", file="", line=None,
            message=f"Risk score cao: {risk_score}/100 — cần regression test kỹ",
            rule_id="REG-001",
            suggestion=f"Chạy regression test cho các module: {dep_list}",
        ))
    elif risk_score >= 40:
        findings.append(Finding(
            gate=_GATE, severity="MEDIUM", file="", line=None,
            message=f"Risk score trung bình: {risk_score}/100",
            rule_id="REG-002",
            suggestion="Review kỹ các thay đổi và chạy integration test",
        ))

    report = GateReport(
        gate=_GATE,
        findings=findings,
        duration_ms=int((time.monotonic() - start) * 1000),
    )
    # Attach risk_score vào report để gate_runner có thể lấy
    report._risk_score = risk_score  # type: ignore[attr-defined]
    return report
