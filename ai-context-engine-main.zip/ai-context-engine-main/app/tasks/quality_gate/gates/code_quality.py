"""Code Quality Gate — cyclomatic complexity, function length, duplication, conventions."""

from __future__ import annotations

import ast
import hashlib
import time

from app.tasks.quality_gate.models import DiffFile, Finding, GateReport, ParsedDiff

_GATE = "code_quality"
_BRANCH_NODES = (
    ast.If, ast.For, ast.While, ast.ExceptHandler,
    ast.With, ast.AsyncFor, ast.AsyncWith,
)


def _cyclomatic_complexity(node: ast.FunctionDef | ast.AsyncFunctionDef) -> int:
    """Đếm branching nodes trong function — complexity = 1 + số nhánh."""
    count = 1
    for child in ast.walk(node):
        if isinstance(child, _BRANCH_NODES):
            count += 1
        elif isinstance(child, ast.BoolOp):
            count += len(child.values) - 1
    return count


def _check_python_file(diff_file: DiffFile) -> list[Finding]:
    findings: list[Finding] = []
    content = diff_file.full_new_content or "\n".join(line for _, line in diff_file.added_lines)
    if not content.strip():
        return findings

    # Missing __future__ import cho file mới
    if diff_file.change_type == "added" and "from __future__ import annotations" not in content:
        findings.append(Finding(
            gate=_GATE, severity="LOW", file=diff_file.path, line=1,
            message="Thiếu 'from __future__ import annotations'",
            rule_id="CQ-004", suggestion="Thêm 'from __future__ import annotations' ở đầu file",
        ))

    try:
        tree = ast.parse(content)
    except SyntaxError:
        return findings

    # print() statement trong non-test file
    is_test = "test" in diff_file.path.lower()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Name) and func.id == "print" and not is_test:
                findings.append(Finding(
                    gate=_GATE, severity="LOW", file=diff_file.path, line=node.lineno,
                    message="Sử dụng print() trong production code",
                    rule_id="CQ-006", suggestion="Dùng logger thay vì print()",
                ))

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        # Cyclomatic complexity
        complexity = _cyclomatic_complexity(node)
        if complexity > 10:
            findings.append(Finding(
                gate=_GATE, severity="HIGH", file=diff_file.path, line=node.lineno,
                message=f"Cyclomatic complexity = {complexity} (threshold: 10) trong '{node.name}'",
                rule_id="CQ-001", suggestion="Refactor thành các function nhỏ hơn",
            ))

        # Function length
        end = getattr(node, "end_lineno", None)
        if end and (end - node.lineno) > 50:
            findings.append(Finding(
                gate=_GATE, severity="MEDIUM", file=diff_file.path, line=node.lineno,
                message=f"Function '{node.name}' có {end - node.lineno} dòng (threshold: 50)",
                rule_id="CQ-002", suggestion="Tách function thành các phần nhỏ hơn",
            ))

        # Missing docstring
        if not (node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant)):
            findings.append(Finding(
                gate=_GATE, severity="LOW", file=diff_file.path, line=node.lineno,
                message=f"Function '{node.name}' thiếu docstring",
                rule_id="CQ-005", suggestion="Thêm docstring mô tả mục đích và args",
            ))

    return findings


def _check_duplication(diff_file: DiffFile) -> list[Finding]:
    """Sliding window 6 dòng — detect duplicated blocks trong added lines."""
    lines = [content for _, content in diff_file.added_lines if content.strip()]
    if len(lines) < 6:
        return []

    window_size = 6
    seen: dict[str, int] = {}
    findings: list[Finding] = []

    for i in range(len(lines) - window_size + 1):
        window = "\n".join(lines[i:i + window_size])
        h = hashlib.md5(window.encode()).hexdigest()
        if h in seen:
            line_num = diff_file.added_lines[i][0] if i < len(diff_file.added_lines) else 0
            findings.append(Finding(
                gate=_GATE, severity="MEDIUM", file=diff_file.path, line=line_num,
                message=f"Đoạn code trùng lặp {window_size} dòng (xuất hiện lần đầu tại dòng {seen[h]})",
                rule_id="CQ-003", suggestion="Extract thành function dùng chung",
            ))
        else:
            line_num = diff_file.added_lines[i][0] if i < len(diff_file.added_lines) else 0
            seen[h] = line_num

    return findings


def run(diff: ParsedDiff) -> GateReport:
    start = time.monotonic()
    findings: list[Finding] = []

    for diff_file in diff.files:
        if diff_file.change_type == "deleted":
            continue
        if not diff_file.path.endswith(".py"):
            continue
        findings.extend(_check_python_file(diff_file))
        findings.extend(_check_duplication(diff_file))

    return GateReport(
        gate=_GATE,
        findings=findings,
        duration_ms=int((time.monotonic() - start) * 1000),
    )
