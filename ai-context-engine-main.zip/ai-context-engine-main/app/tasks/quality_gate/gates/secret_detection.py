"""Secret Detection Gate — hardcoded credentials, API keys, PEM blocks."""

from __future__ import annotations

import re
import time

from app.tasks.quality_gate.models import DiffFile, Finding, GateReport, ParsedDiff

_GATE = "secret_detection"

_SKIP_SUFFIXES = {".example", ".sample", ".template"}
_SKIP_PATHS = {"tests/", ".env.example", ".env.sample"}

_PATTERNS: list[tuple[str, str, str, str]] = [
    # (pattern, rule_id, severity, description)
    (r"glpat-[A-Za-z0-9_\-]{20,}", "SD-001", "CRITICAL", "GitLab Personal Access Token"),
    (r"ghp_[A-Za-z0-9]{36}", "SD-002", "CRITICAL", "GitHub Personal Access Token"),
    (r"sk-[A-Za-z0-9]{32,}", "SD-003", "CRITICAL", "OpenAI API Key"),
    (r"AKIA[0-9A-Z]{16}", "SD-004", "CRITICAL", "AWS Access Key ID"),
    (r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----", "SD-005", "CRITICAL", "Private Key PEM block"),
    (
        r'(?:password|secret|token|api_key|private_key|passwd|pwd)\s*=\s*["\'][^"\']{8,}["\']',
        "SD-006", "CRITICAL", "Hardcoded credential assignment",
    ),
    (r"[a-zA-Z][a-zA-Z0-9+.\-]*://[^:\s]+:[^@\s]{3,}@", "SD-007", "CRITICAL", "Credentials embedded in URL"),
]

_COMPILED = [(re.compile(p, re.IGNORECASE), rid, sev, desc) for p, rid, sev, desc in _PATTERNS]


def _should_skip(path: str) -> bool:
    for suffix in _SKIP_SUFFIXES:
        if path.endswith(suffix):
            return True
    for skip in _SKIP_PATHS:
        if skip in path:
            return True
    return False


def run(diff: ParsedDiff) -> GateReport:
    start = time.monotonic()
    findings: list[Finding] = []

    for diff_file in diff.files:
        if diff_file.change_type == "deleted":
            continue
        if _should_skip(diff_file.path):
            continue

        for line_num, content in diff_file.added_lines:
            for pattern, rule_id, severity, description in _COMPILED:
                if pattern.search(content):
                    findings.append(Finding(
                        gate=_GATE, severity=severity, file=diff_file.path, line=line_num,
                        message=f"{description} phát hiện trong code",
                        rule_id=rule_id,
                        suggestion="Xóa credential khỏi code. Dùng env var hoặc secret manager.",
                    ))
                    break  # 1 finding per line per file

    return GateReport(
        gate=_GATE,
        findings=findings,
        duration_ms=int((time.monotonic() - start) * 1000),
    )
