"""Test Coverage Gate — kiểm tra code mới có test tương ứng không."""

from __future__ import annotations

import ast
import os
import re
import time
from pathlib import Path

from app.tasks.quality_gate.models import DiffFile, Finding, GateReport, ParsedDiff

_GATE = "test_coverage"
_ROUTE_DECORATORS = re.compile(r"@\w+\.(get|post|put|patch|delete|head|options)\s*\(", re.IGNORECASE)
_SKIP_FILES = {"__init__.py", "conftest.py"}
_SKIP_SUFFIXES = {".cfg", ".ini", ".toml", ".yaml", ".yml", ".json", ".md", ".txt"}


def _map_to_test_path(source_path: str) -> str:
    """Map app/tasks/foo.py → tests/test_foo.py."""
    p = Path(source_path)
    return f"tests/test_{p.stem}.py"


def _has_new_functions(diff_file: DiffFile) -> bool:
    content = diff_file.full_new_content or "\n".join(line for _, line in diff_file.added_lines)
    try:
        tree = ast.parse(content)
        return any(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) for n in ast.walk(tree))
    except SyntaxError:
        return False


def _has_new_routes(diff_file: DiffFile) -> bool:
    for _, content in diff_file.added_lines:
        if _ROUTE_DECORATORS.search(content):
            return True
    return False


def _test_file_exists(test_path: str) -> bool:
    return os.path.exists(test_path)


def run(diff: ParsedDiff) -> GateReport:
    start = time.monotonic()
    findings: list[Finding] = []

    for diff_file in diff.files:
        if diff_file.change_type == "deleted":
            continue

        path = diff_file.path
        filename = Path(path).name

        # Skip non-source files
        if filename in _SKIP_FILES:
            continue
        if Path(path).suffix in _SKIP_SUFFIXES:
            continue
        if not path.endswith(".py"):
            continue
        if not path.startswith("app/"):
            continue

        test_path = _map_to_test_path(path)

        # New API endpoint without test → HIGH
        if _has_new_routes(diff_file) and not _test_file_exists(test_path):
            findings.append(Finding(
                gate=_GATE, severity="HIGH", file=path, line=None,
                message=f"API endpoint mới không có integration test tương ứng ({test_path})",
                rule_id="TC-003",
                suggestion=f"Tạo {test_path} với integration test cho endpoint mới",
            ))
        # New functions/classes without test → MEDIUM
        elif _has_new_functions(diff_file) and not _test_file_exists(test_path):
            findings.append(Finding(
                gate=_GATE, severity="MEDIUM", file=path, line=None,
                message=f"Module mới không có test file tương ứng ({test_path})",
                rule_id="TC-001",
                suggestion=f"Tạo {test_path} với unit test cho module mới",
            ))

    return GateReport(
        gate=_GATE,
        findings=findings,
        duration_ms=int((time.monotonic() - start) * 1000),
    )
