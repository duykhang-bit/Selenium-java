from app.tasks.quality_gate.gates import (
    code_quality,
    security,
    secret_detection,
    dependency,
    test_coverage,
    performance,
    api_contract,
    regression,
)
