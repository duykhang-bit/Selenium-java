"""Gate Runner — orchestration, parallel execution, audit logging."""

from __future__ import annotations

import json
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

from app.core.config import settings
from app.core.logging import get_logger
from app.tasks.quality_gate.diff_parser import parse_diff
from app.tasks.quality_gate.gates import (
    code_quality,
    security,
    secret_detection,
    dependency,
    test_coverage,
    performance,
    api_contract,
    regression,
)
from app.tasks.quality_gate.models import GateReport, ParsedDiff, QualityGateReport
from app.tasks.quality_gate.test_generator import generate_tests

logger = get_logger(__name__)

_ALL_GATES = {
    "code_quality": code_quality.run,
    "security": security.run,
    "secret_detection": secret_detection.run,
    "dependency": dependency.run,
    "test_coverage": test_coverage.run,
    "performance": performance.run,
    "api_contract": api_contract.run,
    "regression": regression.run,
}


def _write_audit(
    trace_id: str,
    overall: str,
    report: QualityGateReport,
    diff_lines_added: int,
    diff_files_changed: int,
    duration_ms: int,
) -> None:
    record = {
        "event_type": "qge_analyze",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "details": {
            "trace_id": trace_id,
            "overall": overall,
            "total_critical": report.total_critical,
            "total_high": report.total_high,
            "total_medium": report.total_medium,
            "total_low": report.total_low,
            "gates_run": [r.gate for r in report.gate_reports],
            "duration_ms": duration_ms,
            "diff_lines_added": diff_lines_added,
            "diff_files_changed": diff_files_changed,
        },
    }
    log_path: Path = settings.logs_dir / "qge_audit.jsonl"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except OSError as exc:
        logger.warning("Failed to write QGE audit record: %s", exc)


def run_all_gates(
    diff_text: str,
    collection_name: str = "knowledge",
    enabled_gates: list[str] | None = None,
    trace_id: str | None = None,
) -> QualityGateReport:
    """Chạy tất cả quality gate song song trên code diff.

    Args:
        diff_text: Unified diff text (output của git diff)
        collection_name: ChromaDB collection cho regression analyzer
        enabled_gates: Danh sách gate cần chạy. None = tất cả.
        trace_id: Trace ID xuyên suốt request.

    Returns:
        QualityGateReport tổng hợp kết quả tất cả gate.
    """
    if trace_id is None:
        trace_id = uuid.uuid4().hex[:16]

    start = time.monotonic()
    parsed = parse_diff(diff_text)

    gates_to_run = {
        name: fn for name, fn in _ALL_GATES.items()
        if enabled_gates is None or name in enabled_gates
    }

    logger.info("QGE starting %d gates", len(gates_to_run), extra={"trace_id": trace_id})

    gate_reports: list[GateReport] = []

    with ThreadPoolExecutor(max_workers=max(len(gates_to_run), 1)) as executor:
        futures = {}
        for name, fn in gates_to_run.items():
            if name == "regression":
                futures[executor.submit(fn, parsed, collection_name)] = name
            else:
                futures[executor.submit(fn, parsed)] = name

        for future in as_completed(futures, timeout=60):
            gate_name = futures[future]
            try:
                report = future.result()
                gate_reports.append(report)
            except Exception as exc:
                logger.warning("Gate '%s' failed: %s", gate_name, exc, extra={"trace_id": trace_id})
                gate_reports.append(GateReport(gate=gate_name, error=str(exc)))

    # Extract risk_score từ regression gate
    risk_score = 0
    for r in gate_reports:
        if r.gate == "regression" and hasattr(r, "_risk_score"):
            risk_score = r._risk_score  # type: ignore[attr-defined]

    # Generate test skeleton
    generated_test_code: str | None = None
    try:
        generated_test_code = generate_tests(parsed) or None
    except Exception as exc:
        logger.warning("Test generator failed: %s", exc)

    diff_lines_added = sum(len(f.added_lines) for f in parsed.files)
    diff_files_changed = len(parsed.files)
    duration_ms = int((time.monotonic() - start) * 1000)

    report = QualityGateReport(
        gate_reports=gate_reports,
        generated_test_code=generated_test_code,
        risk_score=risk_score,
        trace_id=trace_id,
    )

    logger.info(
        "QGE completed overall=%s critical=%d high=%d duration_ms=%d",
        report.overall, report.total_critical, report.total_high, duration_ms,
        extra={"trace_id": trace_id},
    )

    _write_audit(trace_id, report.overall, report, diff_lines_added, diff_files_changed, duration_ms)

    return report
