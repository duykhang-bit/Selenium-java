"""Test Generator — sinh pytest skeleton cho function/method mới trong diff."""

from __future__ import annotations

import ast
from pathlib import Path

from app.tasks.quality_gate.models import ParsedDiff


def _get_type_example(annotation: ast.expr | None) -> str:
    """Sinh example value từ type annotation."""
    if annotation is None:
        return "None"
    if isinstance(annotation, ast.Name):
        mapping = {"str": '"test"', "int": "0", "float": "0.0", "bool": "True", "list": "[]", "dict": "{}"}
        return mapping.get(annotation.id, "None")
    if isinstance(annotation, ast.Constant):
        return repr(annotation.value)
    return "None"


def _build_call_args(func: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    """Sinh argument list cho function call trong test."""
    args = []
    for arg in func.args.args:
        if arg.arg == "self":
            continue
        example = _get_type_example(arg.annotation)
        args.append(example)
    return ", ".join(args)


def _generate_for_function(func: ast.FunctionDef | ast.AsyncFunctionDef, module_path: str) -> str:
    name = func.name
    call_args = _build_call_args(func)
    is_async = isinstance(func, ast.AsyncFunctionDef)
    async_prefix = "async " if is_async else ""
    await_prefix = "await " if is_async else ""

    return f"""
class Test{name.title().replace("_", "")}:
    {async_prefix}def test_{name}_happy_path(self):
        # TODO: implement
        result = {await_prefix}{name}({call_args})
        assert result is not None

    {async_prefix}def test_{name}_raises_on_invalid_input(self):
        # TODO: implement
        import pytest
        with pytest.raises(Exception):
            {await_prefix}{name}()
"""


def generate_tests(diff: ParsedDiff) -> str:
    """Sinh pytest skeleton cho tất cả function/method mới trong diff.

    Trả về string (không ghi file).
    """
    if not diff.files:
        return ""

    all_blocks: list[str] = []

    for diff_file in diff.files:
        if diff_file.change_type == "deleted" or not diff_file.path.endswith(".py"):
            continue

        content = diff_file.full_new_content or "\n".join(line for _, line in diff_file.added_lines)
        if not content.strip():
            continue

        try:
            tree = ast.parse(content)
        except SyntaxError:
            continue

        module_name = Path(diff_file.path).stem
        functions = [
            node for node in ast.walk(tree)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and not node.name.startswith("_")
        ]

        if not functions:
            continue

        header = f"# Auto-generated test skeleton for {diff_file.path}\n"
        header += "from __future__ import annotations\nimport pytest\n"
        header += f"from {diff_file.path.replace('/', '.').replace('.py', '')} import *\n"

        blocks = [header]
        for func in functions[:5]:  # max 5 functions per file
            blocks.append(_generate_for_function(func, diff_file.path))

        all_blocks.append("\n".join(blocks))

    return "\n\n".join(all_blocks)
