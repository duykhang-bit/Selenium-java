"""Tạo Epic/Story/Sub-task trên Jira từ intent text."""

from __future__ import annotations

import logging
import re
import uuid
from typing import Any

from app.catalog.database import get_idempotency_key, upsert_idempotency_key
from app.connectors.jira import JiraConnector
from app.connectors.jira_errors import JiraIdempotencyError, JiraQualityGateError
from app.core.utils import sha256_text, utc_now_iso
from app.tasks.jira_quality_gate import AIQualityGate, write_audit_record

logger = logging.getLogger(__name__)

# Thang điểm Fibonacci cho story points
_FIBONACCI = (1, 2, 3, 5, 8, 13)

# Từ khoá để ước lượng độ phức tạp
_COMPLEXITY_HIGH = re.compile(
    r"phức tạp|complex|nhiều service|multiple service|integration|tích hợp|migration|refactor",
    re.IGNORECASE,
)
_COMPLEXITY_LOW = re.compile(
    r"đơn giản|simple|nhỏ|minor|fix text|update label|rename|typo",
    re.IGNORECASE,
)


def _estimate_story_points(complexity_description: str) -> int:
    """Ước lượng story points theo Fibonacci dựa trên mô tả độ phức tạp.

    Returns:
        Giá trị trong tập {1, 2, 3, 5, 8, 13}.
    """
    if _COMPLEXITY_HIGH.search(complexity_description):
        return 8
    if _COMPLEXITY_LOW.search(complexity_description):
        return 2
    # Mặc định: medium complexity
    return 3


def _generate_issue_structure(intent: str, project_key: str) -> dict:
    """Sinh cấu trúc Epic → Story → Sub-task từ intent text.

    Đây là template-based generator. Trong production có thể thay bằng LLM call.

    Returns:
        dict với keys: epic, stories (list of {story, subtasks})
    """
    # Tạo Epic
    epic_summary = f"[Epic] {intent[:100]}"
    epic_description = (
        f"## Business Objective\n\n"
        f"Implement: {intent}\n\n"
        f"## Mục tiêu\n\n"
        f"- Đáp ứng yêu cầu nghiệp vụ: {intent}\n"
        f"- Đảm bảo chất lượng, bảo mật, và performance theo tiêu chuẩn enterprise\n\n"
        f"## Expected Outcome\n\n"
        f"- Tính năng được implement đầy đủ và pass quality gate\n"
        f"- Có unit test coverage >= 80%\n"
        f"- Không có lỗi SAST HIGH/CRITICAL\n"
    )

    # Tạo Story chính
    story_summary = intent[:120]
    story_points = _estimate_story_points(intent)
    story_description = (
        f"## User Story\n\n"
        f"Là một người dùng, tôi muốn {intent}, "
        f"để đáp ứng yêu cầu nghiệp vụ.\n\n"
        f"## Acceptance Criteria\n\n"
        f"- AC1: Tính năng hoạt động đúng theo mô tả\n"
        f"- AC2: Có unit test coverage >= 80%\n"
        f"- AC3: Pass code review và SAST scan\n"
        f"- AC4: Performance đáp ứng SLA (internal < 10ms, external < 500ms)\n\n"
        f"## Definition of Done\n\n"
        f"- [ ] Code pass tất cả unit test\n"
        f"- [ ] Coverage >= 80%\n"
        f"- [ ] Không có lỗi SAST HIGH/CRITICAL\n"
        f"- [ ] Có exception handling cho external calls\n"
        f"- [ ] Có structured logging với trace_id\n"
    )

    # Sub-tasks
    subtasks = [
        {
            "summary": f"[Analysis] Phân tích và thiết kế: {intent[:80]}",
            "description": "Phân tích yêu cầu, thiết kế solution, estimate effort.",
        },
        {
            "summary": f"[Dev] Implement: {intent[:80]}",
            "description": "Implement theo design đã được approve. Viết unit test.",
        },
        {
            "summary": f"[Test] Kiểm thử: {intent[:80]}",
            "description": "Viết và chạy integration test. Verify acceptance criteria.",
        },
    ]

    return {
        "epic": {
            "summary": epic_summary,
            "description": epic_description,
            "issuetype": {"name": "Epic"},
            "project": {"key": project_key},
        },
        "stories": [
            {
                "story": {
                    "summary": story_summary,
                    "description": story_description,
                    "issuetype": {"name": "Story"},
                    "project": {"key": project_key},
                    "story_points": story_points,
                },
                "subtasks": subtasks,
            }
        ],
    }


def create_from_intent(
    intent: str,
    project_key: str,
    connector: dict,
    trace_id: str | None = None,
) -> dict:
    """Sinh và tạo cấu trúc Epic → Story → Sub-task từ intent text.

    Idempotent: cùng intent + project_key sẽ trả về kết quả đã tạo trước đó.
    Quality gate được kiểm tra trước khi gọi Jira API.

    Args:
        intent: mô tả ý tưởng/yêu cầu bằng ngôn ngữ tự nhiên
        project_key: Jira project key, ví dụ "PROJ"
        connector: connector record từ catalog.db
        trace_id: trace ID cho audit log

    Returns:
        dict với keys: epic_key, stories, idempotency_key, quality_gate

    Raises:
        JiraIdempotencyError: nếu intent đã được tạo trước đó
        JiraQualityGateError: nếu không qua quality gate
        JiraConnectorError: nếu Jira API lỗi
    """
    trace_id = trace_id or str(uuid.uuid4())[:8]

    # Kiểm tra idempotency
    idempotency_key = sha256_text(f"{intent}:{project_key}")
    existing = get_idempotency_key(idempotency_key)
    if existing:
        logger.info(
            "Idempotency hit: intent đã tạo trước đó, trả về %s",
            existing["result_ref"],
        )
        raise JiraIdempotencyError(existing_ref=existing["result_ref"])

    # Sinh cấu trúc issue
    structure = _generate_issue_structure(intent, project_key)
    epic_fields = structure["epic"]

    # Quality gate cho Epic
    gate = AIQualityGate()
    gate_result = gate.check(epic_fields)
    if not gate_result.passed:
        write_audit_record(
            action="create_from_intent",
            actor="system",
            issue_key=None,
            input_summary=intent[:200],
            result="failed",
            error=f"Quality gate fail: {gate_result.issues}",
            trace_id=trace_id,
        )
        raise JiraQualityGateError(
            confidence_score=gate_result.confidence_score,
            issues=gate_result.issues,
        )

    jira = JiraConnector(
        base_url=connector["base_url"],
        token=connector["token"],
    )

    # Tạo Epic
    epic_response = jira.create_issue(epic_fields)
    epic_key = epic_response["key"]
    logger.info("Đã tạo Epic: %s", epic_key)

    write_audit_record(
        action="create_epic",
        actor="system",
        issue_key=epic_key,
        input_summary=intent[:200],
        result="success",
        error=None,
        trace_id=trace_id,
    )

    created_stories: list[dict[str, Any]] = []

    for story_def in structure["stories"]:
        story_fields = story_def["story"].copy()
        story_points = story_fields.pop("story_points", 3)

        # Gán Epic link
        story_fields["customfield_10014"] = epic_key  # Epic Link field

        try:
            story_response = jira.create_issue(story_fields)
            story_key = story_response["key"]
            logger.info("Đã tạo Story: %s (points=%d)", story_key, story_points)

            write_audit_record(
                action="create_story",
                actor="system",
                issue_key=story_key,
                input_summary=story_fields.get("summary", "")[:200],
                result="success",
                error=None,
                trace_id=trace_id,
            )

            # Tạo Sub-tasks
            created_subtasks: list[str] = []
            for subtask_def in story_def.get("subtasks", []):
                subtask_fields = {
                    **subtask_def,
                    "issuetype": {"name": "Sub-task"},
                    "project": {"key": project_key},
                    "parent": {"key": story_key},
                }
                try:
                    subtask_response = jira.create_issue(subtask_fields)
                    subtask_key = subtask_response["key"]
                    created_subtasks.append(subtask_key)
                    logger.info("Đã tạo Sub-task: %s", subtask_key)
                except Exception as exc:
                    logger.warning("Không thể tạo sub-task cho %s: %s", story_key, exc)

            created_stories.append({
                "story_key": story_key,
                "summary": story_fields.get("summary", ""),
                "story_points": story_points,
                "subtasks": created_subtasks,
            })

        except Exception as exc:
            # Story thất bại sau khi Epic đã tạo — ghi audit để rollback thủ công
            write_audit_record(
                action="create_story_failed",
                actor="system",
                issue_key=epic_key,
                input_summary=f"Epic {epic_key} đã tạo nhưng Story thất bại: {exc}",
                result="failed",
                error=str(exc),
                trace_id=trace_id,
            )
            logger.error(
                "Story thất bại sau khi Epic %s đã tạo. Cần rollback thủ công. Error: %s",
                epic_key, exc,
            )
            raise

    # Lưu idempotency key
    upsert_idempotency_key(
        key_hash=idempotency_key,
        result_ref=epic_key,
        connector_type="jira",
        metadata={"project_key": project_key, "intent_preview": intent[:100]},
    )

    return {
        "epic_key": epic_key,
        "stories": created_stories,
        "idempotency_key": idempotency_key,
        "quality_gate": {
            "confidence_score": gate_result.confidence_score,
            "passed": gate_result.passed,
        },
    }
