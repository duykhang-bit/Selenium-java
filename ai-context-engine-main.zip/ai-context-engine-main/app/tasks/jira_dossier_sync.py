"""Đồng bộ trạng thái Task Dossier → Jira Transition."""

from __future__ import annotations

import json
import logging
import uuid
from pathlib import Path

from app.catalog.database import list_jira_dossier_links, upsert_jira_dossier_link
from app.connectors.jira import JiraConnector
from app.connectors.jira_errors import JiraConnectorError
from app.core.utils import utc_now_iso
from app.tasks.dossier import _resolve_task_dir, _load_task_payload, _save_task_payload

logger = logging.getLogger(__name__)

# Mapping trạng thái dossier → tên trạng thái Jira đích
DOSSIER_TO_JIRA_STATUS_MAP: dict[str, str] = {
    "started": "In Progress",
    "planned": "In Progress",
    "completed": "Done",
    "blocked": "Blocked",
}


def _append_timeline(task_dir: Path, event_type: str, details: dict) -> None:
    """Ghi 1 record vào timeline.jsonl của dossier."""
    record = {
        "event_type": event_type,
        "created_at": utc_now_iso(),
        "details": details,
    }
    timeline_path = task_dir / "timeline.jsonl"
    with timeline_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def _find_transition_id(transitions: list[dict], target_status: str) -> str | None:
    """Tìm transition ID khớp với tên trạng thái đích."""
    for t in transitions:
        to_name = (t.get("to") or {}).get("name", "")
        if to_name.lower() == target_status.lower():
            return t.get("id")
    return None


def sync_dossier_to_jira(
    task_id: str,
    connector: dict,
    trace_id: str | None = None,
) -> dict:
    """Đọc trạng thái dossier và thực hiện Jira transition tương ứng.

    Không block cập nhật dossier nếu Jira transition thất bại.
    Ghi audit record vào timeline.jsonl cho mọi lần cố gắng transition.

    Args:
        task_id: ID của task dossier
        connector: connector record từ catalog.db
        trace_id: trace ID cho audit log

    Returns:
        dict với keys: transitioned (bool), skipped (bool), error (str | None),
                       issue_keys (list), dossier_status (str)
    """
    trace_id = trace_id or str(uuid.uuid4())[:8]
    task_dir = _resolve_task_dir(task_id)
    payload = _load_task_payload(task_dir)
    dossier_status = payload.get("status", "")

    # Lấy danh sách Jira issue keys từ task.json và catalog.db
    issue_keys: list[str] = []
    # Từ task.json
    if payload.get("jira_issue_key"):
        issue_keys.append(payload["jira_issue_key"])
    if payload.get("jira_issue_keys"):
        for k in payload["jira_issue_keys"]:
            if k not in issue_keys:
                issue_keys.append(k)
    # Từ catalog.db
    for link in list_jira_dossier_links(task_id):
        k = link["issue_key"]
        if k not in issue_keys:
            issue_keys.append(k)

    if not issue_keys:
        logger.debug("Dossier %s không có Jira issue key nào được liên kết", task_id)
        return {
            "transitioned": False,
            "skipped": True,
            "error": None,
            "issue_keys": [],
            "dossier_status": dossier_status,
        }

    target_jira_status = DOSSIER_TO_JIRA_STATUS_MAP.get(dossier_status)
    if not target_jira_status:
        logger.debug(
            "Dossier status '%s' không có mapping Jira, bỏ qua", dossier_status
        )
        return {
            "transitioned": False,
            "skipped": True,
            "error": None,
            "issue_keys": issue_keys,
            "dossier_status": dossier_status,
        }

    jira = JiraConnector(
        base_url=connector["base_url"],
        token=connector["token"],
    )

    results: list[dict] = []

    for issue_key in issue_keys:
        transition_result = _do_single_transition(
            jira=jira,
            issue_key=issue_key,
            target_status=target_jira_status,
            task_dir=task_dir,
            trace_id=trace_id,
            dossier_status=dossier_status,
        )
        results.append(transition_result)

    any_transitioned = any(r["transitioned"] for r in results)
    all_skipped = all(r["skipped"] for r in results)
    errors = [r["error"] for r in results if r.get("error")]

    return {
        "transitioned": any_transitioned,
        "skipped": all_skipped,
        "error": "; ".join(errors) if errors else None,
        "issue_keys": issue_keys,
        "dossier_status": dossier_status,
        "details": results,
    }


def _do_single_transition(
    jira: JiraConnector,
    issue_key: str,
    target_status: str,
    task_dir: Path,
    trace_id: str,
    dossier_status: str,
) -> dict:
    """Thực hiện transition cho một issue. Ghi audit vào timeline dù thành công hay thất bại."""
    try:
        # Kiểm tra trạng thái hiện tại
        issue = jira.get_issue(issue_key)
        current_status = (issue.get("fields", {}).get("status") or {}).get("name", "")

        if current_status.lower() == target_status.lower():
            # Đã đúng trạng thái — bỏ qua, không gọi API thừa
            _append_timeline(task_dir, "jira_transition_skipped", {
                "issue_key": issue_key,
                "current_status": current_status,
                "target_status": target_status,
                "reason": "already_in_target_status",
                "trace_id": trace_id,
            })
            logger.debug(
                "Bỏ qua transition %s: đã ở trạng thái '%s'",
                issue_key, current_status,
            )
            return {"transitioned": False, "skipped": True, "error": None, "issue_key": issue_key}

        # Lấy danh sách transitions khả dụng
        transitions = jira.get_transitions(issue_key)
        transition_id = _find_transition_id(transitions, target_status)

        if not transition_id:
            error_msg = (
                f"Không tìm thấy transition '{target_status}' cho issue {issue_key}. "
                f"Transitions khả dụng: {[t.get('to', {}).get('name') for t in transitions]}"
            )
            _append_timeline(task_dir, "jira_transition_failed", {
                "issue_key": issue_key,
                "from_status": current_status,
                "to_status": target_status,
                "result": "failed",
                "error": error_msg,
                "trace_id": trace_id,
            })
            logger.warning(error_msg)
            return {"transitioned": False, "skipped": False, "error": error_msg, "issue_key": issue_key}

        # Thực hiện transition
        jira.do_transition(issue_key, transition_id)

        _append_timeline(task_dir, "jira_transition", {
            "issue_key": issue_key,
            "from_status": current_status,
            "to_status": target_status,
            "transition_id": transition_id,
            "result": "success",
            "actor": "system",
            "trace_id": trace_id,
        })
        logger.info(
            "Transition thành công: %s '%s' → '%s'",
            issue_key, current_status, target_status,
        )
        return {"transitioned": True, "skipped": False, "error": None, "issue_key": issue_key}

    except JiraConnectorError as exc:
        # Lỗi Jira — ghi audit nhưng KHÔNG block dossier update
        error_msg = str(exc)
        _append_timeline(task_dir, "jira_transition_failed", {
            "issue_key": issue_key,
            "to_status": target_status,
            "result": "failed",
            "error": error_msg,
            "trace_id": trace_id,
        })
        logger.error(
            "Jira transition thất bại cho %s: %s (dossier vẫn được cập nhật)",
            issue_key, exc,
        )
        return {"transitioned": False, "skipped": False, "error": error_msg, "issue_key": issue_key}


def link_dossier_to_jira(task_id: str, issue_key: str) -> dict:
    """Liên kết task dossier với Jira issue key.

    Cập nhật cả task.json và catalog.db.

    Returns:
        dict với keys: task_id, issue_key, linked_at
    """
    task_dir = _resolve_task_dir(task_id)
    payload = _load_task_payload(task_dir)

    issue_key = issue_key.upper()

    # Cập nhật task.json
    existing_keys: list[str] = payload.get("jira_issue_keys") or []
    if issue_key not in existing_keys:
        existing_keys.append(issue_key)
    payload["jira_issue_keys"] = existing_keys
    if not payload.get("jira_issue_key"):
        payload["jira_issue_key"] = issue_key

    _save_task_payload(task_dir, payload)

    # Lưu vào catalog.db
    link = upsert_jira_dossier_link(task_id, issue_key)

    _append_timeline(task_dir, "jira_dossier_linked", {
        "issue_key": issue_key,
        "linked_at": link["linked_at"],
    })

    return {
        "task_id": task_id,
        "issue_key": issue_key,
        "linked_at": link["linked_at"],
    }
