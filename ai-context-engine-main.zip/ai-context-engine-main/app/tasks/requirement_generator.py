"""Requirement Generator — sinh BRD/PRD từ intent text.

Pure Python, không gọi LLM. Sinh structured template document từ intent,
tích hợp domain detection, compliance checking và ChromaDB context.
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from app.core.config import settings
from app.core.logging import get_logger
from app.tasks.compliance_checker import ComplianceReport, check_requirements
from app.tasks.domain_detector import ComplianceClause, detect_domains

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class RequirementGeneratorResult:
    document: str               # markdown content
    domains: list[str]
    compliance_report: ComplianceReport
    context_chunks_used: int
    generated_at: str           # ISO 8601 UTC
    trace_id: str


# ---------------------------------------------------------------------------
# Domain glossary terms
# ---------------------------------------------------------------------------

_DOMAIN_GLOSSARY: dict[str, list[tuple[str, str]]] = {
    "PHARMACY": [
        ("Rx", "Thuốc kê đơn (prescription drug) theo phân loại của Bộ Y tế"),
        ("ADR", "Adverse Drug Reaction — phản ứng có hại của thuốc"),
        ("Dược sĩ", "Người có chuyên môn dược được cấp phép hành nghề"),
        ("Danh mục thuốc Bộ Y tế", "Danh sách thuốc được Bộ Y tế phê duyệt lưu hành"),
    ],
    "LAB_EMR": [
        ("EMR", "Electronic Medical Record — hồ sơ bệnh án điện tử"),
        ("HL7 FHIR", "Health Level 7 Fast Healthcare Interoperability Resources — chuẩn trao đổi dữ liệu y tế"),
        ("Audit Trail", "Nhật ký theo dõi mọi thao tác trên hồ sơ bệnh án"),
        ("Chữ ký số", "Digital signature xác thực tính toàn vẹn của hồ sơ bệnh án"),
    ],
    "VACCINATION": [
        ("Vắc xin", "Chế phẩm sinh học dùng để tạo miễn dịch chủ động"),
        ("Chống chỉ định", "Contraindication — điều kiện y tế không cho phép tiêm vắc xin"),
        ("Hệ thống tiêm chủng quốc gia", "Hệ thống thông tin quản lý tiêm chủng của Bộ Y tế"),
    ],
    "PAYMENT": [
        ("PAN", "Primary Account Number — số thẻ thanh toán"),
        ("CVV", "Card Verification Value — mã xác thực thẻ"),
        ("PCI-DSS", "Payment Card Industry Data Security Standard — tiêu chuẩn bảo mật dữ liệu thẻ"),
        ("Network Segmentation", "Phân vùng mạng tách biệt môi trường thanh toán"),
    ],
    "MEDICAL_DEVICE": [
        ("IoT", "Internet of Things — thiết bị kết nối internet"),
        ("NTP", "Network Time Protocol — giao thức đồng bộ thời gian"),
        ("OTA", "Over-The-Air — cập nhật firmware qua mạng"),
        ("Outlier Detection", "Phát hiện dữ liệu bất thường từ thiết bị"),
    ],
    "INFOSEC": [
        ("RTO", "Recovery Time Objective — thời gian phục hồi tối đa cho phép"),
        ("RPO", "Recovery Point Objective — điểm phục hồi dữ liệu tối đa cho phép"),
        ("VNCERT/CC", "Trung tâm Ứng cứu khẩn cấp không gian mạng Việt Nam"),
        ("ATTTM", "An toàn thông tin mạng"),
    ],
}

# ---------------------------------------------------------------------------
# Template builders
# ---------------------------------------------------------------------------


def _extract_title(intent: str) -> str:
    """Trích xuất tiêu đề từ dòng đầu tiên của intent."""
    first_line = intent.strip().splitlines()[0] if intent.strip() else "Hệ thống mới"
    # Giới hạn độ dài tiêu đề
    title = first_line.strip().rstrip(".")
    return title[:120] if len(title) > 120 else title


def _build_introduction(intent: str, domains: list[str]) -> str:
    """Sinh phần Giới thiệu từ intent và domains."""
    domain_labels = {
        "PHARMACY": "nhà thuốc / dược phẩm",
        "LAB_EMR": "xét nghiệm / hồ sơ bệnh án điện tử",
        "VACCINATION": "tiêm chủng",
        "PAYMENT": "thanh toán",
        "MEDICAL_DEVICE": "thiết bị y tế thông minh",
        "INFOSEC": "an toàn thông tin",
    }
    domain_str = (
        ", ".join(domain_labels.get(d, d) for d in domains)
        if domains
        else "hệ thống tổng quát"
    )

    lines = [
        "## Giới thiệu",
        "",
        intent.strip(),
        "",
        f"Tài liệu này mô tả các yêu cầu nghiệp vụ và kỹ thuật cho hệ thống thuộc lĩnh vực: **{domain_str}**.",
        "Mọi yêu cầu được trình bày theo chuẩn EARS (Easy Approach to Requirements Syntax) và INCOSE.",
        "",
    ]
    return "\n".join(lines)


def _build_glossary(domains: list[str], context_chunks: list[str]) -> str:
    """Sinh Bảng chú giải từ domains và context."""
    lines = ["## Bảng chú giải", ""]
    lines.append("| Thuật ngữ | Định nghĩa |")
    lines.append("|-----------|------------|")

    seen: set[str] = set()
    for domain in domains:
        for term, definition in _DOMAIN_GLOSSARY.get(domain, []):
            if term not in seen:
                seen.add(term)
                lines.append(f"| **{term}** | {definition} |")

    # Thêm các thuật ngữ chung nếu chưa có gì
    if not seen:
        lines.append("| **Intent** | Mô tả yêu cầu nghiệp vụ đầu vào từ người dùng |")
        lines.append("| **Acceptance Criteria** | Tiêu chí chấp nhận đo lường được theo chuẩn EARS |")

    lines.append("")
    return "\n".join(lines)


def _build_requirements_section(intent: str, domains: list[str], context_chunks: list[str]) -> str:
    """Sinh phần Yêu cầu từ intent."""
    lines = ["## Yêu cầu", ""]

    # Sinh user story chính từ intent
    title = _extract_title(intent)
    lines.append(f"### Yêu cầu 1: {title}")
    lines.append("")
    lines.append("**User Story:** Là một người dùng hệ thống, tôi muốn " + intent.strip().lower()[:200] + ", để tôi có thể đạt được mục tiêu nghiệp vụ.")
    lines.append("")
    lines.append("**Acceptance Criteria:**")
    lines.append("")
    lines.append(f"1. WHEN người dùng khởi tạo yêu cầu, THE Hệ thống SHALL xử lý và phản hồi trong vòng 30 giây")
    lines.append(f"2. THE Hệ thống SHALL xác thực đầu vào trước khi xử lý")
    lines.append(f"3. WHEN xử lý hoàn thành, THE Hệ thống SHALL trả về kết quả đúng định dạng")
    lines.append(f"4. IF đầu vào không hợp lệ, THEN THE Hệ thống SHALL trả về thông báo lỗi rõ ràng")

    # Thêm yêu cầu bổ sung từ context nếu có
    if context_chunks:
        lines.append("")
        lines.append("### Yêu cầu 2: Tích hợp hệ thống hiện có")
        lines.append("")
        lines.append("**User Story:** Là một kỹ sư hệ thống, tôi muốn tích hợp tính năng mới với codebase hiện có, để tôi có thể đảm bảo tính nhất quán kiến trúc.")
        lines.append("")
        lines.append("**Acceptance Criteria:**")
        lines.append("")
        lines.append("1. THE Hệ thống SHALL tuân thủ các pattern kiến trúc hiện có trong codebase")
        lines.append("2. WHEN tích hợp, THE Hệ thống SHALL không phá vỡ các API contract hiện tại")
        lines.append("3. THE Hệ thống SHALL có unit test coverage ≥ 80% cho module mới")

    # Thêm yêu cầu domain-specific
    req_num = 3 if context_chunks else 2
    domain_req_map = {
        "PHARMACY": (
            "Quản lý thuốc và kê đơn",
            "Là một dược sĩ, tôi muốn quản lý thuốc và xác nhận kê đơn Rx, để tôi có thể đảm bảo tuân thủ Luật Dược 2016.",
            [
                "WHEN dược sĩ bán thuốc Rx, THE Hệ thống SHALL xác nhận đơn thuốc hợp lệ trước khi cho phép bán (prescription validation)",
                "THE Hệ thống SHALL lưu trữ lịch sử giao dịch thuốc tối thiểu 5 năm theo Luật Dược 2016",
                "THE Hệ thống SHALL đối chiếu thông tin thuốc với danh mục Bộ Y tế",
                "THE Hệ thống SHALL ghi nhận và hỗ trợ báo cáo ADR (adverse drug reaction) định kỳ",
            ],
        ),
        "LAB_EMR": (
            "Quản lý hồ sơ bệnh án điện tử",
            "Là một bác sĩ, tôi muốn quản lý hồ sơ bệnh án điện tử với audit trail đầy đủ, để tôi có thể tuân thủ Nghị định 96/2023.",
            [
                "THE Hệ thống SHALL duy trì audit trail đầy đủ cho mọi thao tác trên hồ sơ bệnh án",
                "THE Hệ thống SHALL yêu cầu chữ ký số của bác sĩ phụ trách theo Nghị định 96/2023",
                "THE Hệ thống SHALL lưu trữ hồ sơ bệnh án tối thiểu 10 năm (người lớn), 15 năm (trẻ em)",
                "THE Hệ thống SHALL hỗ trợ chia sẻ dữ liệu theo chuẩn HL7 FHIR R4",
                "Kết quả xét nghiệm SHALL có giá trị tham chiếu và đơn vị đo chuẩn quốc tế (SI units)",
            ],
        ),
        "VACCINATION": (
            "Quản lý tiêm chủng",
            "Là một nhân viên y tế, tôi muốn quản lý lịch tiêm chủng và kết nối hệ thống quốc gia, để tôi có thể tuân thủ Thông tư 09/2023.",
            [
                "THE Hệ thống SHALL kết nối và đồng bộ với Hệ thống thông tin tiêm chủng quốc gia (TT 09/2023)",
                "WHEN lên lịch tiêm, THE Hệ thống SHALL tự động kiểm tra và cảnh báo chống chỉ định",
                "THE Hệ thống SHALL lưu trữ lịch sử tiêm chủng tối thiểu 20 năm",
            ],
        ),
        "PAYMENT": (
            "Xử lý thanh toán an toàn",
            "Là một nhân viên thu ngân, tôi muốn xử lý thanh toán an toàn theo PCI-DSS, để tôi có thể bảo vệ dữ liệu thẻ khách hàng.",
            [
                "THE Hệ thống KHÔNG ĐƯỢC lưu CVV và full PAN sau khi giao dịch hoàn thành (PCI-DSS Req 3.2)",
                "Dữ liệu thẻ khi lưu trữ SHALL được mã hoá bằng AES-256 (PCI-DSS Req 3.5)",
                "THE Hệ thống SHALL có network segmentation tách biệt môi trường thanh toán (PCI-DSS Req 1.3)",
            ],
        ),
        "MEDICAL_DEVICE": (
            "Quản lý thiết bị y tế IoT",
            "Là một kỹ sư hệ thống, tôi muốn quản lý thiết bị y tế IoT an toàn, để tôi có thể tuân thủ QCVN 117:2020.",
            [
                "Thiết bị SHALL đồng bộ thời gian qua NTP và hệ thống SHALL có outlier detection (QCVN 117:2020)",
                "Firmware SHALL hỗ trợ secure OTA update với xác thực chữ ký số",
            ],
        ),
        "INFOSEC": (
            "An toàn thông tin hệ thống",
            "Là một security officer, tôi muốn đảm bảo hệ thống đáp ứng RTO/RPO và báo cáo sự cố đúng hạn, để tôi có thể tuân thủ Luật ATTTM 2015.",
            [
                "THE Hệ thống SHALL đáp ứng RTO ≤ 4 giờ và RPO ≤ 1 giờ (Luật ATTTM 2015, Điều 21)",
                "THE Hệ thống SHALL báo cáo sự cố an toàn thông tin cho VNCERT/CC trong vòng 24 giờ",
                "THE Hệ thống SHALL thông báo vi phạm dữ liệu cá nhân trong vòng 72 giờ (NĐ 13/2023)",
            ],
        ),
    }

    for domain in domains:
        if domain in domain_req_map:
            req_title, user_story, criteria = domain_req_map[domain]
            lines.append("")
            lines.append(f"### Yêu cầu {req_num}: {req_title}")
            lines.append("")
            lines.append(f"**User Story:** {user_story}")
            lines.append("")
            lines.append("**Acceptance Criteria:**")
            lines.append("")
            for i, criterion in enumerate(criteria, 1):
                lines.append(f"{i}. {criterion}")
            req_num += 1

    lines.append("")
    return "\n".join(lines)


def _build_compliance_section(clauses: list[ComplianceClause]) -> str:
    """Sinh phần Compliance Requirements từ compliance clauses."""
    lines = ["## Compliance Requirements", ""]
    lines.append("*Phần này được tự động inject theo domain được phát hiện.*")
    lines.append("")

    if not clauses:
        lines.append("*Không có compliance requirement đặc thù theo domain. Áp dụng các tiêu chuẩn chung.*")
        lines.append("")
        return "\n".join(lines)

    # Nhóm theo domain
    by_domain: dict[str, list[ComplianceClause]] = {}
    for clause in clauses:
        by_domain.setdefault(clause.domain, []).append(clause)

    domain_titles = {
        "PHARMACY": "Nhà thuốc / Dược phẩm (Luật Dược 2016)",
        "LAB_EMR": "Xét nghiệm / Bệnh án điện tử (NĐ 96/2023, TT 27/2021)",
        "VACCINATION": "Tiêm chủng (TT 09/2023)",
        "PAYMENT": "Thanh toán (PCI-DSS v4.0)",
        "MEDICAL_DEVICE": "Thiết bị y tế thông minh (QCVN 117:2020)",
        "INFOSEC": "An toàn thông tin (Luật ATTTM 2015, NĐ 13/2023)",
    }

    for domain, domain_clauses in by_domain.items():
        title = domain_titles.get(domain, domain)
        lines.append(f"### {title}")
        lines.append("")
        for clause in domain_clauses:
            mandatory_label = "**[BẮT BUỘC]**" if clause.mandatory else "*[Khuyến nghị]*"
            lines.append(f"#### {clause.code}: {clause.title} {mandatory_label}")
            lines.append("")
            lines.append(clause.requirement_text)
            lines.append("")
            lines.append(f"*Căn cứ pháp lý: {clause.legal_basis}*")
            lines.append("")

    return "\n".join(lines)


def _build_correctness_properties(domains: list[str]) -> str:
    """Sinh phần Correctness Properties."""
    lines = ["## Correctness Properties", ""]

    lines.append("### Invariant: Compliance Injection")
    lines.append("")
    lines.append("Với mọi requirement document có domain được phát hiện, document phải chứa ít nhất một compliance clause tương ứng với mỗi domain.")
    lines.append("")
    lines.append("```")
    lines.append("∀ doc, domain ∈ detected_domains(doc) → ∃ clause ∈ doc.compliance_clauses : clause.domain = domain")
    lines.append("```")
    lines.append("")

    if "PHARMACY" in domains:
        lines.append("### Error Condition: Rx Drug Without Prescription Validation")
        lines.append("")
        lines.append("Requirement liên quan đến bán thuốc Rx mà không có điều khoản validation kê đơn phải bị phát hiện bởi Compliance_Checker.")
        lines.append("")
        lines.append("```")
        lines.append("∀ req : is_rx_sale(req) ∧ ¬has_prescription_validation(req) → compliance_check(req) = FAIL(\"PHARMACY-001\")")
        lines.append("```")
        lines.append("")

    if any(d in domains for d in ("PHARMACY", "LAB_EMR", "VACCINATION")):
        lines.append("### Invariant: Data Retention")
        lines.append("")
        lines.append("Thời hạn lưu trữ trong document phải ≥ legal minimum theo từng loại dữ liệu:")
        lines.append("")
        if "PHARMACY" in domains:
            lines.append("- Giao dịch thuốc: ≥ 5 năm (Luật Dược 2016)")
        if "LAB_EMR" in domains:
            lines.append("- Bệnh án người lớn: ≥ 10 năm (TT 27/2021)")
            lines.append("- Bệnh án trẻ em: ≥ 15 năm (TT 27/2021)")
        if "VACCINATION" in domains:
            lines.append("- Lịch sử tiêm chủng: ≥ 20 năm (TT 09/2023)")
        lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Audit logging
# ---------------------------------------------------------------------------


def _write_audit_record(
    trace_id: str,
    domains: list[str],
    compliance_passed: bool,
    violations_count: int,
    duration_ms: int,
    confluence_page_id: str | None = None,
) -> None:
    """Ghi audit record vào rde_audit.jsonl. Không chứa PII."""
    audit_id = uuid.uuid4().hex[:8]
    record = {
        "event_type": "rde_generate_requirements",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "details": {
            "audit_id": audit_id,
            "trace_id": trace_id,
            "action": "generate_requirements",
            "actor": "system",
            "domains": domains,
            "compliance_passed": compliance_passed,
            "violations_count": violations_count,
            "confluence_page_id": confluence_page_id,
            "duration_ms": duration_ms,
        },
    }

    log_path: Path = settings.logs_dir / "rde_audit.jsonl"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except OSError as exc:
        logger.warning("Failed to write audit record", extra={"error": str(exc), "trace_id": trace_id})


# ---------------------------------------------------------------------------
# Core function
# ---------------------------------------------------------------------------


def generate_requirements(
    intent: str,
    collection_name: str = "knowledge",
    top_k: int = 10,
    trace_id: str | None = None,
) -> RequirementGeneratorResult:
    """Sinh tài liệu BRD/PRD từ intent text.

    Không gọi LLM. Sinh structured template document từ intent,
    tích hợp domain detection, compliance clauses và ChromaDB context.

    Args:
        intent: Mô tả yêu cầu nghiệp vụ đầu vào.
        collection_name: Tên ChromaDB collection để lấy context.
        top_k: Số lượng context chunks tối đa lấy từ ChromaDB.
        trace_id: ID để trace request xuyên suốt hệ thống.

    Returns:
        RequirementGeneratorResult với document markdown, domains, compliance_report.
    """
    if trace_id is None:
        trace_id = uuid.uuid4().hex[:16]

    start_time = time.monotonic()

    logger.info(
        "generate_requirements started",
        extra={"trace_id": trace_id, "collection_name": collection_name, "top_k": top_k},
    )

    # 1. Detect domains và lấy compliance clauses
    detection = detect_domains(intent)
    domains = detection.domains
    clauses = detection.compliance_clauses

    # 2. Lấy codebase context từ ChromaDB (graceful degradation nếu không có)
    context_chunks: list[str] = []
    try:
        from app.retrieval.search import search as chroma_search

        results = chroma_search(query=intent, collection_name=collection_name, top_k=top_k)
        context_chunks = [r.content for r in results]
        logger.info(
            "ChromaDB context retrieved",
            extra={"trace_id": trace_id, "chunks_count": len(context_chunks)},
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "ChromaDB search failed, proceeding without context",
            extra={"trace_id": trace_id, "error": str(exc)},
        )

    # 3. Sinh document theo template chuẩn
    title = _extract_title(intent)
    sections: list[str] = [
        f"# Tài liệu Yêu cầu: {title}",
        "",
        _build_introduction(intent, domains),
        _build_glossary(domains, context_chunks),
        _build_requirements_section(intent, domains, context_chunks),
        _build_compliance_section(clauses),
        _build_correctness_properties(domains),
    ]
    document = "\n".join(sections)

    # 4. Kiểm tra compliance
    compliance_report = check_requirements(document, domains)

    duration_ms = int((time.monotonic() - start_time) * 1000)

    # 5. Ghi audit record (không chứa PII — không lưu intent text)
    _write_audit_record(
        trace_id=trace_id,
        domains=domains,
        compliance_passed=compliance_report.passed,
        violations_count=len(compliance_report.violations),
        duration_ms=duration_ms,
    )

    logger.info(
        "generate_requirements completed",
        extra={
            "trace_id": trace_id,
            "domains": domains,
            "context_chunks_used": len(context_chunks),
            "compliance_passed": compliance_report.passed,
            "violations_count": len(compliance_report.violations),
            "duration_ms": duration_ms,
        },
    )

    return RequirementGeneratorResult(
        document=document,
        domains=domains,
        compliance_report=compliance_report,
        context_chunks_used=len(context_chunks),
        generated_at=datetime.now(timezone.utc).isoformat(),
        trace_id=trace_id,
    )
