"""Task brief generation from synced sources and indexed context."""

from __future__ import annotations

import json
import re
import unicodedata

from app.catalog.database import list_sources
from app.retrieval.search import search


def normalize_text(value: str | None) -> str:
    value = value or ""
    normalized = unicodedata.normalize("NFKD", value)
    normalized = "".join(ch for ch in normalized if not unicodedata.combining(ch))
    normalized = re.sub(r"[^a-zA-Z0-9]+", " ", normalized.lower())
    return re.sub(r"\s+", " ", normalized).strip()


def tokenize(value: str | None) -> set[str]:
    return {token for token in normalize_text(value).split() if len(token) > 1}


def source_repo_id(source: dict) -> str:
    metadata = json.loads(source.get("metadata_json") or "{}")
    return metadata.get("repo_id", source["source_id"])


def rank_sources(task: str) -> list[dict]:
    task_tokens = tokenize(task)
    ranked = []
    for source in list_sources(source_type="git_repo"):
        metadata = json.loads(source.get("metadata_json") or "{}")
        candidates = [
            source.get("title", ""),
            source.get("path_with_namespace", ""),
            metadata.get("repo_id", ""),
            metadata.get("description", ""),
        ]
        score = 0.0
        reasons = []
        for candidate in candidates:
            normalized = normalize_text(candidate)
            if not normalized:
                continue
            if normalized in normalize_text(task):
                score += 5.0
                reasons.append(f"matched '{candidate}'")
            else:
                overlap = len(task_tokens & tokenize(candidate))
                if overlap:
                    score += overlap * 1.5
                    reasons.append(f"overlap with '{candidate}'")
        if source.get("status") in {"indexed", "synced"}:
            score += 1.0
        if source.get("local_path"):
            score += 1.0
        ranked.append({"source": source, "score": round(score, 2), "reasons": reasons[:5]})
    ranked.sort(key=lambda item: item["score"], reverse=True)
    return ranked


def build_task_brief(task: str, collection_name: str, top_k: int = 5) -> dict:
    ranked = rank_sources(task)
    if not ranked:
        raise ValueError("No Git repository sources available in catalog.")
    selected = ranked[0]["source"]
    repo_id = source_repo_id(selected)
    results = search(task, collection_name=collection_name, top_k=top_k, repo_id=repo_id)

    # --- Confluence context (enhancement for MCP) ---
    confluence_results_raw = search(
        task, collection_name, top_k=top_k, source_type="confluence_page"
    )
    confluence_items = [r.to_dict() for r in confluence_results_raw]

    lines = [
        "Task:",
        task,
        "",
        "Selected repository:",
        f"- source_id: {selected['source_id']}",
        f"- title: {selected['title']}",
        f"- repo_id: {repo_id}",
        f"- local_path: {selected.get('local_path', '')}",
        "",
        "Why this repo:",
    ]
    reasons = ranked[0]["reasons"] or ["Highest ranked repo from catalog metadata."]
    lines.extend(f"- {reason}" for reason in reasons)
    lines.extend(["", "Relevant context:"])
    if results:
        for index, result in enumerate(results[:3], start=1):
            source = result.metadata.get("relative_source") or result.metadata.get("source") or "unknown"
            snippet = " ".join(result.content.split())[:280]
            lines.append(f"{index}. [{source}] score={result.score:.3f} :: {snippet}")
    else:
        lines.append("1. No semantic results found in the selected collection yet.")
    if confluence_items:
        lines.append("")
        lines.append("Business context (Confluence):")
        for item in confluence_items[:3]:
            title = item.get("metadata", {}).get("title", "")
            snippet = " ".join(item["content"].split())[:280]
            lines.append(f"- [{title}] score={item['score']:.3f} :: {snippet}")
    lines.extend([
        "",
        "Execution guidance:",
        "- Read the real files from local_path before editing.",
        "- Keep the change minimal and consistent with current patterns.",
        "- Run build/test commands discovered for the repo after editing.",
    ])

    return {
        "task": task,
        "selected_source": selected,
        "repo_candidates": [
            {
                "source_id": item["source"]["source_id"],
                "title": item["source"]["title"],
                "score": item["score"],
                "reasons": item["reasons"],
            }
            for item in ranked[:5]
        ],
        "results": [result.to_dict() for result in results],
        "confluence_results": confluence_items,
        "brief": "\n".join(lines),
    }
