"""UAT Promoter — kiểm tra CI success và trigger Jenkins deploy-uat."""

from __future__ import annotations

import uuid

from app.catalog.database import list_deployments, save_deployment_record
from app.core.logging import get_logger
from app.core.utils import utc_now_iso
from app.tasks.k8s._audit import _get_jenkins_connector, _health_check, write_audit
from app.tasks.k8s.models import PromotionResult

logger = get_logger(__name__)


def promote_to_uat(
    service: str,
    build_number: int,
    jenkins_deploy_job: str,
    uat_health_url: str | None = None,
    trace_id: str | None = None,
) -> PromotionResult:
    """Kiểm tra CI deployment success và trigger Jenkins deploy-uat.

    Args:
        service: Tên service
        build_number: Build number cần promote
        jenkins_deploy_job: Tên Jenkins job deploy-uat
        uat_health_url: URL health check sau khi deploy (optional)
        trace_id: Trace ID

    Returns:
        PromotionResult với approved=True nếu tất cả điều kiện pass.
    """
    if trace_id is None:
        trace_id = uuid.uuid4().hex[:16]

    blocking_reasons: list[str] = []

    # 1. Kiểm tra CI deployment success
    ci_deployments = list_deployments(service=service, environment="ci", limit=20)
    ci_success = any(
        d["build_number"] == build_number and d["status"] == "success"
        for d in ci_deployments
    )
    if not ci_success:
        blocking_reasons.append(
            f"Chưa có CI deployment thành công cho build #{build_number}. "
            "Chạy k8s-promote-ci trước."
        )

    # 2. Kiểm tra không có CRITICAL finding (graceful — chỉ warn nếu không check được)
    # (Trong thực tế có thể đọc từ qge_audit.jsonl, hiện tại skip nếu không có data)

    # 3. Kiểm tra không có UAT deployment trùng build_number
    uat_deployments = list_deployments(service=service, environment="uat", limit=20)
    uat_duplicate = any(
        d["build_number"] == build_number and d["status"] == "success"
        for d in uat_deployments
    )
    if uat_duplicate:
        blocking_reasons.append(
            f"UAT deployment cho build #{build_number} đã tồn tại và success. Không cần deploy lại."
        )

    if blocking_reasons:
        result = PromotionResult(
            approved=False, service=service, build_number=build_number,
            environment="uat", blocking_reasons=blocking_reasons,
            promoted_at=utc_now_iso(),
        )
        write_audit("k8s_promote_uat", {
            "trace_id": trace_id, "service": service, "build_number": build_number,
            "approved": False, "blocking_reasons": blocking_reasons,
        })
        return result

    # Trigger Jenkins deploy-uat
    jenkins_build_number: int | None = None
    try:
        connector = _get_jenkins_connector()
        jenkins_build_number = connector.trigger_job(
            jenkins_deploy_job,
            parameters={"SERVICE": service, "BUILD_NUMBER": str(build_number)},
        )
    except Exception as exc:
        logger.warning("Jenkins trigger failed: %s", exc, extra={"trace_id": trace_id})

    # Lưu DeploymentRecord
    record_id = uuid.uuid4().hex[:16]
    deployed_at = utc_now_iso()
    save_deployment_record(
        record_id=record_id,
        service=service, environment="uat", build_number=build_number,
        job_name=jenkins_deploy_job, status="running",
        deployed_at=deployed_at, deployed_by="system",
        build_url=f"{jenkins_deploy_job}/{jenkins_build_number}" if jenkins_build_number else "",
    )

    # Health check
    if uat_health_url:
        healthy = _health_check(uat_health_url)
        final_status = "success" if healthy else "failure"
        save_deployment_record(
            record_id=uuid.uuid4().hex[:16],
            service=service, environment="uat", build_number=build_number,
            job_name=jenkins_deploy_job, status=final_status,
            deployed_at=utc_now_iso(), deployed_by="system",
        )

    write_audit("k8s_promote_uat", {
        "trace_id": trace_id, "service": service, "build_number": build_number,
        "approved": True, "jenkins_build_number": jenkins_build_number,
    })

    logger.info("UAT promotion approved service=%s build=%d", service, build_number,
                extra={"trace_id": trace_id})

    return PromotionResult(
        approved=True, service=service, build_number=build_number,
        environment="uat", jenkins_build_number=jenkins_build_number,
        promoted_at=deployed_at,
    )
