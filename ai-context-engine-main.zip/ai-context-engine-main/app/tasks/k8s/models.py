"""Data models cho K8s & Deployment Intelligence."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class HelmValues:
    filename: str           # "values.yaml"
    content: str            # YAML string
    service_name: str
    environment: str


@dataclass
class ChecklistItem:
    name: str
    status: str             # "PASS" | "FAIL" | "WARN"
    message: str


@dataclass
class GateResult:
    approved: bool
    checklist: list[ChecklistItem] = field(default_factory=list)
    blocking_items: list[ChecklistItem] = field(default_factory=list)
    suggested_command: str = ""
    checked_at: str = ""

    def __post_init__(self) -> None:
        if not self.blocking_items:
            self.blocking_items = [i for i in self.checklist if i.status == "FAIL"]


@dataclass
class PromotionResult:
    approved: bool
    service: str
    build_number: int
    environment: str
    blocking_reasons: list[str] = field(default_factory=list)
    jenkins_build_number: int | None = None
    promoted_at: str = ""


@dataclass
class CorrelationResult:
    service: str
    incident_time: str
    deployment: dict | None             # DeploymentRecord as dict
    time_delta_minutes: float | None
    likely_cause: bool
    suggested_action: str               # "rollback" | "investigate_app" | "investigate_infra"
    context_snippets: list[str] = field(default_factory=list)
    analyzed_at: str = ""
