"""Helm Values Generator — sinh values.yaml cho Helm chart deploy."""

from __future__ import annotations

import yaml

from app.tasks.k8s.models import HelmValues


def generate_helm_values(
    service_name: str,
    image_repository: str,
    image_tag: str,
    port: int,
    environment: str = "uat",
    replicas: int = 1,
    cpu_request: str = "100m",
    cpu_limit: str = "500m",
    memory_request: str = "128Mi",
    memory_limit: str = "512Mi",
    ingress_host: str | None = None,
    env_vars: dict | None = None,
    hpa_enabled: bool = False,
    hpa_min_replicas: int = 1,
    hpa_max_replicas: int = 5,
    hpa_cpu_threshold: int = 70,
    health_path: str = "/health",
) -> HelmValues:
    """Sinh Helm values.yaml từ service metadata.

    Args:
        service_name: Tên service
        image_repository: Docker image repository (ví dụ: registry.example.com/my-service)
        image_tag: Docker image tag (ví dụ: 1.0.0)
        port: Container port
        environment: Target environment (ci/uat/prod)
        replicas: Số replicas mặc định
        cpu_request/limit: CPU resource
        memory_request/limit: Memory resource
        ingress_host: Hostname cho Ingress (None = không tạo ingress)
        env_vars: Dict environment variables
        hpa_enabled: Bật HorizontalPodAutoscaler
        hpa_min/max_replicas: HPA replica range
        hpa_cpu_threshold: CPU utilization threshold (%)
        health_path: Path cho liveness/readiness probe

    Returns:
        HelmValues với content là YAML string hợp lệ.
    """
    values: dict = {
        "replicaCount": replicas,
        "image": {
            "repository": image_repository,
            "tag": str(image_tag),
            "pullPolicy": "IfNotPresent",
        },
        "service": {
            "port": port,
        },
        "resources": {
            "requests": {
                "cpu": cpu_request,
                "memory": memory_request,
            },
            "limits": {
                "cpu": cpu_limit,
                "memory": memory_limit,
            },
        },
        "livenessProbe": {
            "httpGet": {
                "path": health_path,
                "port": port,
            },
            "initialDelaySeconds": 30,
            "periodSeconds": 10,
        },
        "readinessProbe": {
            "httpGet": {
                "path": health_path,
                "port": port,
            },
            "initialDelaySeconds": 10,
            "periodSeconds": 5,
        },
        "ingress": {
            "enabled": ingress_host is not None,
        },
        "env": [],
        "autoscaling": {
            "enabled": False,
        },
    }

    # Ingress config
    if ingress_host:
        values["ingress"].update({
            "host": ingress_host,
            "tls": True,
            "annotations": {
                "kubernetes.io/ingress.class": "nginx",
            },
        })

    # Environment variables
    if env_vars:
        values["env"] = [
            {"name": k, "value": str(v)}
            for k, v in env_vars.items()
        ]

    # HPA config
    if hpa_enabled:
        values["autoscaling"] = {
            "enabled": True,
            "minReplicas": hpa_min_replicas,
            "maxReplicas": hpa_max_replicas,
            "targetCPUUtilizationPercentage": hpa_cpu_threshold,
        }

    # Validate YAML
    content = yaml.dump(values, default_flow_style=False, allow_unicode=True, sort_keys=False)
    yaml.safe_load(content)  # validate — raises if invalid

    return HelmValues(
        filename="values.yaml",
        content=content,
        service_name=service_name,
        environment=environment,
    )
