"""Shared audit logging cho K8s module."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


def write_audit(event_type: str, details: dict) -> None:
    record = {
        "event_type": event_type,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "details": details,
    }
    log_path: Path = settings.logs_dir / "k8s_audit.jsonl"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except OSError as exc:
        logger.warning("Failed to write K8s audit: %s", exc)


def _get_jenkins_connector():
    """Lấy JenkinsConnector từ settings."""
    from app.connectors.jenkins import JenkinsConnector
    if not settings.jenkins_base_url:
        raise ValueError("Jenkins chưa được cấu hình. Đặt AI_CONTEXT_V2_JENKINS_BASE_URL trong .env")
    return JenkinsConnector(settings.jenkins_base_url, settings.jenkins_username, settings.jenkins_token)


def _health_check(url: str) -> bool:
    """HTTP GET health check. Trả về True nếu status 2xx."""
    import urllib.request
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            return 200 <= resp.status < 300
    except Exception:
        return False
