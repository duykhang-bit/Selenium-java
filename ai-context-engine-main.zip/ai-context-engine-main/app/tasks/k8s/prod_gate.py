"""PROD Gate — sinh checklist trước khi promote lên PROD."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone, timedelta

from app.catalog.database import list_deployments
from app.core.config import settings
from app.core.logging import get_logger
from app.core.utils import utc_now_iso
from app.tasks.k8s._audit import write_audit
from app.tasks.k8s.models import ChecklistItem, GateResult

logger = get_logger(__name__)


def _parse_iso(ts: str) -> datetime | None:
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except Exception:
        return None


def check_prod_gate(
    service: str,
    build_number: int,
    jenkins_deploy_job: str = "",
    soak_minutes: int | None = None,
    trace_id: str | None = None,
) -> GateResult:
    """Sinh PROD promotion checklist.

    KHÔNG tự động trigger Jenkins — chỉ trả về checklist để người dùng quyết định.

    Args:
        service: Tên service
        build_number: Build number cần promote lên PROD
        jenkins_deploy_job: Tên Jenkins job deploy-prod (dùng để sinh suggested_command)
        soak_minutes: Thời gian soak tối thiểu sau UAT deploy (default từ settings)
        trace_id: Trace ID

    Returns:
        GateResult với checklist và suggested_command nếu approved.
    """
    if trace_id is None:
        trace_id = uuid.uuid4().hex[:16]

    effective_soak = soak_minutes if soak_minutes is not None else settings.k8s_prod_soak_minutes
    checklist: list[ChecklistItem] = []

    # 1. UAT deployment tồn tại cho build_number
    uat_deployments = list_deployments(service=service, environment="uat", limit=20)
    uat_record = next(
        (d for d in uat_deployments if d["build_number"] == build_number), None
    )
    if uat_record:
        checklist.append(ChecklistItem(
            name="UAT deployment exists",
            status="PASS",
            message=f"UAT deployment tìm thấy: record_id={uat_record['record_id']}",
        ))
    else:
        checklist.append(ChecklistItem(
            name="UAT deployment exists",
            status="FAIL",
            message=f"Không tìm thấy UAT deployment cho build #{build_number}. Chạy k8s-promote-uat trước.",
        ))

    # 2. UAT deployment status = success
    if uat_record:
        if uat_record.get("status") == "success":
            checklist.append(ChecklistItem(
                name="UAT deployment success",
                status="PASS",
                message="UAT deployment status=success",
            ))
        else:
            checklist.append(ChecklistItem(
                name="UAT deployment success",
                status="FAIL",
                message=f"UAT deployment status={uat_record.get('status')} — phải success",
            ))

    # 3. Soak time
    if uat_record:
        deployed_at = _parse_iso(uat_record.get("deployed_at", ""))
        if deployed_at:
            now = datetime.now(timezone.utc)
            delta_minutes = (now - deployed_at).total_seconds() / 60
            if delta_minutes >= effective_soak:
                checklist.append(ChecklistItem(
                    name="UAT soak time",
                    status="PASS",
                    message=f"Soak time {delta_minutes:.0f} phút ≥ {effective_soak} phút",
                ))
            else:
                checklist.append(ChecklistItem(
                    name="UAT soak time",
                    status="WARN",
                    message=f"Soak time {delta_minutes:.0f} phút < {effective_soak} phút. Nên chờ thêm.",
                ))

    # 4. Không có CRITICAL findings (check qge_audit.jsonl nếu có)
    try:
        import json
        from pathlib import Path
        audit_path = settings.logs_dir / "qge_audit.jsonl"
        has_critical = False
        if audit_path.exists():
            for line in audit_path.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                record = json.loads(line)
                if record.get("details", {}).get("total_critical", 0) > 0:
                    has_critical = True
                    break
        if has_critical:
            checklist.append(ChecklistItem(
                name="No CRITICAL findings",
                status="FAIL",
                message="Có CRITICAL finding trong quality gate. Phải fix trước khi lên PROD.",
            ))
        else:
            checklist.append(ChecklistItem(
                name="No CRITICAL findings",
                status="PASS",
                message="Không có CRITICAL finding",
            ))
    except Exception:
        checklist.append(ChecklistItem(
            name="No CRITICAL findings",
            status="WARN",
            message="Không thể kiểm tra quality gate findings — review thủ công",
        ))

    # 5. Không có PROD deployment đang chạy
    prod_deployments = list_deployments(service=service, environment="prod", limit=5)
    running_prod = any(d.get("status") == "running" for d in prod_deployments)
    if running_prod:
        checklist.append(ChecklistItem(
            name="No running PROD deployment",
            status="FAIL",
            message="Đang có PROD deployment chạy. Chờ hoàn thành trước.",
        ))
    else:
        checklist.append(ChecklistItem(
            name="No running PROD deployment",
            status="PASS",
            message="Không có PROD deployment đang chạy",
        ))

    # Tổng hợp
    blocking = [i for i in checklist if i.status == "FAIL"]
    approved = len(blocking) == 0

    suggested_command = ""
    if approved and jenkins_deploy_job:
        suggested_command = (
            f"python -m app.cli jenkins-trigger {jenkins_deploy_job} "
            f"--param SERVICE={service} --param BUILD_NUMBER={build_number} --param ENV=prod"
        )

    checked_at = utc_now_iso()
    write_audit("k8s_prod_gate", {
        "trace_id": trace_id, "service": service, "build_number": build_number,
        "approved": approved,
        "checklist": [{"name": i.name, "status": i.status} for i in checklist],
        "blocking_count": len(blocking),
    })

    logger.info("PROD gate checked service=%s build=%d approved=%s",
                service, build_number, approved, extra={"trace_id": trace_id})

    return GateResult(
        approved=approved,
        checklist=checklist,
        blocking_items=blocking,
        suggested_command=suggested_command,
        checked_at=checked_at,
    )
