"""Incident Correlator — correlate alert với deployment gần nhất."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone, timedelta

from app.catalog.database import list_deployments
from app.core.logging import get_logger
from app.core.utils import utc_now_iso
from app.tasks.k8s.models import CorrelationResult

logger = get_logger(__name__)

_LIKELY_CAUSE_THRESHOLD_MINUTES = 30
_LOOKBACK_HOURS = 24


def _parse_iso(ts: str) -> datetime | None:
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except Exception:
        return None


def correlate_incident(
    service: str,
    incident_time: str,
    collection_name: str = "knowledge",
    trace_id: str | None = None,
) -> CorrelationResult:
    """Correlate incident với deployment gần nhất của service.

    Args:
        service: Tên service bị incident
        incident_time: Thời điểm incident (ISO 8601)
        collection_name: ChromaDB collection để search context
        trace_id: Trace ID

    Returns:
        CorrelationResult với deployment record, time_delta, và suggested_action.
    """
    if trace_id is None:
        trace_id = uuid.uuid4().hex[:16]

    incident_dt = _parse_iso(incident_time)
    if not incident_dt:
        return CorrelationResult(
            service=service, incident_time=incident_time,
            deployment=None, time_delta_minutes=None,
            likely_cause=False, suggested_action="investigate_infra",
            analyzed_at=utc_now_iso(),
        )

    # Lấy tất cả deployments của service (ci + uat + prod)
    all_deployments = list_deployments(service=service, limit=50)

    # Tìm deployment gần nhất trước incident_time
    lookback_cutoff = incident_dt - timedelta(hours=_LOOKBACK_HOURS)
    candidates = []
    for d in all_deployments:
        deployed_at = _parse_iso(d.get("deployed_at", ""))
        if deployed_at and lookback_cutoff <= deployed_at <= incident_dt:
            candidates.append((deployed_at, d))

    # Sort theo deployed_at desc — lấy gần nhất
    candidates.sort(key=lambda x: x[0], reverse=True)

    context_snippets: list[str] = []
    try:
        from app.retrieval.search import search
        results = search(f"{service} error incident deployment", collection_name, top_k=3)
        context_snippets = [r.content[:200] for r in results]
    except Exception:
        pass

    if not candidates:
        logger.info("No deployment found in %dh before incident for service=%s",
                    _LOOKBACK_HOURS, service, extra={"trace_id": trace_id})
        return CorrelationResult(
            service=service, incident_time=incident_time,
            deployment=None, time_delta_minutes=None,
            likely_cause=False, suggested_action="investigate_infra",
            context_snippets=context_snippets,
            analyzed_at=utc_now_iso(),
        )

    nearest_dt, nearest_deployment = candidates[0]
    time_delta_minutes = (incident_dt - nearest_dt).total_seconds() / 60
    likely_cause = time_delta_minutes <= _LIKELY_CAUSE_THRESHOLD_MINUTES

    if likely_cause:
        env = nearest_deployment.get("environment", "")
        suggested_action = "rollback" if env in ("prod", "uat") else "investigate_app"
    elif time_delta_minutes <= _LOOKBACK_HOURS * 60:
        suggested_action = "investigate_app"
    else:
        suggested_action = "investigate_infra"

    logger.info(
        "Incident correlated service=%s time_delta=%.1f likely_cause=%s action=%s",
        service, time_delta_minutes, likely_cause, suggested_action,
        extra={"trace_id": trace_id},
    )

    return CorrelationResult(
        service=service,
        incident_time=incident_time,
        deployment=nearest_deployment,
        time_delta_minutes=round(time_delta_minutes, 1),
        likely_cause=likely_cause,
        suggested_action=suggested_action,
        context_snippets=context_snippets,
        analyzed_at=utc_now_iso(),
    )
