"""CI Promoter — kiểm tra build pass và trigger Jenkins deploy-ci."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from app.catalog.database import list_deployments, save_deployment_record
from app.core.logging import get_logger
from app.core.utils import utc_now_iso
from app.tasks.k8s._audit import _get_jenkins_connector, _health_check, write_audit
from app.tasks.k8s.models import PromotionResult

logger = get_logger(__name__)


def promote_to_ci(
    service: str,
    build_number: int,
    jenkins_deploy_job: str,
    ci_health_url: str | None = None,
    trace_id: str | None = None,
) -> PromotionResult:
    """Kiểm tra build pass và trigger Jenkins deploy-ci.

    Args:
        service: Tên service
        build_number: Jenkins build number của build job (không phải deploy job)
        jenkins_deploy_job: Tên Jenkins job deploy-ci
        ci_health_url: URL health check sau khi deploy (optional)
        trace_id: Trace ID

    Returns:
        PromotionResult với approved=True nếu tất cả điều kiện pass.
    """
    if trace_id is None:
        trace_id = uuid.uuid4().hex[:16]

    blocking_reasons: list[str] = []

    # Kiểm tra Jenkins build status
    try:
        connector = _get_jenkins_connector()
        # Tìm build job tương ứng — convention: job name không có "deploy" prefix
        build_job = jenkins_deploy_job.replace("deploy-ci", "build").replace("deploy_ci", "build")
        status_data = connector.get_build_status(build_job, build_number)
        if status_data.get("status") != "SUCCESS":
            blocking_reasons.append(
                f"Jenkins build #{build_number} status={status_data.get('status', 'UNKNOWN')} — phải SUCCESS"
            )
    except Exception as exc:
        logger.warning("Cannot check Jenkins build status: %s", exc, extra={"trace_id": trace_id})
        # Graceful: nếu không check được thì không block (Jenkins có thể chưa cấu hình)

    if blocking_reasons:
        result = PromotionResult(
            approved=False, service=service, build_number=build_number,
            environment="ci", blocking_reasons=blocking_reasons,
            promoted_at=utc_now_iso(),
        )
        write_audit("k8s_promote_ci", {
            "trace_id": trace_id, "service": service, "build_number": build_number,
            "approved": False, "blocking_reasons": blocking_reasons,
        })
        return result

    # Trigger Jenkins deploy-ci
    jenkins_build_number: int | None = None
    try:
        connector = _get_jenkins_connector()
        jenkins_build_number = connector.trigger_job(
            jenkins_deploy_job,
            parameters={"SERVICE": service, "BUILD_NUMBER": str(build_number)},
        )
    except Exception as exc:
        logger.warning("Jenkins trigger failed: %s", exc, extra={"trace_id": trace_id})

    # Lưu DeploymentRecord
    record_id = uuid.uuid4().hex[:16]
    deployed_at = utc_now_iso()
    save_deployment_record(
        record_id=record_id,
        service=service,
        environment="ci",
        build_number=build_number,
        job_name=jenkins_deploy_job,
        status="running",
        deployed_at=deployed_at,
        deployed_by="system",
        build_url=f"{jenkins_deploy_job}/{jenkins_build_number}" if jenkins_build_number else "",
    )

    # Health check
    if ci_health_url:
        healthy = _health_check(ci_health_url)
        final_status = "success" if healthy else "failure"
        from app.catalog.database import update_source_state
        try:
            from app.catalog.database import save_deployment_record as _save
            save_deployment_record(
                record_id=uuid.uuid4().hex[:16],
                service=service, environment="ci", build_number=build_number,
                job_name=jenkins_deploy_job, status=final_status,
                deployed_at=utc_now_iso(), deployed_by="system",
            )
        except Exception:
            pass

    write_audit("k8s_promote_ci", {
        "trace_id": trace_id, "service": service, "build_number": build_number,
        "approved": True, "jenkins_build_number": jenkins_build_number,
    })

    logger.info("CI promotion approved service=%s build=%d", service, build_number,
                extra={"trace_id": trace_id})

    return PromotionResult(
        approved=True, service=service, build_number=build_number,
        environment="ci", jenkins_build_number=jenkins_build_number,
        promoted_at=deployed_at,
    )
