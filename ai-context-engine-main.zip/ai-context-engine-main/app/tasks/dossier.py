"""Task dossier persistence for planning and implementation handoff."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from app.core.config import ensure_directories, settings
from app.core.utils import safe_workspace_name, utc_now_iso
from app.internal.runtime_hook import emit_runtime_event
from app.tasks.brief import build_task_brief


DEFAULT_MARKDOWN_FILES = {
    "brief": "brief.md",
    "plan": "plan.md",
    "scope": "scope.md",
    "impact": "impact.md",
    "notes": "notes.md",
    "result": "result.md",
}


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _write_text(path: Path, content: str) -> None:
    path.write_text(content.rstrip() + "\n", encoding="utf-8")


def _write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _append_event(task_dir: Path, event_type: str, details: dict | None = None) -> None:
    event = {
        "event_type": event_type,
        "created_at": utc_now_iso(),
        "details": details or {},
    }
    timeline_path = task_dir / "timeline.jsonl"
    with timeline_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=False) + "\n")


def generate_task_id(task: str, created_at: datetime | None = None) -> str:
    moment = created_at or _now()
    timestamp = moment.strftime("%Y%m%d-%H%M%S")
    slug = safe_workspace_name(task)[:60] or "task"
    return f"task-{timestamp}-{slug}"


def create_task_directory(task_id: str, created_at: datetime | None = None) -> Path:
    ensure_directories()
    moment = created_at or _now()
    task_dir = settings.tasks_dir / moment.strftime("%Y") / moment.strftime("%Y-%m") / task_id
    task_dir.mkdir(parents=True, exist_ok=False)
    return task_dir


def _placeholder_content(title: str, prompt: str) -> str:
    return "\n".join(
        [
            f"# {title}",
            "",
            prompt,
            "",
        ]
    )


def _resolve_task_dir(task_id: str) -> Path:
    direct = settings.tasks_dir / task_id
    if direct.exists():
        return direct

    matches = list(settings.tasks_dir.glob(f"**/{task_id}"))
    if not matches:
        raise KeyError(f"Unknown task_id: {task_id}")
    return matches[0]


def _load_task_payload(task_dir: Path) -> dict:
    task_file = task_dir / "task.json"
    if not task_file.exists():
        raise KeyError(f"Task dossier is missing task.json: {task_dir}")
    return json.loads(task_file.read_text(encoding="utf-8"))


def _save_task_payload(task_dir: Path, payload: dict) -> None:
    payload["updated_at"] = utc_now_iso()
    _write_json(task_dir / "task.json", payload)


def _dossier_paths(task_dir: Path) -> dict[str, str]:
    paths = {"task": str(task_dir / "task.json"), "timeline": str(task_dir / "timeline.jsonl")}
    for key, filename in DEFAULT_MARKDOWN_FILES.items():
        paths[key] = str(task_dir / filename)
    return paths


def _context_status(brief_data: dict) -> str:
    return "enough" if brief_data.get("results") else "needs_more_context"


def _allocate_task_dir(task: str, created_at: datetime) -> tuple[str, Path]:
    task_id = generate_task_id(task, created_at=created_at)
    try:
        return task_id, create_task_directory(task_id, created_at=created_at)
    except FileExistsError:
        retry_id = f"{task_id}-{datetime.now().strftime('%f')}"
        return retry_id, create_task_directory(retry_id, created_at=created_at)


def create_task_dossier(task: str, collection_name: str, top_k: int = 5) -> dict:
    brief_data = build_task_brief(task, collection_name, top_k=top_k)
    created_at = _now()
    created_at_iso = utc_now_iso()
    task_id, task_dir = _allocate_task_dir(task, created_at)

    selected_source = brief_data["selected_source"]
    payload = {
        "task_id": task_id,
        "title": task,
        "request": task,
        "status": "started",
        "phase": "briefed",
        "collection": collection_name,
        "context_status": _context_status(brief_data),
        "selected_repo": {
            "source_id": selected_source["source_id"],
            "title": selected_source["title"],
            "local_path": selected_source.get("local_path", ""),
            "url": selected_source.get("url", ""),
        },
        "repo_candidates": brief_data.get("repo_candidates", []),
        "context_results": brief_data.get("results", []),
        "dossier_path": str(task_dir),
        "created_at": created_at_iso,
        "updated_at": created_at_iso,
        "files": _dossier_paths(task_dir),
    }

    _save_task_payload(task_dir, payload)
    _write_text(task_dir / DEFAULT_MARKDOWN_FILES["brief"], brief_data["brief"])
    _write_text(
        task_dir / DEFAULT_MARKDOWN_FILES["plan"],
        _placeholder_content("Plan", "Summarize the approach, assumptions, risks, and main steps."),
    )
    _write_text(
        task_dir / DEFAULT_MARKDOWN_FILES["scope"],
        _placeholder_content("Scope", "List planned files/modules to change, out-of-scope items, and dependencies."),
    )
    _write_text(
        task_dir / DEFAULT_MARKDOWN_FILES["impact"],
        _placeholder_content("Impact", "Assess impact on business flow, API, data, integration, testing, and operations."),
    )
    _write_text(
        task_dir / DEFAULT_MARKDOWN_FILES["notes"],
        _placeholder_content("Notes", "Capture important notes, business rules, constraints, and follow-up checks."),
    )
    _write_text(
        task_dir / DEFAULT_MARKDOWN_FILES["result"],
        _placeholder_content("Result", "Record implementation outcome, build/test status, and any remaining work."),
    )
    _append_event(
        task_dir,
        "task_started",
        {
            "collection": collection_name,
            "selected_source_id": selected_source["source_id"],
            "context_status": payload["context_status"],
        },
    )
    emit_runtime_event(task)
    return get_task_dossier(task_id)


def update_task_plan(
    task_id: str,
    *,
    plan: str | None = None,
    scope: str | None = None,
    impact: str | None = None,
    notes: str | None = None,
    status: str = "planned",
    phase: str = "planning",
) -> dict:
    task_dir = _resolve_task_dir(task_id)
    payload = _load_task_payload(task_dir)

    updates = {
        "plan": plan,
        "scope": scope,
        "impact": impact,
        "notes": notes,
    }
    for key, content in updates.items():
        if content is None:
            continue
        _write_text(task_dir / DEFAULT_MARKDOWN_FILES[key], content)

    payload["status"] = status
    payload["phase"] = phase
    _save_task_payload(task_dir, payload)
    _append_event(
        task_dir,
        "plan_updated",
        {
            "status": status,
            "phase": phase,
            "updated_sections": [key for key, content in updates.items() if content is not None],
        },
    )
    return get_task_dossier(task_id)


def update_task_result(
    task_id: str,
    *,
    result: str,
    status: str = "completed",
    phase: str = "completed",
) -> dict:
    task_dir = _resolve_task_dir(task_id)
    payload = _load_task_payload(task_dir)

    _write_text(task_dir / DEFAULT_MARKDOWN_FILES["result"], result)
    payload["status"] = status
    payload["phase"] = phase
    _save_task_payload(task_dir, payload)
    _append_event(
        task_dir,
        "result_updated",
        {
            "status": status,
            "phase": phase,
        },
    )
    return get_task_dossier(task_id)


def get_task_dossier(task_id: str) -> dict:
    task_dir = _resolve_task_dir(task_id)
    payload = _load_task_payload(task_dir)
    documents = {}
    for key, filename in DEFAULT_MARKDOWN_FILES.items():
        path = task_dir / filename
        documents[key] = path.read_text(encoding="utf-8") if path.exists() else ""

    timeline = []
    timeline_path = task_dir / "timeline.jsonl"
    if timeline_path.exists():
        timeline = [
            json.loads(line)
            for line in timeline_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]

    return {
        "task": payload,
        "documents": documents,
        "timeline": timeline,
    }
