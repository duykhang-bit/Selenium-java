"""Sinh Task Brief từ Jira ticket ID kết hợp context đa nguồn."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from app.catalog.database import list_connectors
from app.connectors.jira import JiraConnector
from app.connectors.jira_errors import JiraIssueNotFoundError, JiraNotFoundError
from app.core.config import settings
from app.core.utils import safe_workspace_name, utc_now_iso
from app.retrieval.search import search
from app.tasks.dossier import (
    _append_event,
    _load_task_payload,
    _resolve_task_dir,
    _save_task_payload,
    _write_json,
    _write_text,
    generate_task_id,
)
from app.tasks.jira_dossier_sync import link_dossier_to_jira

logger = logging.getLogger(__name__)


def _get_jira_connector() -> tuple[JiraConnector, dict]:
    """Lấy Jira connector đầu tiên từ catalog.db."""
    connectors = list_connectors(connector_type="jira")
    if not connectors:
        raise RuntimeError("Chưa có Jira connector nào được đăng ký. Chạy 'setup/jira' trước.")
    connector = connectors[0]
    return JiraConnector(base_url=connector["base_url"], token=connector["token"]), connector


def _extract_acceptance_criteria(description: str) -> str:
    """Trích xuất acceptance criteria từ description."""
    lines = description.splitlines()
    in_ac = False
    ac_lines: list[str] = []
    for line in lines:
        lower = line.lower()
        if any(kw in lower for kw in ("acceptance criteria", "tiêu chí nghiệm thu", "ac:")):
            in_ac = True
        elif in_ac and line.startswith("#"):
            break
        if in_ac:
            ac_lines.append(line)
    return "\n".join(ac_lines).strip() if ac_lines else ""


def build_brief_from_jira(
    issue_key: str,
    collection_name: str = "knowledge",
    top_k: int = 5,
) -> dict:
    """Sinh task brief đầy đủ từ Jira issue key.

    Pull issue trực tiếp từ Jira API (không chỉ từ ChromaDB) để đảm bảo dữ liệu mới nhất.
    Kết hợp Jira context + Confluence business context + GitLab technical context.

    Args:
        issue_key: Jira issue key, ví dụ "PROJ-123"
        collection_name: ChromaDB collection name
        top_k: số lượng kết quả search tối đa

    Returns:
        dict với keys: issue_key, task_id, jira_context, confluence_results,
                       git_results, brief

    Raises:
        JiraIssueNotFoundError: nếu issue_key không tồn tại trên Jira
    """
    issue_key = issue_key.upper().strip()
    jira, connector = _get_jira_connector()

    # Pull issue trực tiếp từ Jira API
    try:
        issue = jira.get_issue(issue_key)
    except JiraNotFoundError:
        raise JiraIssueNotFoundError(issue_key)

    fields = issue.get("fields", {})
    summary = fields.get("summary", "")
    description_raw = fields.get("description") or ""
    if isinstance(description_raw, dict):
        # ADF format
        description = _flatten_adf(description_raw)
    else:
        description = str(description_raw)

    issue_type = (fields.get("issuetype") or {}).get("name", "")
    status = (fields.get("status") or {}).get("name", "")
    priority = (fields.get("priority") or {}).get("name", "")
    assignee = (fields.get("assignee") or {}).get("displayName", "")
    story_points = fields.get("story_points") or fields.get("customfield_10016")
    project_key = (fields.get("project") or {}).get("key", "")

    # Sprint
    sprint_name = ""
    sprint_field = fields.get("customfield_10020") or fields.get("sprint")
    if isinstance(sprint_field, list) and sprint_field:
        last = sprint_field[-1]
        sprint_name = last.get("name", "") if isinstance(last, dict) else ""
    elif isinstance(sprint_field, dict):
        sprint_name = sprint_field.get("name", "")

    # Epic cha
    epic_key = fields.get("customfield_10014") or (fields.get("epic") or {}).get("key", "") or ""
    epic_summary = ""
    if epic_key:
        try:
            epic_issue = jira.get_issue(str(epic_key))
            epic_summary = epic_issue.get("fields", {}).get("summary", "")
        except Exception:
            pass

    acceptance_criteria = _extract_acceptance_criteria(description)

    jira_context = {
        "issue_key": issue_key,
        "summary": summary,
        "description": description[:2000],
        "issue_type": issue_type,
        "status": status,
        "priority": priority,
        "assignee": assignee,
        "story_points": story_points,
        "sprint_name": sprint_name,
        "epic_key": str(epic_key),
        "epic_summary": epic_summary,
        "project_key": project_key,
        "acceptance_criteria": acceptance_criteria,
    }

    # Vector search — Confluence business context
    search_query = f"{summary} {description[:300]}"
    confluence_results_raw = search(
        search_query,
        collection_name=collection_name,
        top_k=top_k,
        source_type="confluence_page",
    )
    confluence_results = [r.to_dict() for r in confluence_results_raw]

    # Vector search — GitLab technical context
    git_results_raw = search(
        search_query,
        collection_name=collection_name,
        top_k=top_k,
        source_type="git_repo",
    )
    git_results = [r.to_dict() for r in git_results_raw]

    # Sinh brief text
    brief = _compose_brief(jira_context, confluence_results, git_results)

    # Tạo hoặc cập nhật task dossier
    task_id = _upsert_dossier(issue_key, jira_context, brief, collection_name)

    return {
        "issue_key": issue_key,
        "task_id": task_id,
        "jira_context": jira_context,
        "confluence_results": confluence_results,
        "git_results": git_results,
        "brief": brief,
        "data_freshness": "live",
    }


def _compose_brief(jira_context: dict, confluence_results: list, git_results: list) -> str:
    """Tổng hợp brief text từ các nguồn context."""
    lines = [
        f"# Task Brief: [{jira_context['issue_key']}] {jira_context['summary']}",
        "",
        "## Jira Context",
        f"- Type: {jira_context['issue_type']} | Status: {jira_context['status']} | Priority: {jira_context['priority']}",
        f"- Sprint: {jira_context['sprint_name']} | Story Points: {jira_context['story_points']}",
        f"- Epic: {jira_context['epic_key']} — {jira_context['epic_summary']}",
        f"- Assignee: {jira_context['assignee']}",
        "",
        "## Description",
        jira_context["description"][:1000],
    ]

    if jira_context.get("acceptance_criteria"):
        lines += ["", "## Acceptance Criteria", jira_context["acceptance_criteria"]]

    if confluence_results:
        lines += ["", "## Business Context (Confluence)"]
        for item in confluence_results[:3]:
            title = item.get("metadata", {}).get("title", "")
            snippet = " ".join(item["content"].split())[:300]
            lines.append(f"- [{title}] score={item['score']:.3f} :: {snippet}")

    if git_results:
        lines += ["", "## Technical Context (GitLab)"]
        for item in git_results[:3]:
            source = item.get("metadata", {}).get("relative_source") or item.get("metadata", {}).get("source", "")
            snippet = " ".join(item["content"].split())[:300]
            lines.append(f"- [{source}] score={item['score']:.3f} :: {snippet}")

    lines += [
        "",
        "## Execution Guidance",
        "- Sync repo về latest trước khi implement: `python -m app.cli sync-source <source_id>`",
        "- Đọc file thật từ `data/workspaces/repos/...` trước khi sửa",
        "- Implement minimal & safe, viết unit test, chạy build/test",
        "- Tạo branch theo format: `features/{dev}-{ticket}-{key-work}`",
    ]

    return "\n".join(lines)


def _flatten_adf(adf: dict) -> str:
    """Trích xuất text thuần từ Atlassian Document Format."""
    parts: list[str] = []
    for node in adf.get("content", []):
        if node.get("type") == "text":
            parts.append(node.get("text", ""))
        elif "content" in node:
            parts.append(_flatten_adf(node))
    return " ".join(parts)


def _upsert_dossier(
    issue_key: str,
    jira_context: dict,
    brief: str,
    collection_name: str,
) -> str:
    """Tạo mới hoặc cập nhật task dossier cho issue_key.

    Returns:
        task_id
    """
    # Tìm dossier hiện có theo jira_issue_key
    existing_task_id = _find_existing_dossier(issue_key)

    if existing_task_id:
        # Cập nhật brief trong dossier hiện có
        task_dir = _resolve_task_dir(existing_task_id)
        payload = _load_task_payload(task_dir)
        payload["jira_context"] = jira_context
        _save_task_payload(task_dir, payload)
        _write_text(task_dir / "brief.md", brief)
        _append_event(task_dir, "jira_brief_updated", {"issue_key": issue_key})
        logger.info("Cập nhật brief cho dossier %s (issue %s)", existing_task_id, issue_key)
        return existing_task_id

    # Tạo dossier mới
    now = datetime.now(timezone.utc)
    task_id = generate_task_id(f"{issue_key} {jira_context['summary']}", created_at=now)
    task_dir = (
        settings.tasks_dir
        / now.strftime("%Y")
        / now.strftime("%Y-%m")
        / task_id
    )
    task_dir.mkdir(parents=True, exist_ok=True)

    payload = {
        "task_id": task_id,
        "title": f"[{issue_key}] {jira_context['summary']}",
        "request": jira_context["summary"],
        "status": "started",
        "phase": "briefed",
        "collection": collection_name,
        "jira_issue_key": issue_key,
        "jira_issue_keys": [issue_key],
        "jira_epic_key": jira_context.get("epic_key", ""),
        "jira_project_key": jira_context.get("project_key", ""),
        "jira_linked_at": utc_now_iso(),
        "jira_context": jira_context,
        "dossier_path": str(task_dir),
        "created_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
    }

    _write_json(task_dir / "task.json", payload)
    _write_text(task_dir / "brief.md", brief)

    for filename, placeholder in [
        ("plan.md", "# Plan\n\nMô tả hướng xử lý, giả định, rủi ro.\n"),
        ("scope.md", "# Scope\n\nFile/module dự kiến sửa.\n"),
        ("impact.md", "# Impact\n\nẢnh hưởng business, API, data, integration.\n"),
        ("notes.md", "# Notes\n\nLưu ý quan trọng.\n"),
        ("result.md", "# Result\n\nKết quả implement.\n"),
    ]:
        _write_text(task_dir / filename, placeholder)

    _append_event(task_dir, "task_started", {"issue_key": issue_key, "source": "jira_brief"})

    # Liên kết trong catalog.db
    from app.catalog.database import upsert_jira_dossier_link
    upsert_jira_dossier_link(task_id, issue_key)

    logger.info("Tạo dossier mới %s cho issue %s", task_id, issue_key)
    return task_id


def _find_existing_dossier(issue_key: str) -> str | None:
    """Tìm task_id của dossier đã liên kết với issue_key."""
    from app.catalog.database import get_connection
    with get_connection() as conn:
        row = conn.execute(
            "SELECT task_id FROM jira_dossier_links WHERE issue_key = ? ORDER BY linked_at DESC LIMIT 1",
            (issue_key.upper(),),
        ).fetchone()
        return row["task_id"] if row else None
