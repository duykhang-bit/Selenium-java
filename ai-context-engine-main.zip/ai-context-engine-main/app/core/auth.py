"""Optional API key authentication for REST API endpoints.

Reads the key from ``AI_CONTEXT_V2_API_KEY`` env var.
- If the env var is **not set or empty** → authentication is disabled (pass-through).
  Safe for local dev and internal-only deployments.
- If the env var **is set** → every request must include the header
  ``X-API-Key: <key>``. Requests with a missing or wrong key receive HTTP 401.

Usage in FastAPI:
    from app.core.auth import api_key_dependency
    app.include_router(router, dependencies=[Depends(api_key_dependency)])
"""

from __future__ import annotations

import os

from fastapi import Header, HTTPException, status


_API_KEY = os.getenv("AI_CONTEXT_V2_API_KEY", "").strip()


async def api_key_dependency(x_api_key: str | None = Header(default=None)) -> None:
    """FastAPI dependency that enforces X-API-Key when configured.

    No-op when ``AI_CONTEXT_V2_API_KEY`` is not set (open access for dev/internal).
    """
    if not _API_KEY:
        return  # Auth disabled — internal network mode

    if x_api_key != _API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing X-API-Key header.",
        )
