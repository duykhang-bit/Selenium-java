"""Symmetric encryption helpers for sensitive credentials (e.g. connector tokens).

Uses Fernet (AES-128-CBC + HMAC-SHA256) from the ``cryptography`` package.
The encryption key is read from the env var ``AI_CONTEXT_V2_SECRET_KEY``
(URL-safe base64-encoded 32-byte key).

If the env var is not set the module falls back to **no-op** (plaintext) mode
with a one-time warning — safe for local dev, not recommended for production.

Generate a key:
    python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
"""

from __future__ import annotations

import logging
import os

_log = logging.getLogger(__name__)

_FERNET_PREFIX = "fernet:"
_PLAINTEXT_PREFIX = "plain:"
_fernet_instance = None
_warn_once_emitted = False


def _get_fernet():
    """Lazily initialize and cache the Fernet instance."""
    global _fernet_instance, _warn_once_emitted  # noqa: PLW0603

    if _fernet_instance is not None:
        return _fernet_instance

    raw_key = os.getenv("AI_CONTEXT_V2_SECRET_KEY", "").strip()
    if not raw_key:
        if not _warn_once_emitted:
            _log.warning(
                "AI_CONTEXT_V2_SECRET_KEY is not set. "
                "Connector tokens will be stored as plaintext. "
                "Set this variable in production to enable encryption."
            )
            _warn_once_emitted = True
        return None

    try:
        from cryptography.fernet import Fernet
        _fernet_instance = Fernet(raw_key.encode())
        _log.info("Token encryption enabled (Fernet).")
        return _fernet_instance
    except Exception as exc:
        _log.error("Failed to initialize Fernet with AI_CONTEXT_V2_SECRET_KEY: %s", exc)
        return None


def encrypt_token(token: str) -> str:
    """Encrypt a plaintext token for storage.

    Returns a prefixed string:
    - ``fernet:<b64>`` when encryption is enabled.
    - ``plain:<token>`` when no key is configured (fallback).
    """
    if not token:
        return token

    fernet = _get_fernet()
    if fernet is None:
        return f"{_PLAINTEXT_PREFIX}{token}"

    encrypted = fernet.encrypt(token.encode("utf-8")).decode("ascii")
    return f"{_FERNET_PREFIX}{encrypted}"


def decrypt_token(stored: str) -> str:
    """Decrypt a stored token value.

    Handles:
    - ``fernet:<b64>`` → Fernet-decrypt
    - ``plain:<token>`` → strip prefix
    - bare string (legacy rows before encryption was added) → return as-is
    """
    if not stored:
        return stored

    if stored.startswith(_FERNET_PREFIX):
        payload = stored[len(_FERNET_PREFIX):]
        fernet = _get_fernet()
        if fernet is None:
            _log.error(
                "Encountered a Fernet-encrypted token but AI_CONTEXT_V2_SECRET_KEY is not set. "
                "Cannot decrypt — returning empty string."
            )
            return ""
        return fernet.decrypt(payload.encode("ascii")).decode("utf-8")

    if stored.startswith(_PLAINTEXT_PREFIX):
        return stored[len(_PLAINTEXT_PREFIX):]

    # Legacy plaintext (no prefix) — return as-is for backward compat.
    return stored
