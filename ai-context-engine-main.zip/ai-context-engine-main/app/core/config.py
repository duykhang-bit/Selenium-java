"""Configuration and path helpers for AI Context Engine V2."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv


PROJECT_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(PROJECT_ROOT / ".env")


@dataclass(slots=True)
class Settings:
    api_host: str = os.getenv("AI_CONTEXT_V2_API_HOST", "0.0.0.0")
    api_port: int = int(os.getenv("AI_CONTEXT_V2_API_PORT", "8100"))
    log_level: str = os.getenv("AI_CONTEXT_V2_LOG_LEVEL", "INFO")
    embedding_model: str = os.getenv(
        "AI_CONTEXT_V2_EMBEDDING_MODEL",
        "sentence-transformers/all-MiniLM-L6-v2",
    )
    chunk_size: int = int(os.getenv("AI_CONTEXT_V2_CHUNK_SIZE", "500"))
    chunk_overlap: int = int(os.getenv("AI_CONTEXT_V2_CHUNK_OVERLAP", "100"))
    repo_chunk_size: int = int(os.getenv("AI_CONTEXT_V2_REPO_CHUNK_SIZE", os.getenv("AI_CONTEXT_V2_CHUNK_SIZE", "500")))
    repo_chunk_overlap: int = int(
        os.getenv("AI_CONTEXT_V2_REPO_CHUNK_OVERLAP", os.getenv("AI_CONTEXT_V2_CHUNK_OVERLAP", "100"))
    )
    confluence_chunk_size: int = int(
        os.getenv("AI_CONTEXT_V2_CONFLUENCE_CHUNK_SIZE", os.getenv("AI_CONTEXT_V2_CHUNK_SIZE", "500"))
    )
    confluence_chunk_overlap: int = int(
        os.getenv("AI_CONTEXT_V2_CONFLUENCE_CHUNK_OVERLAP", os.getenv("AI_CONTEXT_V2_CHUNK_OVERLAP", "100"))
    )
    default_collection: str = os.getenv("AI_CONTEXT_V2_DEFAULT_COLLECTION", "knowledge")
    gitlab_base_url: str = os.getenv("AI_CONTEXT_V2_GITLAB_BASE_URL", "")
    gitlab_token: str = os.getenv("AI_CONTEXT_V2_GITLAB_TOKEN", "")
    gitlab_name: str = os.getenv("AI_CONTEXT_V2_GITLAB_NAME", "GitLab")
    gitlab_excluded_groups_raw: str = os.getenv("AI_CONTEXT_V2_GITLAB_EXCLUDED_GROUPS", "devops-common")
    confluence_base_url: str = os.getenv("AI_CONTEXT_V2_CONFLUENCE_BASE_URL", "")
    confluence_token: str = os.getenv("AI_CONTEXT_V2_CONFLUENCE_TOKEN", "")
    confluence_name: str = os.getenv("AI_CONTEXT_V2_CONFLUENCE_NAME", "Confluence")
    confluence_username: str = os.getenv("AI_CONTEXT_V2_CONFLUENCE_USERNAME", "")
    jenkins_base_url: str = os.getenv("AI_CONTEXT_V2_JENKINS_BASE_URL", "")
    jenkins_username: str = os.getenv("AI_CONTEXT_V2_JENKINS_USERNAME", "")
    jenkins_token: str = os.getenv("AI_CONTEXT_V2_JENKINS_TOKEN", "")
    jenkins_queue_poll_interval: int = int(os.getenv("AI_CONTEXT_V2_JENKINS_QUEUE_POLL_INTERVAL", "2"))
    jenkins_queue_poll_timeout: int = int(os.getenv("AI_CONTEXT_V2_JENKINS_QUEUE_POLL_TIMEOUT", "30"))
    # LLM settings (Code Generation Pipeline)
    llm_api_key: str = os.getenv("AI_CONTEXT_V2_LLM_API_KEY", "")
    llm_model: str = os.getenv("AI_CONTEXT_V2_LLM_MODEL", "gpt-4o-mini")
    llm_timeout: int = int(os.getenv("AI_CONTEXT_V2_LLM_TIMEOUT", "30"))
    # K8s / Deployment Intelligence settings
    k8s_ci_health_url: str = os.getenv("AI_CONTEXT_V2_K8S_CI_HEALTH_URL", "")
    k8s_uat_health_url: str = os.getenv("AI_CONTEXT_V2_K8S_UAT_HEALTH_URL", "")
    k8s_prod_soak_minutes: int = int(os.getenv("AI_CONTEXT_V2_K8S_PROD_SOAK_MINUTES", "30"))
    # Jira connector settings
    jira_base_url: str = os.getenv("AI_CONTEXT_V2_JIRA_BASE_URL", "")
    jira_token: str = os.getenv("AI_CONTEXT_V2_JIRA_TOKEN", "")
    jira_name: str = os.getenv("AI_CONTEXT_V2_JIRA_NAME", "Jira")
    jira_project_keys_raw: str = os.getenv("AI_CONTEXT_V2_JIRA_PROJECT_KEYS", "")
    jira_quality_threshold: float = float(os.getenv("AI_CONTEXT_V2_JIRA_QUALITY_THRESHOLD", "0.7"))
    jira_connect_timeout: float = float(os.getenv("AI_CONTEXT_V2_JIRA_CONNECT_TIMEOUT", "5.0"))
    jira_read_timeout: float = float(os.getenv("AI_CONTEXT_V2_JIRA_READ_TIMEOUT", "30.0"))
    jira_max_pool_size: int = int(os.getenv("AI_CONTEXT_V2_JIRA_MAX_POOL_SIZE", "10"))
    # RDE settings
    rde_llm_model: str = os.getenv("AI_CONTEXT_V2_RDE_LLM_MODEL", "gpt-4o-mini")
    rde_requirement_timeout_s: int = int(os.getenv("AI_CONTEXT_V2_RDE_REQUIREMENT_TIMEOUT_S", "30"))
    rde_design_timeout_s: int = int(os.getenv("AI_CONTEXT_V2_RDE_DESIGN_TIMEOUT_S", "60"))
    data_dir: Path = field(default_factory=lambda: PROJECT_ROOT / "data")

    @property
    def chroma_dir(self) -> Path:
        return self.data_dir / "chroma"

    @property
    def catalog_db_path(self) -> Path:
        return self.data_dir / "catalog.db"

    @property
    def logs_dir(self) -> Path:
        return self.data_dir / "logs"

    @property
    def workspaces_dir(self) -> Path:
        return self.data_dir / "workspaces"

    @property
    def repos_dir(self) -> Path:
        return self.workspaces_dir / "repos"

    @property
    def confluence_dir(self) -> Path:
        return self.workspaces_dir / "confluence"

    @property
    def reports_dir(self) -> Path:
        return self.data_dir / "reports"

    @property
    def tasks_dir(self) -> Path:
        return self.data_dir / "tasks"

    @property
    def gitlab_excluded_groups(self) -> list[str]:
        return [item.strip().strip("/").lower() for item in self.gitlab_excluded_groups_raw.split(",") if item.strip()]

    @property
    def jira_project_keys(self) -> list[str]:
        return [k.strip().upper() for k in self.jira_project_keys_raw.split(",") if k.strip()]

    @property
    def rde_audit_log_path(self) -> Path:
        return self.logs_dir / "rde_audit.jsonl"

    @property
    def confluence_write_queue_path(self) -> Path:
        return self.logs_dir / "confluence_write_queue.jsonl"


SUPPORTED_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx",
    ".md", ".txt", ".rst",
    ".json", ".yaml", ".yml", ".toml",
    ".html", ".css", ".scss",
    ".java", ".go", ".rs",
    ".sql", ".cs", ".csproj", ".sln",
    ".props", ".targets", ".config", ".sh",
}

REPO_SOURCE_ROOT_HINTS = ["src", "app", "apps", "services", "service", "host", "lib", "packages"]
REPO_DOC_ROOT_HINTS = ["docs", "doc", ".github"]
REPO_TEST_ROOT_HINTS = ["tests", "test", "__tests__"]
REPO_MANIFEST_HINTS = [
    "README.md",
    "README.txt",
    "package.json",
    "package-lock.json",
    "pnpm-lock.yaml",
    "yarn.lock",
    "pyproject.toml",
    "requirements.txt",
    "poetry.lock",
    "Pipfile",
    "go.mod",
    "Cargo.toml",
    "pom.xml",
    "build.gradle",
    "settings.gradle",
    "docker-compose.yml",
    "docker-compose.override.yml",
    "docker-compose.migrations.yml",
    "nuget.config",
    "common.props",
    "global.json",
]

DEFAULT_IGNORED_DIRS = {
    ".git", ".idea", ".vs", ".vscode", ".venv", "venv",
    "__pycache__", "node_modules", "dist", "build", "bin", "obj",
    "coverage", ".next", ".nuxt", ".cache", "logs", "Logs",
    "chroma", "data",
}


settings = Settings()


def ensure_directories() -> None:
    """Create all required runtime directories for the V2 app."""
    for path in (
        settings.data_dir,
        settings.chroma_dir,
        settings.logs_dir,
        settings.workspaces_dir,
        settings.repos_dir,
        settings.confluence_dir,
        settings.reports_dir,
        settings.tasks_dir,
    ):
        path.mkdir(parents=True, exist_ok=True)
