"""Shared helper functions."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def stable_json(value: dict | list | None) -> str:
    return json.dumps(value or {}, ensure_ascii=False, sort_keys=True)


def normalize_text(value: str | None) -> str:
    value = value or ""
    normalized = unicodedata.normalize("NFKD", value)
    normalized = "".join(ch for ch in normalized if not unicodedata.combining(ch))
    normalized = re.sub(r"[^a-zA-Z0-9]+", "-", normalized.lower())
    return normalized.strip("-")


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8", errors="ignore")).hexdigest()


def safe_workspace_name(value: str) -> str:
    return normalize_text(value) or "source"


def repo_workspace_path(base_dir: Path, path_with_namespace: str | None, fallback_name: str | None = None) -> Path:
    """Build a nested workspace path that preserves the repo namespace structure."""
    raw_path = (path_with_namespace or "").strip("/")
    if raw_path:
        parts = [safe_workspace_name(part) for part in raw_path.split("/") if part.strip()]
        if parts:
            return base_dir.joinpath(*parts)

    return base_dir / safe_workspace_name(fallback_name or "source")


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def git_url_to_path_with_namespace(repo_url: str) -> str:
    parsed = urlparse(repo_url)
    path = parsed.path.strip("/")
    if path.endswith(".git"):
        path = path[:-4]
    return path


# Private IP ranges bị block để chống SSRF (RFC 1918 + loopback + link-local)
_BLOCKED_IP_PREFIXES = (
    "10.", "172.16.", "172.17.", "172.18.", "172.19.", "172.20.", "172.21.",
    "172.22.", "172.23.", "172.24.", "172.25.", "172.26.", "172.27.", "172.28.",
    "172.29.", "172.30.", "172.31.", "192.168.", "127.", "169.254.", "0.",
)


def validate_jira_url(url: str) -> str:
    """Validate Jira base URL trước khi đăng ký connector.

    Kiểm tra:
    - Scheme phải là http hoặc https
    - Phải có hostname
    - Hostname không được là private/loopback IP (chống SSRF)

    Returns:
        URL đã được strip trailing slash.

    Raises:
        JiraConfigError: nếu URL không hợp lệ.
    """
    from app.connectors.jira_errors import JiraConfigError  # local import tránh circular

    if not url or not url.strip():
        raise JiraConfigError("Jira base_url không được để trống.")

    parsed = urlparse(url.strip())

    if parsed.scheme not in ("http", "https"):
        raise JiraConfigError(
            f"Jira base_url phải dùng scheme http hoặc https, nhận được: '{parsed.scheme}'"
        )

    hostname = parsed.hostname or ""
    if not hostname:
        raise JiraConfigError(f"Jira base_url thiếu hostname: '{url}'")

    if any(hostname.startswith(prefix) for prefix in _BLOCKED_IP_PREFIXES):
        raise JiraConfigError(
            f"Jira base_url không được trỏ đến private/loopback IP: '{hostname}'"
        )

    return url.strip().rstrip("/")
