"""Core utilities and configuration for AI Context Engine V2."""
