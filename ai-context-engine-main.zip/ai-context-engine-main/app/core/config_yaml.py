"""YAML config loader with ${VAR} environment variable interpolation.

Supports config.yaml as an alternative to .env for new deployments.
When config.yaml exists, its values take precedence over .env.
"""

import logging
import os
import re
from pathlib import Path

import yaml

_log = logging.getLogger(__name__)


def interpolate_env_vars(text: str) -> str:
    """Replace ${VAR_NAME} placeholders with environment variable values."""
    def _replace(match: re.Match) -> str:
        var_name = match.group(1)
        return os.environ.get(var_name, "")
    return re.sub(r"\$\{([^}]+)\}", _replace, text)


def load_yaml_config(config_path: Path) -> dict | None:
    """Load and parse config.yaml with env var interpolation.

    Returns None if file does not exist.
    Raises SystemExit with helpful message if YAML is malformed.
    """
    if not config_path.exists():
        return None

    raw = config_path.read_text(encoding="utf-8")
    interpolated = interpolate_env_vars(raw)
    try:
        return yaml.safe_load(interpolated)
    except yaml.YAMLError as e:
        _log.error("Invalid YAML in %s: %s", config_path, e)
        raise SystemExit(f"Error: config.yaml is malformed. Fix the YAML syntax and try again.\n{e}") from e


def apply_yaml_to_settings(yaml_config: dict, settings) -> None:
    """Override settings attributes from parsed YAML config."""
    connectors = yaml_config.get("connectors", {})

    gl = connectors.get("gitlab", {})
    if gl.get("base_url"):
        settings.gitlab_base_url = gl["base_url"]
    if gl.get("token"):
        settings.gitlab_token = gl["token"]
    if gl.get("name"):
        settings.gitlab_name = gl["name"]
    if gl.get("excluded_groups"):
        settings.gitlab_excluded_groups_raw = ",".join(gl["excluded_groups"])

    cf = connectors.get("confluence", {})
    if cf.get("base_url"):
        settings.confluence_base_url = cf["base_url"]
    if cf.get("token"):
        settings.confluence_token = cf["token"]
    if cf.get("username"):
        settings.confluence_username = cf["username"]
    if cf.get("name"):
        settings.confluence_name = cf["name"]

    chunking = yaml_config.get("chunking", {})
    repo_chunk = chunking.get("repo", {})
    if repo_chunk.get("size"):
        settings.repo_chunk_size = int(repo_chunk["size"])
    if repo_chunk.get("overlap"):
        settings.repo_chunk_overlap = int(repo_chunk["overlap"])

    cf_chunk = chunking.get("confluence", {})
    if cf_chunk.get("size"):
        settings.confluence_chunk_size = int(cf_chunk["size"])
    if cf_chunk.get("overlap"):
        settings.confluence_chunk_overlap = int(cf_chunk["overlap"])

    embedding = yaml_config.get("embedding", {})
    if embedding.get("model"):
        settings.embedding_model = embedding["model"]
