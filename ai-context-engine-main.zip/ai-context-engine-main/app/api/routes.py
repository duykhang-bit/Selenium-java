"""FastAPI routes for AI Context Engine V2."""

from __future__ import annotations

import asyncio
import dataclasses
import uuid

from fastapi import APIRouter, HTTPException, Query

from app.api.schemas import (
    ConnectorSetupRequest,
    JiraConnectorSetupRequest,
    JiraCreateFromIntentRequest,
    JiraLinkDossierRequest,
    JiraSyncRequest,
    ManualConfluenceSourceRequest,
    ManualGitSourceRequest,
    QGEAnalyzeRequest,
    QGEGenerateTestsRequest,
    RDEAnalyzeImpactRequest,
    RDECheckComplianceRequest,
    RDEGenerateDesignRequest,
    RDEGenerateRequirementsRequest,
    TaskBriefRequest,
    TaskPlanUpdateRequest,
    TaskResultUpdateRequest,
    TaskStartRequest,
    CGPDecomposeRequest,
    CGPGenerateRequest,
    CGPCommitMessageRequest,
    CGPRunPipelineRequest,
    K8sHelmValuesRequest,
    K8sPromoteCIRequest,
    K8sPromoteUATRequest,
    K8sProdGateRequest,
    K8sCorrelateRequest,
    ObsConfidenceRequest,
    ObsApprovalCreateRequest,
    ObsApproveRequest,
    ObsRejectRequest,
)
from app.catalog.database import list_connectors, list_sources
from app.connectors.jira_errors import (
    JiraConfigError,
    JiraIdempotencyError,
    JiraIssueNotFoundError,
    JiraQualityGateError,
    JiraRateLimitError,
    JiraConnectorError,
)
from app.ingest.store import list_collections
from app.retrieval.search import search
from app.sync.service import (
    create_jira_from_intent,
    discover_sources,
    initialize_runtime,
    link_dossier_to_jira,
    register_confluence_connector,
    register_gitlab_connector,
    register_jira_connector,
    register_manual_confluence_source,
    register_manual_git_source,
    sync_all_confluence_sources,
    sync_all_git_sources,
    sync_all_sources,
    sync_and_ingest_source,
    sync_jira_sources,
)
from app.tasks.brief import build_task_brief
from app.tasks.dossier import create_task_dossier, get_task_dossier, update_task_plan, update_task_result
from app.tasks.jira_brief import build_brief_from_jira
from app.tasks.requirement_generator import generate_requirements
from app.tasks.design_generator import generate_design
from app.tasks.impact_analyzer import analyze_impact
from app.tasks.compliance_checker import check_requirements, check_design
from app.tasks.domain_detector import detect_domains
from app.tasks.confluence_writer import write_document


router = APIRouter()


@router.get("/health")
async def health() -> dict:
    initialize_runtime()
    return {"status": "ok", "service": "ai-context-engine-v2"}


@router.post("/setup/gitlab")
async def setup_gitlab(request: ConnectorSetupRequest) -> dict:
    connector = register_gitlab_connector(request.base_url, request.token, name=request.name)
    return {"connector": connector}


@router.post("/setup/confluence")
async def setup_confluence(request: ConnectorSetupRequest) -> dict:
    connector = register_confluence_connector(
        request.base_url,
        request.token,
        name=request.name,
        username=request.username,
    )
    return {"connector": connector}


@router.get("/connectors")
async def get_connectors() -> dict:
    initialize_runtime()
    return {"connectors": list_connectors()}


@router.post("/sources/manual/git")
async def add_manual_git_source(request: ManualGitSourceRequest) -> dict:
    return {"source": register_manual_git_source(request.repo_url)}


@router.post("/sources/manual/confluence")
async def add_manual_confluence_source(request: ManualConfluenceSourceRequest) -> dict:
    return {"source": register_manual_confluence_source(request.page_url)}


@router.get("/sources")
async def get_sources(source_type: str | None = None) -> dict:
    initialize_runtime()
    return {"sources": list_sources(source_type=source_type)}


@router.post("/discover/all")
async def discover_all(
    cf_space_offset: int = Query(0, description="Skip this many Confluence spaces (batching)."),
    cf_max_spaces: int | None = Query(None, description="Max Confluence spaces to process this run."),
    cf_max_pages_per_space: int | None = Query(None, description="Max pages per Confluence space."),
    cf_max_pages_total: int | None = Query(None, description="Stop after this many Confluence pages."),
    cf_estimate_only: bool = Query(False, description="Probe only; skip GitLab discover and Confluence upserts."),
) -> dict:
    return await asyncio.to_thread(
        discover_sources,
        None,
        confluence_space_offset=cf_space_offset,
        confluence_max_spaces=cf_max_spaces,
        confluence_max_pages_per_space=cf_max_pages_per_space,
        confluence_max_pages_total=cf_max_pages_total,
        confluence_estimate_only=cf_estimate_only,
    )


@router.post("/discover/{connector_id}")
async def discover_for_connector(
    connector_id: int,
    cf_space_offset: int = Query(0),
    cf_max_spaces: int | None = Query(None),
    cf_max_pages_per_space: int | None = Query(None),
    cf_max_pages_total: int | None = Query(None),
    cf_estimate_only: bool = Query(False),
) -> dict:
    return await asyncio.to_thread(
        discover_sources,
        connector_id,
        confluence_space_offset=cf_space_offset,
        confluence_max_spaces=cf_max_spaces,
        confluence_max_pages_per_space=cf_max_pages_per_space,
        confluence_max_pages_total=cf_max_pages_total,
        confluence_estimate_only=cf_estimate_only,
    )


@router.post("/sync/all")
async def sync_all(
    collection: str = Query("knowledge", description="Target collection name"),
    include_confluence: bool = Query(
        True,
        description="If true, sync both Git repos and Confluence pages (default: all sources).",
    ),
) -> dict:
    try:
        results = await asyncio.to_thread(
            sync_all_sources,
            collection_name=collection,
            include_confluence=include_confluence,
        )
        return {"results": results}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc




@router.post("/sync/git/all")
async def sync_git_all(collection: str = Query("knowledge", description="Target collection name")) -> dict:
    try:
        results = await asyncio.to_thread(sync_all_git_sources, collection_name=collection)
        return {"results": results}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/sync/confluence/all")
async def sync_confluence_all(collection: str = Query("knowledge", description="Target collection name")) -> dict:
    try:
        results = await asyncio.to_thread(sync_all_confluence_sources, collection_name=collection)
        return {"results": results}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/sync/source/{source_id}")
async def sync_source(source_id: str, collection: str = Query("knowledge", description="Target collection name")) -> dict:
    try:
        return await asyncio.to_thread(sync_and_ingest_source, source_id, collection_name=collection)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/collections")
async def collections() -> dict:
    return {"collections": list_collections()}


@router.get("/search")
async def search_endpoint(
    q: str = Query(...),
    collection: str = Query("knowledge"),
    top_k: int = Query(5, ge=1, le=20),
    repo_id: str | None = Query(default=None),
    source_id: str | None = Query(default=None),
    source_type: str | None = Query(default=None),
) -> dict:
    results = search(
        q,
        collection_name=collection,
        top_k=top_k,
        repo_id=repo_id,
        source_id=source_id,
        source_type=source_type,
    )
    return {
        "query": q,
        "collection": collection,
        "filters": {
            "repo_id": repo_id,
            "source_id": source_id,
            "source_type": source_type,
        },
        "results": [result.to_dict() for result in results],
    }


@router.post("/tasks/brief")
async def task_brief(request: TaskBriefRequest) -> dict:
    try:
        return build_task_brief(request.task, request.collection, top_k=request.top_k)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/tasks/start")
async def task_start(request: TaskStartRequest) -> dict:
    try:
        return await asyncio.to_thread(create_task_dossier, request.task, request.collection, top_k=request.top_k)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/tasks/{task_id}/plan")
async def task_plan(task_id: str, request: TaskPlanUpdateRequest) -> dict:
    try:
        return update_task_plan(
            task_id,
            plan=request.plan,
            scope=request.scope,
            impact=request.impact,
            notes=request.notes,
            status=request.status,
            phase=request.phase,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/tasks/{task_id}/result")
async def task_result(task_id: str, request: TaskResultUpdateRequest) -> dict:
    try:
        return update_task_result(
            task_id,
            result=request.result,
            status=request.status,
            phase=request.phase,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/tasks/{task_id}")
async def task_get(task_id: str) -> dict:
    try:
        return get_task_dossier(task_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


# ---------------------------------------------------------------------------
# Jira Integration endpoints
# ---------------------------------------------------------------------------

@router.post("/setup/jira")
async def setup_jira(request: JiraConnectorSetupRequest) -> dict:
    """Đăng ký Jira Server/Data Center connector."""
    try:
        connector = register_jira_connector(request.base_url, request.token, name=request.name)
        # Ẩn token khỏi response
        connector = {k: v for k, v in connector.items() if k != "token"}
        return {"connector": connector}
    except JiraConfigError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except JiraConnectorError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/jira/sync")
async def jira_sync(request: JiraSyncRequest) -> dict:
    """Pull Jira issues vào ChromaDB (async, non-blocking)."""
    try:
        results = await asyncio.to_thread(
            sync_jira_sources,
            request.project_keys,
            request.collection,
        )
        return {"results": results}
    except JiraConnectorError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/jira/create-from-intent")
async def jira_create_from_intent(request: JiraCreateFromIntentRequest) -> dict:
    """Tạo Epic/Story/Sub-task từ intent text qua AI Quality Gate."""
    try:
        result = await asyncio.to_thread(
            create_jira_from_intent,
            request.intent,
            request.project_key,
        )
        return result
    except JiraQualityGateError as exc:
        raise HTTPException(
            status_code=422,
            detail={"message": "Quality gate failed", "confidence_score": exc.confidence_score, "issues": exc.issues},
        ) from exc
    except JiraIdempotencyError as exc:
        raise HTTPException(
            status_code=409,
            detail={"message": "Ticket đã tồn tại", "existing_ref": exc.existing_ref},
        ) from exc
    except JiraConnectorError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/jira/brief/{issue_key}")
async def jira_brief(
    issue_key: str,
    collection: str = Query("knowledge", description="ChromaDB collection name"),
    top_k: int = Query(5, ge=1, le=20),
) -> dict:
    """Sinh task brief đầy đủ từ Jira ticket ID."""
    try:
        return await asyncio.to_thread(build_brief_from_jira, issue_key, collection, top_k)
    except JiraIssueNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except JiraConnectorError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/jira/link-dossier")
async def jira_link_dossier(request: JiraLinkDossierRequest) -> dict:
    """Liên kết task dossier với Jira issue key."""
    try:
        return await asyncio.to_thread(link_dossier_to_jira, request.task_id, request.issue_key)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


# ---------------------------------------------------------------------------
# RDE endpoints
# ---------------------------------------------------------------------------

@router.post("/rde/generate-requirements")
async def rde_generate_requirements(request: RDEGenerateRequirementsRequest) -> dict:
    """Sinh tài liệu requirements từ intent text."""
    try:
        result = await asyncio.to_thread(
            generate_requirements,
            request.intent,
            request.collection,
            request.top_k,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    compliance_report = dataclasses.asdict(result.compliance_report)

    if not result.compliance_report.passed:
        raise HTTPException(
            status_code=422,
            detail={
                "message": "Compliance check failed",
                "violations": [dataclasses.asdict(v) for v in result.compliance_report.violations],
            },
        )

    confluence_url: str | None = None
    if request.publish_to_confluence and request.confluence_space_key:
        try:
            title = result.document.splitlines()[0].lstrip("# ").strip()
            write_result = await asyncio.to_thread(
                write_document,
                title,
                result.document,
                request.confluence_space_key,
                request.confluence_parent_page_id,
            )
            confluence_url = write_result.page_url
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Confluence publish failed: {exc}") from exc

    task_id = uuid.uuid4().hex[:16]
    return {
        "task_id": task_id,
        "requirements_doc": result.document,
        "domains": result.domains,
        "compliance_report": compliance_report,
        "confluence_url": confluence_url,
        "trace_id": result.trace_id,
    }


@router.post("/rde/generate-design")
async def rde_generate_design(request: RDEGenerateDesignRequest) -> dict:
    """Sinh tài liệu thiết kế từ requirements document."""
    try:
        result = await asyncio.to_thread(
            generate_design,
            request.requirements_doc,
            request.collection,
            request.top_k,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    confluence_url: str | None = None
    if request.publish_to_confluence and request.confluence_space_key:
        try:
            title = result.document.splitlines()[0].lstrip("# ").strip()
            write_result = await asyncio.to_thread(
                write_document,
                title,
                result.document,
                request.confluence_space_key,
                request.confluence_parent_page_id,
            )
            confluence_url = write_result.page_url
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Confluence publish failed: {exc}") from exc

    task_id = uuid.uuid4().hex[:16]
    return {
        "task_id": task_id,
        "design_doc": result.document,
        "domains": result.domains,
        "compliance_report": dataclasses.asdict(result.compliance_report),
        "impact_report": dataclasses.asdict(result.impact_report),
        "confluence_url": confluence_url,
        "trace_id": result.trace_id,
    }


@router.post("/rde/analyze-impact")
async def rde_analyze_impact(request: RDEAnalyzeImpactRequest) -> dict:
    """Phân tích impact của requirements mới lên codebase."""
    try:
        result = await asyncio.to_thread(
            analyze_impact,
            request.requirements_doc,
            request.collection,
            request.top_k,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return {
        "impact_report": dataclasses.asdict(result),
        "trace_id": result.trace_id,
    }


@router.post("/rde/check-compliance")
async def rde_check_compliance(request: RDECheckComplianceRequest) -> dict:
    """Kiểm tra compliance của document theo domain."""
    trace_id = uuid.uuid4().hex[:16]

    domains = request.domains
    if domains is None:
        detection = await asyncio.to_thread(detect_domains, request.document)
        domains = detection.domains

    doc_type = request.document_type.lower()
    if doc_type not in ("requirements", "design"):
        raise HTTPException(
            status_code=422,
            detail="document_type phải là 'requirements' hoặc 'design'",
        )

    try:
        if doc_type == "requirements":
            report = await asyncio.to_thread(check_requirements, request.document, domains)
        else:
            report = await asyncio.to_thread(check_design, request.document, domains)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return {
        "compliance_report": dataclasses.asdict(report),
        "trace_id": trace_id,
    }


# ---------------------------------------------------------------------------
# QGE endpoints
# ---------------------------------------------------------------------------

@router.post("/qge/analyze")
async def qge_analyze(request: QGEAnalyzeRequest) -> dict:
    """Chạy tất cả quality gate trên code diff."""
    from app.tasks.quality_gate.gate_runner import run_all_gates
    import dataclasses as dc

    try:
        report = await asyncio.to_thread(
            run_all_gates,
            request.diff,
            request.collection,
            request.enabled_gates,
        )
        report_dict = {
            "overall": report.overall,
            "total_critical": report.total_critical,
            "total_high": report.total_high,
            "total_medium": report.total_medium,
            "total_low": report.total_low,
            "risk_score": report.risk_score,
            "generated_test_code": report.generated_test_code,
            "analyzed_at": report.analyzed_at,
            "trace_id": report.trace_id,
            "gate_reports": [
                {
                    "gate": r.gate,
                    "passed": r.passed,
                    "error": r.error,
                    "duration_ms": r.duration_ms,
                    "findings": [dc.asdict(f) for f in r.findings],
                }
                for r in report.gate_reports
            ],
        }
        if report.overall == "FAIL":
            raise HTTPException(status_code=422, detail=report_dict)
        return report_dict
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/qge/gates")
async def qge_list_gates() -> dict:
    """Trả về danh sách gate và trạng thái."""
    from app.tasks.quality_gate.gate_runner import _ALL_GATES
    return {
        "gates": [
            {"name": name, "enabled": True, "description": fn.__doc__ or ""}
            for name, fn in _ALL_GATES.items()
        ]
    }


@router.post("/qge/generate-tests")
async def qge_generate_tests(request: QGEGenerateTestsRequest) -> dict:
    """Sinh pytest skeleton cho code mới trong diff."""
    from app.tasks.quality_gate.diff_parser import parse_diff
    from app.tasks.quality_gate.test_generator import generate_tests

    try:
        parsed = parse_diff(request.diff)
        test_code = await asyncio.to_thread(generate_tests, parsed)
        return {"generated_test_code": test_code}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


# ---------------------------------------------------------------------------
# Jenkins endpoints
# ---------------------------------------------------------------------------

@router.post("/jenkins/trigger")
async def jenkins_trigger(request: "JenkinsTriggerRequest") -> dict:
    from app.api.schemas import JenkinsTriggerRequest
    from app.tasks.jenkins.trigger import trigger_pipeline
    from app.connectors.jenkins import JenkinsConnectionError, JenkinsJobNotFoundError
    import dataclasses
    try:
        result = await asyncio.to_thread(
            trigger_pipeline, request.job_name, request.parameters, request.triggered_by
        )
        return dataclasses.asdict(result)
    except JenkinsJobNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (JenkinsConnectionError, ValueError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@router.get("/jenkins/builds/{job_name}/{build_number}")
async def jenkins_build_status(job_name: str, build_number: int) -> dict:
    from app.connectors.jenkins import JenkinsConnector, JenkinsConnectionError, JenkinsJobNotFoundError
    from app.tasks.jenkins.log_analyzer import analyze_log
    from app.core.config import settings
    import dataclasses
    if not settings.jenkins_base_url:
        raise HTTPException(status_code=503, detail="Jenkins not configured")
    connector = JenkinsConnector(settings.jenkins_base_url, settings.jenkins_username, settings.jenkins_token)
    try:
        status = connector.get_build_status(job_name, build_number)
        analysis = None
        if status["status"] == "FAILURE":
            log = connector.get_build_log(job_name, build_number)
            analysis = dataclasses.asdict(analyze_log(log))
        return {"status": status, "analysis": analysis}
    except JenkinsJobNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except JenkinsConnectionError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@router.post("/jenkins/quality-gate")
async def jenkins_quality_gate(request: "JenkinsQualityGateRequest") -> dict:
    from app.api.schemas import JenkinsQualityGateRequest
    from app.tasks.quality_gate.gate_runner import run_all_gates
    import dataclasses as dc
    try:
        report = await asyncio.to_thread(run_all_gates, request.diff)
        report_dict = {
            "overall": report.overall,
            "total_critical": report.total_critical,
            "total_high": report.total_high,
            "findings": [dc.asdict(f) for f in report.all_findings],
        }
        if report.overall == "FAIL":
            raise HTTPException(status_code=422, detail=report_dict)
        return report_dict
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/jenkins/deployments", status_code=201)
async def jenkins_record_deploy(request: "JenkinsRecordDeployRequest") -> dict:
    from app.api.schemas import JenkinsRecordDeployRequest
    from app.tasks.jenkins.tracker import record_deployment
    import dataclasses
    rec = record_deployment(
        service=request.service, environment=request.environment,
        build_number=request.build_number, job_name=request.job_name,
        status=request.status, deployed_by=request.deployed_by, build_url=request.build_url,
    )
    return dataclasses.asdict(rec)


@router.get("/jenkins/deployments")
async def jenkins_list_deployments(
    service: str | None = Query(default=None),
    environment: str | None = Query(default=None),
    limit: int = Query(default=20, ge=1, le=100),
) -> dict:
    from app.tasks.jenkins.tracker import get_deployments
    import dataclasses
    records = get_deployments(service=service, environment=environment, limit=limit)
    return {"deployments": [dataclasses.asdict(r) for r in records]}


# ---------------------------------------------------------------------------
# CGP endpoints
# ---------------------------------------------------------------------------
# CGP endpoints
# ---------------------------------------------------------------------------

@router.post("/cgp/decompose")
async def cgp_decompose(request: CGPDecomposeRequest) -> dict:
    """Phân tích design doc → danh sách coding tasks."""
    from app.tasks.code_gen.decomposer import decompose
    import dataclasses
    tasks = await asyncio.to_thread(decompose, request.design_doc, request.collection)
    return {"tasks": [dataclasses.asdict(t) for t in tasks]}


@router.post("/cgp/generate")
async def cgp_generate(request: CGPGenerateRequest) -> dict:
    """Sinh code cho một coding task."""
    from app.tasks.code_gen.models import CodingTask
    from app.tasks.code_gen.generator import generate
    import dataclasses
    task = CodingTask(**request.task)
    result = await asyncio.to_thread(generate, task, request.collection, request.existing_content)
    return dataclasses.asdict(result)


@router.post("/cgp/commit-message")
async def cgp_commit_message(request: CGPCommitMessageRequest) -> dict:
    """Sinh conventional commit message từ diff."""
    from app.tasks.code_gen.commit_message import generate_message
    msg = generate_message(request.diff, request.task_description)
    return {"message": msg}


@router.post("/cgp/run-pipeline")
async def cgp_run_pipeline(request: CGPRunPipelineRequest) -> dict:
    """Chạy toàn bộ pipeline: decompose → generate → commit → MR."""
    from app.tasks.code_gen.pipeline import run_pipeline
    from app.tasks.code_gen.models import BranchAlreadyExistsError
    import dataclasses
    try:
        result = await asyncio.to_thread(
            run_pipeline,
            request.design_doc, request.source_id, request.branch_name,
            request.collection, request.from_branch,
        )
        return {
            "tasks": [dataclasses.asdict(t) for t in result.tasks],
            "generated_files": [dataclasses.asdict(f) for f in result.generated_files],
            "mr_result": dataclasses.asdict(result.mr_result) if result.mr_result else None,
            "duration_ms": result.duration_ms,
            "trace_id": result.trace_id,
            "errors": result.errors,
        }
    except BranchAlreadyExistsError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


# ---------------------------------------------------------------------------
# K8s endpoints
# ---------------------------------------------------------------------------

@router.post("/k8s/helm-values")
async def k8s_helm_values(request: K8sHelmValuesRequest) -> dict:
    """Sinh Helm values.yaml từ service metadata."""
    from app.tasks.k8s.helm_generator import generate_helm_values
    import dataclasses
    result = generate_helm_values(
        service_name=request.service_name,
        image_repository=request.image_repository,
        image_tag=request.image_tag,
        port=request.port,
        environment=request.environment,
        replicas=request.replicas,
        ingress_host=request.ingress_host,
        env_vars=request.env_vars,
        hpa_enabled=request.hpa_enabled,
        health_path=request.health_path,
    )
    return dataclasses.asdict(result)


@router.post("/k8s/promote-ci")
async def k8s_promote_ci(request: K8sPromoteCIRequest) -> dict:
    """Kiểm tra build pass và trigger Jenkins deploy-ci."""
    from app.tasks.k8s.ci_promoter import promote_to_ci
    import dataclasses
    result = await asyncio.to_thread(
        promote_to_ci, request.service, request.build_number,
        request.jenkins_deploy_job, request.ci_health_url,
    )
    return dataclasses.asdict(result)


@router.post("/k8s/promote-uat")
async def k8s_promote_uat(request: K8sPromoteUATRequest) -> dict:
    """Kiểm tra CI success và trigger Jenkins deploy-uat."""
    from app.tasks.k8s.uat_promoter import promote_to_uat
    import dataclasses
    result = await asyncio.to_thread(
        promote_to_uat, request.service, request.build_number,
        request.jenkins_deploy_job, request.uat_health_url,
    )
    return dataclasses.asdict(result)


@router.post("/k8s/prod-gate")
async def k8s_prod_gate(request: K8sProdGateRequest) -> dict:
    """Sinh PROD promotion checklist."""
    from app.tasks.k8s.prod_gate import check_prod_gate
    import dataclasses
    result = await asyncio.to_thread(
        check_prod_gate, request.service, request.build_number,
        request.jenkins_deploy_job, request.soak_minutes,
    )
    return dataclasses.asdict(result)


@router.post("/k8s/correlate-incident")
async def k8s_correlate_incident(request: K8sCorrelateRequest) -> dict:
    """Correlate incident với deployment gần nhất."""
    from app.tasks.k8s.incident_correlator import correlate_incident
    import dataclasses
    result = await asyncio.to_thread(
        correlate_incident, request.service, request.incident_time, request.collection,
    )
    return dataclasses.asdict(result)


# ---------------------------------------------------------------------------
# Observability endpoints
# ---------------------------------------------------------------------------

@router.get("/obs/audit-logs")
async def obs_audit_logs(
    event_type: list[str] | None = Query(default=None),
    since: str | None = Query(default=None),
    until: str | None = Query(default=None),
    trace_id: str | None = Query(default=None),
    service: str | None = Query(default=None),
    limit: int = Query(default=100, ge=1, le=1000),
    format: str = Query(default="json"),
) -> dict:
    """Query unified audit logs từ tất cả modules."""
    from app.tasks.observability.audit_query import query_audit_logs, export_audit_logs
    import dataclasses
    events = await asyncio.to_thread(
        query_audit_logs, event_type, since, until, trace_id, service, limit
    )
    if format == "csv":
        return {"content": export_audit_logs(events, "csv"), "format": "csv", "total": len(events)}
    return {"events": [dataclasses.asdict(e) for e in events], "total": len(events)}


@router.post("/obs/confidence")
async def obs_confidence(request: ObsConfidenceRequest) -> dict:
    """Tính confidence score cho AI output."""
    from app.tasks.observability.confidence import score_confidence
    import dataclasses
    result = await asyncio.to_thread(
        score_confidence, request.output_type, request.output_data, request.threshold
    )
    return dataclasses.asdict(result)


@router.post("/obs/approvals", status_code=201)
async def obs_create_approval(request: ObsApprovalCreateRequest) -> dict:
    """Tạo approval request."""
    from app.tasks.observability.hitl_gate import request_approval
    rid = await asyncio.to_thread(
        request_approval, request.action_type, request.description,
        request.payload, request.requested_by, request.expires_hours,
    )
    return {"request_id": rid}


@router.get("/obs/approvals")
async def obs_list_approvals(action_type: str | None = Query(default=None)) -> dict:
    """List pending approval requests."""
    from app.tasks.observability.hitl_gate import list_pending
    import dataclasses
    requests = await asyncio.to_thread(list_pending, action_type)
    return {"approvals": [dataclasses.asdict(r) for r in requests], "total": len(requests)}


@router.get("/obs/approvals/{request_id}")
async def obs_get_approval(request_id: str) -> dict:
    """Lấy approval request theo ID."""
    from app.tasks.observability.hitl_gate import get_request
    import dataclasses
    req = await asyncio.to_thread(get_request, request_id)
    if not req:
        raise HTTPException(status_code=404, detail=f"Approval request {request_id} not found")
    return dataclasses.asdict(req)


@router.post("/obs/approvals/{request_id}/approve")
async def obs_approve(request_id: str, request: ObsApproveRequest) -> dict:
    """Approve một request."""
    from app.tasks.observability.hitl_gate import approve
    import dataclasses
    try:
        result = await asyncio.to_thread(approve, request_id, request.approved_by, request.comment)
        return dataclasses.asdict(result)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post("/obs/approvals/{request_id}/reject")
async def obs_reject(request_id: str, request: ObsRejectRequest) -> dict:
    """Reject một request."""
    from app.tasks.observability.hitl_gate import reject
    import dataclasses
    try:
        result = await asyncio.to_thread(reject, request_id, request.rejected_by, request.comment)
        return dataclasses.asdict(result)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
