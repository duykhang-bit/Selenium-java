"""Pydantic schemas for the V2 API."""

from __future__ import annotations

from pydantic import BaseModel, Field


class ConnectorSetupRequest(BaseModel):
    base_url: str = Field(..., description="Base domain URL")
    token: str = Field(..., description="Access token")
    name: str | None = Field(default=None, description="Optional display name")
    username: str = Field(default="", description="Optional username for systems that still need it")


class ManualGitSourceRequest(BaseModel):
    repo_url: str


class ManualConfluenceSourceRequest(BaseModel):
    page_url: str


class TaskBriefRequest(BaseModel):
    task: str
    collection: str = "knowledge"
    top_k: int = 5


class TaskStartRequest(BaseModel):
    task: str
    collection: str = "knowledge"
    top_k: int = 5


class TaskPlanUpdateRequest(BaseModel):
    plan: str | None = None
    scope: str | None = None
    impact: str | None = None
    notes: str | None = None
    status: str = "planned"
    phase: str = "planning"


class TaskResultUpdateRequest(BaseModel):
    result: str
    status: str = "completed"
    phase: str = "completed"


# ---------------------------------------------------------------------------
# Jira Integration schemas
# ---------------------------------------------------------------------------

class JiraConnectorSetupRequest(BaseModel):
    base_url: str = Field(..., description="Jira Server/Data Center base URL (https://...)")
    token: str = Field(..., description="Personal Access Token (PAT)")
    name: str | None = Field(default=None, description="Tên hiển thị cho connector")


class JiraSyncRequest(BaseModel):
    project_keys: list[str] = Field(..., description="Danh sách Jira project key, ví dụ ['PROJ', 'OMS']")
    collection: str = Field(default="knowledge", description="ChromaDB collection name")


class JiraCreateFromIntentRequest(BaseModel):
    intent: str = Field(..., description="Mô tả ý tưởng/yêu cầu bằng ngôn ngữ tự nhiên")
    project_key: str = Field(..., description="Jira project key, ví dụ 'PROJ'")
    collection: str = Field(default="knowledge")


class JiraLinkDossierRequest(BaseModel):
    task_id: str = Field(..., description="Task dossier ID")
    issue_key: str = Field(..., description="Jira issue key, ví dụ 'PROJ-123'")


# ---------------------------------------------------------------------------
# RDE schemas
# ---------------------------------------------------------------------------

class RDEGenerateRequirementsRequest(BaseModel):
    intent: str = Field(..., max_length=10000, description="Mô tả yêu cầu nghiệp vụ")
    collection: str = Field(default="knowledge", description="ChromaDB collection name")
    top_k: int = Field(default=10, ge=1, le=50)
    publish_to_confluence: bool = Field(default=False)
    confluence_space_key: str | None = Field(default=None)
    confluence_parent_page_id: str | None = Field(default=None)


class RDEGenerateRequirementsResponse(BaseModel):
    task_id: str
    requirements_doc: str
    domains: list[str]
    compliance_report: dict
    confluence_url: str | None
    trace_id: str


class RDEGenerateDesignRequest(BaseModel):
    requirements_doc: str = Field(..., description="Nội dung requirements document")
    collection: str = Field(default="knowledge")
    top_k: int = Field(default=15, ge=1, le=50)
    publish_to_confluence: bool = Field(default=False)
    confluence_space_key: str | None = Field(default=None)
    confluence_parent_page_id: str | None = Field(default=None)


class RDEGenerateDesignResponse(BaseModel):
    task_id: str
    design_doc: str
    domains: list[str]
    compliance_report: dict
    impact_report: dict
    confluence_url: str | None
    trace_id: str


class RDEAnalyzeImpactRequest(BaseModel):
    requirements_doc: str = Field(..., description="Nội dung requirements document")
    collection: str = Field(default="knowledge")
    top_k: int = Field(default=10, ge=1, le=50)


class RDEAnalyzeImpactResponse(BaseModel):
    impact_report: dict
    trace_id: str


class RDECheckComplianceRequest(BaseModel):
    document: str = Field(..., description="Nội dung document cần kiểm tra")
    document_type: str = Field(..., description="'requirements' hoặc 'design'")
    domains: list[str] | None = Field(default=None, description="None = auto-detect")


class RDECheckComplianceResponse(BaseModel):
    compliance_report: dict
    trace_id: str


# ---------------------------------------------------------------------------
# QGE schemas
# ---------------------------------------------------------------------------

class QGEAnalyzeRequest(BaseModel):
    diff: str = Field(..., description="Unified diff text (output của git diff)")
    collection: str = Field(default="knowledge", description="ChromaDB collection name")
    enabled_gates: list[str] | None = Field(default=None, description="None = tất cả gate")
    source_id: str | None = Field(default=None, description="GitLab source_id để lấy context")


class QGEGenerateTestsRequest(BaseModel):
    diff: str = Field(..., description="Unified diff text")


# ---------------------------------------------------------------------------
# Jenkins schemas
# ---------------------------------------------------------------------------

class JenkinsTriggerRequest(BaseModel):
    job_name: str = Field(..., description="Tên Jenkins job")
    parameters: dict | None = Field(default=None, description="Build parameters")
    triggered_by: str = Field(default="system")


class JenkinsQualityGateRequest(BaseModel):
    source_id: str = Field(..., description="GitLab source_id")
    diff: str = Field(..., description="Unified diff text")
    job_name: str = Field(default="")
    build_number: int = Field(default=0)


class JenkinsRecordDeployRequest(BaseModel):
    service: str
    environment: str
    build_number: int
    job_name: str
    status: str
    deployed_by: str = "system"
    build_url: str = ""


# ---------------------------------------------------------------------------
# CGP schemas
# ---------------------------------------------------------------------------

class CGPDecomposeRequest(BaseModel):
    design_doc: str = Field(..., description="Nội dung design document")
    collection: str = Field(default="knowledge")
    source_id: str = Field(default="", description="GitLab source_id để gợi ý target_file")


class CGPGenerateRequest(BaseModel):
    task: dict = Field(..., description="CodingTask dạng dict")
    collection: str = Field(default="knowledge")
    existing_content: str | None = Field(default=None)


class CGPCommitMessageRequest(BaseModel):
    diff: str = Field(..., description="Unified diff text")
    task_description: str | None = Field(default=None)


class CGPRunPipelineRequest(BaseModel):
    design_doc: str = Field(..., description="Nội dung design document")
    source_id: str = Field(..., description="GitLab source_id")
    branch_name: str = Field(..., description="Tên branch mới")
    collection: str = Field(default="knowledge")
    from_branch: str | None = Field(default=None)


# ---------------------------------------------------------------------------
# K8s schemas
# ---------------------------------------------------------------------------

class K8sHelmValuesRequest(BaseModel):
    service_name: str
    image_repository: str
    image_tag: str
    port: int
    environment: str = "uat"
    replicas: int = 1
    ingress_host: str | None = None
    env_vars: dict | None = None
    hpa_enabled: bool = False
    health_path: str = "/health"


class K8sPromoteCIRequest(BaseModel):
    service: str
    build_number: int
    jenkins_deploy_job: str
    ci_health_url: str | None = None


class K8sPromoteUATRequest(BaseModel):
    service: str
    build_number: int
    jenkins_deploy_job: str
    uat_health_url: str | None = None


class K8sProdGateRequest(BaseModel):
    service: str
    build_number: int
    jenkins_deploy_job: str = ""
    soak_minutes: int | None = None


class K8sCorrelateRequest(BaseModel):
    service: str
    incident_time: str = Field(..., description="ISO 8601 timestamp")
    collection: str = "knowledge"


# ---------------------------------------------------------------------------
# Observability schemas
# ---------------------------------------------------------------------------

class ObsConfidenceRequest(BaseModel):
    output_type: str = Field(..., description="requirements_doc | design_doc | generated_code | commit_message | helm_values")
    output_data: str | dict = Field(..., description="Nội dung output cần score")
    threshold: float = Field(default=0.6, ge=0.0, le=1.0)


class ObsApprovalCreateRequest(BaseModel):
    action_type: str = Field(..., description="merge_to_main | deploy_prod | create_jira_epic | publish_confluence")
    description: str
    payload: dict = Field(default_factory=dict)
    requested_by: str = "system"
    expires_hours: int = 24


class ObsApproveRequest(BaseModel):
    approved_by: str
    comment: str = ""


class ObsRejectRequest(BaseModel):
    rejected_by: str
    comment: str = ""
