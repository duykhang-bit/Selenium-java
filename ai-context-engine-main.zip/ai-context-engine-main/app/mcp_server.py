"""MCP Server for AI Context Engine.

Exposes Confluence + GitLab context to any MCP-compatible AI coding tool.
Runs on port 3000 via streamable-http transport, separate from the REST API (port 8100).
"""

from pathlib import Path

from mcp.server.fastmcp import FastMCP

from app.retrieval import search as search_mod
from app.catalog import database as db
from app.core.config import settings
from app.core.logging import get_logger
from app.ingest.pipeline import html_to_text, detect_repo_layout
from app.tasks.brief import build_task_brief
from app.sync import service

logger = get_logger(__name__)

mcp = FastMCP(
    "AI Context Engine",
    instructions="Enterprise context from Confluence + GitLab for AI coding agents",
    host="0.0.0.0",
    port=3000,
)


@mcp.tool()
def search_context(
    query: str,
    source_type: str | None = None,
    top_k: int = 5,
) -> dict:
    """Search across all indexed Confluence pages and GitLab repositories.

    Use this to find business rules, code patterns, architecture docs,
    or any enterprise knowledge relevant to your current task.

    Args:
        query: Natural language search query (e.g. "order service API")
        source_type: Filter by "confluence_page" or "git_repo". None = search all.
        top_k: Number of results to return (default 5).
    """
    try:
        results = search_mod.search(
            query, settings.default_collection, top_k=top_k, source_type=source_type
        )
        items = [r.to_dict() for r in results]
        if not items:
            return {
                "query": query,
                "results": [],
                "message": "No matching context found. Try broader query or check that sources are indexed.",
            }
        return {"query": query, "results": items}
    except Exception as e:
        logger.exception("search_context failed for query=%r", query)
        return {"error": "search_failed", "message": str(e)}


@mcp.tool()
def list_sources(source_type: str | None = None) -> dict:
    """List all indexed knowledge sources (Confluence pages and GitLab repos).

    Use this to see what enterprise knowledge is available for search.

    Args:
        source_type: Filter by "confluence_page" or "git_repo". None = list all.
    """
    try:
        sources = db.list_sources(source_type=source_type)
        items = [
            {
                "source_id": s["source_id"],
                "source_type": s["source_type"],
                "title": s["title"],
                "url": s.get("url", ""),
                "status": s.get("status", "unknown"),
            }
            for s in sources
        ]
        return {"sources": items, "total": len(items)}
    except Exception as e:
        logger.exception("list_sources failed")
        return {"error": "list_failed", "message": str(e)}


@mcp.tool()
def get_confluence_page(page_id: str) -> dict:
    """Fetch a specific Confluence page's content as plain text.

    Use this when you know the exact page ID and want the full content,
    not just search snippets.

    Args:
        page_id: Confluence page ID (numeric string, e.g. "12345").
    """
    source_id = f"confluence:{page_id}"
    try:
        source = db.get_source(source_id)
        if not source:
            return {"error": "not_found", "message": f"No Confluence page with ID {page_id} in catalog."}

        local_path = Path(source.get("local_path", ""))
        if not local_path.exists():
            return {
                "error": "not_synced",
                "message": f"Page {page_id} discovered but not synced yet. Call sync_sources(source_id='{source_id}') first.",
            }

        html = local_path.read_text(encoding="utf-8")
        content = html_to_text(html)
        return {
            "page_id": page_id,
            "title": source.get("title", ""),
            "url": source.get("url", ""),
            "content": content,
        }
    except Exception as e:
        logger.exception("get_confluence_page failed for page_id=%r", page_id)
        return {"error": "fetch_failed", "message": str(e)}


@mcp.tool()
def get_repo_structure(source_id: str) -> dict:
    """Get the directory layout and build commands for a GitLab repository.

    Returns source roots, docs, tests, manifests, and detected build/test commands.

    Args:
        source_id: Source ID (e.g. "gitlab:42").
    """
    try:
        source = db.get_source(source_id)
        if not source:
            return {"error": "not_found", "message": f"No source with ID '{source_id}' in catalog."}
        if source.get("source_type") != "git_repo":
            return {"error": "wrong_type", "message": f"Source '{source_id}' is not a git_repo."}

        local_path = Path(source.get("local_path", ""))
        if not local_path.exists():
            return {
                "error": "not_synced",
                "message": f"Repo '{source_id}' discovered but not synced. Call sync_sources(source_id='{source_id}') first.",
            }

        layout = detect_repo_layout(local_path)
        return {
            "source_id": source_id,
            "title": source.get("title", ""),
            "url": source.get("url", ""),
            "local_path": str(local_path),
            "default_branch": source.get("default_branch", "main"),
            "layout": layout,
        }
    except Exception as e:
        logger.exception("get_repo_structure failed for source_id=%r", source_id)
        return {"error": "layout_failed", "message": str(e)}


@mcp.tool()
def sync_sources(source_id: str | None = None) -> dict:
    """Sync and index sources from GitLab/Confluence into the knowledge base.

    Provide a source_id to sync a specific source. Call without arguments
    to get a list of all source_ids that can be synced individually.

    Args:
        source_id: Specific source to sync (e.g. "gitlab:42" or "confluence:123").
                   If omitted, returns the list of available sources instead of syncing all.
    """
    try:
        if source_id:
            result = service.sync_and_ingest_source(source_id)
            return {"synced": 1, "results": [result]}
        else:
            # Don't sync all — could block for 30+ minutes.
            # Return list of sources so the agent can sync individually.
            sources = db.list_sources()
            source_ids = [s["source_id"] for s in sources]
            return {
                "message": "Use sync_sources(source_id='...') to sync individual sources. Syncing all at once can take 30+ minutes.",
                "available_sources": source_ids,
                "total": len(source_ids),
            }
    except Exception as e:
        logger.exception("sync_sources failed for source_id=%r", source_id)
        return {"error": "sync_failed", "message": str(e)}


@mcp.tool()
def get_task_brief(task_description: str, top_k: int = 5) -> dict:
    """Generate a context-rich task brief from enterprise knowledge.

    Searches both GitLab repos and Confluence pages to build a structured
    brief with technical context (code) and business context (Confluence).
    No LLM call - pure retrieval.

    Args:
        task_description: Natural language description of the task.
        top_k: Number of context chunks to retrieve per source (default 5).
    """
    try:
        return build_task_brief(task_description, settings.default_collection, top_k=top_k)
    except Exception as e:
        logger.exception("get_task_brief failed for task=%r", task_description)
        return {"error": "brief_failed", "message": str(e)}


# ---------------------------------------------------------------------------
# Jira MCP Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def jira_sync_project(project_key: str, collection: str = "knowledge") -> dict:
    """Pull Jira issues của một project vào ChromaDB để AI có thể search.

    Args:
        project_key: Jira project key, ví dụ "PROJ" hoặc "OMS".
        collection: ChromaDB collection name (mặc định "knowledge").
    """
    try:
        results = service.sync_jira_sources(project_keys=[project_key], collection_name=collection)
        return {"results": results}
    except Exception as exc:
        logger.exception("jira_sync_project failed for project_key=%r", project_key)
        return {"error": "sync_failed", "message": str(exc)}


@mcp.tool()
def jira_create_from_intent(intent: str, project_key: str) -> dict:
    """Tạo Epic/Story/Sub-task trên Jira từ mô tả ý tưởng/yêu cầu.

    Tự động qua AI Quality Gate trước khi tạo ticket.
    Idempotent: cùng intent + project_key sẽ trả về kết quả đã tạo trước đó.

    Args:
        intent: Mô tả ý tưởng hoặc yêu cầu bằng ngôn ngữ tự nhiên.
        project_key: Jira project key, ví dụ "PROJ".
    """
    try:
        return service.create_jira_from_intent(intent, project_key)
    except Exception as exc:
        logger.exception("jira_create_from_intent failed")
        return {"error": "create_failed", "message": str(exc)}


@mcp.tool()
def jira_brief_from_ticket(issue_key: str, collection: str = "knowledge", top_k: int = 5) -> dict:
    """Sinh task brief đầy đủ từ Jira ticket ID.

    Kết hợp Jira context + Confluence business context + GitLab technical context.

    Args:
        issue_key: Jira issue key, ví dụ "PROJ-123".
        collection: ChromaDB collection name (mặc định "knowledge").
        top_k: Số lượng kết quả search tối đa (mặc định 5).
    """
    from app.tasks.jira_brief import build_brief_from_jira
    try:
        return build_brief_from_jira(issue_key, collection, top_k=top_k)
    except Exception as exc:
        logger.exception("jira_brief_from_ticket failed for issue_key=%r", issue_key)
        return {"error": "brief_failed", "message": str(exc)}


@mcp.tool()
def jira_link_dossier(task_id: str, issue_key: str) -> dict:
    """Liên kết task dossier với Jira issue key.

    Args:
        task_id: Task dossier ID.
        issue_key: Jira issue key, ví dụ "PROJ-123".
    """
    try:
        return service.link_dossier_to_jira(task_id, issue_key)
    except Exception as exc:
        logger.exception("jira_link_dossier failed")
        return {"error": "link_failed", "message": str(exc)}


@mcp.tool()
def jira_search(query: str, top_k: int = 5) -> dict:
    """Tìm kiếm Jira issues trong ChromaDB bằng natural language query.

    Args:
        query: Câu hỏi hoặc từ khoá tìm kiếm.
        top_k: Số lượng kết quả trả về (mặc định 5).
    """
    try:
        results = search_mod.search(
            query,
            settings.default_collection,
            top_k=top_k,
            source_type="jira_issue",
        )
        items = [r.to_dict() for r in results]
        return {"query": query, "results": items, "total": len(items)}
    except Exception as exc:
        logger.exception("jira_search failed for query=%r", query)
        return {"error": "search_failed", "message": str(exc)}


# ---------------------------------------------------------------------------
# RDE MCP Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def rde_generate_requirements(intent: str, collection: str = "knowledge") -> dict:
    """Sinh tài liệu requirements từ intent text."""
    import dataclasses
    from app.tasks.requirement_generator import generate_requirements
    try:
        result = generate_requirements(intent, collection_name=collection)
        return {
            "requirements_doc": result.document,
            "domains": result.domains,
            "compliance_report": dataclasses.asdict(result.compliance_report),
            "context_chunks_used": result.context_chunks_used,
            "generated_at": result.generated_at,
            "trace_id": result.trace_id,
        }
    except Exception as exc:
        logger.exception("rde_generate_requirements failed")
        return {"error": "generate_failed", "message": str(exc)}


@mcp.tool()
def rde_generate_design(requirements_doc: str, collection: str = "knowledge") -> dict:
    """Sinh tài liệu thiết kế từ requirements document."""
    import dataclasses
    from app.tasks.design_generator import generate_design
    try:
        result = generate_design(requirements_doc, collection_name=collection)
        return {
            "design_doc": result.document,
            "domains": result.domains,
            "compliance_report": dataclasses.asdict(result.compliance_report),
            "impact_report": dataclasses.asdict(result.impact_report),
            "context_chunks_used": result.context_chunks_used,
            "generated_at": result.generated_at,
            "trace_id": result.trace_id,
        }
    except Exception as exc:
        logger.exception("rde_generate_design failed")
        return {"error": "generate_failed", "message": str(exc)}


@mcp.tool()
def rde_analyze_impact(requirements_doc: str, collection: str = "knowledge") -> dict:
    """Phân tích impact của requirements mới lên codebase."""
    import dataclasses
    from app.tasks.impact_analyzer import analyze_impact
    try:
        result = analyze_impact(requirements_doc, collection_name=collection)
        return dataclasses.asdict(result)
    except Exception as exc:
        logger.exception("rde_analyze_impact failed")
        return {"error": "analyze_failed", "message": str(exc)}


@mcp.tool()
def rde_check_compliance(document: str, document_type: str, domains: list[str] | None = None) -> dict:
    """Kiểm tra compliance của document theo domain."""
    import dataclasses
    from app.tasks.compliance_checker import check_requirements, check_design
    from app.tasks.domain_detector import detect_domains
    try:
        effective_domains = domains
        if effective_domains is None:
            detection = detect_domains(document)
            effective_domains = detection.domains

        doc_type = document_type.lower()
        if doc_type == "requirements":
            report = check_requirements(document, effective_domains)
        elif doc_type == "design":
            report = check_design(document, effective_domains)
        else:
            return {"error": "invalid_document_type", "message": "document_type phải là 'requirements' hoặc 'design'"}

        return {"compliance_report": dataclasses.asdict(report)}
    except Exception as exc:
        logger.exception("rde_check_compliance failed")
        return {"error": "check_failed", "message": str(exc)}


@mcp.tool()
def rde_publish_to_confluence(
    title: str,
    content: str,
    space_key: str,
    parent_page_id: str | None = None,
) -> dict:
    """Tạo hoặc cập nhật trang Confluence từ markdown document."""
    import dataclasses
    from app.tasks.confluence_writer import write_document
    try:
        result = write_document(
            title=title,
            content_markdown=content,
            space_key=space_key,
            parent_page_id=parent_page_id,
        )
        return dataclasses.asdict(result)
    except Exception as exc:
        logger.exception("rde_publish_to_confluence failed")
        return {"error": "publish_failed", "message": str(exc)}


def main():
    """Start MCP server with runtime initialization."""
    import logging
    from pathlib import Path
    from app.sync.service import initialize_runtime
    from app.core.config_yaml import load_yaml_config, apply_yaml_to_settings
    from app.core.config import settings

    logging.basicConfig(level=settings.log_level)
    _log = logging.getLogger("mcp.server")

    # 1. Initialize runtime (directories, database)
    initialize_runtime()

    # 2. Load config.yaml if present (takes precedence over .env)
    yaml_cfg = load_yaml_config(Path("config.yaml"))
    if yaml_cfg:
        apply_yaml_to_settings(yaml_cfg, settings)
        _log.info("Loaded config.yaml")

    # 3. Auto-bootstrap on first start (no catalog.db or empty = fresh install)
    if not settings.catalog_db_path.exists() or settings.catalog_db_path.stat().st_size == 0:
        _log.info("First start detected - running bootstrap...")
        try:
            from app.sync.service import bootstrap_from_env
            bootstrap_from_env()
            _log.info("Bootstrap complete.")
        except Exception as e:
            _log.warning("Bootstrap failed: %s. Server will start anyway - use sync_sources tool to retry.", e)

    # 4. Serve
    _log.info("Starting MCP server on port 3000...")
    mcp.run(transport="streamable-http")


# ---------------------------------------------------------------------------
# QGE MCP tools
# ---------------------------------------------------------------------------

@mcp.tool()
def qge_analyze(diff: str, collection: str = "knowledge") -> dict:
    """Chạy tất cả quality gate trên code diff.

    Phân tích code diff qua 8 gate song song: code quality, security, secret detection,
    dependency vulnerability, test coverage, performance, API contract, regression risk.

    Args:
        diff: Unified diff text (output của git diff)
        collection: ChromaDB collection name (default: "knowledge")
    """
    try:
        from app.tasks.quality_gate.gate_runner import run_all_gates
        import dataclasses
        report = run_all_gates(diff, collection_name=collection)
        return {
            "overall": report.overall,
            "total_critical": report.total_critical,
            "total_high": report.total_high,
            "total_medium": report.total_medium,
            "total_low": report.total_low,
            "risk_score": report.risk_score,
            "findings": [dataclasses.asdict(f) for f in report.all_findings],
            "generated_test_code": report.generated_test_code,
            "trace_id": report.trace_id,
        }
    except Exception as e:
        return {"error": "qge_analyze_failed", "message": str(e)}


@mcp.tool()
def qge_generate_tests(diff: str) -> dict:
    """Sinh pytest skeleton cho code mới trong diff.

    Args:
        diff: Unified diff text (output của git diff)
    """
    try:
        from app.tasks.quality_gate.diff_parser import parse_diff
        from app.tasks.quality_gate.test_generator import generate_tests
        parsed = parse_diff(diff)
        return {"generated_test_code": generate_tests(parsed)}
    except Exception as e:
        return {"error": "qge_generate_tests_failed", "message": str(e)}


# ---------------------------------------------------------------------------
# Jenkins MCP tools
# ---------------------------------------------------------------------------

@mcp.tool()
def jenkins_trigger_pipeline(job_name: str, parameters: dict | None = None) -> dict:
    """Trigger Jenkins pipeline và trả về build number.

    Args:
        job_name: Tên Jenkins job
        parameters: Build parameters (key-value dict)
    """
    try:
        import dataclasses
        from app.tasks.jenkins.trigger import trigger_pipeline
        result = trigger_pipeline(job_name, parameters=parameters)
        return dataclasses.asdict(result)
    except Exception as e:
        return {"error": "jenkins_trigger_failed", "message": str(e)}


@mcp.tool()
def jenkins_get_build_status(job_name: str, build_number: int) -> dict:
    """Lấy trạng thái build Jenkins.

    Args:
        job_name: Tên Jenkins job
        build_number: Build number
    """
    try:
        from app.connectors.jenkins import JenkinsConnector
        from app.core.config import settings
        if not settings.jenkins_base_url:
            return {"error": "not_configured", "message": "Jenkins chưa được cấu hình"}
        connector = JenkinsConnector(settings.jenkins_base_url, settings.jenkins_username, settings.jenkins_token)
        return connector.get_build_status(job_name, build_number)
    except Exception as e:
        return {"error": "jenkins_status_failed", "message": str(e)}


@mcp.tool()
def jenkins_analyze_build_log(job_name: str, build_number: int) -> dict:
    """Lấy và phân tích Jenkins build log để tìm root cause.

    Args:
        job_name: Tên Jenkins job
        build_number: Build number
    """
    try:
        import dataclasses
        from app.connectors.jenkins import JenkinsConnector
        from app.core.config import settings
        from app.tasks.jenkins.log_analyzer import analyze_log
        if not settings.jenkins_base_url:
            return {"error": "not_configured", "message": "Jenkins chưa được cấu hình"}
        connector = JenkinsConnector(settings.jenkins_base_url, settings.jenkins_username, settings.jenkins_token)
        log = connector.get_build_log(job_name, build_number)
        analysis = analyze_log(log)
        return dataclasses.asdict(analysis)
    except Exception as e:
        return {"error": "jenkins_analyze_failed", "message": str(e)}


@mcp.tool()
def jenkins_get_deployments(
    service: str | None = None,
    environment: str | None = None,
    limit: int = 10,
) -> dict:
    """Lấy lịch sử deployment per service/environment.

    Args:
        service: Tên service (None = tất cả)
        environment: Environment (dev/uat/prod, None = tất cả)
        limit: Số lượng records tối đa (default 10)
    """
    try:
        import dataclasses
        from app.tasks.jenkins.tracker import get_deployments
        records = get_deployments(service=service, environment=environment, limit=limit)
        return {"deployments": [dataclasses.asdict(r) for r in records], "total": len(records)}
    except Exception as e:
        return {"error": "jenkins_deployments_failed", "message": str(e)}


if __name__ == "__main__":
    main()


# ---------------------------------------------------------------------------
# CGP MCP tools
# ---------------------------------------------------------------------------

@mcp.tool()
def cgp_decompose_tasks(design_doc: str, source_id: str = "", collection: str = "knowledge") -> dict:
    """Phân tích design doc → danh sách coding tasks có dependency order.

    Args:
        design_doc: Nội dung design document (markdown)
        source_id: GitLab source_id để gợi ý target_file (optional)
        collection: ChromaDB collection name
    """
    try:
        import dataclasses
        from app.tasks.code_gen.decomposer import decompose
        tasks = decompose(design_doc, collection)
        return {"tasks": [dataclasses.asdict(t) for t in tasks], "total": len(tasks)}
    except Exception as e:
        return {"error": "decompose_failed", "message": str(e)}


@mcp.tool()
def cgp_generate_code(task_json: str, collection: str = "knowledge") -> dict:
    """Sinh code cho một coding task (skeleton hoặc LLM mode).

    Args:
        task_json: CodingTask dạng JSON string
        collection: ChromaDB collection name
    """
    try:
        import dataclasses
        import json as _json
        from app.tasks.code_gen.models import CodingTask
        from app.tasks.code_gen.generator import generate
        task_dict = _json.loads(task_json)
        task = CodingTask(**task_dict)
        result = generate(task, collection)
        return dataclasses.asdict(result)
    except Exception as e:
        return {"error": "generate_failed", "message": str(e)}


@mcp.tool()
def cgp_generate_commit_message(diff: str, task_description: str = "") -> dict:
    """Sinh conventional commit message từ diff.

    Args:
        diff: Unified diff text (output của git diff)
        task_description: Mô tả task để sinh message chính xác hơn (optional)
    """
    try:
        from app.tasks.code_gen.commit_message import generate_message
        msg = generate_message(diff, task_description or None)
        return {"message": msg}
    except Exception as e:
        return {"error": "commit_message_failed", "message": str(e)}


@mcp.tool()
def cgp_run_pipeline(
    design_doc: str,
    source_id: str,
    branch_name: str,
    collection: str = "knowledge",
) -> dict:
    """Chạy toàn bộ pipeline: decompose → generate code → commit → tạo MR.

    Args:
        design_doc: Nội dung design document
        source_id: GitLab source_id (ví dụ "gitlab:42")
        branch_name: Tên branch mới cần tạo (ví dụ "feature/my-feature")
        collection: ChromaDB collection name
    """
    try:
        import dataclasses
        from app.tasks.code_gen.pipeline import run_pipeline
        result = run_pipeline(design_doc, source_id, branch_name, collection)
        return {
            "tasks_count": len(result.tasks),
            "files_generated": len(result.generated_files),
            "mr_url": result.mr_result.mr_url if result.mr_result else None,
            "trace_id": result.trace_id,
            "errors": result.errors,
            "duration_ms": result.duration_ms,
        }
    except Exception as e:
        return {"error": "pipeline_failed", "message": str(e)}


# ---------------------------------------------------------------------------
# K8s MCP tools
# ---------------------------------------------------------------------------

@mcp.tool()
def k8s_generate_helm_values(
    service_name: str,
    image_repository: str,
    image_tag: str,
    port: int,
    environment: str = "uat",
    ingress_host: str | None = None,
) -> dict:
    """Sinh Helm values.yaml từ service metadata.

    Args:
        service_name: Tên service
        image_repository: Docker image repository
        image_tag: Docker image tag
        port: Container port
        environment: Target environment (ci/uat/prod)
        ingress_host: Hostname cho Ingress (optional)
    """
    try:
        import dataclasses
        from app.tasks.k8s.helm_generator import generate_helm_values
        result = generate_helm_values(
            service_name=service_name, image_repository=image_repository,
            image_tag=image_tag, port=port, environment=environment,
            ingress_host=ingress_host,
        )
        return dataclasses.asdict(result)
    except Exception as e:
        return {"error": "helm_values_failed", "message": str(e)}


@mcp.tool()
def k8s_promote_to_ci(service: str, build_number: int, jenkins_deploy_job: str) -> dict:
    """Kiểm tra build pass và trigger Jenkins deploy-ci.

    Args:
        service: Tên service
        build_number: Jenkins build number
        jenkins_deploy_job: Tên Jenkins job deploy-ci
    """
    try:
        import dataclasses
        from app.tasks.k8s.ci_promoter import promote_to_ci
        result = promote_to_ci(service, build_number, jenkins_deploy_job)
        return dataclasses.asdict(result)
    except Exception as e:
        return {"error": "promote_ci_failed", "message": str(e)}


@mcp.tool()
def k8s_promote_to_uat(service: str, build_number: int, jenkins_deploy_job: str) -> dict:
    """Kiểm tra CI success và trigger Jenkins deploy-uat.

    Args:
        service: Tên service
        build_number: Build number cần promote
        jenkins_deploy_job: Tên Jenkins job deploy-uat
    """
    try:
        import dataclasses
        from app.tasks.k8s.uat_promoter import promote_to_uat
        result = promote_to_uat(service, build_number, jenkins_deploy_job)
        return dataclasses.asdict(result)
    except Exception as e:
        return {"error": "promote_uat_failed", "message": str(e)}


@mcp.tool()
def k8s_check_prod_gate(service: str, build_number: int, jenkins_deploy_job: str = "") -> dict:
    """Sinh PROD promotion checklist. KHÔNG tự deploy — chỉ trả về checklist.

    Args:
        service: Tên service
        build_number: Build number cần promote lên PROD
        jenkins_deploy_job: Tên Jenkins job deploy-prod (để sinh suggested_command)
    """
    try:
        import dataclasses
        from app.tasks.k8s.prod_gate import check_prod_gate
        result = check_prod_gate(service, build_number, jenkins_deploy_job)
        return dataclasses.asdict(result)
    except Exception as e:
        return {"error": "prod_gate_failed", "message": str(e)}


@mcp.tool()
def k8s_correlate_incident(
    service: str,
    incident_time: str,
    collection: str = "knowledge",
) -> dict:
    """Correlate incident với deployment gần nhất để tìm root cause.

    Args:
        service: Tên service bị incident
        incident_time: Thời điểm incident (ISO 8601, ví dụ: 2024-01-15T10:00:00Z)
        collection: ChromaDB collection name
    """
    try:
        import dataclasses
        from app.tasks.k8s.incident_correlator import correlate_incident
        result = correlate_incident(service, incident_time, collection)
        return dataclasses.asdict(result)
    except Exception as e:
        return {"error": "correlate_failed", "message": str(e)}


# ---------------------------------------------------------------------------
# Observability MCP tools
# ---------------------------------------------------------------------------

@mcp.tool()
def obs_query_audit_logs(
    event_types: list[str] | None = None,
    since: str | None = None,
    until: str | None = None,
    trace_id: str | None = None,
    limit: int = 100,
) -> dict:
    """Query unified audit logs từ tất cả modules.

    Args:
        event_types: Filter theo event type (None = tất cả)
        since: ISO timestamp — chỉ lấy events sau thời điểm này
        until: ISO timestamp — chỉ lấy events trước thời điểm này
        trace_id: Filter theo trace_id
        limit: Số lượng records tối đa (default 100)
    """
    try:
        import dataclasses
        from app.tasks.observability.audit_query import query_audit_logs
        events = query_audit_logs(event_types=event_types, since=since, until=until,
                                   trace_id=trace_id, limit=limit)
        return {"events": [dataclasses.asdict(e) for e in events], "total": len(events)}
    except Exception as e:
        return {"error": "audit_query_failed", "message": str(e)}


@mcp.tool()
def obs_score_confidence(output_type: str, output_data: str) -> dict:
    """Tính confidence score cho AI output.

    Args:
        output_type: requirements_doc | design_doc | generated_code | commit_message | helm_values
        output_data: Nội dung output cần score
    """
    try:
        import dataclasses
        from app.tasks.observability.confidence import score_confidence
        result = score_confidence(output_type, output_data)
        return dataclasses.asdict(result)
    except Exception as e:
        return {"error": "confidence_failed", "message": str(e)}


@mcp.tool()
def obs_request_approval(
    action_type: str,
    description: str,
    payload: dict | None = None,
    requested_by: str = "system",
) -> dict:
    """Tạo approval request cho critical action.

    Args:
        action_type: merge_to_main | deploy_prod | create_jira_epic | publish_confluence
        description: Mô tả action cần approve
        payload: Data cần thiết để thực thi sau khi approved
        requested_by: Người/system yêu cầu
    """
    try:
        from app.tasks.observability.hitl_gate import request_approval
        rid = request_approval(action_type, description, payload or {}, requested_by)
        return {"request_id": rid, "status": "pending"}
    except Exception as e:
        return {"error": "approval_request_failed", "message": str(e)}


@mcp.tool()
def obs_list_pending_approvals(action_type: str | None = None) -> dict:
    """List tất cả pending approval requests.

    Args:
        action_type: Filter theo action type (None = tất cả)
    """
    try:
        import dataclasses
        from app.tasks.observability.hitl_gate import list_pending
        requests = list_pending(action_type)
        return {"approvals": [dataclasses.asdict(r) for r in requests], "total": len(requests)}
    except Exception as e:
        return {"error": "list_approvals_failed", "message": str(e)}


@mcp.tool()
def obs_approve(request_id: str, approved_by: str, comment: str = "") -> dict:
    """Approve một HITL request.

    Args:
        request_id: ID của approval request
        approved_by: Tên người approve
        comment: Ghi chú (optional)
    """
    try:
        import dataclasses
        from app.tasks.observability.hitl_gate import approve
        result = approve(request_id, approved_by, comment)
        return dataclasses.asdict(result)
    except Exception as e:
        return {"error": "approve_failed", "message": str(e)}


@mcp.tool()
def obs_reject(request_id: str, rejected_by: str, comment: str = "") -> dict:
    """Reject một HITL request.

    Args:
        request_id: ID của approval request
        rejected_by: Tên người reject
        comment: Lý do reject
    """
    try:
        import dataclasses
        from app.tasks.observability.hitl_gate import reject
        result = reject(request_id, rejected_by, comment)
        return dataclasses.asdict(result)
    except Exception as e:
        return {"error": "reject_failed", "message": str(e)}
