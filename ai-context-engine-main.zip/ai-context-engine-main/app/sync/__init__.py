"""Sync pipeline for source discovery and local workspace synchronization."""
