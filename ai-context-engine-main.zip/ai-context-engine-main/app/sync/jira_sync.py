"""Pull Jira issues vào ChromaDB cho AI Context Engine V2."""

from __future__ import annotations

import re
import logging
from typing import Any

from app.catalog.database import (
    create_sync_run,
    finish_sync_run,
    update_sync_run_progress,
)
from app.connectors.jira import JiraConnector
from app.connectors.jira_errors import JiraAuthError, JiraConnectorError
from app.core.utils import utc_now_iso
from app.ingest.chunker import Chunk
from app.ingest.store import upsert_chunks

logger = logging.getLogger(__name__)

# Chunk size nhỏ hơn Confluence để giữ context issue gọn
_JIRA_CHUNK_SIZE = 500
_JIRA_CHUNK_OVERLAP = 50
_PAGE_SIZE = 100  # tối đa 100 issues/request theo Jira API

# ---------------------------------------------------------------------------
# PII Masking (Nghị định 13/2023/NĐ-CP)
# ---------------------------------------------------------------------------

_PII_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    # CMND/CCCD: 9 hoặc 12 chữ số đứng độc lập
    (re.compile(r"(?<!\d)\d{9}(?!\d)|(?<!\d)\d{12}(?!\d)"), "[CMND/CCCD]"),
    # Số điện thoại VN: 0[3-9]xxxxxxxx hoặc +84[3-9]xxxxxxxx
    (re.compile(r"(?<!\d)(?:\+84|0)[3-9]\d{8}(?!\d)"), "[SĐT]"),
    # Email
    (re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"), "[EMAIL]"),
    # Số thẻ ngân hàng (16 chữ số, có thể có dấu cách/gạch)
    (re.compile(r"(?<!\d)(?:\d[ \-]?){15,16}(?!\d)"), "[CARD]"),
]


def mask_pii(text: str) -> str:
    """Mask PII trong text trước khi lưu vào ChromaDB."""
    for pattern, replacement in _PII_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


# ---------------------------------------------------------------------------
# Document builder
# ---------------------------------------------------------------------------

def _extract_field(issue: dict, *keys: str, default: str = "") -> str:
    """Trích xuất field lồng nhau từ Jira issue dict."""
    obj: Any = issue.get("fields", {})
    for key in keys:
        if not isinstance(obj, dict):
            return default
        obj = obj.get(key)
        if obj is None:
            return default
    return str(obj) if obj is not None else default


def _build_issue_document(issue: dict, connector_id: int) -> tuple[str, dict]:
    """Chuyển Jira issue thành (text_content, metadata) cho ChromaDB.

    PII trong description và acceptance criteria được mask trước khi lưu.
    """
    fields = issue.get("fields", {})
    issue_key = issue.get("key", "")
    summary = fields.get("summary", "")
    issue_type = _extract_field(issue, "issuetype", "name")
    status = _extract_field(issue, "status", "name")
    priority = _extract_field(issue, "priority", "name")
    assignee = _extract_field(issue, "assignee", "displayName")
    story_points = fields.get("story_points") or fields.get("customfield_10016")
    project_key = _extract_field(issue, "project", "key")

    # Sprint info
    sprint_name = ""
    sprint_field = fields.get("customfield_10020") or fields.get("sprint")
    if isinstance(sprint_field, list) and sprint_field:
        sprint_name = sprint_field[-1].get("name", "") if isinstance(sprint_field[-1], dict) else ""
    elif isinstance(sprint_field, dict):
        sprint_name = sprint_field.get("name", "")

    # Epic
    epic_key = fields.get("customfield_10014") or fields.get("epic", {}).get("key", "") or ""

    # Description — mask PII
    description_raw = fields.get("description") or ""
    if isinstance(description_raw, dict):
        # Jira v3 ADF format — lấy text thuần
        description_raw = _extract_adf_text(description_raw)
    description = mask_pii(str(description_raw))

    text_content = (
        f"[JIRA] {issue_key}: {summary}\n"
        f"Type: {issue_type} | Status: {status} | Priority: {priority}\n"
        f"Sprint: {sprint_name} | Story Points: {story_points}\n"
        f"Epic: {epic_key} | Project: {project_key}\n"
        f"Assignee: {assignee}\n\n"
        f"Description:\n{description}"
    )

    metadata: dict[str, Any] = {
        "source_type": "jira_issue",
        "source_id": f"jira:{issue_key}",
        "issue_key": issue_key,
        "issue_type": issue_type,
        "status": status,
        "priority": priority,
        "assignee": assignee,
        "sprint_name": sprint_name,
        "epic_key": str(epic_key),
        "story_points": str(story_points) if story_points is not None else "",
        "project_key": project_key,
        "connector_id": str(connector_id),
        "last_synced_at": utc_now_iso(),
    }

    return text_content, metadata


def _extract_adf_text(adf: dict) -> str:
    """Trích xuất text thuần từ Atlassian Document Format (ADF)."""
    parts: list[str] = []
    for node in adf.get("content", []):
        if node.get("type") == "text":
            parts.append(node.get("text", ""))
        elif "content" in node:
            parts.append(_extract_adf_text(node))
    return " ".join(parts)


# ---------------------------------------------------------------------------
# Main sync function
# ---------------------------------------------------------------------------

def sync_jira_project(
    project_key: str,
    connector: dict,
    collection_name: str = "knowledge",
) -> dict:
    """Pull toàn bộ issues của một Jira project vào ChromaDB.

    Args:
        project_key: Jira project key, ví dụ "PROJ"
        connector: connector record từ catalog.db (có base_url, token, id)
        collection_name: ChromaDB collection name

    Returns:
        dict với keys: synced, failed, total, sync_run_id, status
    """
    connector_id = connector["id"]
    sync_run_id = create_sync_run(f"jira:{project_key}", "jira_sync")

    jira = JiraConnector(
        base_url=connector["base_url"],
        token=connector["token"],
    )

    results: dict[str, Any] = {
        "project_key": project_key,
        "synced": 0,
        "failed": 0,
        "total": 0,
        "sync_run_id": sync_run_id,
        "status": "running",
        "errors": [],
    }

    try:
        # Lấy tổng số issues trước
        first_page = jira.search_issues(
            jql=f"project = {project_key} ORDER BY updated DESC",
            start_at=0,
            max_results=1,
        )
        total = first_page.get("total", 0)
        results["total"] = total
        logger.info("Jira sync bắt đầu: project=%s, total=%d", project_key, total)

        start_at = 0
        while start_at < total:
            page = jira.search_issues(
                jql=f"project = {project_key} ORDER BY updated DESC",
                start_at=start_at,
                max_results=_PAGE_SIZE,
            )
            issues = page.get("issues", [])
            if not issues:
                break

            chunks: list[Chunk] = []
            for issue in issues:
                issue_key = issue.get("key", "unknown")
                try:
                    text_content, metadata = _build_issue_document(issue, connector_id)
                    chunks.append(Chunk(content=text_content, metadata=metadata))
                    results["synced"] += 1
                except JiraAuthError:
                    # Permission denied trên issue cụ thể — log và tiếp tục
                    logger.warning(
                        "Không có quyền truy cập issue %s, bỏ qua",
                        issue_key,
                    )
                    results["failed"] += 1
                    results["errors"].append({"issue_key": issue_key, "error": "permission_denied"})
                except Exception as exc:
                    logger.warning("Lỗi khi xử lý issue %s: %s", issue_key, exc)
                    results["failed"] += 1
                    results["errors"].append({"issue_key": issue_key, "error": str(exc)})

            # Batch upsert vào ChromaDB theo source_id từng issue
            for chunk in chunks:
                source_id = chunk.metadata.get("source_id", "")
                try:
                    upsert_chunks([chunk], collection_name, source_id)
                except Exception as exc:
                    logger.error("ChromaDB upsert thất bại cho %s: %s", source_id, exc)
                    results["failed"] += 1
                    results["synced"] -= 1

            start_at += len(issues)
            update_sync_run_progress(
                sync_run_id,
                {"synced": results["synced"], "total": total, "failed": results["failed"]},
            )
            logger.info(
                "Jira sync tiến độ: %d/%d (failed=%d)",
                results["synced"], total, results["failed"],
            )

        results["status"] = "success"
        finish_sync_run(sync_run_id, "success", details=results)
        logger.info(
            "Jira sync hoàn thành: project=%s synced=%d failed=%d",
            project_key, results["synced"], results["failed"],
        )

    except JiraConnectorError as exc:
        results["status"] = "failed"
        results["error"] = str(exc)
        finish_sync_run(sync_run_id, "failed", details=results)
        logger.error("Jira sync thất bại: project=%s error=%s", project_key, exc)
        raise

    return results
