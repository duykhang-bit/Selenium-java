"""Discovery services for GitLab and Confluence connectors."""

from __future__ import annotations

import math
import time

from app.catalog.database import get_connector, list_connectors, list_sources, upsert_source
from app.connectors.confluence import ConfluenceConnector
from app.connectors.gitlab import GitLabConnector
from app.core.config import settings
from app.core.utils import repo_workspace_path, safe_workspace_name, utc_now_iso


def _git_source_payload(connector: dict, project: dict) -> dict:
    path_with_namespace = project.get("path_with_namespace", "")
    local_path = repo_workspace_path(settings.repos_dir, path_with_namespace, project["name"])
    return {
        "source_id": f"gitlab:{project['id']}",
        "connector_id": connector["id"],
        "connector_type": "gitlab",
        "source_type": "git_repo",
        "external_id": str(project["id"]),
        "title": project["name"],
        "url": project.get("web_url") or project.get("http_url_to_repo"),
        "path_with_namespace": path_with_namespace,
        "clone_url": project.get("http_url_to_repo") or "",
        "default_branch": project.get("default_branch") or "main",
        "local_path": str(local_path),
        "status": "discovered",
        "discovered_at": utc_now_iso(),
        "metadata": {
            "repo_id": safe_workspace_name(path_with_namespace or project["name"]),
            "description": project.get("description") or "",
            "name_with_namespace": project.get("name_with_namespace") or "",
            "visibility": project.get("visibility") or "",
        },
    }




def _is_excluded_gitlab_project(project: dict) -> bool:
    path_with_namespace = (project.get("path_with_namespace") or "").strip("/").lower()
    if not path_with_namespace:
        return False
    namespaces = path_with_namespace.split("/")[:-1]
    excluded = set(settings.gitlab_excluded_groups)
    return any(namespace in excluded for namespace in namespaces)


def _confluence_source_payload(connector: dict, page: dict) -> dict:
    space = page.get("space", {})
    space_key = space.get("key", "unknown")
    local_path = settings.confluence_dir / safe_workspace_name(space_key) / f"{page['id']}.html"
    return {
        "source_id": f"confluence:{page['id']}",
        "connector_id": connector["id"],
        "connector_type": "confluence",
        "source_type": "confluence_page",
        "external_id": str(page["id"]),
        "title": page.get("title") or f"Page {page['id']}",
        "url": f"{connector['base_url'].rstrip('/')}/pages/viewpage.action?pageId={page['id']}",
        "local_path": str(local_path),
        "status": "discovered",
        "discovered_at": utc_now_iso(),
        "metadata": {
            "space_key": space_key,
            "space_name": space.get("name", ""),
            "version_number": (page.get("version") or {}).get("number"),
        },
    }


def discover_gitlab_sources(connector_id: int) -> list[dict]:
    connector = get_connector(connector_id)
    if not connector:
        raise KeyError(f"Unknown connector id: {connector_id}")
    client = GitLabConnector(connector["base_url"], connector["token"])
    projects = [project for project in client.list_projects() if not _is_excluded_gitlab_project(project)]
    return [upsert_source(_git_source_payload(connector, project)) for project in projects]


def discover_confluence_sources(
    connector_id: int,
    *,
    space_offset: int = 0,
    max_spaces: int | None = None,
    max_pages_per_space: int | None = None,
    max_pages_total: int | None = None,
    estimate_only: bool = False,
) -> dict:
    connector = get_connector(connector_id)
    if not connector:
        raise KeyError(f"Unknown connector id: {connector_id}")
    client = ConfluenceConnector(connector["base_url"], connector["token"], connector.get("username", ""))
    t0 = time.perf_counter()
    catalog_before = len(list_sources(source_type="confluence_page", enabled_only=False))
    est_pages = client.estimate_total_pages_via_search()

    if estimate_only:
        _, total_spaces = client.collect_spaces_window(space_offset=0, max_spaces=0, page_size=100)
        probe_n = 50
        t_probe = time.perf_counter()
        window_spaces, _ = client.collect_spaces_window(space_offset=0, max_spaces=1, page_size=100)
        sample_len = 0
        if window_spaces:
            sample = client.list_pages(window_spaces[0]["key"], limit=100, max_pages=probe_n)
            sample_len = len(sample)
        probe_elapsed = max(time.perf_counter() - t_probe, 1e-6)
        pages_per_sec = sample_len / probe_elapsed if sample_len else None
        remaining_by_api = None
        if est_pages is not None:
            remaining_by_api = max(0, est_pages - catalog_before)
        eta_discover_seconds = None
        if pages_per_sec and remaining_by_api is not None and pages_per_sec > 0:
            eta_discover_seconds = remaining_by_api / pages_per_sec
        elapsed = time.perf_counter() - t0
        return {
            "sources": [],
            "report": {
                "mode": "estimate_only",
                "elapsed_seconds": round(elapsed, 2),
                "catalog_confluence_pages_before": catalog_before,
                "estimated_total_pages_api": est_pages,
                "total_spaces": total_spaces,
                "sample_pages_fetched": sample_len,
                "sample_probe_seconds": round(probe_elapsed, 2),
                "estimated_pages_per_second": round(pages_per_sec, 2) if pages_per_sec else None,
                "estimated_remaining_pages_by_api": remaining_by_api,
                "estimated_seconds_to_discover_all_pages": round(eta_discover_seconds, 0) if eta_discover_seconds else None,
                "note": "ETA assumes listing + DB upsert cost stays similar to the sample; full ingest (sync/chunk/embed) is additional.",
            },
        }

    pages, coll_stats = client.collect_pages_window(
        space_offset=space_offset,
        max_spaces=max_spaces,
        max_pages_per_space=max_pages_per_space,
        max_pages_total=max_pages_total,
        api_batch=100,
    )
    sources = [upsert_source(_confluence_source_payload(connector, page)) for page in pages]
    elapsed = time.perf_counter() - t0
    catalog_after = len(list_sources(source_type="confluence_page", enabled_only=False))
    total_spaces = coll_stats["total_spaces_scanned"]
    spaces_in_window = coll_stats["spaces_in_window"]
    next_space_offset = space_offset + spaces_in_window
    all_spaces_done = next_space_offset >= total_spaces
    pages_per_sec = len(sources) / elapsed if elapsed > 0 and sources else None
    remaining_by_api = None
    if est_pages is not None:
        remaining_by_api = max(0, est_pages - catalog_after)
    eta_pages_seconds = None
    if pages_per_sec and remaining_by_api is not None and pages_per_sec > 0:
        eta_pages_seconds = remaining_by_api / pages_per_sec
    runs_remaining_same_space_batch = None
    if max_spaces and max_spaces > 0 and not all_spaces_done:
        runs_remaining_same_space_batch = math.ceil(max(0, total_spaces - next_space_offset) / max_spaces)
    est_seconds_remaining_batches = (
        runs_remaining_same_space_batch * elapsed if runs_remaining_same_space_batch else None
    )

    return {
        "sources": sources,
        "report": {
            "mode": "discover",
            "elapsed_seconds": round(elapsed, 2),
            "catalog_confluence_pages_before": catalog_before,
            "catalog_confluence_pages_after": catalog_after,
            "pages_upserted_this_run": len(sources),
            "estimated_total_pages_api": est_pages,
            "total_spaces": total_spaces,
            "space_offset_start": space_offset,
            "space_offset_next": next_space_offset,
            "all_spaces_processed": all_spaces_done,
            "max_spaces": max_spaces,
            "max_pages_per_space": max_pages_per_space,
            "max_pages_total": max_pages_total,
            "truncated_by_max_pages_total": coll_stats["truncated_by_max_pages_total"],
            "estimated_pages_per_second_this_run": round(pages_per_sec, 2) if pages_per_sec else None,
            "estimated_remaining_pages_by_api": remaining_by_api,
            "estimated_seconds_to_finish_all_pages_at_this_rate": round(eta_pages_seconds, 0) if eta_pages_seconds else None,
            "approx_runs_remaining_same_space_batch": runs_remaining_same_space_batch,
            "rough_seconds_remaining_same_space_batches": (
                round(est_seconds_remaining_batches, 0) if est_seconds_remaining_batches else None
            ),
            "next_invocation_example": (
                None
                if all_spaces_done
                else " ".join(
                    part
                    for part in (
                        f"python -m app.cli discover {connector_id}",
                        f"--cf-space-offset {next_space_offset}",
                        f"--cf-max-spaces {max_spaces}" if max_spaces else None,
                        f"--cf-max-pages-per-space {max_pages_per_space}" if max_pages_per_space else None,
                        f"--cf-max-pages-total {max_pages_total}" if max_pages_total else None,
                    )
                    if part is not None
                )
            ),
        },
    }


def discover_all_sources(
    *,
    space_offset: int = 0,
    max_spaces: int | None = None,
    max_pages_per_space: int | None = None,
    max_pages_total: int | None = None,
    estimate_only: bool = False,
) -> dict:
    discovered: dict = {"gitlab": [], "confluence": []}
    for connector in list_connectors():
        if connector["connector_type"] == "gitlab":
            if estimate_only:
                continue
            discovered["gitlab"].extend(discover_gitlab_sources(connector["id"]))
        elif connector["connector_type"] == "confluence":
            result = discover_confluence_sources(
                connector["id"],
                space_offset=space_offset,
                max_spaces=max_spaces,
                max_pages_per_space=max_pages_per_space,
                max_pages_total=max_pages_total,
                estimate_only=estimate_only,
            )
            discovered["confluence"].extend(result["sources"])
            discovered["_confluence_report"] = result["report"]
    return discovered
