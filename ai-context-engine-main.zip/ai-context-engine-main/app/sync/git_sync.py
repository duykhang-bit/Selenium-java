"""Git repository synchronization."""

from __future__ import annotations

import subprocess
from pathlib import Path

from app.catalog.database import create_sync_run, finish_sync_run, update_source_state
from app.core.utils import utc_now_iso
from app.sync.git_utils import get_local_head_sha


def _run_git(command: list[str], cwd: Path | None = None) -> None:
    subprocess.run(command, cwd=str(cwd) if cwd else None, check=True, capture_output=True, text=True, timeout=300)


def sync_git_source(source: dict, connector: dict | None = None) -> dict:
    sync_run_id = create_sync_run(source["source_id"], "git_sync")
    repo_path = Path(source["local_path"])
    repo_path.parent.mkdir(parents=True, exist_ok=True)
    clone_url = source["clone_url"]
    branch = source.get("default_branch") or "main"

    try:
        auth_prefix = ["-c", f"http.extraHeader=PRIVATE-TOKEN: {connector['token']}"] if connector else []
        if (repo_path / ".git").exists():
            _run_git(["git", *auth_prefix, "fetch", "--all", "--prune"], cwd=repo_path)
            _run_git(["git", "checkout", branch], cwd=repo_path)
            _run_git(["git", *auth_prefix, "pull", "--ff-only", "origin", branch], cwd=repo_path)
        else:
            _run_git(["git", *auth_prefix, "clone", "--branch", branch, clone_url, str(repo_path)])

        updated = update_source_state(
            source["source_id"],
            status="synced",
            local_path=str(repo_path),
            last_synced_at=utc_now_iso(),
        )
        # Record current HEAD SHA so re-sync can skip this repo if no new commits.
        head_sha = get_local_head_sha(repo_path)
        if head_sha:
            import json
            current_meta = json.loads(updated.get("metadata_json") or "{}")
            current_meta["last_commit_sha"] = head_sha
            updated = update_source_state(source["source_id"], metadata=current_meta)
        finish_sync_run(sync_run_id, "success", {"local_path": str(repo_path)})
        return updated
    except Exception as exc:
        finish_sync_run(sync_run_id, "failed", {"error": str(exc)})
        raise
