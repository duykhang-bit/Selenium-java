"""Source orchestration service for setup, discovery, sync, and manual registration."""

from __future__ import annotations

import json
import shutil
from urllib.parse import urlparse

from app.catalog.database import (
    get_connector,
    get_source,
    init_database,
    list_connectors,
    list_sources,
    update_source_state,
    upsert_connector,
    upsert_source,
)
from app.connectors.confluence import ConfluenceConnector
from app.connectors.gitlab import GitLabConnector
from app.connectors.jira_errors import JiraConfigError
from app.core.config import ensure_directories, settings
from app.core.logging import get_logger
from app.core.utils import git_url_to_path_with_namespace, repo_workspace_path, safe_workspace_name, utc_now_iso, validate_jira_url
from app.ingest.pipeline import ingest_source
from app.sync.confluence_sync import sync_confluence_source
from app.sync.discovery import discover_all_sources, discover_confluence_sources, discover_gitlab_sources
from app.sync.git_sync import sync_git_source
from app.sync.git_utils import has_new_commits

logger = get_logger(__name__)


def initialize_runtime() -> None:
    ensure_directories()
    init_database()


def reset_runtime_data() -> dict:
    """Remove V2 runtime data and recreate an empty runtime layout."""
    targets = [
        settings.catalog_db_path,
        settings.chroma_dir,
        settings.repos_dir,
        settings.confluence_dir,
        settings.reports_dir,
        settings.logs_dir,
    ]
    removed: list[str] = []
    for target in targets:
        if not target.exists():
            continue
        if target.is_dir():
            shutil.rmtree(target)
        else:
            target.unlink()
        removed.append(str(target))

    initialize_runtime()
    return {
        "removed": removed,
        "recreated": [
            str(settings.data_dir),
            str(settings.chroma_dir),
            str(settings.logs_dir),
            str(settings.workspaces_dir),
            str(settings.repos_dir),
            str(settings.confluence_dir),
            str(settings.reports_dir),
            str(settings.catalog_db_path),
        ],
    }


def register_gitlab_connector(base_url: str, token: str, name: str | None = None) -> dict:
    initialize_runtime()
    return upsert_connector("gitlab", base_url, token, name=name)


def register_jira_connector(base_url: str, token: str, name: str | None = None) -> dict:
    """Đăng ký Jira Server/Data Center connector.

    Validate URL (SSRF prevention) trước khi lưu vào catalog.db.
    Token được mã hoá Fernet tự động bởi upsert_connector.
    """
    initialize_runtime()
    validated_url = validate_jira_url(base_url)
    return upsert_connector("jira", validated_url, token, name=name or settings.jira_name)


def register_confluence_connector(base_url: str, token: str, name: str | None = None, username: str = "") -> dict:
    initialize_runtime()
    return upsert_connector("confluence", base_url, token, name=name, username=username)


def register_connectors_from_env() -> dict:
    initialize_runtime()
    configured: dict[str, dict] = {}

    if settings.gitlab_base_url and settings.gitlab_token:
        configured["gitlab"] = register_gitlab_connector(
            settings.gitlab_base_url,
            settings.gitlab_token,
            name=settings.gitlab_name or None,
        )

    if settings.confluence_base_url and settings.confluence_token:
        configured["confluence"] = register_confluence_connector(
            settings.confluence_base_url,
            settings.confluence_token,
            name=settings.confluence_name or None,
            username=settings.confluence_username,
        )

    if settings.jira_base_url and settings.jira_token:
        configured["jira"] = register_jira_connector(
            settings.jira_base_url,
            settings.jira_token,
            name=settings.jira_name or None,
        )

    return configured


def connector_for_url(connector_type: str, target_url: str) -> dict | None:
    parsed = urlparse(target_url)
    target_root = f"{parsed.scheme}://{parsed.netloc}".rstrip("/")
    for connector in list_connectors(connector_type=connector_type):
        if target_root.startswith(connector["base_url"].rstrip("/")) or connector["base_url"].startswith(target_root):
            return connector
    return None


def register_manual_git_source(repo_url: str) -> dict:
    initialize_runtime()
    connector = connector_for_url("gitlab", repo_url)
    if connector:
        project = GitLabConnector(connector["base_url"], connector["token"]).get_project_by_url(repo_url)
        path_with_namespace = project.get("path_with_namespace", git_url_to_path_with_namespace(repo_url))
        return upsert_source(
            {
                "source_id": f"gitlab:{project['id']}",
                "connector_id": connector["id"],
                "connector_type": "gitlab",
                "source_type": "git_repo",
                "external_id": str(project["id"]),
                "title": project.get("name") or path_with_namespace.split("/")[-1],
                "url": project.get("web_url") or repo_url,
                "path_with_namespace": path_with_namespace,
                "clone_url": project.get("http_url_to_repo") or repo_url,
                "default_branch": project.get("default_branch") or "main",
                "local_path": str(repo_workspace_path(settings.repos_dir, path_with_namespace, project.get("name"))),
                "status": "manual",
                "discovered_at": utc_now_iso(),
                "metadata": {
                    "repo_id": safe_workspace_name(path_with_namespace),
                    "description": project.get("description") or "",
                },
            }
        )

    path_with_namespace = git_url_to_path_with_namespace(repo_url)
    return upsert_source(
        {
            "source_id": f"manual-git:{safe_workspace_name(path_with_namespace)}",
            "connector_id": None,
            "connector_type": "manual_git",
            "source_type": "git_repo",
            "external_id": path_with_namespace,
            "title": path_with_namespace.split("/")[-1],
            "url": repo_url,
            "path_with_namespace": path_with_namespace,
            "clone_url": repo_url,
            "default_branch": "main",
            "local_path": str(repo_workspace_path(settings.repos_dir, path_with_namespace)),
            "status": "manual",
            "discovered_at": utc_now_iso(),
            "metadata": {
                "repo_id": safe_workspace_name(path_with_namespace),
                "description": "Manual Git source",
            },
        }
    )


def register_manual_confluence_source(page_url: str) -> dict:
    initialize_runtime()
    connector = connector_for_url("confluence", page_url)
    if not connector:
        raise ValueError("No matching Confluence connector found for the provided URL.")
    client = ConfluenceConnector(connector["base_url"], connector["token"], connector.get("username", ""))
    page_id = client.extract_page_id(page_url)
    page = client.get_page(page_id)
    space = page.get("space", {})
    return upsert_source(
        {
            "source_id": f"confluence:{page_id}",
            "connector_id": connector["id"],
            "connector_type": "confluence",
            "source_type": "confluence_page",
            "external_id": page_id,
            "title": page.get("title") or f"Page {page_id}",
            "url": page_url,
            "local_path": str(settings.confluence_dir / safe_workspace_name(space.get('key', 'manual')) / f"{page_id}.html"),
            "status": "manual",
            "discovered_at": utc_now_iso(),
            "metadata": {
                "space_key": space.get("key", ""),
                "space_name": space.get("name", ""),
                "version_number": page.get("version", {}).get("number"),
            },
        }
    )


def discover_sources(
    connector_id: int | None = None,
    *,
    confluence_space_offset: int = 0,
    confluence_max_spaces: int | None = None,
    confluence_max_pages_per_space: int | None = None,
    confluence_max_pages_total: int | None = None,
    confluence_estimate_only: bool = False,
) -> dict:
    initialize_runtime()
    if connector_id is None:
        return discover_all_sources(
            space_offset=confluence_space_offset,
            max_spaces=confluence_max_spaces,
            max_pages_per_space=confluence_max_pages_per_space,
            max_pages_total=confluence_max_pages_total,
            estimate_only=confluence_estimate_only,
        )
    connector = get_connector(connector_id)
    if not connector:
        raise KeyError(f"Unknown connector id: {connector_id}")
    if connector["connector_type"] == "gitlab":
        return {"gitlab": discover_gitlab_sources(connector_id), "confluence": []}
    if connector["connector_type"] == "confluence":
        result = discover_confluence_sources(
            connector["id"],
            space_offset=confluence_space_offset,
            max_spaces=confluence_max_spaces,
            max_pages_per_space=confluence_max_pages_per_space,
            max_pages_total=confluence_max_pages_total,
            estimate_only=confluence_estimate_only,
        )
        return {
            "gitlab": [],
            "confluence": result["sources"],
            "_confluence_report": result["report"],
        }
    raise ValueError(f"Unsupported connector type: {connector['connector_type']}")


def sync_and_ingest_source(source_id: str, collection_name: str | None = None) -> dict:
    initialize_runtime()
    source = get_source(source_id)
    if not source:
        raise KeyError(f"Unknown source_id: {source_id}")

    connector = get_connector(source["connector_id"]) if source.get("connector_id") else None
    synced = source
    if source["source_type"] == "git_repo":
        synced = sync_git_source(source, connector)
    elif source["source_type"] == "confluence_page":
        if not connector:
            raise ValueError("Confluence source requires a configured connector.")
        synced = sync_confluence_source(source, connector)
    else:
        raise ValueError(f"Unsupported source_type: {source['source_type']}")

    ingest_result = ingest_source(synced, collection_name=collection_name)
    merged_metadata = json.loads(synced.get("metadata_json") or "{}")
    merged_metadata["last_layout"] = ingest_result.get("layout", {})
    merged_metadata["last_collection"] = ingest_result["collection"]

    updated = update_source_state(
        source_id,
        status="indexed",
        last_ingested_at=ingest_result["last_ingested_at"],
        content_hash=ingest_result.get("content_hash", synced.get("content_hash", "")),
        metadata=merged_metadata,
    )
    return {"source": updated, "ingest": ingest_result}


def _sync_and_ingest_safe(source_id: str, collection_name: str | None = None) -> dict:
    """Like sync_and_ingest_source, but capture failures so batch sync can continue.

    Success: ``{"ok": True, "source": ..., "ingest": ...}`` (same keys as before, plus ``ok``).
    Failure: ``{"ok": False, "source_id": ..., "error": ...}``.
    """
    try:
        payload = sync_and_ingest_source(source_id, collection_name=collection_name)
        return {"ok": True, **payload}
    except Exception as exc:
        logger.error("Sync failed for %s: %s", source_id, exc, exc_info=True)
        return {"ok": False, "source_id": source_id, "error": str(exc)}


def sync_all_sources(
    collection_name: str | None = None,
    *,
    include_confluence: bool = True,
) -> list[dict]:
    """Sync and ingest enabled sources.

    Git repos are skipped only when the remote HEAD SHA matches the last ingested SHA
    (detected via GitLab API). Confluence pages are always re-synced.
    Per-source errors are returned as entries with ``ok: False`` instead of aborting the batch.
    """
    results = []
    for source in list_sources():
        if source["source_type"] == "confluence_page" and not include_confluence:
            continue
        if source["source_type"] == "git_repo":
            connector = get_connector(source["connector_id"]) if source.get("connector_id") else None
            if not has_new_commits(source, connector):
                continue
        results.append(_sync_and_ingest_safe(source["source_id"], collection_name))
    ok_count = sum(1 for r in results if r.get("ok"))
    logger.info("sync_all_sources complete: %d ok, %d failed.", ok_count, len(results) - ok_count)
    return results


def sync_all_git_sources(collection_name: str | None = None) -> list[dict]:
    """Sync and ingest every enabled Git repository source.

    Repos are skipped only when the remote HEAD SHA matches the last ingested SHA.
    Failures for individual repos do not stop the rest of the batch; see ``_sync_and_ingest_safe``.
    """
    results = []
    for source in list_sources(source_type="git_repo"):
        connector = get_connector(source["connector_id"]) if source.get("connector_id") else None
        if not has_new_commits(source, connector):
            continue
        results.append(_sync_and_ingest_safe(source["source_id"], collection_name))
    ok_count = sum(1 for r in results if r.get("ok"))
    logger.info("sync_all_git_sources complete: %d ok, %d failed.", ok_count, len(results) - ok_count)
    return results


def sync_all_confluence_sources(collection_name: str | None = None) -> list[dict]:
    """Sync and ingest every enabled Confluence page source.

    Per-page errors are returned as ``ok: False`` entries instead of aborting the batch.
    """
    results = []
    for source in list_sources(source_type="confluence_page"):
        results.append(_sync_and_ingest_safe(source["source_id"], collection_name))
    return results


def bootstrap_from_env(
    collection_name: str | None = None,
    *,
    confluence_space_offset: int = 0,
    confluence_max_spaces: int | None = None,
    confluence_max_pages_per_space: int | None = None,
    confluence_max_pages_total: int | None = None,
    confluence_estimate_only: bool = False,
    include_git_in_sync: bool = False,
    include_confluence_in_sync: bool = False,
) -> dict:
    """Run the full startup flow from local .env configuration."""
    initialize_runtime()
    connectors = register_connectors_from_env()
    discovered = discover_sources(
        confluence_space_offset=confluence_space_offset,
        confluence_max_spaces=confluence_max_spaces,
        confluence_max_pages_per_space=confluence_max_pages_per_space,
        confluence_max_pages_total=confluence_max_pages_total,
        confluence_estimate_only=confluence_estimate_only,
    )
    if confluence_estimate_only:
        synced = []
    else:
        synced = []
        if include_git_in_sync:
            synced.extend(sync_all_git_sources(collection_name=collection_name))
        if include_confluence_in_sync:
            synced.extend(sync_all_confluence_sources(collection_name=collection_name))
    return {
        "connectors": connectors,
        "discovered": discovered,
        "synced": synced,
    }


def sync_jira_sources(
    project_keys: list[str] | None = None,
    collection_name: str | None = None,
) -> list[dict]:
    """Pull Jira issues của các project vào ChromaDB.

    Args:
        project_keys: danh sách project key. Nếu None, dùng settings.jira_project_keys.
        collection_name: ChromaDB collection name.

    Returns:
        list kết quả sync theo từng project.
    """
    from app.sync.jira_sync import sync_jira_project

    initialize_runtime()
    keys = project_keys or settings.jira_project_keys
    if not keys:
        logger.warning("Không có Jira project key nào được cấu hình.")
        return []

    connectors = list_connectors(connector_type="jira")
    if not connectors:
        logger.warning("Chưa có Jira connector nào được đăng ký.")
        return []

    connector = connectors[0]
    coll = collection_name or settings.default_collection
    results = []

    for project_key in keys:
        try:
            result = sync_jira_project(project_key, connector, collection_name=coll)
            results.append({"ok": True, **result})
        except Exception as exc:
            logger.error("Jira sync thất bại cho project %s: %s", project_key, exc)
            results.append({"ok": False, "project_key": project_key, "error": str(exc)})

    return results


def create_jira_from_intent(
    intent: str,
    project_key: str,
    trace_id: str | None = None,
) -> dict:
    """Tạo Epic/Story/Sub-task trên Jira từ intent text.

    Wrapper cho jira_writer.create_from_intent với connector từ catalog.db.
    """
    from app.tasks.jira_writer import create_from_intent

    initialize_runtime()
    connectors = list_connectors(connector_type="jira")
    if not connectors:
        raise RuntimeError("Chưa có Jira connector nào được đăng ký.")
    return create_from_intent(intent, project_key, connectors[0], trace_id=trace_id)


def link_dossier_to_jira(task_id: str, issue_key: str) -> dict:
    """Liên kết task dossier với Jira issue key."""
    from app.tasks.jira_dossier_sync import link_dossier_to_jira as _link

    initialize_runtime()
    return _link(task_id, issue_key)
