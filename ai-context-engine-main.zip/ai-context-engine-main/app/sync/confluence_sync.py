"""Confluence page synchronization."""

from __future__ import annotations

from pathlib import Path

from app.catalog.database import create_sync_run, finish_sync_run, update_source_state
from app.connectors.confluence import ConfluenceConnector
from app.core.utils import ensure_parent, sha256_text, utc_now_iso


def sync_confluence_source(source: dict, connector: dict) -> dict:
    sync_run_id = create_sync_run(source["source_id"], "confluence_sync")
    file_path = Path(source["local_path"])
    ensure_parent(file_path)

    try:
        client = ConfluenceConnector(connector["base_url"], connector["token"], connector.get("username", ""))
        page = client.get_page(source["external_id"])
        html = page.get("body", {}).get("storage", {}).get("value", "")
        file_path.write_text(html, encoding="utf-8")
        updated = update_source_state(
            source["source_id"],
            status="synced",
            local_path=str(file_path),
            content_hash=sha256_text(html),
            last_synced_at=utc_now_iso(),
            metadata={
                "space_key": page.get("space", {}).get("key", ""),
                "space_name": page.get("space", {}).get("name", ""),
                "version_number": page.get("version", {}).get("number"),
            },
        )
        finish_sync_run(sync_run_id, "success", {"local_path": str(file_path)})
        return updated
    except Exception as exc:
        finish_sync_run(sync_run_id, "failed", {"error": str(exc)})
        raise
