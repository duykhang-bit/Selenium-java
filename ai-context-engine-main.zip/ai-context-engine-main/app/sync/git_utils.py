"""Utilities to detect whether a Git repository has new remote commits.

Uses the GitLab API (already authenticated) to get the latest commit SHA on the
default branch, then compares it to the locally stored ``last_commit_sha`` in
the source metadata. This avoids unnecessary re-ingestion.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import requests

from app.core.logging import get_logger

logger = get_logger(__name__)


def get_local_head_sha(repo_path: Path) -> str | None:
    """Return the current HEAD commit SHA of a local clone, or None on error."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=True,
            timeout=30,
        )
        return result.stdout.strip() or None
    except Exception as exc:
        logger.debug("Could not read local HEAD SHA at %s: %s", repo_path, exc)
        return None


def get_remote_head_sha_via_gitlab(
    base_url: str,
    token: str,
    project_id: str,
    branch: str = "main",
) -> str | None:
    """Fetch the latest commit SHA on *branch* from the GitLab API.

    Endpoint: GET /projects/:id/repository/commits?ref_name=<branch>&per_page=1
    """
    api_url = f"{base_url.rstrip('/')}/api/v4/projects/{project_id}/repository/commits"
    try:
        response = requests.get(
            api_url,
            params={"ref_name": branch, "per_page": 1},
            headers={"PRIVATE-TOKEN": token},
            timeout=30,
        )
        response.raise_for_status()
        commits = response.json()
        if commits and isinstance(commits, list):
            return commits[0].get("id")
    except Exception as exc:
        logger.debug("Could not fetch remote HEAD SHA for project %s: %s", project_id, exc)
    return None


def has_new_commits(source: dict, connector: dict | None) -> bool:
    """Return True if the remote has commits not yet ingested locally.

    Decision logic:
    1. If the repo has never been synced → True (needs first sync).
    2. Try to get the stored ``last_commit_sha`` from source metadata.
    3. Fetch remote HEAD SHA via GitLab API.
    4. If either lookup fails → True (sync to be safe, don't skip).
    5. Compare SHAs — return True when they differ.
    """
    import json

    local_path = Path(source.get("local_path", ""))
    if not local_path.exists() or not (local_path / ".git").exists():
        return True  # Not cloned yet

    metadata = json.loads(source.get("metadata_json") or "{}")
    stored_sha = metadata.get("last_commit_sha")

    # If we have no stored SHA at all → compare local HEAD to remote HEAD
    if not stored_sha:
        stored_sha = get_local_head_sha(local_path)

    if not stored_sha:
        return True  # Cannot determine → sync to be safe

    # Try GitLab API for remote SHA
    if connector:
        project_id = source.get("external_id", "")
        branch = source.get("default_branch") or "main"
        remote_sha = get_remote_head_sha_via_gitlab(
            connector["base_url"],
            connector["token"],
            project_id,
            branch,
        )
        if remote_sha is None:
            logger.warning(
                "Could not fetch remote HEAD for %s — will re-sync to be safe.",
                source["source_id"],
            )
            return True
        changed = remote_sha != stored_sha
        if changed:
            logger.info(
                "New commits detected for %s (local=%s, remote=%s).",
                source["source_id"],
                stored_sha[:8],
                remote_sha[:8],
            )
        else:
            logger.debug("No new commits for %s (SHA=%s).", source["source_id"], stored_sha[:8])
        return changed

    # No connector (manual git) — compare local HEAD to see if pull brought changes
    return False
