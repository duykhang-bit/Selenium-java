"""Catalog storage for connectors and discovered sources."""
