"""SQLite catalog used as the source of truth for connectors and sources."""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from typing import Iterator

from app.core.config import ensure_directories, settings
from app.core.crypto import decrypt_token, encrypt_token
from app.core.logging import get_logger
from app.core.utils import stable_json, utc_now_iso


logger = get_logger(__name__)


def _connect() -> sqlite3.Connection:
    ensure_directories()
    connection = sqlite3.connect(settings.catalog_db_path)
    connection.row_factory = sqlite3.Row
    return connection


@contextmanager
def get_connection() -> Iterator[sqlite3.Connection]:
    connection = _connect()
    try:
        yield connection
        connection.commit()
    finally:
        connection.close()


def init_database() -> None:
    """Initialize the SQLite schema if it does not exist."""
    schema = """
    CREATE TABLE IF NOT EXISTS connectors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        connector_type TEXT NOT NULL,
        name TEXT NOT NULL,
        base_url TEXT NOT NULL,
        token TEXT NOT NULL,
        username TEXT DEFAULT '',
        metadata_json TEXT DEFAULT '{}',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE(connector_type, base_url)
    );

    CREATE TABLE IF NOT EXISTS sources (
        source_id TEXT PRIMARY KEY,
        connector_id INTEGER,
        connector_type TEXT NOT NULL,
        source_type TEXT NOT NULL,
        external_id TEXT,
        title TEXT NOT NULL,
        url TEXT NOT NULL,
        path_with_namespace TEXT DEFAULT '',
        clone_url TEXT DEFAULT '',
        default_branch TEXT DEFAULT '',
        local_path TEXT DEFAULT '',
        status TEXT DEFAULT 'discovered',
        enabled INTEGER DEFAULT 1,
        discovered_at TEXT NOT NULL,
        last_synced_at TEXT DEFAULT '',
        last_ingested_at TEXT DEFAULT '',
        content_hash TEXT DEFAULT '',
        metadata_json TEXT DEFAULT '{}',
        FOREIGN KEY(connector_id) REFERENCES connectors(id)
    );

    CREATE TABLE IF NOT EXISTS sync_runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source_id TEXT,
        action TEXT NOT NULL,
        status TEXT NOT NULL,
        started_at TEXT NOT NULL,
        finished_at TEXT DEFAULT '',
        details_json TEXT DEFAULT '{}',
        progress_json TEXT DEFAULT '{}'
    );

    CREATE TABLE IF NOT EXISTS idempotency_keys (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key_hash TEXT NOT NULL UNIQUE,
        connector_type TEXT NOT NULL DEFAULT 'jira',
        result_ref TEXT NOT NULL,
        created_at TEXT NOT NULL,
        metadata_json TEXT DEFAULT '{}'
    );
    CREATE INDEX IF NOT EXISTS idx_idempotency_keys_hash ON idempotency_keys(key_hash);

    CREATE TABLE IF NOT EXISTS jira_dossier_links (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id TEXT NOT NULL,
        issue_key TEXT NOT NULL,
        linked_at TEXT NOT NULL,
        UNIQUE(task_id, issue_key)
    );

    CREATE TABLE IF NOT EXISTS jenkins_triggers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_name TEXT NOT NULL,
        build_number INTEGER NOT NULL,
        build_url TEXT DEFAULT '',
        triggered_by TEXT DEFAULT 'system',
        parameters_json TEXT DEFAULT '{}',
        triggered_at TEXT NOT NULL,
        trace_id TEXT DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS jenkins_deployments (
        record_id TEXT PRIMARY KEY,
        service TEXT NOT NULL,
        environment TEXT NOT NULL,
        build_number INTEGER NOT NULL,
        job_name TEXT NOT NULL,
        status TEXT NOT NULL,
        deployed_at TEXT NOT NULL,
        deployed_by TEXT DEFAULT 'system',
        build_url TEXT DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_jenkins_deployments_service ON jenkins_deployments(service, environment);

    CREATE TABLE IF NOT EXISTS approval_requests (
        request_id TEXT PRIMARY KEY,
        action_type TEXT NOT NULL,
        description TEXT NOT NULL,
        payload_json TEXT DEFAULT '{}',
        requested_by TEXT DEFAULT 'system',
        status TEXT DEFAULT 'pending',
        created_at TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        approved_by TEXT DEFAULT '',
        comment TEXT DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_approval_status ON approval_requests(status, action_type);
    CREATE INDEX IF NOT EXISTS idx_jira_dossier_links_task ON jira_dossier_links(task_id);
    CREATE INDEX IF NOT EXISTS idx_jira_dossier_links_issue ON jira_dossier_links(issue_key);
    """
    with get_connection() as connection:
        connection.executescript(schema)
        # Migration: thêm cột progress_json vào sync_runs nếu chưa có
        try:
            connection.execute("ALTER TABLE sync_runs ADD COLUMN progress_json TEXT DEFAULT '{}'")
        except Exception:
            pass  # cột đã tồn tại
    logger.info("Catalog database initialized at %s", settings.catalog_db_path)


def _rows_to_dicts(rows: list[sqlite3.Row]) -> list[dict]:
    return [dict(row) for row in rows]


def upsert_connector(
    connector_type: str,
    base_url: str,
    token: str,
    name: str | None = None,
    username: str = "",
    metadata: dict | None = None,
) -> dict:
    now = utc_now_iso()
    connector_name = name or f"{connector_type}:{base_url}"
    encrypted_token = encrypt_token(token)
    with get_connection() as connection:
        connection.execute(
            """
            INSERT INTO connectors (connector_type, name, base_url, token, username, metadata_json, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(connector_type, base_url)
            DO UPDATE SET
                name = excluded.name,
                token = excluded.token,
                username = excluded.username,
                metadata_json = excluded.metadata_json,
                updated_at = excluded.updated_at
            """,
            (
                connector_type,
                connector_name,
                base_url.rstrip("/"),
                encrypted_token,
                username,
                stable_json(metadata),
                now,
                now,
            ),
        )
        row = connection.execute(
            "SELECT * FROM connectors WHERE connector_type = ? AND base_url = ?",
            (connector_type, base_url.rstrip("/")),
        ).fetchone()
        result = dict(row)
        result["token"] = decrypt_token(result["token"])
        return result


def list_connectors(connector_type: str | None = None) -> list[dict]:
    query = "SELECT * FROM connectors"
    params: tuple = ()
    if connector_type:
        query += " WHERE connector_type = ?"
        params = (connector_type,)
    query += " ORDER BY id ASC"
    with get_connection() as connection:
        rows = connection.execute(query, params).fetchall()
        results = [dict(row) for row in rows]
        for item in results:
            item["token"] = decrypt_token(item["token"])
        return results


def get_connector(connector_id: int) -> dict | None:
    with get_connection() as connection:
        row = connection.execute("SELECT * FROM connectors WHERE id = ?", (connector_id,)).fetchone()
        if row is None:
            return None
        result = dict(row)
        result["token"] = decrypt_token(result["token"])
        return result


def upsert_source(source: dict) -> dict:
    now = utc_now_iso()
    with get_connection() as connection:
        connection.execute(
            """
            INSERT INTO sources (
                source_id, connector_id, connector_type, source_type, external_id, title, url,
                path_with_namespace, clone_url, default_branch, local_path, status, enabled,
                discovered_at, last_synced_at, last_ingested_at, content_hash, metadata_json
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(source_id)
            DO UPDATE SET
                connector_id = excluded.connector_id,
                connector_type = excluded.connector_type,
                source_type = excluded.source_type,
                external_id = excluded.external_id,
                title = excluded.title,
                url = excluded.url,
                path_with_namespace = excluded.path_with_namespace,
                clone_url = excluded.clone_url,
                default_branch = excluded.default_branch,
                local_path = excluded.local_path,
                status = excluded.status,
                enabled = excluded.enabled,
                content_hash = excluded.content_hash,
                metadata_json = excluded.metadata_json
            """,
            (
                source["source_id"],
                source.get("connector_id"),
                source["connector_type"],
                source["source_type"],
                source.get("external_id", ""),
                source["title"],
                source["url"],
                source.get("path_with_namespace", ""),
                source.get("clone_url", ""),
                source.get("default_branch", ""),
                source.get("local_path", ""),
                source.get("status", "discovered"),
                1 if source.get("enabled", True) else 0,
                source.get("discovered_at", now),
                source.get("last_synced_at", ""),
                source.get("last_ingested_at", ""),
                source.get("content_hash", ""),
                stable_json(source.get("metadata")),
            ),
        )
        row = connection.execute("SELECT * FROM sources WHERE source_id = ?", (source["source_id"],)).fetchone()
        return dict(row)


def list_sources(
    connector_type: str | None = None,
    source_type: str | None = None,
    enabled_only: bool = True,
) -> list[dict]:
    clauses = []
    params: list = []
    if connector_type:
        clauses.append("connector_type = ?")
        params.append(connector_type)
    if source_type:
        clauses.append("source_type = ?")
        params.append(source_type)
    if enabled_only:
        clauses.append("enabled = 1")
    query = "SELECT * FROM sources"
    if clauses:
        query += " WHERE " + " AND ".join(clauses)
    query += " ORDER BY title ASC"
    with get_connection() as connection:
        rows = connection.execute(query, tuple(params)).fetchall()
        return _rows_to_dicts(rows)


def get_source(source_id: str) -> dict | None:
    with get_connection() as connection:
        row = connection.execute("SELECT * FROM sources WHERE source_id = ?", (source_id,)).fetchone()
        return dict(row) if row else None


def update_source_state(
    source_id: str,
    *,
    status: str | None = None,
    local_path: str | None = None,
    content_hash: str | None = None,
    last_synced_at: str | None = None,
    last_ingested_at: str | None = None,
    metadata: dict | None = None,
) -> dict:
    current = get_source(source_id)
    if not current:
        raise KeyError(f"Unknown source_id: {source_id}")
    fields = {
        "status": status if status is not None else current["status"],
        "local_path": local_path if local_path is not None else current["local_path"],
        "content_hash": content_hash if content_hash is not None else current["content_hash"],
        "last_synced_at": last_synced_at if last_synced_at is not None else current["last_synced_at"],
        "last_ingested_at": last_ingested_at if last_ingested_at is not None else current["last_ingested_at"],
        "metadata_json": stable_json(metadata) if metadata is not None else current["metadata_json"],
        "source_id": source_id,
    }
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE sources
            SET status = :status,
                local_path = :local_path,
                content_hash = :content_hash,
                last_synced_at = :last_synced_at,
                last_ingested_at = :last_ingested_at,
                metadata_json = :metadata_json
            WHERE source_id = :source_id
            """,
            fields,
        )
        row = connection.execute("SELECT * FROM sources WHERE source_id = ?", (source_id,)).fetchone()
        return dict(row)


def create_sync_run(source_id: str, action: str) -> int:
    started_at = utc_now_iso()
    with get_connection() as connection:
        cursor = connection.execute(
            "INSERT INTO sync_runs (source_id, action, status, started_at) VALUES (?, ?, ?, ?)",
            (source_id, action, "running", started_at),
        )
        return int(cursor.lastrowid)


def finish_sync_run(sync_run_id: int, status: str, details: dict | None = None) -> None:
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE sync_runs
            SET status = ?, finished_at = ?, details_json = ?
            WHERE id = ?
            """,
            (status, utc_now_iso(), stable_json(details), sync_run_id),
        )


def update_sync_run_progress(sync_run_id: int, progress: dict) -> None:
    """Cập nhật tiến độ sync run (progress_json)."""
    with get_connection() as connection:
        connection.execute(
            "UPDATE sync_runs SET progress_json = ? WHERE id = ?",
            (stable_json(progress), sync_run_id),
        )


# ---------------------------------------------------------------------------
# Idempotency keys (dùng cho Jira create-from-intent)
# ---------------------------------------------------------------------------

def upsert_idempotency_key(
    key_hash: str,
    result_ref: str,
    connector_type: str = "jira",
    metadata: dict | None = None,
) -> dict:
    """Lưu idempotency key. Nếu đã tồn tại thì trả về record hiện có."""
    now = utc_now_iso()
    with get_connection() as connection:
        connection.execute(
            """
            INSERT OR IGNORE INTO idempotency_keys
                (key_hash, connector_type, result_ref, created_at, metadata_json)
            VALUES (?, ?, ?, ?, ?)
            """,
            (key_hash, connector_type, result_ref, now, stable_json(metadata)),
        )
        row = connection.execute(
            "SELECT * FROM idempotency_keys WHERE key_hash = ?", (key_hash,)
        ).fetchone()
        return dict(row)


def get_idempotency_key(key_hash: str) -> dict | None:
    """Tìm idempotency key theo hash. Trả về None nếu không tồn tại."""
    with get_connection() as connection:
        row = connection.execute(
            "SELECT * FROM idempotency_keys WHERE key_hash = ?", (key_hash,)
        ).fetchone()
        return dict(row) if row else None


# ---------------------------------------------------------------------------
# Jira dossier links (mapping task_id ↔ Jira issue_key)
# ---------------------------------------------------------------------------

def upsert_jira_dossier_link(task_id: str, issue_key: str) -> dict:
    """Liên kết task dossier với Jira issue key (idempotent)."""
    now = utc_now_iso()
    with get_connection() as connection:
        connection.execute(
            """
            INSERT OR IGNORE INTO jira_dossier_links (task_id, issue_key, linked_at)
            VALUES (?, ?, ?)
            """,
            (task_id, issue_key.upper(), now),
        )
        row = connection.execute(
            "SELECT * FROM jira_dossier_links WHERE task_id = ? AND issue_key = ?",
            (task_id, issue_key.upper()),
        ).fetchone()
        return dict(row)


def list_jira_dossier_links(task_id: str) -> list[dict]:
    """Lấy tất cả Jira issue keys được liên kết với một task dossier."""
    with get_connection() as connection:
        rows = connection.execute(
            "SELECT * FROM jira_dossier_links WHERE task_id = ? ORDER BY linked_at",
            (task_id,),
        ).fetchall()
        return _rows_to_dicts(rows)


# ---------------------------------------------------------------------------
# Jenkins catalog functions
# ---------------------------------------------------------------------------

def save_trigger_record(
    job_name: str,
    build_number: int,
    build_url: str = "",
    triggered_by: str = "system",
    parameters: dict | None = None,
    triggered_at: str = "",
    trace_id: str = "",
) -> dict:
    from app.core.utils import stable_json, utc_now_iso
    now = triggered_at or utc_now_iso()
    with get_connection() as conn:
        cursor = conn.execute(
            """INSERT INTO jenkins_triggers
               (job_name, build_number, build_url, triggered_by, parameters_json, triggered_at, trace_id)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (job_name, build_number, build_url, triggered_by, stable_json(parameters), now, trace_id),
        )
        row = conn.execute("SELECT * FROM jenkins_triggers WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)


def save_deployment_record(
    record_id: str,
    service: str,
    environment: str,
    build_number: int,
    job_name: str,
    status: str,
    deployed_at: str = "",
    deployed_by: str = "system",
    build_url: str = "",
) -> dict:
    from app.core.utils import utc_now_iso
    now = deployed_at or utc_now_iso()
    with get_connection() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO jenkins_deployments
               (record_id, service, environment, build_number, job_name, status, deployed_at, deployed_by, build_url)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (record_id, service, environment, build_number, job_name, status, now, deployed_by, build_url),
        )
        row = conn.execute("SELECT * FROM jenkins_deployments WHERE record_id = ?", (record_id,)).fetchone()
        return dict(row)


def list_deployments(
    service: str | None = None,
    environment: str | None = None,
    limit: int = 20,
) -> list[dict]:
    clauses, params = [], []
    if service:
        clauses.append("service = ?")
        params.append(service)
    if environment:
        clauses.append("environment = ?")
        params.append(environment)
    query = "SELECT * FROM jenkins_deployments"
    if clauses:
        query += " WHERE " + " AND ".join(clauses)
    query += " ORDER BY deployed_at DESC LIMIT ?"
    params.append(limit)
    with get_connection() as conn:
        return _rows_to_dicts(conn.execute(query, tuple(params)).fetchall())


def get_latest_deployment(service: str, environment: str) -> dict | None:
    with get_connection() as conn:
        row = conn.execute(
            "SELECT * FROM jenkins_deployments WHERE service = ? AND environment = ? ORDER BY deployed_at DESC LIMIT 1",
            (service, environment),
        ).fetchone()
        return dict(row) if row else None


# ---------------------------------------------------------------------------
# Approval requests (HITL Gate)
# ---------------------------------------------------------------------------

def save_approval_request(
    request_id: str,
    action_type: str,
    description: str,
    payload: dict | None = None,
    requested_by: str = "system",
    created_at: str = "",
    expires_at: str = "",
) -> dict:
    from app.core.utils import stable_json, utc_now_iso
    now = created_at or utc_now_iso()
    with get_connection() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO approval_requests
               (request_id, action_type, description, payload_json, requested_by, status, created_at, expires_at)
               VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)""",
            (request_id, action_type, description, stable_json(payload), requested_by, now, expires_at),
        )
        row = conn.execute("SELECT * FROM approval_requests WHERE request_id = ?", (request_id,)).fetchone()
        return dict(row)


def update_approval_status(
    request_id: str,
    status: str,
    approved_by: str = "",
    comment: str = "",
) -> dict:
    with get_connection() as conn:
        conn.execute(
            "UPDATE approval_requests SET status = ?, approved_by = ?, comment = ? WHERE request_id = ?",
            (status, approved_by, comment, request_id),
        )
        row = conn.execute("SELECT * FROM approval_requests WHERE request_id = ?", (request_id,)).fetchone()
        return dict(row) if row else {}


def list_approval_requests(
    status: str | None = None,
    action_type: str | None = None,
) -> list[dict]:
    clauses, params = [], []
    if status:
        clauses.append("status = ?")
        params.append(status)
    if action_type:
        clauses.append("action_type = ?")
        params.append(action_type)
    query = "SELECT * FROM approval_requests"
    if clauses:
        query += " WHERE " + " AND ".join(clauses)
    query += " ORDER BY created_at DESC"
    with get_connection() as conn:
        return _rows_to_dicts(conn.execute(query, tuple(params)).fetchall())


def get_approval_request(request_id: str) -> dict | None:
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM approval_requests WHERE request_id = ?", (request_id,)).fetchone()
        return dict(row) if row else None
