"""Report exporters for catalog data."""

from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path

from app.catalog.database import list_sources
from app.core.config import ensure_directories, settings
from app.core.utils import utc_now_iso


def _md_inline(value: str | None) -> str:
    return (value or "").replace("|", r"\|").strip()


def _source_sort_key(source: dict) -> tuple[str, str]:
    namespace = source.get("path_with_namespace") or source.get("title") or ""
    return (namespace.lower(), (source.get("source_id") or "").lower())


def export_git_sources_markdown(output_path: str | None = None) -> dict:
    """Export discovered Git sources to a Markdown report.

    The target file is overwritten on every run.
    """
    ensure_directories()
    sources = sorted(list_sources(source_type="git_repo"), key=_source_sort_key)
    destination = Path(output_path) if output_path else settings.reports_dir / "git-sources.md"
    destination.parent.mkdir(parents=True, exist_ok=True)

    status_counter = Counter((source.get("status") or "unknown") for source in sources)
    grouped_sources: dict[str, list[dict]] = defaultdict(list)
    for source in sources:
        namespace = source.get("path_with_namespace") or source.get("title") or "unknown"
        parts = [part for part in namespace.split("/") if part]
        group_key = "/".join(parts[:-1]) if len(parts) > 1 else "ungrouped"
        grouped_sources[group_key].append(source)

    lines = [
        "# Git Sources Report",
        "",
        f"Generated at: `{utc_now_iso()}`",
        "",
        "## Summary",
        "",
        f"- Total repositories: **{len(sources)}**",
        f"- Namespace groups: **{len(grouped_sources)}**",
    ]

    if sources:
        lines.append(f"- Status breakdown: {', '.join(f'`{status}`={count}' for status, count in sorted(status_counter.items()))}")
    lines.append("")

    if not sources:
        lines.extend([
            "No Git repository sources found in catalog.",
            "",
            "Run `python -m app.cli bootstrap` or `python -m app.cli discover-all` first.",
        ])
    else:
        lines.extend([
            "## Quick View",
            "",
            "| Namespace Group | Repositories |",
            "| --- | ---: |",
        ])
        for group_name, group_items in sorted(grouped_sources.items(), key=lambda item: item[0].lower()):
            lines.append(f"| `{_md_inline(group_name)}` | {len(group_items)} |")

        for group_name, group_items in sorted(grouped_sources.items(), key=lambda item: item[0].lower()):
            lines.extend([
                "",
                f"## {_md_inline(group_name)}",
                "",
            ])
            for index, source in enumerate(group_items, start=1):
                title = _md_inline(source.get("title") or source.get("path_with_namespace") or "Untitled")
                namespace = _md_inline(source.get("path_with_namespace") or "")
                source_id = _md_inline(source.get("source_id") or "")
                status = _md_inline(source.get("status") or "unknown")
                local_path = _md_inline(source.get("local_path") or "")
                url = source.get("url") or ""

                lines.extend([
                    f"### {index}. {title}",
                    f"- Source ID: `{source_id}`",
                    f"- Namespace: `{namespace}`" if namespace else "- Namespace: `n/a`",
                    f"- Status: `{status}`",
                    f"- Local path: `{local_path}`" if local_path else "- Local path: `n/a`",
                ])
                if url:
                    lines.append(f"- URL: [{url}]({url})")
                lines.append("")

    destination.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {
        "output_path": str(destination),
        "count": len(sources),
        "overwritten": True,
        "group_count": len(grouped_sources),
    }
