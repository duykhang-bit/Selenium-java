"""Confluence connector for space/page discovery and page retrieval."""

from __future__ import annotations

import base64
import re
from urllib.parse import parse_qs, urlparse

import markdown as md_lib
import requests

from app.core.logging import get_logger


logger = get_logger(__name__)


def markdown_to_storage(markdown_text: str) -> str:
    """Convert markdown to Confluence Storage Format.

    Uses the ``markdown`` library to produce HTML first, then post-processes
    the result to replace standard HTML constructs with Confluence-specific
    Storage Format macros (e.g. code blocks → ac:structured-macro).
    """
    # Convert markdown → HTML (with tables and fenced-code extensions)
    html = md_lib.markdown(
        markdown_text,
        extensions=["tables", "fenced_code"],
    )

    # --- Code blocks → Confluence code macro ---
    # markdown library renders fenced code as:
    #   <code class="language-python">...</code>  (inside <pre>)
    def _replace_code_block(m: re.Match) -> str:
        lang = m.group(1) or ""
        body = m.group(2)
        lang_param = (
            f'<ac:parameter ac:name="language">{lang}</ac:parameter>'
            if lang
            else ""
        )
        return (
            '<ac:structured-macro ac:name="code">'
            f"{lang_param}"
            "<ac:plain-text-body>"
            f"<![CDATA[{body}]]>"
            "</ac:plain-text-body>"
            "</ac:structured-macro>"
        )

    html = re.sub(
        r'<pre><code(?:\s+class="language-([^"]*)")?>(.*?)</code></pre>',
        _replace_code_block,
        html,
        flags=re.DOTALL,
    )

    # --- Inline code (not inside pre) — leave as-is (already <code>) ---

    # --- Tables: ensure tbody wrapper exists ---
    # markdown library already produces <table><thead>/<tbody> — nothing extra needed.

    # --- Wrap bare text blocks in <p> if not already wrapped ---
    # The markdown library already wraps paragraphs in <p>; nothing extra needed.

    return html


class ConfluenceConnector:
    def __init__(self, base_url: str, token: str, username: str = ""):
        self.base_url = base_url.rstrip("/")
        self.username = username
        self.token = token
        self.session = requests.Session()
        # Disable cookie persistence — Confluence Server JSESSIONID expiry causes
        # intermittent 401 when session cookie overrides Bearer token auth
        self.session.cookies.clear()
        self.session.headers.update({
            "Accept": "application/json",
            "X-Atlassian-Token": "no-check",
        })

    def _candidate_api_roots(self) -> list[str]:
        if self.base_url.endswith("/wiki"):
            return [f"{self.base_url}/rest/api"]
        return [f"{self.base_url}/wiki/rest/api", f"{self.base_url}/rest/api"]

    def _auth_headers(self) -> list[dict[str, str]]:
        """Try multiple auth styles to support Cloud and Server/Data Center."""
        headers: list[dict[str, str]] = []
        if self.token:
            headers.append({"Authorization": f"Bearer {self.token}"})
        if self.username and self.token:
            credentials = f"{self.username}:{self.token}".encode("utf-8")
            encoded = base64.b64encode(credentials).decode("ascii")
            headers.append({"Authorization": f"Basic {encoded}"})
        # Note: empty auth fallback removed — it always 401s and hides real errors
        return headers

    def _get(self, path: str, **params) -> dict:
        last_error = None
        for api_root in self._candidate_api_roots():
            for auth_header in self._auth_headers():
                try:
                    response = self.session.get(
                        f"{api_root}{path}",
                        params=params,
                        headers=auth_header or None,
                        timeout=60,
                    )
                    response.raise_for_status()
                    return response.json()
                except requests.RequestException as exc:
                    last_error = exc
        raise last_error  # type: ignore[misc]

    def iter_spaces(self, page_size: int = 100):
        """Yield all spaces using Confluence pagination (start/limit)."""
        start = 0
        while True:
            data = self._get("/space", limit=page_size, start=start)
            results = data.get("results", [])
            if not results:
                break
            yield from results
            if len(results) < page_size:
                break
            start += page_size

    def list_spaces(self, limit: int = 100) -> list[dict]:
        spaces: list[dict] = []
        start = 0
        while True:
            data = self._get("/space", limit=limit, start=start)
            results = data.get("results", [])
            if not results:
                break
            spaces.extend(results)
            if len(results) < limit:
                break
            start += limit
        logger.info("Discovered %s Confluence spaces", len(spaces))
        return spaces

    def collect_spaces_window(
        self,
        *,
        space_offset: int = 0,
        max_spaces: int | None = None,
        page_size: int = 100,
    ) -> tuple[list[dict], int]:
        """Return up to ``max_spaces`` spaces after skipping ``space_offset``.

        Performs a full scan over spaces so the second return value is the total
        number of spaces (for progress reporting).
        """
        selected: list[dict] = []
        seen_index = 0
        for space in self.iter_spaces(page_size=page_size):
            if seen_index < space_offset:
                seen_index += 1
                continue
            if max_spaces is None or len(selected) < max_spaces:
                selected.append(space)
            seen_index += 1
        return selected, seen_index

    def estimate_total_pages_via_search(self) -> int | None:
        """Best-effort page count from Search API (CQL). Returns ``None`` if the endpoint is unavailable."""
        last_error = None
        for api_root in self._candidate_api_roots():
            for auth_header in self._auth_headers():
                try:
                    response = self.session.get(
                        f"{api_root}/search",
                        params={"cql": "type=page", "limit": 1, "start": 0},
                        headers=auth_header or None,
                        timeout=60,
                    )
                    response.raise_for_status()
                    data = response.json()
                    total = data.get("totalSize")
                    if isinstance(total, int):
                        return total
                except requests.RequestException as exc:  # noqa: PERF203
                    last_error = exc
        if last_error:
            logger.warning("Could not estimate total pages via search: %s", last_error)
        return None

    def list_pages(
        self,
        space_key: str,
        limit: int = 100,
        *,
        max_pages: int | None = None,
    ) -> list[dict]:
        pages: list[dict] = []
        start = 0
        while True:
            if max_pages is not None and len(pages) >= max_pages:
                return pages[:max_pages]
            data = self._get(
                "/content",
                type="page",
                spaceKey=space_key,
                status="current",
                limit=limit,
                start=start,
                expand="space,version",
            )
            results = data.get("results", [])
            if not results:
                break
            if max_pages is not None:
                remaining = max_pages - len(pages)
                if remaining <= 0:
                    return pages
                if len(results) > remaining:
                    pages.extend(results[:remaining])
                    return pages
            pages.extend(results)
            if len(results) < limit:
                break
            start += limit
        return pages

    def list_all_pages(self, limit: int = 100) -> list[dict]:
        pages: list[dict] = []
        for space in self.list_spaces(limit=limit):
            pages.extend(self.list_pages(space["key"], limit=limit))
        logger.info("Discovered %s Confluence pages", len(pages))
        return pages

    def collect_pages_window(
        self,
        *,
        space_offset: int = 0,
        max_spaces: int | None = None,
        max_pages_per_space: int | None = None,
        max_pages_total: int | None = None,
        api_batch: int = 100,
    ) -> tuple[list[dict], dict]:
        """Collect pages for a subset of spaces and optional global page cap."""
        spaces, total_spaces = self.collect_spaces_window(
            space_offset=space_offset,
            max_spaces=max_spaces,
            page_size=api_batch,
        )
        pages: list[dict] = []
        truncated_by_total = False
        for space in spaces:
            if max_pages_total is not None and len(pages) >= max_pages_total:
                truncated_by_total = True
                break
            cap: int | None = max_pages_per_space
            if max_pages_total is not None:
                room = max_pages_total - len(pages)
                if cap is None or cap > room:
                    cap = room
            batch = self.list_pages(space["key"], limit=api_batch, max_pages=cap)
            pages.extend(batch)
            if max_pages_total is not None and len(pages) >= max_pages_total:
                pages = pages[: max_pages_total]
                truncated_by_total = True
                break
        logger.info(
            "Collected %s Confluence pages (%s spaces in this window, total_spaces=%s)",
            len(pages),
            len(spaces),
            total_spaces,
        )
        stats = {
            "spaces_in_window": len(spaces),
            "total_spaces_scanned": total_spaces,
            "pages_collected": len(pages),
            "truncated_by_max_pages_total": truncated_by_total,
        }
        return pages, stats

    def get_page(self, page_id: str) -> dict:
        return self._get(f"/content/{page_id}", expand="body.storage,space,version")

    # ------------------------------------------------------------------
    # Write / search methods (added for Requirement & Design Engine)
    # ------------------------------------------------------------------

    def create_page(
        self,
        space_key: str,
        title: str,
        body_storage: str,
        parent_id: str | None = None,
    ) -> dict:
        """Create a new Confluence page and return {id, title, _links.webui}."""
        payload: dict = {
            "type": "page",
            "title": title,
            "space": {"key": space_key},
            "body": {
                "storage": {
                    "value": body_storage,
                    "representation": "storage",
                }
            },
            "ancestors": [{"id": parent_id}] if parent_id else [],
        }
        last_error = None
        for api_root in self._candidate_api_roots():
            for auth_header in self._auth_headers():
                try:
                    response = self.session.post(
                        f"{api_root}/content",
                        json=payload,
                        headers={**{"Content-Type": "application/json"}, **(auth_header or {})},
                        timeout=60,
                    )
                    response.raise_for_status()
                    data = response.json()
                    logger.info(
                        "Created Confluence page id=%s title=%s",
                        data.get("id"),
                        title,
                    )
                    return data
                except requests.RequestException as exc:
                    last_error = exc
        raise last_error  # type: ignore[misc]

    def update_page(
        self,
        page_id: str,
        title: str,
        body_storage: str,
        version_number: int,
        minor_edit: bool = False,
    ) -> dict:
        """Update an existing Confluence page. ``version_number`` must match the current version."""
        payload: dict = {
            "version": {"number": version_number, "minorEdit": minor_edit},
            "title": title,
            "type": "page",
            "body": {
                "storage": {
                    "value": body_storage,
                    "representation": "storage",
                }
            },
        }
        last_error = None
        for api_root in self._candidate_api_roots():
            for auth_header in self._auth_headers():
                try:
                    response = self.session.put(
                        f"{api_root}/content/{page_id}",
                        json=payload,
                        headers={**{"Content-Type": "application/json"}, **(auth_header or {})},
                        timeout=60,
                    )
                    response.raise_for_status()
                    data = response.json()
                    logger.info(
                        "Updated Confluence page id=%s version=%s",
                        page_id,
                        version_number,
                    )
                    return data
                except requests.RequestException as exc:
                    last_error = exc
        raise last_error  # type: ignore[misc]

    def search_pages(self, cql: str, limit: int = 25) -> list[dict]:
        """Search Confluence pages using CQL and return a list of page dicts."""
        last_error = None
        for api_root in self._candidate_api_roots():
            for auth_header in self._auth_headers():
                try:
                    response = self.session.get(
                        f"{api_root}/content/search",
                        params={"cql": cql, "limit": limit},
                        headers=auth_header or None,
                        timeout=60,
                    )
                    response.raise_for_status()
                    data = response.json()
                    results: list[dict] = data.get("results", [])
                    logger.info(
                        "search_pages cql=%r returned %s results",
                        cql,
                        len(results),
                    )
                    return results
                except requests.RequestException as exc:
                    last_error = exc
        raise last_error  # type: ignore[misc]

    def extract_page_id(self, page_url: str) -> str:
        parsed = urlparse(page_url)
        query = parse_qs(parsed.query)
        page_ids = query.get("pageId") or query.get("pageid")
        if page_ids:
            return page_ids[0]
        path_parts = [part for part in parsed.path.split("/") if part]
        for part in reversed(path_parts):
            if part.isdigit():
                return part
        raise ValueError(f"Could not extract pageId from URL: {page_url}")
