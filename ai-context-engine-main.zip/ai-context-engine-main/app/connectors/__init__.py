"""GitLab and Confluence source connectors."""
