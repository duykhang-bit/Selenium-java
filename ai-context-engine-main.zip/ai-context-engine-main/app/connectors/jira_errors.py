"""Exception hierarchy cho Jira Integration."""

from __future__ import annotations


class JiraError(Exception):
    """Base exception cho tất cả Jira-related errors."""


class JiraConnectorError(JiraError):
    """Lỗi kết nối hoặc HTTP khi gọi Jira API."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response_body: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class JiraAuthError(JiraConnectorError):
    """HTTP 401/403 — token sai hoặc không đủ quyền. Fatal, không retry."""


class JiraNotFoundError(JiraConnectorError):
    """HTTP 404 — issue/project không tồn tại."""


class JiraRateLimitError(JiraConnectorError):
    """HTTP 429 — rate limit, có thể retry với exponential backoff."""


class JiraServerError(JiraConnectorError):
    """HTTP 5xx — lỗi phía Jira server, có thể retry."""


class JiraNetworkError(JiraConnectorError):
    """Timeout hoặc connection refused — có thể retry."""


class JiraConfigError(JiraError):
    """Cấu hình không hợp lệ: URL sai, token rỗng, v.v."""


class JiraQualityGateError(JiraError):
    """Issue không qua AI Quality Gate."""

    def __init__(self, confidence_score: float, issues: list[str]) -> None:
        super().__init__(
            f"Quality gate failed (score={confidence_score:.2f}): {'; '.join(issues)}"
        )
        self.confidence_score = confidence_score
        self.issues = issues


class JiraIdempotencyError(JiraError):
    """Idempotency key đã tồn tại — ticket đã được tạo trước đó."""

    def __init__(self, existing_ref: str) -> None:
        super().__init__(f"Ticket đã tồn tại: {existing_ref}")
        self.existing_ref = existing_ref


class JiraIssueNotFoundError(JiraError):
    """Issue key không tồn tại trên Jira (dùng cho Brief Builder)."""

    def __init__(self, issue_key: str) -> None:
        super().__init__(f"Jira issue không tồn tại: {issue_key}")
        self.issue_key = issue_key
