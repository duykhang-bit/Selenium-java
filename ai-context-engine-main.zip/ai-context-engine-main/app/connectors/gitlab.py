"""GitLab connector for project discovery and manual lookup."""

from __future__ import annotations

from urllib.parse import quote_plus

import requests

from app.core.logging import get_logger
from app.core.utils import git_url_to_path_with_namespace


logger = get_logger(__name__)


class GitLabConnector:
    def __init__(self, base_url: str, token: str):
        self.base_url = base_url.rstrip("/")
        self.api_url = f"{self.base_url}/api/v4"
        self.session = requests.Session()
        self.session.headers.update({"PRIVATE-TOKEN": token, "Accept": "application/json"})

    def _get(self, path: str, **params) -> dict | list:
        response = self.session.get(f"{self.api_url}{path}", params=params, timeout=60)
        response.raise_for_status()
        return response.json()

    def list_projects(self, per_page: int = 100) -> list[dict]:
        projects: list[dict] = []
        page = 1
        while True:
            data = self._get(
                "/projects",
                membership=True,
                simple=True,
                archived=False,
                per_page=per_page,
                page=page,
                order_by="last_activity_at",
                sort="desc",
            )
            if not data:
                break
            projects.extend(data)
            if len(data) < per_page:
                break
            page += 1
        logger.info("Discovered %s GitLab projects", len(projects))
        return projects

    def get_project(self, path_with_namespace: str) -> dict:
        encoded = quote_plus(path_with_namespace)
        return self._get(f"/projects/{encoded}")

    def get_project_by_url(self, repo_url: str) -> dict:
        path_with_namespace = git_url_to_path_with_namespace(repo_url)
        return self.get_project(path_with_namespace)

    def _post(self, path: str, json: dict) -> dict:
        response = self.session.post(f"{self.api_url}{path}", json=json, timeout=30)
        response.raise_for_status()
        return response.json()

    def get_branch(self, project_id: int, branch_name: str) -> dict | None:
        """GET /projects/{id}/repository/branches/{branch} — None nếu không tồn tại."""
        from urllib.parse import quote
        try:
            response = self.session.get(
                f"{self.api_url}/projects/{project_id}/repository/branches/{quote(branch_name, safe='')}",
                timeout=30,
            )
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except Exception:
            return None

    def create_branch(self, project_id: int, branch_name: str, ref: str) -> dict:
        """POST /projects/{id}/repository/branches"""
        return self._post(
            f"/projects/{project_id}/repository/branches",
            {"branch": branch_name, "ref": ref},
        )

    def commit_files(
        self,
        project_id: int,
        branch_name: str,
        files: list[dict],
        commit_message: str,
    ) -> dict:
        """POST /projects/{id}/repository/commits

        files: [{"file_path": ..., "content": ..., "action": "create"|"update"|"delete"}]
        """
        return self._post(
            f"/projects/{project_id}/repository/commits",
            {
                "branch": branch_name,
                "commit_message": commit_message,
                "actions": files,
            },
        )

    def create_merge_request(
        self,
        project_id: int,
        source_branch: str,
        target_branch: str,
        title: str,
        description: str = "",
    ) -> dict:
        """POST /projects/{id}/merge_requests"""
        return self._post(
            f"/projects/{project_id}/merge_requests",
            {
                "source_branch": source_branch,
                "target_branch": target_branch,
                "title": title,
                "description": description,
            },
        )
