"""Jira Server / Data Center API client cho AI Context Engine V2."""

from __future__ import annotations

import logging
import time
from typing import Any

import requests
from requests.adapters import HTTPAdapter

from app.connectors.jira_errors import (
    JiraAuthError,
    JiraConnectorError,
    JiraNetworkError,
    JiraNotFoundError,
    JiraRateLimitError,
    JiraServerError,
)

logger = logging.getLogger(__name__)

# Số lần retry tối đa cho recoverable errors (429, 5xx, network)
_MAX_RETRIES = 3
_BASE_DELAY = 1.0  # giây


class JiraConnector:
    """HTTP client kết nối đến Jira Server / Data Center REST API v2.

    Sử dụng Personal Access Token (PAT) để xác thực.
    Connection pooling tối đa 10 connections.
    Timeout: connect 5s / read 30s (cấu hình được).
    """

    def __init__(
        self,
        base_url: str,
        token: str,
        connect_timeout: float = 5.0,
        read_timeout: float = 30.0,
        max_pool_size: int = 10,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self._token = token
        self._timeout = (connect_timeout, read_timeout)

        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        })
        adapter = HTTPAdapter(
            pool_connections=min(5, max_pool_size),
            pool_maxsize=max_pool_size,
            pool_block=False,
        )
        self._session.mount("https://", adapter)
        self._session.mount("http://", adapter)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _raise_for_status(self, response: requests.Response) -> None:
        """Wrap HTTP error thành đúng exception subclass."""
        code = response.status_code
        body = response.text[:500] if response.text else ""
        if code in (401, 403):
            raise JiraAuthError(
                f"Xác thực thất bại (HTTP {code})", status_code=code, response_body=body
            )
        if code == 404:
            raise JiraNotFoundError(
                f"Không tìm thấy resource (HTTP 404)", status_code=404, response_body=body
            )
        if code == 429:
            raise JiraRateLimitError(
                "Rate limit — thử lại sau", status_code=429, response_body=body
            )
        if code >= 500:
            raise JiraServerError(
                f"Lỗi Jira server (HTTP {code})", status_code=code, response_body=body
            )
        if not response.ok:
            raise JiraConnectorError(
                f"Jira API trả về HTTP {code}", status_code=code, response_body=body
            )

    def _get(self, path: str, params: dict | None = None) -> Any:
        """GET request với retry cho recoverable errors."""
        return self._request_with_retry("GET", path, params=params)

    def _post(self, path: str, json_body: dict) -> Any:
        """POST request với retry cho recoverable errors."""
        return self._request_with_retry("POST", path, json_body=json_body)

    def _put(self, path: str, json_body: dict) -> Any:
        """PUT request với retry cho recoverable errors."""
        return self._request_with_retry("PUT", path, json_body=json_body)

    def _request_with_retry(
        self,
        method: str,
        path: str,
        params: dict | None = None,
        json_body: dict | None = None,
    ) -> Any:
        url = self._url(path)
        last_exc: Exception | None = None

        for attempt in range(_MAX_RETRIES + 1):
            try:
                resp = self._session.request(
                    method,
                    url,
                    params=params,
                    json=json_body,
                    timeout=self._timeout,
                )
                self._raise_for_status(resp)
                # PUT issue có thể trả 204 No Content
                if resp.status_code == 204 or not resp.content:
                    return {}
                return resp.json()

            except (JiraRateLimitError, JiraServerError) as exc:
                last_exc = exc
                if attempt == _MAX_RETRIES:
                    break
                delay = _BASE_DELAY * (2 ** attempt)
                logger.warning(
                    "Jira retry %d/%d sau %.1fs — %s",
                    attempt + 1, _MAX_RETRIES, delay, exc,
                )
                time.sleep(delay)

            except (JiraAuthError, JiraNotFoundError, JiraConnectorError):
                raise  # fatal, không retry

            except requests.Timeout as exc:
                last_exc = JiraNetworkError(
                    f"Timeout khi gọi {url}: {exc}", response_body=None
                )
                if attempt == _MAX_RETRIES:
                    break
                delay = _BASE_DELAY * (2 ** attempt)
                logger.warning("Jira timeout retry %d/%d", attempt + 1, _MAX_RETRIES)
                time.sleep(delay)

            except requests.ConnectionError as exc:
                last_exc = JiraNetworkError(
                    f"Lỗi kết nối đến {url}: {exc}", response_body=None
                )
                if attempt == _MAX_RETRIES:
                    break
                delay = _BASE_DELAY * (2 ** attempt)
                logger.warning("Jira connection error retry %d/%d", attempt + 1, _MAX_RETRIES)
                time.sleep(delay)

        raise last_exc  # type: ignore[misc]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def verify_connection(self) -> dict:
        """Xác thực kết nối bằng cách gọi /rest/api/2/serverInfo."""
        return self._get("/rest/api/2/serverInfo")

    def get_myself(self) -> dict:
        """Thông tin user ứng với PAT (GET /rest/api/2/myself)."""
        return self._get("/rest/api/2/myself")

    def update_issue(self, issue_key: str, fields: dict) -> None:
        """Cập nhật fields của issue (PUT /rest/api/2/issue/{key})."""
        self._put(f"/rest/api/2/issue/{issue_key}", json_body={"fields": fields})

    def search_issues(
        self,
        jql: str,
        start_at: int = 0,
        max_results: int = 100,
        fields: list[str] | None = None,
    ) -> dict:
        """JQL search với pagination.

        Returns:
            dict với keys: issues, total, startAt, maxResults
        """
        params: dict[str, Any] = {
            "jql": jql,
            "startAt": start_at,
            "maxResults": min(max_results, 100),
        }
        if fields:
            params["fields"] = ",".join(fields)
        return self._get("/rest/api/2/search", params=params)

    def get_issue(self, issue_key: str) -> dict:
        """Lấy chi tiết một issue theo key (ví dụ PROJ-123)."""
        return self._get(f"/rest/api/2/issue/{issue_key}")

    def create_issue(self, fields: dict) -> dict:
        """Tạo issue mới.

        Returns:
            dict với keys: id, key, self
        """
        return self._post("/rest/api/2/issue", json_body={"fields": fields})

    def add_remote_link(self, issue_key: str, url: str, title: str) -> dict:
        """Gắn remote link (Confluence, web) vào issue.

        Dùng Jira REST: ``POST /rest/api/2/issue/{issueKey}/remotelink``.
        """
        return self._post(
            f"/rest/api/2/issue/{issue_key}/remotelink",
            json_body={"object": {"url": url, "title": title}},
        )

    def list_remote_links(self, issue_key: str) -> list[dict]:
        """Danh sách remote link (web/Confluence) gắn với issue."""
        data = self._get(f"/rest/api/2/issue/{issue_key}/remotelink")
        return data if isinstance(data, list) else []

    def delete_remote_link(self, issue_key: str, link_id: int) -> None:
        """Xóa một remote link theo ``id`` trả về từ ``list_remote_links``."""
        url = self._url(f"/rest/api/2/issue/{issue_key}/remotelink/{link_id}")
        resp = self._session.delete(url, timeout=self._timeout)
        self._raise_for_status(resp)

    def get_transitions(self, issue_key: str) -> list[dict]:
        """Lấy danh sách transition khả dụng cho issue."""
        result = self._get(f"/rest/api/2/issue/{issue_key}/transitions")
        return result.get("transitions", [])

    def do_transition(self, issue_key: str, transition_id: str) -> None:
        """Thực hiện transition cho issue."""
        self._post(
            f"/rest/api/2/issue/{issue_key}/transitions",
            json_body={"transition": {"id": transition_id}},
        )

    def get_sprints(self, board_id: int) -> list[dict]:
        """Lấy danh sách sprint của một board (Agile API)."""
        result = self._get(f"/rest/agile/1.0/board/{board_id}/sprint")
        return result.get("values", [])
