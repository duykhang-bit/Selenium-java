"""Jenkins REST API connector."""

from __future__ import annotations

import time
from urllib.parse import urljoin

import requests

from app.core.logging import get_logger

logger = get_logger(__name__)


class JenkinsConnectionError(Exception):
    """Jenkins server không khả dụng hoặc credentials sai."""


class JenkinsJobNotFoundError(Exception):
    """Jenkins job không tồn tại."""


class JenkinsConnector:
    """Client gọi Jenkins REST API."""

    def __init__(self, base_url: str, username: str, token: str) -> None:
        self.base_url = base_url.rstrip("/")
        self._auth = (username, token)
        self._session = requests.Session()
        self._session.auth = self._auth

    def _get(self, path: str, **kwargs) -> requests.Response:
        url = f"{self.base_url}{path}"
        try:
            resp = self._session.get(url, timeout=kwargs.pop("timeout", 10), **kwargs)
        except requests.exceptions.ConnectionError as exc:
            raise JenkinsConnectionError(f"Cannot connect to Jenkins at {self.base_url}: {exc}") from exc
        except requests.exceptions.Timeout as exc:
            raise JenkinsConnectionError(f"Jenkins request timed out: {exc}") from exc
        return resp

    def _post(self, path: str, **kwargs) -> requests.Response:
        url = f"{self.base_url}{path}"
        try:
            resp = self._session.post(url, timeout=kwargs.pop("timeout", 10), **kwargs)
        except requests.exceptions.ConnectionError as exc:
            raise JenkinsConnectionError(f"Cannot connect to Jenkins at {self.base_url}: {exc}") from exc
        except requests.exceptions.Timeout as exc:
            raise JenkinsConnectionError(f"Jenkins request timed out: {exc}") from exc
        return resp

    def check_connection(self) -> bool:
        """Kiểm tra kết nối và credentials. Raise JenkinsConnectionError nếu thất bại."""
        resp = self._get("/api/json")
        if resp.status_code == 401:
            raise JenkinsConnectionError("Jenkins authentication failed — check username/token")
        if resp.status_code == 403:
            raise JenkinsConnectionError("Jenkins access forbidden — insufficient permissions")
        if not resp.ok:
            raise JenkinsConnectionError(f"Jenkins returned HTTP {resp.status_code}")
        return True

    def trigger_job(
        self,
        job_name: str,
        parameters: dict | None = None,
        poll_interval: int = 2,
        poll_timeout: int = 30,
    ) -> int:
        """Trigger Jenkins job và trả về build_number.

        Poll queue item cho đến khi build bắt đầu hoặc timeout.
        """
        path = f"/job/{job_name}/buildWithParameters" if parameters else f"/job/{job_name}/build"
        resp = self._post(path, data=parameters or {})

        if resp.status_code == 404:
            raise JenkinsJobNotFoundError(f"Jenkins job '{job_name}' not found")
        if not resp.ok and resp.status_code != 201:
            raise JenkinsConnectionError(f"Trigger failed: HTTP {resp.status_code}")

        # Lấy queue item URL từ Location header
        queue_url = resp.headers.get("Location", "")
        if not queue_url:
            raise JenkinsConnectionError("No Location header in trigger response")

        # Poll queue item để lấy build number
        queue_api = queue_url.rstrip("/") + "/api/json"
        deadline = time.monotonic() + poll_timeout
        while time.monotonic() < deadline:
            time.sleep(poll_interval)
            try:
                q_resp = self._session.get(queue_api, timeout=10)
                if q_resp.ok:
                    data = q_resp.json()
                    executable = data.get("executable")
                    if executable and executable.get("number"):
                        return int(executable["number"])
            except Exception:
                pass

        raise JenkinsConnectionError(f"Timed out waiting for build to start (job={job_name})")

    def get_build_status(self, job_name: str, build_number: int) -> dict:
        """Lấy build status từ Jenkins API."""
        resp = self._get(f"/job/{job_name}/{build_number}/api/json")
        if resp.status_code == 404:
            raise JenkinsJobNotFoundError(f"Build {job_name}#{build_number} not found")
        if not resp.ok:
            raise JenkinsConnectionError(f"HTTP {resp.status_code} getting build status")
        data = resp.json()
        result = data.get("result")  # None khi đang chạy
        return {
            "status": result if result else "RUNNING",
            "duration_ms": data.get("duration", 0),
            "timestamp": data.get("timestamp", 0),
            "url": data.get("url", ""),
            "display_name": data.get("displayName", f"#{build_number}"),
        }

    def get_build_log(self, job_name: str, build_number: int, max_bytes: int = 51200) -> str:
        """Lấy console log của build (giới hạn max_bytes)."""
        resp = self._get(
            f"/job/{job_name}/{build_number}/logText/progressiveText",
            params={"start": 0},
        )
        if resp.status_code == 404:
            raise JenkinsJobNotFoundError(f"Build {job_name}#{build_number} not found")
        if not resp.ok:
            raise JenkinsConnectionError(f"HTTP {resp.status_code} getting build log")
        return resp.text[:max_bytes]

    def list_jobs(self, folder: str | None = None) -> list[dict]:
        """List Jenkins jobs trong folder hoặc root."""
        path = f"/job/{folder}/api/json" if folder else "/api/json"
        resp = self._get(path, params={"tree": "jobs[name,url,color]"})
        if not resp.ok:
            raise JenkinsConnectionError(f"HTTP {resp.status_code} listing jobs")
        return resp.json().get("jobs", [])
