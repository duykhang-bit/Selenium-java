"""CLI entrypoint for AI Context Engine V2."""

from __future__ import annotations

import argparse
import json
import sys

from app.catalog.database import list_connectors, list_sources
from app.catalog.reports import export_git_sources_markdown
from app.ingest.store import list_collections
from app.sync.service import (
    bootstrap_from_env,
    create_jira_from_intent,
    discover_sources,
    initialize_runtime,
    link_dossier_to_jira,
    register_confluence_connector,
    register_connectors_from_env,
    register_gitlab_connector,
    register_jira_connector,
    reset_runtime_data,
    register_manual_confluence_source,
    register_manual_git_source,
    sync_all_confluence_sources,
    sync_all_git_sources,
    sync_all_sources,
    sync_and_ingest_source,
    sync_jira_sources,
)
from app.tasks.brief import build_task_brief
from app.tasks.dossier import create_task_dossier, get_task_dossier, update_task_plan, update_task_result
from app.tasks.jira_brief import build_brief_from_jira


def _redact_for_cli(value):
    """Strip secrets from structures printed as JSON (connectors store tokens)."""
    if isinstance(value, dict):
        return {
            k: ("***" if k in ("token", "password", "secret") else _redact_for_cli(v))
            for k, v in value.items()
        }
    if isinstance(value, list):
        return [_redact_for_cli(v) for v in value]
    return value


def _print_json(data) -> None:
    print(json.dumps(_redact_for_cli(data), ensure_ascii=False, indent=2))


def _configure_stdio() -> None:
    """Prefer UTF-8 console output so CLI JSON works on Windows terminals."""
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is None or not hasattr(stream, "reconfigure"):
            continue
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            continue


def add_confluence_window_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--cf-space-offset",
        type=int,
        default=0,
        help="Skip this many Confluence spaces (batch discover).",
    )
    parser.add_argument(
        "--cf-max-spaces",
        type=int,
        default=None,
        help="Discover at most this many Confluence spaces in this run.",
    )
    parser.add_argument(
        "--cf-max-pages-per-space",
        type=int,
        default=None,
        help="Cap pages fetched per space (default: all pages in that space).",
    )
    parser.add_argument(
        "--cf-max-pages-total",
        type=int,
        default=None,
        help="Stop after this many Confluence pages total in this run (across spaces).",
    )
    parser.add_argument(
        "--cf-estimate-only",
        action="store_true",
        help="Probe Confluence only: estimated page counts & ETA; skips GitLab discover and DB upserts.",
    )


def main() -> None:
    _configure_stdio()
    parser = argparse.ArgumentParser(description="AI Context Engine V2 CLI")
    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("init", help="Initialize data folders and catalog database")
    subparsers.add_parser("reset-data", help="Remove V2 runtime data and recreate an empty runtime state")
    subparsers.add_parser("setup-env", help="Register GitLab and Confluence connectors from .env")
    bootstrap = subparsers.add_parser("bootstrap", help="Run init + setup-env + discover-all (no sync by default)")
    bootstrap.add_argument("--collection", default="knowledge")
    bootstrap.add_argument(
        "--sync-git",
        action="store_true",
        help="Also sync+ingest all discovered Git repositories after bootstrap.",
    )
    bootstrap.add_argument(
        "--sync-confluence",
        action="store_true",
        help="Also sync+ingest all discovered Confluence pages after bootstrap.",
    )
    add_confluence_window_args(bootstrap)

    setup_gitlab = subparsers.add_parser("setup-gitlab", help="Register a GitLab connector")
    setup_gitlab.add_argument("--base-url", required=True)
    setup_gitlab.add_argument("--token", required=True)
    setup_gitlab.add_argument("--name", default=None)

    setup_confluence = subparsers.add_parser("setup-confluence", help="Register a Confluence connector")
    setup_confluence.add_argument("--base-url", required=True)
    setup_confluence.add_argument("--token", required=True)
    setup_confluence.add_argument("--name", default=None)
    setup_confluence.add_argument("--username", default="")

    discover_all = subparsers.add_parser("discover-all", help="Discover all sources from configured connectors")
    add_confluence_window_args(discover_all)

    discover = subparsers.add_parser("discover", help="Discover sources for a specific connector")
    discover.add_argument("connector_id", type=int)
    add_confluence_window_args(discover)

    add_git = subparsers.add_parser("add-git", help="Register a manual Git source")
    add_git.add_argument("repo_url")

    add_confluence = subparsers.add_parser("add-confluence", help="Register a manual Confluence page source")
    add_confluence.add_argument("page_url")

    sync_all = subparsers.add_parser(
        "sync-all",
        help="Sync+ingest all enabled sources (Git + Confluence by default)",
    )
    sync_all.add_argument("--collection", default="knowledge")
    sync_all.add_argument(
        "--git-only",
        action="store_true",
        help="Skip Confluence pages and process only Git repositories.",
    )

    sync_git = subparsers.add_parser(
        "sync-git-all",
        help="Sync+ingest all enabled Git repository sources only",
    )
    sync_git.add_argument("--collection", default="knowledge")

    sync_cf = subparsers.add_parser(
        "sync-confluence-all",
        help="Sync+ingest all enabled Confluence page sources only",
    )
    sync_cf.add_argument("--collection", default="knowledge")

    sync_one = subparsers.add_parser("sync-source", help="Sync and ingest a single source")
    sync_one.add_argument("source_id")
    sync_one.add_argument("--collection", default="knowledge")

    task_brief = subparsers.add_parser("task-brief", help="Build a task brief from indexed context")
    task_brief.add_argument("task")
    task_brief.add_argument("--collection", default="knowledge")
    task_brief.add_argument("--top-k", type=int, default=5)

    task_start = subparsers.add_parser("task-start", help="Build a task brief and persist a task dossier")
    task_start.add_argument("task")
    task_start.add_argument("--collection", default="knowledge")
    task_start.add_argument("--top-k", type=int, default=5)

    task_plan = subparsers.add_parser("task-plan", help="Update plan, scope, impact, and notes in a task dossier")
    task_plan.add_argument("task_id")
    task_plan.add_argument("--plan", default=None)
    task_plan.add_argument("--scope", default=None)
    task_plan.add_argument("--impact", default=None)
    task_plan.add_argument("--notes", default=None)
    task_plan.add_argument("--status", default="planned")
    task_plan.add_argument("--phase", default="planning")

    task_show = subparsers.add_parser("task-show", help="Show a persisted task dossier")
    task_show.add_argument("task_id")

    task_result = subparsers.add_parser("task-result", help="Update the final result section in a task dossier")
    task_result.add_argument("task_id")
    task_result.add_argument("--result", required=True)
    task_result.add_argument("--status", default="completed")
    task_result.add_argument("--phase", default="completed")

    subparsers.add_parser("list-connectors", help="List configured connectors")
    subparsers.add_parser("list-sources", help="List discovered sources")
    subparsers.add_parser("list-git-sources", help="List discovered Git repository sources")
    export_git_md = subparsers.add_parser("export-git-sources-md", help="Export discovered Git repository sources to Markdown")
    export_git_md.add_argument("--output", default=None)
    subparsers.add_parser("list-collections", help="List ChromaDB collections")

    # Jira commands
    jira_sync_p = subparsers.add_parser("jira-sync", help="Pull Jira issues vào ChromaDB")
    jira_sync_p.add_argument("--project-key", action="append", dest="project_keys", default=None,
                              help="Jira project key (có thể lặp lại nhiều lần)")
    jira_sync_p.add_argument("--collection", default="knowledge")

    jira_create_p = subparsers.add_parser("jira-create", help="Tạo Epic/Story/Sub-task từ intent")
    jira_create_p.add_argument("intent", help="Mô tả ý tưởng/yêu cầu")
    jira_create_p.add_argument("--project-key", required=True, dest="project_key")

    jira_brief_p = subparsers.add_parser("jira-brief", help="Sinh task brief từ Jira ticket")
    jira_brief_p.add_argument("issue_key", help="Jira issue key, ví dụ PROJ-123")
    jira_brief_p.add_argument("--collection", default="knowledge")
    jira_brief_p.add_argument("--top-k", type=int, default=5)

    # RDE commands
    rde_req_p = subparsers.add_parser("rde-requirements", help="Sinh tài liệu requirements từ intent")
    rde_req_p.add_argument("intent", help="Mô tả yêu cầu nghiệp vụ")
    rde_req_p.add_argument("--collection", default="knowledge")
    rde_req_p.add_argument("--publish", action="store_true", help="Publish lên Confluence")
    rde_req_p.add_argument("--space", default=None, dest="space_key", help="Confluence space key")

    rde_design_p = subparsers.add_parser("rde-design", help="Sinh tài liệu thiết kế từ requirements file")
    rde_design_p.add_argument("requirements_file", help="Đường dẫn file requirements")
    rde_design_p.add_argument("--publish", action="store_true", help="Publish lên Confluence")
    rde_design_p.add_argument("--space", default=None, dest="space_key", help="Confluence space key")

    rde_impact_p = subparsers.add_parser("rde-impact", help="Phân tích impact từ requirements file")
    rde_impact_p.add_argument("requirements_file", help="Đường dẫn file requirements")

    rde_compliance_p = subparsers.add_parser("rde-check-compliance", help="Kiểm tra compliance của document")
    rde_compliance_p.add_argument("doc_file", help="Đường dẫn file document")
    rde_compliance_p.add_argument("--type", required=True, dest="doc_type",
                                   choices=["requirements", "design"],
                                   help="Loại document: requirements hoặc design")

    # QGE commands
    qge_analyze_p = subparsers.add_parser("qge-analyze", help="Chạy quality gate trên code diff")
    qge_analyze_p.add_argument("diff_file", help="Đường dẫn file diff hoặc '-' để đọc từ stdin")
    qge_analyze_p.add_argument("--collection", default="knowledge")
    qge_analyze_p.add_argument("--gates", default=None, help="Danh sách gate cách nhau bởi dấu phẩy")

    qge_tests_p = subparsers.add_parser("qge-generate-tests", help="Sinh pytest skeleton từ code diff")
    qge_tests_p.add_argument("diff_file", help="Đường dẫn file diff hoặc '-' để đọc từ stdin")

    # Jenkins commands
    jenkins_trigger_p = subparsers.add_parser("jenkins-trigger", help="Trigger Jenkins pipeline")
    jenkins_trigger_p.add_argument("job_name", help="Tên Jenkins job")
    jenkins_trigger_p.add_argument("--param", action="append", dest="params", default=[], metavar="KEY=VALUE")

    jenkins_status_p = subparsers.add_parser("jenkins-status", help="Lấy build status")
    jenkins_status_p.add_argument("job_name")
    jenkins_status_p.add_argument("build_number", type=int)

    jenkins_log_p = subparsers.add_parser("jenkins-log", help="Lấy và phân tích build log")
    jenkins_log_p.add_argument("job_name")
    jenkins_log_p.add_argument("build_number", type=int)

    jenkins_deploys_p = subparsers.add_parser("jenkins-deployments", help="Xem lịch sử deployment")
    jenkins_deploys_p.add_argument("--service", default=None)
    jenkins_deploys_p.add_argument("--env", default=None, dest="environment")
    jenkins_deploys_p.add_argument("--limit", type=int, default=20)

    jenkins_record_p = subparsers.add_parser("jenkins-record-deploy", help="Ghi deployment record")
    jenkins_record_p.add_argument("service")
    jenkins_record_p.add_argument("environment")
    jenkins_record_p.add_argument("build_number", type=int)
    jenkins_record_p.add_argument("job_name")

    # CGP commands
    cgp_decompose_p = subparsers.add_parser("cgp-decompose", help="Phân tích design doc → coding tasks")
    cgp_decompose_p.add_argument("design_file", help="Đường dẫn file design doc")
    cgp_decompose_p.add_argument("--collection", default="knowledge")

    cgp_generate_p = subparsers.add_parser("cgp-generate", help="Sinh code cho một coding task")
    cgp_generate_p.add_argument("task_json_file", help="Đường dẫn file task JSON")
    cgp_generate_p.add_argument("--collection", default="knowledge")

    cgp_commit_p = subparsers.add_parser("cgp-commit-message", help="Sinh conventional commit message")
    cgp_commit_p.add_argument("diff_file", help="Đường dẫn file diff hoặc '-' để đọc từ stdin")
    cgp_commit_p.add_argument("--desc", default=None, dest="task_description")

    cgp_pipeline_p = subparsers.add_parser("cgp-run-pipeline", help="Chạy toàn bộ CGP pipeline")
    cgp_pipeline_p.add_argument("design_file", help="Đường dẫn file design doc")
    cgp_pipeline_p.add_argument("--source-id", required=True, dest="source_id")
    cgp_pipeline_p.add_argument("--branch", required=True, dest="branch_name")
    cgp_pipeline_p.add_argument("--collection", default="knowledge")
    cgp_pipeline_p.add_argument("--from-branch", default=None, dest="from_branch")

    # K8s commands
    k8s_helm_p = subparsers.add_parser("k8s-helm-values", help="Sinh Helm values.yaml")
    k8s_helm_p.add_argument("service_name")
    k8s_helm_p.add_argument("--image", required=True, dest="image_repository")
    k8s_helm_p.add_argument("--tag", required=True, dest="image_tag")
    k8s_helm_p.add_argument("--port", type=int, required=True)
    k8s_helm_p.add_argument("--env", default="uat", dest="environment")
    k8s_helm_p.add_argument("--ingress", default=None, dest="ingress_host")

    k8s_ci_p = subparsers.add_parser("k8s-promote-ci", help="Trigger Jenkins deploy-ci")
    k8s_ci_p.add_argument("service")
    k8s_ci_p.add_argument("--build", type=int, required=True, dest="build_number")
    k8s_ci_p.add_argument("--job", required=True, dest="jenkins_deploy_job")

    k8s_uat_p = subparsers.add_parser("k8s-promote-uat", help="Trigger Jenkins deploy-uat")
    k8s_uat_p.add_argument("service")
    k8s_uat_p.add_argument("--build", type=int, required=True, dest="build_number")
    k8s_uat_p.add_argument("--job", required=True, dest="jenkins_deploy_job")

    k8s_prod_p = subparsers.add_parser("k8s-prod-gate", help="Sinh PROD promotion checklist")
    k8s_prod_p.add_argument("service")
    k8s_prod_p.add_argument("--build", type=int, required=True, dest="build_number")
    k8s_prod_p.add_argument("--job", default="", dest="jenkins_deploy_job")

    k8s_corr_p = subparsers.add_parser("k8s-correlate", help="Correlate incident với deployment")
    k8s_corr_p.add_argument("service")
    k8s_corr_p.add_argument("--time", required=True, dest="incident_time")
    k8s_corr_p.add_argument("--collection", default="knowledge")

    # Observability commands
    obs_audit_p = subparsers.add_parser("obs-audit-logs", help="Query unified audit logs")
    obs_audit_p.add_argument("--type", action="append", dest="event_types", default=None)
    obs_audit_p.add_argument("--since", default=None)
    obs_audit_p.add_argument("--until", default=None)
    obs_audit_p.add_argument("--trace", default=None, dest="trace_id")
    obs_audit_p.add_argument("--limit", type=int, default=100)
    obs_audit_p.add_argument("--format", default="json", choices=["json", "csv"])

    obs_score_p = subparsers.add_parser("obs-score", help="Tính confidence score cho AI output")
    obs_score_p.add_argument("output_type")
    obs_score_p.add_argument("content_file", help="Đường dẫn file content hoặc '-' cho stdin")

    obs_req_p = subparsers.add_parser("obs-request-approval", help="Tạo approval request")
    obs_req_p.add_argument("action_type")
    obs_req_p.add_argument("--desc", required=True, dest="description")
    obs_req_p.add_argument("--payload", default="{}", dest="payload_json")
    obs_req_p.add_argument("--by", default="system", dest="requested_by")

    obs_list_p = subparsers.add_parser("obs-list-approvals", help="List pending approvals")
    obs_list_p.add_argument("--type", default=None, dest="action_type")

    obs_approve_p = subparsers.add_parser("obs-approve", help="Approve một request")
    obs_approve_p.add_argument("request_id")
    obs_approve_p.add_argument("--by", required=True, dest="approved_by")
    obs_approve_p.add_argument("--comment", default="")

    obs_reject_p = subparsers.add_parser("obs-reject", help="Reject một request")
    obs_reject_p.add_argument("request_id")
    obs_reject_p.add_argument("--by", required=True, dest="rejected_by")
    obs_reject_p.add_argument("--comment", default="")

    args = parser.parse_args()
    initialize_runtime()

    if args.command == "init":
        print("Initialized AI Context Engine V2")
    elif args.command == "reset-data":
        _print_json(reset_runtime_data())
    elif args.command == "setup-env":
        _print_json(register_connectors_from_env())
    elif args.command == "bootstrap":
        _print_json(
            bootstrap_from_env(
                collection_name=args.collection,
                confluence_space_offset=args.cf_space_offset,
                confluence_max_spaces=args.cf_max_spaces,
                confluence_max_pages_per_space=args.cf_max_pages_per_space,
                confluence_max_pages_total=args.cf_max_pages_total,
                confluence_estimate_only=args.cf_estimate_only,
                include_git_in_sync=args.sync_git,
                include_confluence_in_sync=args.sync_confluence,
            )
        )
    elif args.command == "setup-gitlab":
        _print_json(register_gitlab_connector(args.base_url, args.token, name=args.name))
    elif args.command == "setup-confluence":
        _print_json(register_confluence_connector(args.base_url, args.token, name=args.name, username=args.username))
    elif args.command == "discover-all":
        _print_json(
            discover_sources(
                None,
                confluence_space_offset=args.cf_space_offset,
                confluence_max_spaces=args.cf_max_spaces,
                confluence_max_pages_per_space=args.cf_max_pages_per_space,
                confluence_max_pages_total=args.cf_max_pages_total,
                confluence_estimate_only=args.cf_estimate_only,
            )
        )
    elif args.command == "discover":
        _print_json(
            discover_sources(
                args.connector_id,
                confluence_space_offset=args.cf_space_offset,
                confluence_max_spaces=args.cf_max_spaces,
                confluence_max_pages_per_space=args.cf_max_pages_per_space,
                confluence_max_pages_total=args.cf_max_pages_total,
                confluence_estimate_only=args.cf_estimate_only,
            )
        )
    elif args.command == "add-git":
        _print_json(register_manual_git_source(args.repo_url))
    elif args.command == "add-confluence":
        _print_json(register_manual_confluence_source(args.page_url))
    elif args.command == "sync-all":
        _print_json(
            sync_all_sources(
                collection_name=args.collection,
                include_confluence=not args.git_only,
            )
        )
    elif args.command == "sync-git-all":
        _print_json(sync_all_git_sources(collection_name=args.collection))
    elif args.command == "sync-confluence-all":
        _print_json(sync_all_confluence_sources(collection_name=args.collection))
    elif args.command == "sync-source":
        _print_json(sync_and_ingest_source(args.source_id, collection_name=args.collection))
    elif args.command == "task-brief":
        print(build_task_brief(args.task, args.collection, top_k=args.top_k)["brief"])
    elif args.command == "task-start":
        _print_json(create_task_dossier(args.task, args.collection, top_k=args.top_k))
    elif args.command == "task-plan":
        _print_json(
            update_task_plan(
                args.task_id,
                plan=args.plan,
                scope=args.scope,
                impact=args.impact,
                notes=args.notes,
                status=args.status,
                phase=args.phase,
            )
        )
    elif args.command == "task-show":
        _print_json(get_task_dossier(args.task_id))
    elif args.command == "task-result":
        _print_json(
            update_task_result(
                args.task_id,
                result=args.result,
                status=args.status,
                phase=args.phase,
            )
        )
    elif args.command == "list-connectors":
        _print_json(list_connectors())
    elif args.command == "list-sources":
        _print_json(list_sources())
    elif args.command == "list-git-sources":
        _print_json(list_sources(source_type="git_repo"))
    elif args.command == "export-git-sources-md":
        _print_json(export_git_sources_markdown(output_path=args.output))
    elif args.command == "list-collections":
        _print_json(list_collections())
    elif args.command == "jira-sync":
        _print_json(sync_jira_sources(project_keys=args.project_keys, collection_name=args.collection))
    elif args.command == "jira-create":
        _print_json(create_jira_from_intent(args.intent, args.project_key))
    elif args.command == "jira-brief":
        result = build_brief_from_jira(args.issue_key, args.collection, top_k=args.top_k)
        print(result["brief"])
    elif args.command == "rde-requirements":
        import dataclasses
        from app.tasks.requirement_generator import generate_requirements
        from app.tasks.confluence_writer import write_document
        result = generate_requirements(args.intent, collection_name=args.collection)
        print(result.document)
        if args.publish and args.space_key:
            title = result.document.splitlines()[0].lstrip("# ").strip()
            write_result = write_document(title, result.document, args.space_key)
            print(f"\nPublished to Confluence: {write_result.page_url}")
        _print_json({
            "domains": result.domains,
            "compliance_passed": result.compliance_report.passed,
            "violations": [dataclasses.asdict(v) for v in result.compliance_report.violations],
            "trace_id": result.trace_id,
        })
    elif args.command == "rde-design":
        import dataclasses
        from pathlib import Path as _Path
        from app.tasks.design_generator import generate_design
        from app.tasks.confluence_writer import write_document
        req_content = _Path(args.requirements_file).read_text(encoding="utf-8")
        result = generate_design(req_content)
        print(result.document)
        if args.publish and args.space_key:
            title = result.document.splitlines()[0].lstrip("# ").strip()
            write_result = write_document(title, result.document, args.space_key)
            print(f"\nPublished to Confluence: {write_result.page_url}")
        _print_json({
            "domains": result.domains,
            "compliance_passed": result.compliance_report.passed,
            "trace_id": result.trace_id,
        })
    elif args.command == "rde-impact":
        import dataclasses
        from pathlib import Path as _Path
        from app.tasks.impact_analyzer import analyze_impact
        req_content = _Path(args.requirements_file).read_text(encoding="utf-8")
        result = analyze_impact(req_content)
        _print_json(dataclasses.asdict(result))
    elif args.command == "rde-check-compliance":
        import dataclasses
        from pathlib import Path as _Path
        from app.tasks.compliance_checker import check_requirements, check_design
        from app.tasks.domain_detector import detect_domains
        doc_content = _Path(args.doc_file).read_text(encoding="utf-8")
        detection = detect_domains(doc_content)
        if args.doc_type == "requirements":
            report = check_requirements(doc_content, detection.domains)
        else:
            report = check_design(doc_content, detection.domains)
        _print_json(dataclasses.asdict(report))
    elif args.command == "qge-analyze":
        import dataclasses
        import sys
        from pathlib import Path as _Path
        from app.tasks.quality_gate.gate_runner import run_all_gates
        if args.diff_file == "-":
            diff_text = sys.stdin.read()
        else:
            diff_text = _Path(args.diff_file).read_text(encoding="utf-8")
        gates = args.gates.split(",") if args.gates else None
        report = run_all_gates(diff_text, collection_name=args.collection, enabled_gates=gates)
        _print_json({
            "overall": report.overall,
            "total_critical": report.total_critical,
            "total_high": report.total_high,
            "total_medium": report.total_medium,
            "total_low": report.total_low,
            "risk_score": report.risk_score,
            "findings": [dataclasses.asdict(f) for f in report.all_findings],
        })
    elif args.command == "qge-generate-tests":
        import sys
        from pathlib import Path as _Path
        from app.tasks.quality_gate.diff_parser import parse_diff
        from app.tasks.quality_gate.test_generator import generate_tests
        if args.diff_file == "-":
            diff_text = sys.stdin.read()
        else:
            diff_text = _Path(args.diff_file).read_text(encoding="utf-8")
        print(generate_tests(parse_diff(diff_text)))
    elif args.command == "jenkins-trigger":
        import dataclasses
        from app.tasks.jenkins.trigger import trigger_pipeline
        params = dict(p.split("=", 1) for p in args.params if "=" in p)
        _print_json(dataclasses.asdict(trigger_pipeline(args.job_name, parameters=params or None)))
    elif args.command == "jenkins-status":
        from app.connectors.jenkins import JenkinsConnector
        from app.core.config import settings
        connector = JenkinsConnector(settings.jenkins_base_url, settings.jenkins_username, settings.jenkins_token)
        _print_json(connector.get_build_status(args.job_name, args.build_number))
    elif args.command == "jenkins-log":
        import dataclasses
        from app.connectors.jenkins import JenkinsConnector
        from app.core.config import settings
        from app.tasks.jenkins.log_analyzer import analyze_log
        connector = JenkinsConnector(settings.jenkins_base_url, settings.jenkins_username, settings.jenkins_token)
        log = connector.get_build_log(args.job_name, args.build_number)
        analysis = analyze_log(log)
        _print_json(dataclasses.asdict(analysis))
    elif args.command == "jenkins-deployments":
        import dataclasses
        from app.tasks.jenkins.tracker import get_deployments
        records = get_deployments(service=args.service, environment=args.environment, limit=args.limit)
        _print_json([dataclasses.asdict(r) for r in records])
    elif args.command == "jenkins-record-deploy":
        import dataclasses
        from app.tasks.jenkins.tracker import record_deployment
        rec = record_deployment(args.service, args.environment, args.build_number, args.job_name, "success")
        _print_json(dataclasses.asdict(rec))
    elif args.command == "cgp-decompose":
        import dataclasses
        from pathlib import Path as _Path
        from app.tasks.code_gen.decomposer import decompose
        design = _Path(args.design_file).read_text(encoding="utf-8")
        tasks = decompose(design, args.collection)
        _print_json([dataclasses.asdict(t) for t in tasks])
    elif args.command == "cgp-generate":
        import dataclasses, json as _json
        from pathlib import Path as _Path
        from app.tasks.code_gen.models import CodingTask
        from app.tasks.code_gen.generator import generate
        task_dict = _json.loads(_Path(args.task_json_file).read_text(encoding="utf-8"))
        task = CodingTask(**task_dict)
        result = generate(task, args.collection)
        print(result.content)
    elif args.command == "cgp-commit-message":
        import sys
        from pathlib import Path as _Path
        from app.tasks.code_gen.commit_message import generate_message
        diff_text = sys.stdin.read() if args.diff_file == "-" else _Path(args.diff_file).read_text(encoding="utf-8")
        print(generate_message(diff_text, args.task_description))
    elif args.command == "cgp-run-pipeline":
        import dataclasses
        from pathlib import Path as _Path
        from app.tasks.code_gen.pipeline import run_pipeline
        design = _Path(args.design_file).read_text(encoding="utf-8")
        result = run_pipeline(design, args.source_id, args.branch_name, args.collection, args.from_branch)
        _print_json({
            "tasks_count": len(result.tasks),
            "files_generated": len(result.generated_files),
            "mr_url": result.mr_result.mr_url if result.mr_result else None,
            "errors": result.errors,
            "trace_id": result.trace_id,
        })
    elif args.command == "k8s-helm-values":
        import dataclasses
        from app.tasks.k8s.helm_generator import generate_helm_values
        result = generate_helm_values(
            service_name=args.service_name, image_repository=args.image_repository,
            image_tag=args.image_tag, port=args.port, environment=args.environment,
            ingress_host=args.ingress_host,
        )
        print(result.content)
    elif args.command == "k8s-promote-ci":
        import dataclasses
        from app.tasks.k8s.ci_promoter import promote_to_ci
        _print_json(dataclasses.asdict(promote_to_ci(args.service, args.build_number, args.jenkins_deploy_job)))
    elif args.command == "k8s-promote-uat":
        import dataclasses
        from app.tasks.k8s.uat_promoter import promote_to_uat
        _print_json(dataclasses.asdict(promote_to_uat(args.service, args.build_number, args.jenkins_deploy_job)))
    elif args.command == "k8s-prod-gate":
        import dataclasses
        from app.tasks.k8s.prod_gate import check_prod_gate
        result = check_prod_gate(args.service, args.build_number, args.jenkins_deploy_job)
        _print_json(dataclasses.asdict(result))
    elif args.command == "k8s-correlate":
        import dataclasses
        from app.tasks.k8s.incident_correlator import correlate_incident
        _print_json(dataclasses.asdict(correlate_incident(args.service, args.incident_time, args.collection)))
    elif args.command == "obs-audit-logs":
        from app.tasks.observability.audit_query import query_audit_logs, export_audit_logs
        events = query_audit_logs(
            event_types=args.event_types, since=args.since, until=args.until,
            trace_id=args.trace_id, limit=args.limit,
        )
        print(export_audit_logs(events, args.format))
    elif args.command == "obs-score":
        import dataclasses, sys
        from pathlib import Path as _Path
        from app.tasks.observability.confidence import score_confidence
        content = sys.stdin.read() if args.content_file == "-" else _Path(args.content_file).read_text(encoding="utf-8")
        _print_json(dataclasses.asdict(score_confidence(args.output_type, content)))
    elif args.command == "obs-request-approval":
        import json as _json
        from app.tasks.observability.hitl_gate import request_approval
        payload = _json.loads(args.payload_json)
        rid = request_approval(args.action_type, args.description, payload, args.requested_by)
        _print_json({"request_id": rid})
    elif args.command == "obs-list-approvals":
        import dataclasses
        from app.tasks.observability.hitl_gate import list_pending
        _print_json([dataclasses.asdict(r) for r in list_pending(args.action_type)])
    elif args.command == "obs-approve":
        import dataclasses
        from app.tasks.observability.hitl_gate import approve
        _print_json(dataclasses.asdict(approve(args.request_id, args.approved_by, args.comment)))
    elif args.command == "obs-reject":
        import dataclasses
        from app.tasks.observability.hitl_gate import reject
        _print_json(dataclasses.asdict(reject(args.request_id, args.rejected_by, args.comment)))
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
