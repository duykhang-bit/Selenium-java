# AI-CONTEXT-ENGINE-V2

## 🚀 Tổng quan

AI-CONTEXT-ENGINE-V2 là bộ não trung tâm của toàn bộ SDLC — từ ý tưởng đến production. Hệ thống tích hợp GitLab, Confluence, Jira, Jenkins và K8s để tự động hoá quy trình phát triển phần mềm.

### 🎯 7 Modules

| Module | Chức năng |
|--------|-----------|
| **Module 1** — Jira Integration | Đọc/ghi Jira tickets, sync context vào ChromaDB |
| **Module 2** — Requirement & Design Engine | Sinh BRD/PRD, HLD/LLD/ERD/OpenAPI từ intent |
| **Module 3** — Quality Gate Engine | SAST, secret detection, code quality, test generator |
| **Module 4** — Jenkins Integration | Trigger pipeline, đọc build log, quality gate webhook |
| **Module 5** — Code Generation Pipeline | Decompose design → sinh code → tạo branch/MR |
| **Module 6** — K8s & Deployment Intelligence | Helm values, CI→UAT→PROD promotion, incident correlation |
| **Module 7** — Observability | Unified audit log, confidence scoring, HITL approval |

### 📚 Tài liệu

- **Onboarding (người mới — ưu tiên Cursor/Kiro/Antigravity + prompt mẫu)**: `docs/onboarding-new-developer.md`
- **Local setup (chi tiết)**: `docs/local-setup-guide.md`
- **DevOps setup**: `docs/devops-setup-guide.md`
- **Deploy V2 production (VM/Compose)**: `docs/deploy-v2-production-guide.md`
- **Developer guide**: `docs/developer-guide.md`
- **MCP tools reference**: `MCP_GUIDE.md`
- **Daily runbook**: `RUNBOOK.md`

---

## 🧠 Flow thực thi chi tiết

```mermaid
flowchart LR
subgraph INPUT["User Input"]
    U[User Chat Request]
end
subgraph CONNECTORS["Connectors"]
    G[GitLab API]
    C[Confluence API]
end
subgraph DISCOVERY["Discovery Layer"]
    D1[Discover Repos]
    D2[Discover Pages]
end
subgraph CATALOG["Catalog"]
    DB[(catalog.db)]
end
subgraph SYNC["Sync Layer"]
    S1[Clone / Pull Repo]
    S2[Fetch Confluence Page]
end
subgraph WORKSPACE["Local Workspace"]
    W1[data/workspaces/repos]
    W2[data/workspaces/confluence]
end
subgraph INGEST["Ingest Pipeline"]
    I1[Read Files]
    I2[Chunking]
    I3[Metadata Tagging]
    I4[Embedding]
end
subgraph VECTOR["Vector Store"]
    V[(ChromaDB)]
end
subgraph RETRIEVAL["Retrieval"]
    R1[Search Context]
end
subgraph TASK["Task Engine"]
    T1[Repo Ranking]
    T2[Context Selection]
    T3[Task Brief Builder]
end
subgraph AGENT["AI Agent"]
    A1[Analyze]
    A2[Plan]
    A3[Code]
    A4[Test]
end
U --> T1
G --> D1 --> DB
C --> D2 --> DB
DB --> S1
DB --> S2
S1 --> W1
S2 --> W2
W1 --> I1
W2 --> I1
I1 --> I2 --> I3 --> I4 --> V
T1 --> R1 --> V
R1 --> T2 --> T3
T3 --> A1 --> A2 --> A3 --> A4
```

---

## ⚙️ Cài đặt

### Yêu cầu

- Python 3.11+
- Git

### Cài dependencies

```bash
pip install -r requirements.txt
```

---

## 🔐 Cấu hình bảo mật & Credentials

> **Thông tin nhạy cảm (GitLab token, Confluence token) được mã hoá Fernet trước khi lưu vào `catalog.db`.**
> Không bao giờ commit file `.env` vào git.

### Bước 1 – Tạo file `.env` từ template

```bash
cp .env.example .env
```

### Bước 2 – Tạo Secret Key (bắt buộc cho production)

Key này dùng để mã hoá token GitLab/Confluence trong database. Chạy lệnh sau để tạo:

```bash
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Sao chép output và điền vào `.env`:

```env
AI_CONTEXT_V2_SECRET_KEY=your-generated-key-here
```

> **Lưu ý:** Nếu để trống, hệ thống vẫn chạy được nhưng token sẽ được lưu dạng `plain:` (plaintext).
> Chỉ chấp nhận được trong môi trường dev local — **không dùng cho production**.

### Bước 3 – Tạo Personal Access Token

#### GitLab Token

Truy cập: `https://<gitlab-host>/-/user_settings/personal_access_tokens`

**Scopes cần thiết:**
- ✅ `api` (hoặc tối thiểu `read_api`)

```env
AI_CONTEXT_V2_GITLAB_BASE_URL=https://git2.fptshop.com.vn
AI_CONTEXT_V2_GITLAB_TOKEN=glpat-xxxxxxxxxxxxxxxxxxxx
AI_CONTEXT_V2_GITLAB_NAME=GitLab
AI_CONTEXT_V2_GITLAB_EXCLUDED_GROUPS=devops-common
```

#### Confluence Token

Truy cập: `https://<confluence-host>/plugins/personalaccesstokens/usertokens.action`

**Tạo token:**
- Name: `ai-context-v2`
- Copy token sau khi tạo (chỉ hiện 1 lần)

```env
AI_CONTEXT_V2_CONFLUENCE_BASE_URL=https://confluence.frt.vn
AI_CONTEXT_V2_CONFLUENCE_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
AI_CONTEXT_V2_CONFLUENCE_USERNAME=your-username-or-email
AI_CONTEXT_V2_CONFLUENCE_NAME=Confluence
```

### Bước 4 (Tùy chọn) – Bật API Authentication

Nếu cần bảo vệ REST API bằng API key (khuyến nghị khi expose ra khỏi máy local):

```bash
# Tạo một API key bất kỳ (ví dụ dùng openssl)
openssl rand -hex 32
```

Điền vào `.env`:

```env
AI_CONTEXT_V2_API_KEY=your-api-key-here
```

Sau đó mọi request phải kèm header:

```
X-API-Key: your-api-key-here
```

> **Để trống `AI_CONTEXT_V2_API_KEY`** = tắt authentication (mặc định, phù hợp
> internal network hoặc dev local).

### File `.env` mẫu đầy đủ

```env
# Server
AI_CONTEXT_V2_API_HOST=0.0.0.0
AI_CONTEXT_V2_API_PORT=8100
AI_CONTEXT_V2_LOG_LEVEL=INFO

# Security
AI_CONTEXT_V2_SECRET_KEY=<output của lệnh generate key ở trên>
AI_CONTEXT_V2_API_KEY=                          # để trống = tắt auth

# Embedding & Chunking
AI_CONTEXT_V2_EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2
AI_CONTEXT_V2_CHUNK_SIZE=350
AI_CONTEXT_V2_CHUNK_OVERLAP=70
AI_CONTEXT_V2_REPO_CHUNK_SIZE=350
AI_CONTEXT_V2_REPO_CHUNK_OVERLAP=70
AI_CONTEXT_V2_CONFLUENCE_CHUNK_SIZE=700
AI_CONTEXT_V2_CONFLUENCE_CHUNK_OVERLAP=140

# GitLab
AI_CONTEXT_V2_GITLAB_NAME=GitLab
AI_CONTEXT_V2_GITLAB_BASE_URL=https://git2.fptshop.com.vn
AI_CONTEXT_V2_GITLAB_TOKEN=glpat-xxxxxxxxxxxxxxxxxxxx
AI_CONTEXT_V2_GITLAB_EXCLUDED_GROUPS=devops-common

# Confluence
AI_CONTEXT_V2_CONFLUENCE_NAME=Confluence
AI_CONTEXT_V2_CONFLUENCE_BASE_URL=https://confluence.frt.vn
AI_CONTEXT_V2_CONFLUENCE_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
AI_CONTEXT_V2_CONFLUENCE_USERNAME=your-username
```

---

## 🔄 Khởi động hệ thống

### Lần đầu (Bootstrap)

```bash
# 1. Khởi tạo database và thư mục
python -m app.cli bootstrap

# 2. (Tuỳ chọn) Sync ngay toàn bộ Git repos
python -m app.cli bootstrap --sync-git

# 3. (Tuỳ chọn) Sync ngay cả Confluence
python -m app.cli bootstrap --sync-git --sync-confluence
```

### Reset dữ liệu (nếu muốn bắt đầu lại)

```bash
python -m app.cli reset-data
python -m app.cli bootstrap
```

> ⚠️ `reset-data` sẽ xoá toàn bộ `catalog.db`, `chroma/`, `workspaces/`.
> Sau đó cần bootstrap và sync lại từ đầu.

---

## ➕ Thêm source thủ công

### Git Repository

```bash
# Thêm và sync một repo cụ thể
python -m app.cli add-git "https://git2.fptshop.com.vn/dx-ict-projects/ict-pricing-api"
python -m app.cli list-sources
python -m app.cli sync-source "<source_id>"
```

### Confluence Page

```bash
# Thêm và sync một trang Confluence
python -m app.cli add-confluence "https://confluence.frt.vn/spaces/ICT/pages/144019569"
python -m app.cli sync-source "confluence:144019569"
```

---

## 🔄 Sync định kỳ

```bash
# Sync tất cả (Git + Confluence) — chỉ sync repo có commit mới
python -m app.cli sync-all

# Sync chỉ Git
python -m app.cli sync-git-all

# Sync chỉ Confluence
python -m app.cli sync-confluence-all

# Force sync một source cụ thể
python -m app.cli sync-source "<source_id>"
```

> **Smart re-sync:** Hệ thống tự động so sánh SHA commit mới nhất trên remote
> với SHA đã ingest. Repo không có commit mới sẽ được **bỏ qua tự động** để
> tiết kiệm thời gian.

---

## 📋 Task Brief

```bash
# Tạo task brief từ context (dùng trước khi code)
python -m app.cli task-brief "thêm field extraInfo vào OMS order response"

# Bắt đầu task với dossier đầy đủ
python -m app.cli task-start "thêm field extraInfo vào OMS order response"

# Xem dossier của task
python -m app.cli task-show "<task_id>"

# Cập nhật plan
python -m app.cli task-plan "<task_id>" --plan "..." --scope "..." --impact "..."

# Ghi nhận kết quả
python -m app.cli task-result "<task_id>" --result "Đã implement và test xong"
```

---

## 🌐 REST API

Khởi động server:

```bash
python -m app.main
# hoặc
uvicorn app.main:app --host 0.0.0.0 --port 8100 --reload
```

Swagger UI: `http://localhost:8100/docs`

### Các endpoint chính

| Method | Endpoint | Mô tả |
|--------|----------|-------|
| `POST` | `/api/setup/gitlab` | Đăng ký GitLab connector |
| `POST` | `/api/setup/confluence` | Đăng ký Confluence connector |
| `POST` | `/api/discover/all` | Discover tất cả sources |
| `POST` | `/api/sync/all` | Sync + ingest tất cả sources |
| `POST` | `/api/sync/source/{source_id}` | Sync một source cụ thể |
| `GET` | `/api/search?q=...` | Tìm kiếm context |
| `POST` | `/api/tasks/brief` | Tạo task brief |
| `POST` | `/api/tasks/start` | Tạo task dossier |
| `GET` | `/api/tasks/{task_id}` | Xem task dossier |

### Gọi API khi có X-API-Key

```bash
# Khi AI_CONTEXT_V2_API_KEY được set
curl -H "X-API-Key: your-api-key" http://localhost:8100/api/health

# Khi không set AI_CONTEXT_V2_API_KEY (mặc định)
curl http://localhost:8100/api/health
```

---

## 🤖 MCP Server (cho AI Coding Agent)

Khởi động MCP server (port 3000):

```bash
python -m app.mcp_server
```

### Các MCP Tools

| Tool | Mô tả |
|------|-------|
| `search_context` | Tìm kiếm context từ Git + Confluence |
| `list_sources` | Liệt kê tất cả sources đã index |
| `get_confluence_page` | Đọc nội dung một trang Confluence |
| `get_repo_structure` | Xem cấu trúc thư mục và lệnh build của repo |
| `sync_sources` | Sync một source cụ thể |
| `get_task_brief` | Tạo task brief từ context |

### Cấu hình Cursor / Windsurf / Claude Desktop

Thêm vào cấu hình MCP client:

```json
{
  "mcpServers": {
    "ai-context-engine": {
      "url": "http://localhost:3000/mcp"
    }
  }
}
```

---

## 📦 Workspace & Dữ liệu

```
data/
├── catalog.db              ← Nguồn sự thật (connectors, sources, sync runs)
├── chroma/                 ← Vector store (ChromaDB)
├── workspaces/
│   ├── repos/<org>/<project>/<repo>    ← Git repos đã clone
│   └── confluence/<space>/<page_id>.html
├── tasks/
│   └── <year>/<year-month>/<task-id>/
│       ├── task.json
│       ├── brief.md
│       ├── plan.md
│       ├── scope.md
│       ├── impact.md
│       ├── notes.md
│       ├── result.md
│       └── timeline.jsonl
└── logs/
```

### Chunking notes

| Biến | Dùng cho |
|------|----------|
| `AI_CONTEXT_V2_REPO_CHUNK_SIZE` / `OVERLAP` | Source code và tài liệu trong repo |
| `AI_CONTEXT_V2_CONFLUENCE_CHUNK_SIZE` / `OVERLAP` | Nội dung Confluence |
| `AI_CONTEXT_V2_CHUNK_SIZE` / `OVERLAP` | Fallback nếu chưa khai báo biến riêng |

Khuyến nghị: repo/source code chunk nhỏ (350), Confluence chunk lớn hơn (700) để giữ business context liền mạch.

---

## 📦 Migration dữ liệu

| Mục đích | Cần copy |
|----------|----------|
| Chỉ cần Search context | `data/chroma/`, `data/catalog.db` |
| Tiếp tục implement code | + `data/workspaces/repos/`, `data/workspaces/confluence/` |

---

## 🐳 Docker

```bash
# Build và chạy
docker-compose up -d

# Xem logs
docker-compose logs -f
```

> Đảm bảo file `.env` đã được tạo và có đủ thông tin trước khi chạy Docker.

---

## ⚠️ Nguyên tắc quan trọng

- ChromaDB chỉ để tìm context — **không sửa code từ vector chunk**
- Repo thật trong `data/workspaces/repos/` mới là nơi đọc và sửa code
- Không code khi chưa có context và task brief
- Luôn sync repo về latest trước khi implement

---

## 💡 Core Principle

```mermaid
flowchart LR
A[User] --> B[Task Brief]
B --> C[Context]
C --> D[Understanding]
D --> E[Real Repo]
E --> F[Modify Code]
```

👉 **Context để hiểu — Repo để sửa**
