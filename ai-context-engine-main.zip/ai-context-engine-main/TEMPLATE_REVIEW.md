# TEMPLATE_REVIEW.md

## Mục tiêu

Template này dùng khi user muốn review thay đổi, review bugfix, hoặc review
plan trước khi code.

## Cách dùng

Trong chat, nhập:

```text
@TEMPLATE_REVIEW.md
<nội dung cần review>
```

Ví dụ:

```text
@TEMPLATE_REVIEW.md
Review thay đổi cho task [OMS] Cung cấp API tạo đơn hàng Service
```

## Yêu cầu bắt buộc

1. Nếu task chưa có dossier thì tạo dossier trước để lưu review context.
2. Xác định repo, file, và phạm vi thay đổi liên quan.
3. Tập trung review theo thứ tự:
   - bug/risk
   - behavioral regression
   - missing validation/business rule
   - missing test
4. Nếu review cho code:
   - đọc file thật trong `data/workspaces/repos/...`
   - không review chỉ dựa trên vector chunk
5. Nếu review cho plan:
   - đánh giá thiếu context, scope, impact, rủi ro
6. Không ưu tiên văn phong hay style nếu chưa xử lý rủi ro chức năng.

## Output bắt buộc

1. Findings theo mức độ ưu tiên
2. File chính liên quan
3. Rủi ro còn lại
4. Thiếu test hoặc thiếu context
5. Tóm tắt ngắn cuối cùng

## Prompt chuẩn

```text
Review nội dung dưới đây theo mindset review kỹ thuật. Hãy ưu tiên tìm bug, rủi ro, regression, thiếu business rule, thiếu validation và thiếu test. Nếu cần đọc code thì phải đọc file thật trong data/workspaces/repos. Nếu chưa đủ context thì nêu rõ phần còn thiếu thay vì đoán.
```
