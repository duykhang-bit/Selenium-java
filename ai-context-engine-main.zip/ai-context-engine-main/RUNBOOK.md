# Runbook — AI Context Engine V2

Hướng dẫn vận hành hàng ngày. Xem thêm:
- **DevOps setup**: `docs/devops-setup-guide.md`
- **Developer guide**: `docs/developer-guide.md`

## Quick Start

Bước 0: setup Python

Bước 1: đọc Readme.md (lấy token: git, conflu)
Bước 2: đọc Runbook.md

Bước 3:
+ mở cursor/codex => (@Readme.md) setup môi trường giúp tôi => Done
+ git2.fptshop.vn (link source) => Nạp giúp tôi git này
+ conflu.vn (Link tài liệu) => Nạp giúp tôi tài liệu này

[ Prompts ngôn ngữ tự nhiên là nó tự chạy không cần chạy lệnh CLI ]

Lưu ý: Khi yêu cầu phân tích task / làm task => Luôn (@Agents.md) => Prompts Nội dung => IDE sẽ tự chạy theo role (lấy context liên quan vừa nạp vào => plan => xử lý)

---

## 0. Setup lần đầu

```bash
cp .env.example .env
# Điền token GitLab, Confluence, Jira, Jenkins vào .env

python -m app.cli bootstrap
```

---

## 1. Khởi động server

```bash
# MCP Server (port 3000) — cho AI coding tools
python -m app.mcp_server

# REST API (port 8100) — cho web UI, CI/CD
python -m app.main

# Docker
docker compose up -d
```

---

## 2. Quản lý sources

```bash
# Thêm Git repo
python -m app.cli add-git "https://git.example.com/org/repo"

# Thêm Confluence page
python -m app.cli add-confluence "https://confluence.example.com/spaces/ICT/pages/123"

# Sync tất cả
python -m app.cli sync-all

# Sync một source
python -m app.cli sync-source gitlab:42

# Xem danh sách
python -m app.cli list-sources
python -m app.cli list-connectors
```

---

## 3. Requirements & Design (Module 2)

```bash
python -m app.cli rde-requirements "mô tả yêu cầu" --publish --space ICT
python -m app.cli rde-design requirements.md --publish --space ICT
python -m app.cli rde-check-compliance requirements.md --type requirements
python -m app.cli rde-impact requirements.md
```

---

## 4. Jira Integration (Module 1)

```bash
python -m app.cli jira-create "mô tả ý tưởng" --project-key PROJ
python -m app.cli jira-brief PROJ-123
python -m app.cli jira-sync --project-key PROJ
```

---

## 5. Quality Gate (Module 3)

```bash
git diff origin/main...HEAD > changes.diff
python -m app.cli qge-analyze changes.diff
python -m app.cli qge-generate-tests changes.diff
```

---

## 6. Jenkins (Module 4)

```bash
python -m app.cli jenkins-trigger <job-name> --param KEY=VALUE
python -m app.cli jenkins-status <job-name> <build-number>
python -m app.cli jenkins-log <job-name> <build-number>
python -m app.cli jenkins-deployments --service order-service --env uat
```

---

## 7. Code Generation (Module 5)

```bash
python -m app.cli cgp-decompose design.md --source-id gitlab:42
python -m app.cli cgp-commit-message changes.diff --desc "add feature"
python -m app.cli cgp-run-pipeline design.md --source-id gitlab:42 --branch feature/my-feature
```

---

## 8. K8s Deployment (Module 6)

```bash
# Sinh Helm values
python -m app.cli k8s-helm-values order-service --image registry/svc --tag 1.0.0 --port 8080

# Deploy flow: CI → UAT → PROD
python -m app.cli k8s-promote-ci order-service --build 42 --job deploy-ci
python -m app.cli k8s-promote-uat order-service --build 42 --job deploy-uat
python -m app.cli k8s-prod-gate order-service --build 42 --job deploy-prod

# Correlate incident
python -m app.cli k8s-correlate order-service --time "2024-01-15T10:30:00Z"
```

---

## 9. Observability (Module 7)

```bash
# Audit logs
python -m app.cli obs-audit-logs --limit 50
python -m app.cli obs-audit-logs --type qge_analyze --trace abc123

# Confidence scoring
python -m app.cli obs-score requirements_doc requirements.md

# HITL Approval
python -m app.cli obs-request-approval deploy_prod --desc "Deploy v1.0" --payload '{}'
python -m app.cli obs-list-approvals
python -m app.cli obs-approve <request_id> --by "manager" --comment "LGTM"
```

---

## 10. Reset

```bash
python -m app.cli reset-data
python -m app.cli bootstrap
python -m app.cli sync-all
```
