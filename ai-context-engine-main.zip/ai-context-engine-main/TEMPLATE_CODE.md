# TEMPLATE_CODE.md

## Mục tiêu

Template này dùng khi user muốn đi hết flow từ phân tích đến implement
code.

## Cách dùng

Trong chat, nhập:

```text
@TEMPLATE_CODE.md
<nội dung task>
```

Ví dụ:

```text
@TEMPLATE_CODE.md
[OMS] Cung cấp API tạo đơn hàng Service
```

## Yêu cầu bắt buộc

1. Tạo task dossier trong `data/tasks/...`.
2. Sinh brief, chọn repo phù hợp, đọc context Confluence và Git.
3. Cập nhật dossier với:
   - `plan`
   - `scope`
   - `impact`
   - `notes`
4. Trước khi code trên Git source:
   - bắt buộc sync repo thật về latest bằng `sync-source`
   - sau đó mới mở repo trong `data/workspaces/repos/...`
   - chỉ đọc và sửa file thật trong repo local
5. Implement theo hướng minimal, safe, đúng pattern hiện có.
6. Chạy build/test phù hợp sau khi sửa.
7. Cập nhật `result` vào dossier sau khi hoàn thành.

## Điều không được bỏ qua

- Không code từ vector chunk.
- Không đoán repo.
- Không sửa repo local khi chưa sync latest.
- Không bỏ qua dossier.
- Không mở rộng scope nếu chưa cập nhật lại plan.

## Output bắt buộc

1. Brief
2. Repo
3. File chính liên quan
4. Dossier
5. Plan
6. Implementation
7. Build/Test
8. Result

## Prompt chuẩn

```text
Thực hiện task dưới đây theo flow chuẩn của project: tạo task dossier, sinh brief, chọn repo phù hợp, đọc context Confluence và Git, cập nhật dossier với plan/scope/impact/notes, sync repo thật về latest trước khi code, đọc file thật trong data/workspaces/repos, implement minimal theo pattern hiện có, chạy build/test, cập nhật result vào dossier, rồi tóm tắt kết quả.
```
